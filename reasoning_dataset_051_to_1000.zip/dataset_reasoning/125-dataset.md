# Dataset Reasoning 125

Q: Fajar memiliki 14 kunci. Dia memberikan 5 kepada Andi. Kemudian membeli 5 kunci. Setelah itu memberikan 6 kepada Tono. Berapa kunci Fajar sekarang?
A: 8.
Q: Indra lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Indra lebih tinggi dari Maya.
Q: Budi lebih tinggi dari Dewi. Dewi lebih tinggi dari Nanda. Nanda lebih tinggi dari Lina. Lina lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Berapa hasil dari 11 dikali 3 ditambah 2?
A: 35.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Hadi lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Eka belajar selama dua minggu. Apakah Eka akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Udin lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
