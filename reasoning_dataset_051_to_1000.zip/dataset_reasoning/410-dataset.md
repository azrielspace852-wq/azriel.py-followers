# Dataset Reasoning 410

Q: Indra lebih cepat dari Lina. Fajar lebih cepat dari Indra. Siapa yang paling cepat antara Lina dan Fajar?
A: Tidak dapat dipastikan.
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Udin memiliki 10 kemeja. Dia memberikan 4 kepada Gita. Kemudian membeli 6 kemeja. Setelah itu memberikan 11 kepada Nanda. Berapa kemeja Udin sekarang?
A: 1.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Gita menyukai Putri. Putri menyukai Kartika. Apakah Gita menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Eka diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi belajar selama dua minggu. Apakah Dewi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Indra lebih cepat dari Rina. Rina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Maya menyukai Nanda. Nanda menyukai Tono. Apakah Maya menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
