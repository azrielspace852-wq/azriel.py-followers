# Dataset Reasoning 352

Q: Indra lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Indra lebih tinggi dari Maya.
Q: Andi lebih tua dari Candra. Candra lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Fajar lebih tinggi dari Indra. Indra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Sari memiliki 22 dompet. Dia memberikan 10 kepada Rina. Kemudian membeli 8 dompet. Setelah itu memberikan 9 kepada Putri. Berapa dompet Sari sekarang?
A: 11.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Berapa hasil dari 5 dikali 3 ditambah 12?
A: 27.
Q: Lina lebih tinggi dari Joko. Joko lebih tinggi dari Hadi. Hadi lebih tinggi dari Tono. Tono lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Budi lebih tinggi dari Andi. Andi lebih tinggi dari Kartika. Kartika lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
