# Dataset Reasoning 248

Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Tono lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Berapa hasil dari 2 dikali 6 ditambah 20?
A: 32.
Q: Gita lebih cepat dari Putri. Kartika lebih cepat dari Gita. Siapa yang paling cepat antara Putri dan Kartika?
A: Tidak dapat dipastikan.
Q: Hadi memiliki 25 tas. Dia memberikan 7 kepada Eka. Kemudian membeli 11 tas. Setelah itu memberikan 7 kepada Wati. Berapa tas Hadi sekarang?
A: 22.
Q: Indra lebih cepat dari Sari. Sari lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Gita lebih cepat dari Eka. Andi lebih cepat dari Gita. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Sari tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Sari tidak datang.
Q: Hadi menyukai Eka. Eka menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Maya menyukai Tono. Tono menyukai Andi. Apakah Maya menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa 11 ditambah 10 dikali 7?
A: 81.
Q: Nanda lebih cepat dari Udin. Gita lebih cepat dari Nanda. Siapa yang paling cepat antara Udin dan Gita?
A: Tidak dapat dipastikan.
Q: Wati menyukai Eka. Eka menyukai Hadi. Apakah Wati menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
