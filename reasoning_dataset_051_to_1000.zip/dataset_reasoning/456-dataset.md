# Dataset Reasoning 456

Q: Candra lebih tinggi dari Rina. Rina lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tono lebih tua dari Dewi. Dewi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Putri lebih tinggi dari Tono. Tono lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Berapa 2 ditambah 6 dikali 20?
A: 122.
Q: Joko diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Budi lebih tinggi dari Joko. Joko lebih tinggi dari Lina. Lina lebih tinggi dari Wati. Wati lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Fajar lebih tinggi dari Putri. Putri lebih tinggi dari Tono. Tono lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Lina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Nanda memiliki 10 celana. Dia memberikan 8 kepada Indra. Kemudian membeli 7 celana. Setelah itu memberikan 5 kepada Putri. Berapa celana Nanda sekarang?
A: 4.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
