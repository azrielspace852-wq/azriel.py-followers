# Dataset Reasoning 326

Q: Berapa 8 ditambah 9 dikali 8?
A: 80.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa hasil dari 7 dikali 8 ditambah 11?
A: 67.
Q: Nanda lebih cepat dari Fajar. Fajar lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra lebih tinggi dari Sari. Sari lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Jika 20 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 0.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Udin memiliki 10 kemeja. Dia memberikan 4 kepada Gita. Kemudian membeli 6 kemeja. Setelah itu memberikan 11 kepada Nanda. Berapa kemeja Udin sekarang?
A: 1.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Tono lebih tinggi dari Hadi. Hadi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Gita lebih cepat dari Sari. Rina lebih cepat dari Gita. Siapa yang paling cepat antara Sari dan Rina?
A: Tidak dapat dipastikan.
