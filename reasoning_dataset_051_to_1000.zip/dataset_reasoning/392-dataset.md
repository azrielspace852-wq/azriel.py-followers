# Dataset Reasoning 392

Q: Candra lebih tua dari Budi. Budi lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Gita lebih cepat dari Sari. Rina lebih cepat dari Gita. Siapa yang paling cepat antara Sari dan Rina?
A: Tidak dapat dipastikan.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Tono. Tono lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Putri yang paling tua.
Q: Nanda lebih tinggi dari Budi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Budi.
Q: Jika 39 dibagi 6, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 3.
Q: Nanda lebih tinggi dari Hadi. Hadi lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Putri lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Eka.
Q: Kartika menyukai Maya. Maya menyukai Indra. Apakah Kartika menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Rina lebih tua dari Tono. Tono lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Budi tidak datang.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
Q: Tono lebih tinggi dari Andi. Andi lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
