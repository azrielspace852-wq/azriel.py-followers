# Dataset Reasoning 150

Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Eka tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Eka tidak datang.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Putri menyukai Candra. Candra menyukai Joko. Apakah Putri menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar memiliki 18 tas. Dia memberikan 11 kepada Nanda. Kemudian membeli 12 tas. Setelah itu memberikan 4 kepada Rina. Berapa tas Fajar sekarang?
A: 15.
Q: Indra lebih tua dari Sari. Sari lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Putri memiliki 22 kunci. Dia memberikan 9 kepada Tono. Kemudian membeli 12 kunci. Setelah itu memberikan 1 kepada Fajar. Berapa kunci Putri sekarang?
A: 24.
Q: Kartika lebih cepat dari Tono. Putri lebih cepat dari Kartika. Siapa yang paling cepat antara Tono dan Putri?
A: Tidak dapat dipastikan.
Q: Sari memiliki 9 kemeja. Dia memberikan 7 kepada Putri. Kemudian membeli 4 kemeja. Setelah itu memberikan 4 kepada Indra. Berapa kemeja Sari sekarang?
A: 2.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Tono memiliki 8 kunci. Dia memberikan 3 kepada Fajar. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Tono sekarang?
A: 6.
