# Dataset Reasoning 404

Q: Wati menyukai Udin. Udin menyukai Joko. Apakah Wati menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Indra belajar selama dua minggu. Apakah Indra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 10 ditambah 7 dikali 4?
A: 38.
Q: Wati lebih tinggi dari Kartika. Kartika lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Hadi menyukai Joko. Joko menyukai Wati. Apakah Hadi menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar lebih tua dari Indra. Indra lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa 12 ditambah 12 dikali 19?
A: 240.
Q: Hadi lebih cepat dari Indra. Sari lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Sari?
A: Tidak dapat dipastikan.
Q: Eka belajar selama dua minggu. Apakah Eka akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
