# Dataset Reasoning 294

Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Sari memiliki 16 hp. Dia memberikan 12 kepada Joko. Kemudian membeli 11 hp. Setelah itu memberikan 13 kepada Dewi. Berapa hp Sari sekarang?
A: 2.
Q: Fajar memiliki 18 bola. Dia memberikan 4 kepada Gita. Kemudian membeli 10 bola. Setelah itu memberikan 23 kepada Rina. Berapa bola Fajar sekarang?
A: 1.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Hadi lebih tinggi dari Candra. Candra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Maya lebih tinggi dari Putri. Putri lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Hadi lebih tua dari Eka. Eka lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Indra belajar selama dua minggu. Apakah Indra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Joko lebih cepat dari Sari. Sari lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Gita tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Gita tidak datang.
