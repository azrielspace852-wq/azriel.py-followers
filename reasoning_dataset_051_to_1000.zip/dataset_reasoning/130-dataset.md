# Dataset Reasoning 130

Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Putri lebih tua dari Lina. Lina lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Putri menyukai Sari. Sari menyukai Tono. Apakah Putri menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Gita lebih cepat dari Putri. Kartika lebih cepat dari Gita. Siapa yang paling cepat antara Putri dan Kartika?
A: Tidak dapat dipastikan.
Q: Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Indra lebih cepat dari Sari. Sari lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Dewi lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Candra lebih tinggi dari Gita. Gita lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda lebih cepat dari Maya. Fajar lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
