# Dataset Reasoning 509

Q: Putri lebih cepat dari Eka. Eka lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Kartika lebih tua dari Eka. Eka lebih tua dari Putri. Putri lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Kartika yang paling tua.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Rina lebih cepat dari Hadi. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Hadi dan Indra?
A: Tidak dapat dipastikan.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Budi lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Tono.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Tono memiliki 22 pensil. Dia memberikan 2 kepada Joko. Kemudian membeli 5 pensil. Setelah itu memberikan 9 kepada Putri. Berapa pensil Tono sekarang?
A: 16.
Q: Eka memiliki 20 bola. Dia memberikan 8 kepada Putri. Kemudian membeli 9 bola. Setelah itu memberikan 19 kepada Indra. Berapa bola Eka sekarang?
A: 2.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
