# Dataset Reasoning 112

Q: Candra lebih tua dari Sari. Sari lebih tua dari Fajar. Fajar lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Candra yang paling tua.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Joko. Siapa yang paling lambat?
A: Joko.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Berapa 4 ditambah 4 dikali 20?
A: 84.
Q: Udin memiliki 23 buku. Dia memberikan 15 kepada Putri. Kemudian membeli 7 buku. Setelah itu memberikan 9 kepada Sari. Berapa buku Udin sekarang?
A: 6.
Q: Wati lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Eka.
Q: Wati lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Udin.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
