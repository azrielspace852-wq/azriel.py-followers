# Dataset Reasoning 121

Q: Rina lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Rina yang paling tua.
Q: Berapa hasil dari 2 dikali 11 ditambah 9?
A: 31.
Q: Fajar memiliki 15 apel. Dia memberikan 3 kepada Nanda. Kemudian membeli 10 apel. Setelah itu memberikan 3 kepada Putri. Berapa apel Fajar sekarang?
A: 19.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Tono lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Andi menyukai Maya. Maya menyukai Wati. Apakah Andi menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
