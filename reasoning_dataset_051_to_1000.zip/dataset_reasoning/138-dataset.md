# Dataset Reasoning 138

Q: Udin memiliki 9 kunci. Dia memberikan 2 kepada Putri. Kemudian membeli 6 kunci. Setelah itu memberikan 10 kepada Dewi. Berapa kunci Udin sekarang?
A: 3.
Q: Udin memiliki 10 kemeja. Dia memberikan 4 kepada Gita. Kemudian membeli 6 kemeja. Setelah itu memberikan 11 kepada Nanda. Berapa kemeja Udin sekarang?
A: 1.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Indra lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Rina memiliki 18 dompet. Dia memberikan 13 kepada Budi. Kemudian membeli 7 dompet. Setelah itu memberikan 11 kepada Wati. Berapa dompet Rina sekarang?
A: 1.
Q: Lina memiliki 18 kunci. Dia memberikan 6 kepada Kartika. Kemudian membeli 9 kunci. Setelah itu memberikan 7 kepada Indra. Berapa kunci Lina sekarang?
A: 14.
Q: Tono memiliki 12 kunci. Dia memberikan 5 kepada Eka. Kemudian membeli 2 kunci. Setelah itu memberikan 1 kepada Rina. Berapa kunci Tono sekarang?
A: 8.
Q: Kartika menyukai Tono. Tono menyukai Putri. Apakah Kartika menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Joko lebih tua dari Sari. Sari lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Kartika lebih tinggi dari Gita. Gita lebih tinggi dari Indra. Indra lebih tinggi dari Sari. Sari lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Tono lebih tua dari Hadi. Hadi lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Berapa 8 ditambah 3 dikali 10?
A: 38.
