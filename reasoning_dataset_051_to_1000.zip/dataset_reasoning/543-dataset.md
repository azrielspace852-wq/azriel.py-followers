# Dataset Reasoning 543

Q: Berapa hasil dari 7 dikali 8 ditambah 11?
A: 67.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Eka tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Eka tidak datang.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Nanda menyukai Budi. Budi menyukai Gita. Apakah Nanda menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Wati lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Sari.
Q: Joko lebih cepat dari Candra. Candra lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Maya memiliki 19 kunci. Dia memberikan 10 kepada Andi. Kemudian membeli 6 kunci. Setelah itu memberikan 1 kepada Udin. Berapa kunci Maya sekarang?
A: 14.
Q: Putri memiliki 9 jam. Dia memberikan 6 kepada Hadi. Kemudian membeli 7 jam. Setelah itu memberikan 4 kepada Lina. Berapa jam Putri sekarang?
A: 6.
Q: Fajar memiliki 21 pensil. Dia memberikan 19 kepada Fajar. Kemudian membeli 12 pensil. Setelah itu memberikan 13 kepada Candra. Berapa pensil Fajar sekarang?
A: 1.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
