# Dataset Reasoning 515

Q: Andi lebih cepat dari Lina. Joko lebih cepat dari Andi. Siapa yang paling cepat antara Lina dan Joko?
A: Tidak dapat dipastikan.
Q: Andi lebih tua dari Candra. Candra lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Sari tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Nanda lebih tua dari Dewi. Dewi lebih tua dari Hadi. Hadi lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Nanda yang paling tua.
Q: Tono lebih tua dari Andi. Andi lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Hadi memiliki 9 hp. Dia memberikan 5 kepada Lina. Kemudian membeli 9 hp. Setelah itu memberikan 5 kepada Hadi. Berapa hp Hadi sekarang?
A: 8.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Lina lebih tinggi dari Indra. Indra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Udin lebih tinggi dari Nanda. Nanda lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
