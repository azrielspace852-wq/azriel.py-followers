# Dataset Reasoning 342

Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Jika 37 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 2.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Gita lebih cepat dari Putri. Kartika lebih cepat dari Gita. Siapa yang paling cepat antara Putri dan Kartika?
A: Tidak dapat dipastikan.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 12 ditambah 12 dikali 19?
A: 240.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Wati lebih tua dari Budi. Budi lebih tua dari Kartika. Kartika lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Wati yang paling tua.
Q: Budi lebih tinggi dari Wati. Wati lebih tinggi dari Rina. Rina lebih tinggi dari Sari. Sari lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
