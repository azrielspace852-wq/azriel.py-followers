# Dataset Reasoning 510

Q: Nanda memiliki 24 tas. Dia memberikan 5 kepada Sari. Kemudian membeli 3 tas. Setelah itu memberikan 9 kepada Indra. Berapa tas Nanda sekarang?
A: 13.
Q: Jika 11 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 1, sisa 4.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Sari belajar selama dua minggu. Apakah Sari akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Berapa 11 ditambah 12 dikali 13?
A: 167.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati lebih tinggi dari Candra. Candra lebih tinggi dari Hadi. Hadi lebih tinggi dari Maya. Maya lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Kartika memiliki 22 dompet. Dia memberikan 18 kepada Tono. Kemudian membeli 9 dompet. Setelah itu memberikan 6 kepada Maya. Berapa dompet Kartika sekarang?
A: 7.
Q: Rina memiliki 25 jam. Dia memberikan 8 kepada Andi. Kemudian membeli 9 jam. Setelah itu memberikan 21 kepada Candra. Berapa jam Rina sekarang?
A: 5.
Q: Hadi menyukai Indra. Indra menyukai Kartika. Apakah Hadi menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
