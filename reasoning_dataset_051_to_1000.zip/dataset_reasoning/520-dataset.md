# Dataset Reasoning 520

Q: Andi lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Maya menyukai Nanda. Nanda menyukai Tono. Apakah Maya menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Nanda lebih cepat dari Hadi. Hadi lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Berapa 6 ditambah 7 dikali 19?
A: 139.
Q: Hadi lebih cepat dari Joko. Wati lebih cepat dari Hadi. Siapa yang paling cepat antara Joko dan Wati?
A: Tidak dapat dipastikan.
Q: Udin memiliki 23 buku. Dia memberikan 15 kepada Putri. Kemudian membeli 7 buku. Setelah itu memberikan 9 kepada Sari. Berapa buku Udin sekarang?
A: 6.
Q: Indra belajar selama dua minggu. Apakah Indra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Rina menyukai Hadi. Hadi menyukai Indra. Apakah Rina menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
