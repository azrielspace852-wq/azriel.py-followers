# Dataset Reasoning 102

Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Rina lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Hadi.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Tono memiliki 21 tas. Dia memberikan 6 kepada Sari. Kemudian membeli 5 tas. Setelah itu memberikan 5 kepada Sari. Berapa tas Tono sekarang?
A: 15.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
