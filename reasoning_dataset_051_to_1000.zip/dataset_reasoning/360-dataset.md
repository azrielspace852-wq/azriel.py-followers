# Dataset Reasoning 360

Q: Udin lebih tua dari Indra. Indra lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Joko lebih tua dari Maya. Maya lebih tua dari Nanda. Nanda lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
Q: Kartika lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Maya.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Berapa 6 ditambah 11 dikali 8?
A: 94.
Q: Tono lebih cepat dari Indra. Indra lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Joko. Siapa yang paling muda?
A: Joko.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi lebih tinggi dari Hadi. Hadi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Gita lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Eka.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Sari memiliki 16 hp. Dia memberikan 12 kepada Joko. Kemudian membeli 11 hp. Setelah itu memberikan 13 kepada Dewi. Berapa hp Sari sekarang?
A: 2.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
