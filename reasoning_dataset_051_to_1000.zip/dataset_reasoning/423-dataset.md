# Dataset Reasoning 423

Q: Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Rina lebih cepat dari Andi. Tono lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Tono?
A: Tidak dapat dipastikan.
Q: Berapa 7 ditambah 8 dikali 11?
A: 95.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Wati menyukai Candra. Candra menyukai Putri. Apakah Wati menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Lina lebih tinggi dari Indra. Indra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Tono lebih cepat dari Gita. Gita lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Kartika menyukai Tono. Tono menyukai Putri. Apakah Kartika menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
