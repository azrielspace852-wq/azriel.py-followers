# Dataset Reasoning 074

Q: Kartika lebih tua dari Eka. Eka lebih tua dari Putri. Putri lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Kartika yang paling tua.
Q: Nanda lebih tinggi dari Hadi. Hadi lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Berapa hasil dari 6 dikali 7 ditambah 19?
A: 61.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih tinggi dari Tono. Tono lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Gita lebih tinggi dari Rina. Rina lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Budi menyukai Hadi. Hadi menyukai Rina. Apakah Budi menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Fajar lebih cepat dari Nanda. Nanda lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Gita lebih tua dari Joko. Joko lebih tua dari Wati. Wati lebih tua dari Eka. Siapa yang paling muda dan siapa yang paling tua?
A: Eka yang paling muda, Gita yang paling tua.
