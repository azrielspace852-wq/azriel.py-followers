# Dataset Reasoning 284

Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa 11 ditambah 3 dikali 2?
A: 17.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Maya lebih tua dari Putri. Putri lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Joko. Joko lebih tua dari Indra. Siapa yang paling muda dan siapa yang paling tua?
A: Indra yang paling muda, Rina yang paling tua.
Q: Jika 11 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 1, sisa 4.
Q: Tono tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Kartika lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Tono.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Joko lebih tinggi dari Sari. Sari lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
