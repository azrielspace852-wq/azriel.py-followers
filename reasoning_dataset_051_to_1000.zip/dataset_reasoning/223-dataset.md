# Dataset Reasoning 223

Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Udin memiliki 23 buku. Dia memberikan 15 kepada Putri. Kemudian membeli 7 buku. Setelah itu memberikan 9 kepada Sari. Berapa buku Udin sekarang?
A: 6.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Tono tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Udin memiliki 8 kemeja. Dia memberikan 3 kepada Rina. Kemudian membeli 6 kemeja. Setelah itu memberikan 10 kepada Eka. Berapa kemeja Udin sekarang?
A: 1.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Andi lebih tua dari Rina. Rina lebih tua dari Nanda. Nanda lebih tua dari Fajar. Siapa yang paling muda dan siapa yang paling tua?
A: Fajar yang paling muda, Andi yang paling tua.
Q: Budi menyukai Lina. Lina menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
