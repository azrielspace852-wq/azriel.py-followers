# Dataset Reasoning 539

Q: Andi lebih tinggi dari Putri. Putri lebih tinggi dari Dewi. Dewi lebih tinggi dari Candra. Candra lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Dewi lebih tinggi dari Eka. Eka lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Hadi memiliki 8 hp. Dia memberikan 2 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 3 kepada Andi. Berapa hp Hadi sekarang?
A: 5.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Jika 34 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 2.
Q: Lina lebih cepat dari Wati. Wati lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Maya lebih cepat dari Eka. Gita lebih cepat dari Maya. Siapa yang paling cepat antara Eka dan Gita?
A: Tidak dapat dipastikan.
Q: Maya lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Candra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Tono lebih cepat dari Indra. Indra lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
