# Dataset Reasoning 279

Q: Joko lebih tua dari Candra. Candra lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Candra lebih tinggi dari Gita. Gita lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Fajar menyukai Sari. Sari menyukai Putri. Apakah Fajar menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Nanda memiliki 24 tas. Dia memberikan 5 kepada Sari. Kemudian membeli 3 tas. Setelah itu memberikan 9 kepada Indra. Berapa tas Nanda sekarang?
A: 13.
Q: Rina lebih tua dari Tono. Tono lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Lina lebih cepat dari Indra. Indra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Tono menyukai Hadi. Hadi menyukai Rina. Apakah Tono menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Kartika menyukai Tono. Tono menyukai Candra. Apakah Kartika menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
