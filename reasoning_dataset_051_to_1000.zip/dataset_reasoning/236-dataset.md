# Dataset Reasoning 236

Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Tono. Tono lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Putri yang paling tua.
Q: Maya memiliki 22 tas. Dia memberikan 19 kepada Andi. Kemudian membeli 11 tas. Setelah itu memberikan 11 kepada Rina. Berapa tas Maya sekarang?
A: 3.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Putri tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Udin lebih tua dari Indra. Indra lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Berapa hasil dari 6 dikali 7 ditambah 4?
A: 46.
Q: Rina lebih tua dari Candra. Candra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Hadi lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Hadi yang paling tua.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Putri lebih cepat dari Tono. Tono lebih cepat dari Dewi. Siapa yang paling lambat?
A: Dewi.
