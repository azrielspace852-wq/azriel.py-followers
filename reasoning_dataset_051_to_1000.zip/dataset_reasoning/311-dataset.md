# Dataset Reasoning 311

Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Kartika memiliki 22 dompet. Dia memberikan 18 kepada Tono. Kemudian membeli 9 dompet. Setelah itu memberikan 6 kepada Maya. Berapa dompet Kartika sekarang?
A: 7.
Q: Nanda memiliki 13 dompet. Dia memberikan 5 kepada Dewi. Kemudian membeli 2 dompet. Setelah itu memberikan 3 kepada Candra. Berapa dompet Nanda sekarang?
A: 7.
Q: Sari memiliki 11 sepatu. Dia memberikan 9 kepada Putri. Kemudian membeli 8 sepatu. Setelah itu memberikan 4 kepada Putri. Berapa sepatu Sari sekarang?
A: 6.
Q: Joko memiliki 17 hp. Dia memberikan 14 kepada Wati. Kemudian membeli 11 hp. Setelah itu memberikan 7 kepada Budi. Berapa hp Joko sekarang?
A: 7.
Q: Andi lebih tua dari Indra. Indra lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Indra lebih cepat dari Eka. Eka lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Maya lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Eka.
Q: Gita lebih tua dari Tono. Tono lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Budi lebih cepat dari Lina. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Lina dan Hadi?
A: Tidak dapat dipastikan.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Berapa hasil dari 10 dikali 7 ditambah 4?
A: 74.
