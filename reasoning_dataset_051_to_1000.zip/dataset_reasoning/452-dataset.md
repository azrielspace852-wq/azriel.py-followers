# Dataset Reasoning 452

Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Budi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Lina.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Gita lebih cepat dari Wati. Wati lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Rina memiliki 21 celana. Dia memberikan 2 kepada Maya. Kemudian membeli 7 celana. Setelah itu memberikan 24 kepada Maya. Berapa celana Rina sekarang?
A: 2.
Q: Lina lebih cepat dari Wati. Wati lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Indra lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Eka menyukai Rina. Rina menyukai Dewi. Apakah Eka menyukai Dewi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa 2 ditambah 11 dikali 9?
A: 101.
Q: Andi lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
