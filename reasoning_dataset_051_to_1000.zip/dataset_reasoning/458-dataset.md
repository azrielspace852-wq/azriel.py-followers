# Dataset Reasoning 458

Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Joko memiliki 17 hp. Dia memberikan 14 kepada Wati. Kemudian membeli 11 hp. Setelah itu memberikan 7 kepada Budi. Berapa hp Joko sekarang?
A: 7.
Q: Andi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kartika lebih cepat dari Tono. Putri lebih cepat dari Kartika. Siapa yang paling cepat antara Tono dan Putri?
A: Tidak dapat dipastikan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Hadi lebih cepat dari Eka. Eka lebih cepat dari Sari. Siapa yang paling lambat?
A: Sari.
Q: Joko memiliki 17 kemeja. Dia memberikan 4 kepada Udin. Kemudian membeli 8 kemeja. Setelah itu memberikan 8 kepada Lina. Berapa kemeja Joko sekarang?
A: 13.
Q: Jika 38 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 3.
Q: Lina lebih cepat dari Indra. Indra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
