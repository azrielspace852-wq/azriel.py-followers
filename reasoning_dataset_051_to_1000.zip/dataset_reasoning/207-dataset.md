# Dataset Reasoning 207

Q: Andi lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Andi lebih tinggi dari Maya.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Wati menyukai Dewi. Dewi menyukai Fajar. Apakah Wati menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Udin lebih tua dari Tono. Tono lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Maya lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Maya yang paling tua.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa hasil dari 6 dikali 9 ditambah 14?
A: 68.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
