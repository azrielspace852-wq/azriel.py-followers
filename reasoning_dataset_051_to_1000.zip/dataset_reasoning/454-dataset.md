# Dataset Reasoning 454

Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Joko lebih tinggi dari Gita. Gita lebih tinggi dari Budi. Budi lebih tinggi dari Tono. Tono lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Kartika lebih cepat dari Maya. Fajar lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Candra lebih tua dari Rina. Rina lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Joko lebih cepat dari Hadi. Hadi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Rina yang paling tua.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Sari lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Sari lebih tinggi dari Kartika.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra lebih cepat dari Budi. Andi lebih cepat dari Candra. Siapa yang paling cepat antara Budi dan Andi?
A: Tidak dapat dipastikan.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Berapa 8 ditambah 9 dikali 8?
A: 80.
