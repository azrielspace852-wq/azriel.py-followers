# Dataset Reasoning 059

Q: Putri lebih tinggi dari Eka. Eka lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Fajar menyukai Sari. Sari menyukai Putri. Apakah Fajar menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Indra lebih cepat dari Eka. Eka lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Andi lebih cepat dari Candra. Candra lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Budi lebih tua dari Wati. Wati lebih tua dari Lina. Lina lebih tua dari Joko. Siapa yang paling muda dan siapa yang paling tua?
A: Joko yang paling muda, Budi yang paling tua.
Q: Nanda menyukai Maya. Maya menyukai Fajar. Apakah Nanda menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih cepat dari Indra. Sari lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Sari?
A: Tidak dapat dipastikan.
Q: Dewi lebih tua dari Budi. Budi lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Berapa 6 ditambah 7 dikali 12?
A: 90.
Q: Udin belajar selama dua minggu. Apakah Udin akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda lebih cepat dari Udin. Kartika lebih cepat dari Nanda. Siapa yang paling cepat antara Udin dan Kartika?
A: Tidak dapat dipastikan.
