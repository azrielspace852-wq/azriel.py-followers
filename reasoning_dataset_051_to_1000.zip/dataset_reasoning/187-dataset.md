# Dataset Reasoning 187

Q: Candra lebih tua dari Kartika. Kartika lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Candra lebih tua dari Wati. Wati lebih tua dari Sari. Sari lebih tua dari Maya. Siapa yang paling muda dan siapa yang paling tua?
A: Maya yang paling muda, Candra yang paling tua.
Q: Eka lebih cepat dari Wati. Hadi lebih cepat dari Eka. Siapa yang paling cepat antara Wati dan Hadi?
A: Tidak dapat dipastikan.
Q: Wati lebih tua dari Rina. Rina lebih tua dari Sari. Sari lebih tua dari Eka. Siapa yang paling muda dan siapa yang paling tua?
A: Eka yang paling muda, Wati yang paling tua.
Q: Dewi lebih tua dari Sari. Sari lebih tua dari Udin. Udin lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Hadi lebih cepat dari Joko. Wati lebih cepat dari Hadi. Siapa yang paling cepat antara Joko dan Wati?
A: Tidak dapat dipastikan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Berapa 8 ditambah 7 dikali 15?
A: 113.
Q: Sari memiliki 22 dompet. Dia memberikan 10 kepada Rina. Kemudian membeli 8 dompet. Setelah itu memberikan 9 kepada Putri. Berapa dompet Sari sekarang?
A: 11.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Indra lebih tua dari Rina. Rina lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
