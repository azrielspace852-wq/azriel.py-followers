# Dataset Reasoning 237

Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Jika 22 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 1.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jika 26 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 13, sisa 0.
Q: Jika 48 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Rina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Rina tidak datang.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Fajar lebih tua dari Eka. Eka lebih tua dari Candra. Candra lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Fajar yang paling tua.
Q: Berapa 8 ditambah 7 dikali 14?
A: 106.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Kartika memiliki 12 hp. Dia memberikan 2 kepada Maya. Kemudian membeli 9 hp. Setelah itu memberikan 9 kepada Candra. Berapa hp Kartika sekarang?
A: 10.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
