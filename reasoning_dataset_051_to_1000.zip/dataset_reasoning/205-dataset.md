# Dataset Reasoning 205

Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Nanda memiliki 10 celana. Dia memberikan 8 kepada Indra. Kemudian membeli 7 celana. Setelah itu memberikan 5 kepada Putri. Berapa celana Nanda sekarang?
A: 4.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Joko memiliki 17 hp. Dia memberikan 14 kepada Wati. Kemudian membeli 11 hp. Setelah itu memberikan 7 kepada Budi. Berapa hp Joko sekarang?
A: 7.
Q: Candra memiliki 25 bola. Dia memberikan 1 kepada Dewi. Kemudian membeli 10 bola. Setelah itu memberikan 27 kepada Putri. Berapa bola Candra sekarang?
A: 7.
Q: Udin lebih tua dari Budi. Budi lebih tua dari Lina. Lina lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Udin yang paling tua.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Indra lebih tua dari Eka. Eka lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Hadi lebih tua dari Candra. Candra lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Candra memiliki 13 jam. Dia memberikan 10 kepada Lina. Kemudian membeli 8 jam. Setelah itu memberikan 8 kepada Nanda. Berapa jam Candra sekarang?
A: 3.
