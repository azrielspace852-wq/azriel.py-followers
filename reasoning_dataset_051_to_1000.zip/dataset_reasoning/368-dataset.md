# Dataset Reasoning 368

Q: Hadi memiliki 25 tas. Dia memberikan 7 kepada Eka. Kemudian membeli 11 tas. Setelah itu memberikan 7 kepada Wati. Berapa tas Hadi sekarang?
A: 22.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Nanda lebih cepat dari Indra. Candra lebih cepat dari Nanda. Siapa yang paling cepat antara Indra dan Candra?
A: Tidak dapat dipastikan.
Q: Maya memiliki 22 tas. Dia memberikan 19 kepada Andi. Kemudian membeli 11 tas. Setelah itu memberikan 11 kepada Rina. Berapa tas Maya sekarang?
A: 3.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Wati menyukai Sari. Sari menyukai Nanda. Apakah Wati menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Berapa 6 ditambah 7 dikali 19?
A: 139.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Joko. Joko lebih tua dari Indra. Siapa yang paling muda dan siapa yang paling tua?
A: Indra yang paling muda, Rina yang paling tua.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Tono lebih tua dari Gita. Gita lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Wati tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Indra lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
