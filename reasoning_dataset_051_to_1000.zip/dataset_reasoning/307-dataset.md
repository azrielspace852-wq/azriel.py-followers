# Dataset Reasoning 307

Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Nanda. Nanda lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Indra lebih tua dari Eka. Eka lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Joko memiliki 17 kemeja. Dia memberikan 4 kepada Udin. Kemudian membeli 8 kemeja. Setelah itu memberikan 8 kepada Lina. Berapa kemeja Joko sekarang?
A: 13.
Q: Eka belajar selama dua minggu. Apakah Eka akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 3 ditambah 8 dikali 4?
A: 35.
Q: Udin menyukai Maya. Maya menyukai Rina. Apakah Udin menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Maya menyukai Tono. Tono menyukai Andi. Apakah Maya menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Hadi lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Eka.
