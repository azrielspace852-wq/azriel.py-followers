# Dataset Reasoning 109

Q: Hadi lebih tinggi dari Eka. Eka lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Tono lebih cepat dari Andi. Andi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Lina lebih tua dari Wati. Wati lebih tua dari Eka. Eka lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Lina yang paling tua.
Q: Hadi lebih tinggi dari Candra. Candra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Gita menyukai Putri. Putri menyukai Kartika. Apakah Gita menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Budi lebih tinggi dari Wati. Wati lebih tinggi dari Rina. Rina lebih tinggi dari Sari. Sari lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Nanda lebih tinggi dari Candra. Candra lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
