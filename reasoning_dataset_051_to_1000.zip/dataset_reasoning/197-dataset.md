# Dataset Reasoning 197

Q: Fajar lebih cepat dari Indra. Indra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Tono diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Andi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa 4 ditambah 12 dikali 16?
A: 196.
Q: Jika 42 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 21, sisa 0.
Q: Maya lebih cepat dari Candra. Candra lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Berapa hasil dari 8 dikali 3 ditambah 10?
A: 34.
Q: Berapa hasil dari 8 dikali 7 ditambah 15?
A: 71.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Joko. Joko lebih tua dari Indra. Siapa yang paling muda dan siapa yang paling tua?
A: Indra yang paling muda, Rina yang paling tua.
Q: Dewi lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Indra lebih tinggi dari Wati. Wati lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Hadi lebih cepat dari Gita. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Gita dan Andi?
A: Tidak dapat dipastikan.
