# Dataset Reasoning 301

Q: Sari lebih tua dari Fajar. Fajar lebih tua dari Lina. Lina lebih tua dari Tono. Siapa yang paling muda dan siapa yang paling tua?
A: Tono yang paling muda, Sari yang paling tua.
Q: Berapa hasil dari 8 dikali 8 ditambah 4?
A: 68.
Q: Berapa 4 ditambah 12 dikali 16?
A: 196.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Wati menyukai Candra. Candra menyukai Putri. Apakah Wati menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Eka lebih cepat dari Hadi. Hadi lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Tono lebih tinggi dari Indra. Indra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Putri lebih tinggi dari Eka. Eka lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Kartika tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
