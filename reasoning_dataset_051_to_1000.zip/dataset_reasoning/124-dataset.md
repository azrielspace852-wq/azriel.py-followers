# Dataset Reasoning 124

Q: Andi lebih tua dari Indra. Indra lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Nanda lebih tinggi dari Tono. Tono lebih tinggi dari Rina. Rina lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Joko lebih tinggi dari Hadi. Hadi lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Candra memiliki 16 bola. Dia memberikan 9 kepada Nanda. Kemudian membeli 2 bola. Setelah itu memberikan 4 kepada Rina. Berapa bola Candra sekarang?
A: 5.
Q: Wati lebih cepat dari Candra. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Candra dan Putri?
A: Tidak dapat dipastikan.
Q: Hadi lebih tua dari Eka. Eka lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Berapa hasil dari 8 dikali 9 ditambah 8?
A: 80.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Berapa 8 ditambah 8 dikali 4?
A: 40.
