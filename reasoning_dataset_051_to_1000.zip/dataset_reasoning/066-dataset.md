# Dataset Reasoning 066

Q: Dewi memiliki 20 jam. Dia memberikan 1 kepada Lina. Kemudian membeli 6 jam. Setelah itu memberikan 18 kepada Indra. Berapa jam Dewi sekarang?
A: 7.
Q: Berapa 2 ditambah 11 dikali 9?
A: 101.
Q: Nanda lebih cepat dari Putri. Putri lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Sari memiliki 12 hp. Dia memberikan 8 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 2 kepada Dewi. Berapa hp Sari sekarang?
A: 4.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Berapa 3 ditambah 3 dikali 3?
A: 12.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Eka belajar selama dua minggu. Apakah Eka akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri menyukai Wati. Wati menyukai Udin. Apakah Putri menyukai Udin?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Udin belajar selama dua minggu. Apakah Udin akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
