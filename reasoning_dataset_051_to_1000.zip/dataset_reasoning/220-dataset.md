# Dataset Reasoning 220

Q: Jika 48 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 12, sisa 0.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Wati lebih cepat dari Udin. Joko lebih cepat dari Wati. Siapa yang paling cepat antara Udin dan Joko?
A: Tidak dapat dipastikan.
Q: Putri lebih cepat dari Eka. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Eka dan Tono?
A: Tidak dapat dipastikan.
Q: Sari lebih tua dari Tono. Tono lebih tua dari Lina. Lina lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Sari yang paling tua.
Q: Gita tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Andi lebih tinggi dari Candra. Candra lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Tono lebih cepat dari Dewi. Dewi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Jika 24 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Joko lebih tua dari Lina. Lina lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Budi lebih cepat dari Tono. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Tono dan Hadi?
A: Tidak dapat dipastikan.
