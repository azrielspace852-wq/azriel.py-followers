# Dataset Reasoning 160

Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Dewi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa 6 ditambah 7 dikali 4?
A: 34.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Joko. Joko lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Berapa 6 ditambah 9 dikali 14?
A: 132.
Q: Berapa hasil dari 8 dikali 7 ditambah 14?
A: 70.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Sari memiliki 11 sepatu. Dia memberikan 9 kepada Putri. Kemudian membeli 8 sepatu. Setelah itu memberikan 4 kepada Putri. Berapa sepatu Sari sekarang?
A: 6.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
