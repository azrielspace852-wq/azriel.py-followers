# Dataset Reasoning 180

Q: Hadi lebih tinggi dari Wati. Wati lebih tinggi dari Eka. Siapa yang paling pendek?
A: Eka.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Joko lebih tua dari Indra. Indra lebih tua dari Eka. Eka lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
Q: Dewi lebih tinggi dari Andi. Andi lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri menyukai Sari. Sari menyukai Tono. Apakah Putri menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Nanda lebih cepat dari Maya. Andi lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Andi?
A: Tidak dapat dipastikan.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Putri lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Udin lebih tinggi dari Tono. Tono lebih tinggi dari Eka. Eka lebih tinggi dari Nanda. Nanda lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
