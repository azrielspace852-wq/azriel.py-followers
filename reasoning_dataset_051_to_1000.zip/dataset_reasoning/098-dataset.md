# Dataset Reasoning 098

Q: Jika 19 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 1.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Gita lebih tinggi dari Tono. Tono lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Kartika lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Maya.
Q: Berapa hasil dari 12 dikali 6 ditambah 12?
A: 84.
Q: Gita lebih tinggi dari Dewi. Dewi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Rina lebih tinggi dari Andi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Andi.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi lebih tua dari Sari. Sari lebih tua dari Udin. Udin lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Maya lebih tinggi dari Putri. Putri lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Eka lebih tinggi dari Rina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Eka lebih tinggi dari Rina.
Q: Budi lebih cepat dari Hadi. Hadi lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
