# Dataset Reasoning 504

Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Kartika menyukai Maya. Maya menyukai Indra. Apakah Kartika menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Maya lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Maya yang paling tua.
Q: Budi menyukai Tono. Tono menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Sari memiliki 9 kemeja. Dia memberikan 7 kepada Putri. Kemudian membeli 4 kemeja. Setelah itu memberikan 4 kepada Indra. Berapa kemeja Sari sekarang?
A: 2.
Q: Maya memiliki 22 tas. Dia memberikan 19 kepada Andi. Kemudian membeli 11 tas. Setelah itu memberikan 11 kepada Rina. Berapa tas Maya sekarang?
A: 3.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Putri lebih tinggi dari Lina. Lina lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Indra lebih cepat dari Eka. Eka lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Gita lebih cepat dari Wati. Wati lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Wati lebih tinggi dari Eka. Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Fajar. Fajar lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Hadi menyukai Gita. Gita menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
