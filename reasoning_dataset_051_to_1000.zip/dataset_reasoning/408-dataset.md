# Dataset Reasoning 408

Q: Rina lebih cepat dari Putri. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Putri dan Indra?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 9 dikali 11 ditambah 15?
A: 114.
Q: Rina memiliki 16 kunci. Dia memberikan 14 kepada Kartika. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Rina sekarang?
A: 3.
Q: Hadi lebih cepat dari Gita. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Gita dan Andi?
A: Tidak dapat dipastikan.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Indra lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Indra lebih tinggi dari Maya.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Andi lebih cepat dari Candra. Candra lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
