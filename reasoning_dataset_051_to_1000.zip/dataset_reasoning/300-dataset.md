# Dataset Reasoning 300

Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Berapa 6 ditambah 7 dikali 12?
A: 90.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Eka memiliki 11 kunci. Dia memberikan 9 kepada Eka. Kemudian membeli 5 kunci. Setelah itu memberikan 6 kepada Candra. Berapa kunci Eka sekarang?
A: 1.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Candra lebih tinggi dari Nanda. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Candra lebih tinggi dari Nanda.
Q: Maya lebih cepat dari Tono. Andi lebih cepat dari Maya. Siapa yang paling cepat antara Tono dan Andi?
A: Tidak dapat dipastikan.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
