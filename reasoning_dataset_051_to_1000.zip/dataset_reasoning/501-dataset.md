# Dataset Reasoning 501

Q: Sari lebih tinggi dari Indra. Indra lebih tinggi dari Eka. Eka lebih tinggi dari Lina. Lina lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Berapa hasil dari 10 dikali 7 ditambah 4?
A: 74.
Q: Candra lebih tinggi dari Sari. Sari lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Tono lebih tinggi dari Hadi. Hadi lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi memiliki 9 jam. Dia memberikan 4 kepada Putri. Kemudian membeli 8 jam. Setelah itu memberikan 7 kepada Candra. Berapa jam Dewi sekarang?
A: 6.
Q: Putri lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
