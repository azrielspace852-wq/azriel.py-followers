# Dataset Reasoning 528

Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Candra lebih tinggi dari Gita. Gita lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Berapa 7 ditambah 8 dikali 11?
A: 95.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Eka memiliki 11 kunci. Dia memberikan 9 kepada Eka. Kemudian membeli 5 kunci. Setelah itu memberikan 6 kepada Candra. Berapa kunci Eka sekarang?
A: 1.
Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Fajar lebih tua dari Indra. Indra lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Indra lebih cepat dari Rina. Rina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Berapa hasil dari 6 dikali 11 ditambah 8?
A: 74.
