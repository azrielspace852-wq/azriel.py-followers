# Dataset Reasoning 075

Q: Jika 48 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Candra lebih cepat dari Nanda. Udin lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Udin?
A: Tidak dapat dipastikan.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Hadi memiliki 10 celana. Dia memberikan 4 kepada Candra. Kemudian membeli 12 celana. Setelah itu memberikan 10 kepada Nanda. Berapa celana Hadi sekarang?
A: 8.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
