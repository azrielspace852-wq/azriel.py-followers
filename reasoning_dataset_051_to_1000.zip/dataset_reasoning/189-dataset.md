# Dataset Reasoning 189

Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Wati lebih tinggi dari Eka. Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Fajar. Fajar lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Dewi lebih cepat dari Tono. Tono lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Udin lebih tua dari Nanda. Nanda lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Budi lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Hadi.
Q: Nanda lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Udin.
Q: Dewi lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Udin. Udin lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Berapa 3 ditambah 3 dikali 3?
A: 12.
Q: Joko lebih tua dari Candra. Candra lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Eka lebih tua dari Maya. Maya lebih tua dari Tono. Tono lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Eka yang paling tua.
Q: Eka belajar selama dua minggu. Apakah Eka akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
