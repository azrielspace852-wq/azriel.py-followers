# Dataset Reasoning 141

Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Berapa 6 ditambah 7 dikali 19?
A: 139.
Q: Tono lebih tua dari Eka. Eka lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Berapa 2 ditambah 4 dikali 5?
A: 22.
Q: Gita lebih cepat dari Tono. Tono lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Kartika lebih cepat dari Maya. Indra lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Indra?
A: Tidak dapat dipastikan.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Dewi memiliki 13 buku. Dia memberikan 1 kepada Maya. Kemudian membeli 6 buku. Setelah itu memberikan 16 kepada Rina. Berapa buku Dewi sekarang?
A: 2.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Sari lebih cepat dari Kartika. Candra lebih cepat dari Sari. Siapa yang paling cepat antara Kartika dan Candra?
A: Tidak dapat dipastikan.
Q: Fajar diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda memiliki 10 celana. Dia memberikan 8 kepada Indra. Kemudian membeli 7 celana. Setelah itu memberikan 5 kepada Putri. Berapa celana Nanda sekarang?
A: 4.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
