# Dataset Reasoning 393

Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Tono memiliki 23 pensil. Dia memberikan 16 kepada Maya. Kemudian membeli 5 pensil. Setelah itu memberikan 8 kepada Gita. Berapa pensil Tono sekarang?
A: 4.
Q: Hadi menyukai Eka. Eka menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Eka lebih tinggi dari Rina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Eka lebih tinggi dari Rina.
Q: Dewi lebih cepat dari Putri. Eka lebih cepat dari Dewi. Siapa yang paling cepat antara Putri dan Eka?
A: Tidak dapat dipastikan.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Rina memiliki 12 hp. Dia memberikan 7 kepada Nanda. Kemudian membeli 12 hp. Setelah itu memberikan 4 kepada Indra. Berapa hp Rina sekarang?
A: 13.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Putri lebih cepat dari Eka. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Eka dan Tono?
A: Tidak dapat dipastikan.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Berapa hasil dari 2 dikali 4 ditambah 9?
A: 17.
Q: Rina lebih cepat dari Hadi. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Hadi dan Indra?
A: Tidak dapat dipastikan.
