# Dataset Reasoning 341

Q: Wati lebih cepat dari Sari. Nanda lebih cepat dari Wati. Siapa yang paling cepat antara Sari dan Nanda?
A: Tidak dapat dipastikan.
Q: Udin lebih tua dari Nanda. Nanda lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Jika 19 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 3.
Q: Fajar lebih tua dari Nanda. Nanda lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Andi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Gita lebih cepat dari Dewi. Dewi lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Hadi lebih tinggi dari Joko. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Joko.
Q: Wati memiliki 10 kunci. Dia memberikan 1 kepada Andi. Kemudian membeli 8 kunci. Setelah itu memberikan 11 kepada Candra. Berapa kunci Wati sekarang?
A: 6.
