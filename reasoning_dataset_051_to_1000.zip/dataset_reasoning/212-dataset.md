# Dataset Reasoning 212

Q: Lina memiliki 11 apel. Dia memberikan 6 kepada Maya. Kemudian membeli 10 apel. Setelah itu memberikan 11 kepada Indra. Berapa apel Lina sekarang?
A: 4.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Andi menyukai Lina. Lina menyukai Joko. Apakah Andi menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Candra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Hadi lebih tua dari Rina. Rina lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Maya lebih cepat dari Nanda. Tono lebih cepat dari Maya. Siapa yang paling cepat antara Nanda dan Tono?
A: Tidak dapat dipastikan.
Q: Tono memiliki 17 apel. Dia memberikan 11 kepada Putri. Kemudian membeli 8 apel. Setelah itu memberikan 13 kepada Candra. Berapa apel Tono sekarang?
A: 1.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Fajar lebih tinggi dari Nanda. Nanda lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
