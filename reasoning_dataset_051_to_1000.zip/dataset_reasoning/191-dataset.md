# Dataset Reasoning 191

Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Maya lebih cepat dari Dewi. Dewi lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Hadi lebih tinggi dari Gita. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Gita.
Q: Tono lebih tua dari Andi. Andi lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Fajar diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tono memiliki 8 kunci. Dia memberikan 3 kepada Fajar. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Tono sekarang?
A: 6.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Andi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Nanda memiliki 24 tas. Dia memberikan 5 kepada Sari. Kemudian membeli 3 tas. Setelah itu memberikan 9 kepada Indra. Berapa tas Nanda sekarang?
A: 13.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
