# Dataset Reasoning 357

Q: Rina lebih cepat dari Candra. Candra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Putri lebih cepat dari Sari. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Sari dan Tono?
A: Tidak dapat dipastikan.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Putri lebih cepat dari Wati. Udin lebih cepat dari Putri. Siapa yang paling cepat antara Wati dan Udin?
A: Tidak dapat dipastikan.
Q: Putri lebih cepat dari Fajar. Budi lebih cepat dari Putri. Siapa yang paling cepat antara Fajar dan Budi?
A: Tidak dapat dipastikan.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Indra memiliki 11 kemeja. Dia memberikan 4 kepada Candra. Kemudian membeli 12 kemeja. Setelah itu memberikan 7 kepada Fajar. Berapa kemeja Indra sekarang?
A: 12.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Wati tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Wati tidak datang.
