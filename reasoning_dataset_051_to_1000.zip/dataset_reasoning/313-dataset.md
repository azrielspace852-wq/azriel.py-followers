# Dataset Reasoning 313

Q: Fajar memiliki 15 apel. Dia memberikan 3 kepada Nanda. Kemudian membeli 10 apel. Setelah itu memberikan 3 kepada Putri. Berapa apel Fajar sekarang?
A: 19.
Q: Kartika tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa 8 ditambah 3 dikali 10?
A: 38.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Kartika lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Fajar lebih tua dari Eka. Eka lebih tua dari Candra. Candra lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Fajar yang paling tua.
Q: Berapa 11 ditambah 12 dikali 18?
A: 227.
Q: Wati lebih cepat dari Udin. Joko lebih cepat dari Wati. Siapa yang paling cepat antara Udin dan Joko?
A: Tidak dapat dipastikan.
Q: Gita lebih cepat dari Tono. Tono lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Maya lebih cepat dari Nanda. Tono lebih cepat dari Maya. Siapa yang paling cepat antara Nanda dan Tono?
A: Tidak dapat dipastikan.
