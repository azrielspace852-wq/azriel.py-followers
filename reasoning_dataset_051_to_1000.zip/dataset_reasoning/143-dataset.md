# Dataset Reasoning 143

Q: Sari memiliki 15 kunci. Dia memberikan 10 kepada Putri. Kemudian membeli 2 kunci. Setelah itu memberikan 6 kepada Andi. Berapa kunci Sari sekarang?
A: 1.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra lebih cepat dari Gita. Gita lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Andi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Tono lebih tinggi dari Hadi. Hadi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Andi lebih tinggi dari Indra. Indra lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Putri lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Wati.
