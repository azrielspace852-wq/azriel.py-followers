# Dataset Reasoning 347

Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tono menyukai Putri. Putri menyukai Fajar. Apakah Tono menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih tinggi dari Wati. Wati lebih tinggi dari Eka. Siapa yang paling pendek?
A: Eka.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Candra lebih cepat dari Nanda. Eka lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Eka?
A: Tidak dapat dipastikan.
Q: Berapa 3 ditambah 3 dikali 3?
A: 12.
Q: Lina lebih cepat dari Wati. Wati lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Budi lebih tinggi dari Rina. Rina lebih tinggi dari Hadi. Hadi lebih tinggi dari Gita. Gita lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Joko memiliki 11 apel. Dia memberikan 2 kepada Budi. Kemudian membeli 9 apel. Setelah itu memberikan 6 kepada Kartika. Berapa apel Joko sekarang?
A: 12.
