# Dataset Reasoning 383

Q: Udin lebih tinggi dari Nanda. Nanda lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Kartika lebih tinggi dari Gita. Gita lebih tinggi dari Indra. Indra lebih tinggi dari Sari. Sari lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Tono lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Udin lebih cepat dari Nanda. Nanda lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Berapa hasil dari 3 dikali 8 ditambah 4?
A: 28.
Q: Jika 46 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
Q: Maya lebih tua dari Putri. Putri lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Dewi lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Indra lebih tinggi dari Wati. Wati lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Candra lebih cepat dari Kartika. Kartika lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Putri lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Budi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
