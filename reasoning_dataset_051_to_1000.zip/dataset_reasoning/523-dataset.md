# Dataset Reasoning 523

Q: Putri lebih tinggi dari Fajar. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Fajar.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Berapa 3 ditambah 3 dikali 3?
A: 12.
Q: Berapa hasil dari 6 dikali 7 ditambah 12?
A: 54.
Q: Kartika menyukai Tono. Tono menyukai Putri. Apakah Kartika menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Fajar lebih tinggi dari Nanda. Nanda lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Dewi lebih tinggi dari Andi. Andi lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Budi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
