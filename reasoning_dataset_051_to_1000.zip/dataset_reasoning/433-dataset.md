# Dataset Reasoning 433

Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Sari lebih cepat dari Kartika. Candra lebih cepat dari Sari. Siapa yang paling cepat antara Kartika dan Candra?
A: Tidak dapat dipastikan.
Q: Rina memiliki 18 dompet. Dia memberikan 13 kepada Budi. Kemudian membeli 7 dompet. Setelah itu memberikan 11 kepada Wati. Berapa dompet Rina sekarang?
A: 1.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Candra lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Wati memiliki 25 dompet. Dia memberikan 23 kepada Joko. Kemudian membeli 7 dompet. Setelah itu memberikan 7 kepada Putri. Berapa dompet Wati sekarang?
A: 2.
Q: Dewi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Nanda menyukai Udin. Udin menyukai Kartika. Apakah Nanda menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Tono.
Q: Sari memiliki 12 hp. Dia memberikan 8 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 2 kepada Dewi. Berapa hp Sari sekarang?
A: 4.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
