# Dataset Reasoning 483

Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Kartika lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Candra menyukai Nanda. Nanda menyukai Eka. Apakah Candra menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Andi lebih tinggi dari Indra. Indra lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Andi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Andi lebih tinggi dari Lina.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Hadi lebih tua dari Wati. Wati lebih tua dari Eka. Siapa yang paling muda?
A: Eka.
Q: Eka lebih tinggi dari Rina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Eka lebih tinggi dari Rina.
Q: Gita lebih tinggi dari Rina. Rina lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Nanda lebih cepat dari Budi. Gita lebih cepat dari Nanda. Siapa yang paling cepat antara Budi dan Gita?
A: Tidak dapat dipastikan.
Q: Udin memiliki 10 kemeja. Dia memberikan 4 kepada Gita. Kemudian membeli 6 kemeja. Setelah itu memberikan 11 kepada Nanda. Berapa kemeja Udin sekarang?
A: 1.
Q: Kartika lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Nanda lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Maya.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
