# Dataset Reasoning 370

Q: Eka lebih cepat dari Hadi. Hadi lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Gita lebih tua dari Dewi. Dewi lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Jika 21 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
