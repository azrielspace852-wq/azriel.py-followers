# Dataset Reasoning 362

Q: Andi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Candra lebih tinggi dari Nanda. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Candra lebih tinggi dari Nanda.
Q: Nanda lebih tinggi dari Fajar. Fajar lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Berapa 8 ditambah 7 dikali 15?
A: 113.
Q: Joko lebih tinggi dari Lina. Lina lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Berapa hasil dari 8 dikali 3 ditambah 10?
A: 34.
Q: Tono lebih tinggi dari Dewi. Dewi lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Nanda memiliki 9 pensil. Dia memberikan 3 kepada Hadi. Kemudian membeli 7 pensil. Setelah itu memberikan 6 kepada Sari. Berapa pensil Nanda sekarang?
A: 7.
Q: Hadi menyukai Gita. Gita menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
