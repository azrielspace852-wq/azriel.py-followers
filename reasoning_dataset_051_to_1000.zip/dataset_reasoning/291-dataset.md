# Dataset Reasoning 291

Q: Sari memiliki 11 celana. Dia memberikan 3 kepada Indra. Kemudian membeli 9 celana. Setelah itu memberikan 10 kepada Nanda. Berapa celana Sari sekarang?
A: 7.
Q: Gita lebih tinggi dari Maya. Maya lebih tinggi dari Kartika. Kartika lebih tinggi dari Indra. Indra lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Berapa hasil dari 11 dikali 12 ditambah 18?
A: 150.
Q: Berapa 2 ditambah 11 dikali 18?
A: 200.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Berapa hasil dari 8 dikali 8 ditambah 15?
A: 79.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
