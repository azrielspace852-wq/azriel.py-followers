# Dataset Reasoning 063

Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Berapa 12 ditambah 6 dikali 12?
A: 84.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Joko. Joko lebih tua dari Indra. Siapa yang paling muda dan siapa yang paling tua?
A: Indra yang paling muda, Rina yang paling tua.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Hadi lebih cepat dari Udin. Udin lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Maya diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi memiliki 14 kemeja. Dia memberikan 10 kepada Budi. Kemudian membeli 6 kemeja. Setelah itu memberikan 3 kepada Joko. Berapa kemeja Dewi sekarang?
A: 7.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
