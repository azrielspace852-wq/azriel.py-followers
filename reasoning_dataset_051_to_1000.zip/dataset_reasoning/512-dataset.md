# Dataset Reasoning 512

Q: Rina memiliki 12 hp. Dia memberikan 7 kepada Nanda. Kemudian membeli 12 hp. Setelah itu memberikan 4 kepada Indra. Berapa hp Rina sekarang?
A: 13.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Rina memiliki 21 celana. Dia memberikan 2 kepada Maya. Kemudian membeli 7 celana. Setelah itu memberikan 24 kepada Maya. Berapa celana Rina sekarang?
A: 2.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Jika 41 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 1.
Q: Dewi lebih tua dari Sari. Sari lebih tua dari Udin. Udin lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Tono lebih cepat dari Andi. Andi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Dewi lebih cepat dari Eka. Eka lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Hadi lebih tua dari Udin. Udin lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Sari memiliki 11 sepatu. Dia memberikan 9 kepada Putri. Kemudian membeli 8 sepatu. Setelah itu memberikan 4 kepada Putri. Berapa sepatu Sari sekarang?
A: 6.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
