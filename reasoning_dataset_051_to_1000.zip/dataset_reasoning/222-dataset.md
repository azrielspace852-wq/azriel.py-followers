# Dataset Reasoning 222

Q: Dewi memiliki 17 bola. Dia memberikan 4 kepada Maya. Kemudian membeli 8 bola. Setelah itu memberikan 16 kepada Udin. Berapa bola Dewi sekarang?
A: 5.
Q: Hadi lebih cepat dari Indra. Kartika lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Kartika?
A: Tidak dapat dipastikan.
Q: Jika 20 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 0.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Lina memiliki 18 kunci. Dia memberikan 6 kepada Kartika. Kemudian membeli 9 kunci. Setelah itu memberikan 7 kepada Indra. Berapa kunci Lina sekarang?
A: 14.
Q: Berapa 7 ditambah 8 dikali 11?
A: 95.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Wati lebih tinggi dari Candra. Candra lebih tinggi dari Hadi. Hadi lebih tinggi dari Maya. Maya lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Indra belajar selama dua minggu. Apakah Indra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Hadi lebih tinggi dari Udin. Udin lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
