# Dataset Reasoning 106

Q: Rina memiliki 21 celana. Dia memberikan 2 kepada Maya. Kemudian membeli 7 celana. Setelah itu memberikan 24 kepada Maya. Berapa celana Rina sekarang?
A: 2.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Candra memiliki 13 jam. Dia memberikan 10 kepada Lina. Kemudian membeli 8 jam. Setelah itu memberikan 8 kepada Nanda. Berapa jam Candra sekarang?
A: 3.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Maya lebih cepat dari Rina. Wati lebih cepat dari Maya. Siapa yang paling cepat antara Rina dan Wati?
A: Tidak dapat dipastikan.
Q: Maya lebih cepat dari Dewi. Dewi lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Dewi menyukai Putri. Putri menyukai Eka. Apakah Dewi menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Udin lebih tua dari Budi. Budi lebih tua dari Lina. Lina lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Udin yang paling tua.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Indra memiliki 11 kemeja. Dia memberikan 4 kepada Candra. Kemudian membeli 12 kemeja. Setelah itu memberikan 7 kepada Fajar. Berapa kemeja Indra sekarang?
A: 12.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
