# Dataset Reasoning 199

Q: Nanda lebih cepat dari Maya. Fajar lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Candra lebih cepat dari Kartika. Kartika lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Berapa 6 ditambah 11 dikali 8?
A: 94.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Candra lebih cepat dari Rina. Rina lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Maya lebih cepat dari Rina. Wati lebih cepat dari Maya. Siapa yang paling cepat antara Rina dan Wati?
A: Tidak dapat dipastikan.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Indra memiliki 19 bola. Dia memberikan 15 kepada Dewi. Kemudian membeli 6 bola. Setelah itu memberikan 5 kepada Gita. Berapa bola Indra sekarang?
A: 5.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Hadi lebih tua dari Eka. Eka lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
