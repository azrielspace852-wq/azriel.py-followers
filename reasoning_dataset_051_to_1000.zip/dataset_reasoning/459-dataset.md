# Dataset Reasoning 459

Q: Rina lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Rina yang paling tua.
Q: Wati diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Eka memiliki 9 hp. Dia memberikan 7 kepada Gita. Kemudian membeli 7 hp. Setelah itu memberikan 4 kepada Candra. Berapa hp Eka sekarang?
A: 5.
Q: Andi menyukai Maya. Maya menyukai Wati. Apakah Andi menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Maya lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Hadi lebih tinggi dari Candra. Candra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Lina memiliki 11 apel. Dia memberikan 6 kepada Maya. Kemudian membeli 10 apel. Setelah itu memberikan 11 kepada Indra. Berapa apel Lina sekarang?
A: 4.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Fajar lebih tua dari Eka. Eka lebih tua dari Candra. Candra lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Fajar yang paling tua.
