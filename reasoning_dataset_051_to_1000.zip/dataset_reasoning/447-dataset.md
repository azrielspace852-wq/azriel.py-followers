# Dataset Reasoning 447

Q: Gita lebih cepat dari Eka. Andi lebih cepat dari Gita. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Joko lebih tua dari Lina. Lina lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Nanda lebih cepat dari Maya. Andi lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Andi?
A: Tidak dapat dipastikan.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Andi lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Indra lebih tinggi dari Putri. Putri lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Rina lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Putri.
Q: Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Fajar. Fajar lebih tinggi dari Kartika. Kartika lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Maya menyukai Tono. Tono menyukai Andi. Apakah Maya menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Candra lebih cepat dari Nanda. Udin lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Udin?
A: Tidak dapat dipastikan.
Q: Fajar lebih tua dari Sari. Sari lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
