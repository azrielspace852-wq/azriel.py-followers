# Dataset Reasoning 151

Q: Dewi lebih cepat dari Eka. Eka lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Berapa 11 ditambah 10 dikali 7?
A: 81.
Q: Joko lebih tinggi dari Candra. Candra lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Rina lebih cepat dari Hadi. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Hadi dan Indra?
A: Tidak dapat dipastikan.
Q: Udin lebih cepat dari Hadi. Hadi lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Berapa 10 ditambah 3 dikali 12?
A: 46.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Budi lebih cepat dari Lina. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Lina dan Hadi?
A: Tidak dapat dipastikan.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Joko lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
