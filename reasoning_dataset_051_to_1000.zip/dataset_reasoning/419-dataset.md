# Dataset Reasoning 419

Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Nanda lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Wati lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Sari.
Q: Gita lebih cepat dari Dewi. Dewi lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Tono memiliki 22 pensil. Dia memberikan 2 kepada Joko. Kemudian membeli 5 pensil. Setelah itu memberikan 9 kepada Putri. Berapa pensil Tono sekarang?
A: 16.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Berapa hasil dari 6 dikali 7 ditambah 12?
A: 54.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
