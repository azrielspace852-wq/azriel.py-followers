# Dataset Reasoning 334

Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Indra lebih tinggi dari Joko. Joko lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Eka lebih tinggi dari Lina. Lina lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Gita lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Eka.
Q: Fajar lebih cepat dari Sari. Putri lebih cepat dari Fajar. Siapa yang paling cepat antara Sari dan Putri?
A: Tidak dapat dipastikan.
Q: Berapa 8 ditambah 7 dikali 15?
A: 113.
Q: Udin lebih tinggi dari Tono. Tono lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Berapa hasil dari 10 dikali 7 ditambah 4?
A: 74.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
