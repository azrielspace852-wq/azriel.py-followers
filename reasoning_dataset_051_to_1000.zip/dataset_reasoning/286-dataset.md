# Dataset Reasoning 286

Q: Eka lebih cepat dari Wati. Hadi lebih cepat dari Eka. Siapa yang paling cepat antara Wati dan Hadi?
A: Tidak dapat dipastikan.
Q: Maya lebih cepat dari Dewi. Dewi lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Dewi lebih cepat dari Tono. Tono lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Rina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Rina tidak datang.
Q: Tono lebih cepat dari Dewi. Dewi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Lina lebih tua dari Wati. Wati lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Berapa hasil dari 10 dikali 3 ditambah 12?
A: 42.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Candra memiliki 10 pensil. Dia memberikan 6 kepada Indra. Kemudian membeli 11 pensil. Setelah itu memberikan 3 kepada Wati. Berapa pensil Candra sekarang?
A: 12.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
