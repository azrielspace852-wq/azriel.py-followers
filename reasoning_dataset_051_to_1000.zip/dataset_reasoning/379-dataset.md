# Dataset Reasoning 379

Q: Hadi lebih tua dari Wati. Wati lebih tua dari Eka. Siapa yang paling muda?
A: Eka.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Hadi lebih tinggi dari Rina. Rina lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Dewi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Nanda lebih tua dari Candra. Candra lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Maya menyukai Eka. Eka menyukai Gita. Apakah Maya menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tono lebih tinggi dari Gita. Gita lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Jika 19 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 1.
Q: Berapa hasil dari 12 dikali 6 ditambah 12?
A: 84.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Indra lebih cepat dari Candra. Candra lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
