# Dataset Reasoning 348

Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Joko lebih tua dari Sari. Sari lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Putri memiliki 15 tas. Dia memberikan 9 kepada Tono. Kemudian membeli 4 tas. Setelah itu memberikan 7 kepada Nanda. Berapa tas Putri sekarang?
A: 3.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Gita lebih tua dari Rina. Rina lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Wati memiliki 25 dompet. Dia memberikan 23 kepada Joko. Kemudian membeli 7 dompet. Setelah itu memberikan 7 kepada Putri. Berapa dompet Wati sekarang?
A: 2.
