# Dataset Reasoning 351

Q: Wati menyukai Sari. Sari menyukai Nanda. Apakah Wati menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Putri lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Indra lebih cepat dari Rina. Rina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Berapa 10 ditambah 7 dikali 4?
A: 38.
Q: Putri tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Sari lebih tinggi dari Indra. Indra lebih tinggi dari Eka. Eka lebih tinggi dari Lina. Lina lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Kartika lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Indra lebih tinggi dari Lina. Lina lebih tinggi dari Sari. Sari lebih tinggi dari Maya. Maya lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
