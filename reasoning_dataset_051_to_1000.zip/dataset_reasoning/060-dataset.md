# Dataset Reasoning 060

Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Joko lebih tua dari Indra. Indra lebih tua dari Eka. Eka lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
Q: Maya memiliki 18 dompet. Dia memberikan 9 kepada Andi. Kemudian membeli 7 dompet. Setelah itu memberikan 2 kepada Tono. Berapa dompet Maya sekarang?
A: 14.
Q: Hadi lebih cepat dari Rina. Rina lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Lina memiliki 11 apel. Dia memberikan 6 kepada Maya. Kemudian membeli 10 apel. Setelah itu memberikan 11 kepada Indra. Berapa apel Lina sekarang?
A: 4.
Q: Jika 44 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 4.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Tono lebih tinggi dari Gita. Gita lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Sari lebih tua dari Tono. Tono lebih tua dari Lina. Lina lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Sari yang paling tua.
Q: Berapa 11 ditambah 12 dikali 13?
A: 167.
Q: Jika 49 dibagi 6, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 1.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
