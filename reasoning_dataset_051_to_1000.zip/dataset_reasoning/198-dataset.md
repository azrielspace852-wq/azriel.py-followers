# Dataset Reasoning 198

Q: Hadi lebih cepat dari Wati. Wati lebih cepat dari Eka. Siapa yang paling lambat?
A: Eka.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Udin menyukai Maya. Maya menyukai Rina. Apakah Udin menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Candra lebih tua dari Joko. Joko lebih tua dari Putri. Putri lebih tua dari Tono. Siapa yang paling muda dan siapa yang paling tua?
A: Tono yang paling muda, Candra yang paling tua.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Dewi lebih tinggi dari Budi. Budi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Jika 29 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 5.
Q: Sari memiliki 12 hp. Dia memberikan 8 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 2 kepada Dewi. Berapa hp Sari sekarang?
A: 4.
Q: Lina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
