# Dataset Reasoning 127

Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa hasil dari 6 dikali 11 ditambah 8?
A: 74.
Q: Joko memiliki 11 apel. Dia memberikan 2 kepada Budi. Kemudian membeli 9 apel. Setelah itu memberikan 6 kepada Kartika. Berapa apel Joko sekarang?
A: 12.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Hadi lebih cepat dari Eka. Eka lebih cepat dari Sari. Siapa yang paling lambat?
A: Sari.
Q: Indra lebih tinggi dari Rina. Rina lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Tono menyukai Hadi. Hadi menyukai Rina. Apakah Tono menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jika 25 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 2, sisa 7.
Q: Kartika menyukai Maya. Maya menyukai Indra. Apakah Kartika menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Gita lebih tinggi dari Kartika. Kartika lebih tinggi dari Hadi. Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
