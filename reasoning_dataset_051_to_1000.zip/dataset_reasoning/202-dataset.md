# Dataset Reasoning 202

Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Tono tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Joko lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Gita lebih tinggi dari Kartika. Kartika lebih tinggi dari Hadi. Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Nanda menyukai Maya. Maya menyukai Andi. Apakah Nanda menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa 11 ditambah 3 dikali 2?
A: 17.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Putri memiliki 15 tas. Dia memberikan 9 kepada Tono. Kemudian membeli 4 tas. Setelah itu memberikan 7 kepada Nanda. Berapa tas Putri sekarang?
A: 3.
Q: Putri lebih cepat dari Eka. Eka lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
