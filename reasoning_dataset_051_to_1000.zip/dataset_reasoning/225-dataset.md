# Dataset Reasoning 225

Q: Dewi lebih tua dari Eka. Eka lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Budi lebih tinggi dari Andi. Andi lebih tinggi dari Kartika. Kartika lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Joko lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Joko lebih tinggi dari Wati.
Q: Hadi lebih tua dari Wati. Wati lebih tua dari Eka. Siapa yang paling muda?
A: Eka.
Q: Joko lebih cepat dari Lina. Lina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Indra lebih cepat dari Rina. Rina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Kartika lebih cepat dari Tono. Putri lebih cepat dari Kartika. Siapa yang paling cepat antara Tono dan Putri?
A: Tidak dapat dipastikan.
Q: Berapa 2 ditambah 4 dikali 9?
A: 38.
Q: Wati lebih cepat dari Eka. Hadi lebih cepat dari Wati. Siapa yang paling cepat antara Eka dan Hadi?
A: Tidak dapat dipastikan.
Q: Wati diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Sari lebih cepat dari Kartika. Candra lebih cepat dari Sari. Siapa yang paling cepat antara Kartika dan Candra?
A: Tidak dapat dipastikan.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
