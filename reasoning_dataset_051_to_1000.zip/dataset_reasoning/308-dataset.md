# Dataset Reasoning 308

Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Joko lebih cepat dari Hadi. Hadi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Putri lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Tono lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Tono lebih tinggi dari Putri.
Q: Candra lebih tua dari Kartika. Kartika lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Jika 24 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda lebih tua dari Candra. Candra lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
