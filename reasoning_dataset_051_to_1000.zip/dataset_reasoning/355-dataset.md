# Dataset Reasoning 355

Q: Jika 29 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 5.
Q: Indra lebih cepat dari Sari. Sari lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Berapa 8 ditambah 8 dikali 15?
A: 128.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Tono memiliki 17 apel. Dia memberikan 11 kepada Putri. Kemudian membeli 8 apel. Setelah itu memberikan 13 kepada Candra. Berapa apel Tono sekarang?
A: 1.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Budi menyukai Lina. Lina menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Nanda lebih tinggi dari Sari. Sari lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Udin belajar selama dua minggu. Apakah Udin akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati menyukai Kartika. Kartika menyukai Putri. Apakah Wati menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
