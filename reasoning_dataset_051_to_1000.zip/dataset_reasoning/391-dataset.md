# Dataset Reasoning 391

Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Lina lebih tinggi dari Wati. Wati lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Udin. Udin lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Berapa hasil dari 2 dikali 11 ditambah 9?
A: 31.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Udin lebih tua dari Budi. Budi lebih tua dari Lina. Lina lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Udin yang paling tua.
Q: Putri memiliki 9 jam. Dia memberikan 6 kepada Hadi. Kemudian membeli 7 jam. Setelah itu memberikan 4 kepada Lina. Berapa jam Putri sekarang?
A: 6.
Q: Berapa hasil dari 8 dikali 9 ditambah 8?
A: 80.
Q: Maya memiliki 19 kunci. Dia memberikan 10 kepada Andi. Kemudian membeli 6 kunci. Setelah itu memberikan 1 kepada Udin. Berapa kunci Maya sekarang?
A: 14.
