# Dataset Reasoning 235

Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 3 ditambah 10 dikali 7?
A: 73.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Candra menyukai Budi. Budi menyukai Andi. Apakah Candra menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Maya menyukai Rina. Rina menyukai Wati. Apakah Maya menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Gita lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Eka.
Q: Budi lebih tinggi dari Sari. Sari lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Fajar lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Gita lebih tua dari Tono. Tono lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
