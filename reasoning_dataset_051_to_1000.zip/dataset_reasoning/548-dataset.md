# Dataset Reasoning 548

Q: Wati lebih cepat dari Candra. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Candra dan Putri?
A: Tidak dapat dipastikan.
Q: Candra menyukai Budi. Budi menyukai Andi. Apakah Candra menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasil dari 6 dikali 7 ditambah 19?
A: 61.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Berapa hasil dari 7 dikali 4 ditambah 18?
A: 46.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Hadi lebih cepat dari Rina. Rina lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Rina memiliki 11 jam. Dia memberikan 1 kepada Putri. Kemudian membeli 11 jam. Setelah itu memberikan 10 kepada Kartika. Berapa jam Rina sekarang?
A: 11.
Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
Q: Putri lebih tua dari Eka. Eka lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
