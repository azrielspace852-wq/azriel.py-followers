# Dataset Reasoning 108

Q: Nanda menyukai Budi. Budi menyukai Gita. Apakah Nanda menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Dewi belajar selama dua minggu. Apakah Dewi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Candra menyukai Budi. Budi menyukai Andi. Apakah Candra menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih tua dari Wati. Wati lebih tua dari Eka. Siapa yang paling muda?
A: Eka.
Q: Berapa hasil dari 7 dikali 8 ditambah 11?
A: 67.
Q: Berapa hasil dari 11 dikali 12 ditambah 13?
A: 145.
Q: Berapa hasil dari 4 dikali 4 ditambah 20?
A: 36.
Q: Hadi memiliki 8 hp. Dia memberikan 2 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 3 kepada Andi. Berapa hp Hadi sekarang?
A: 5.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Budi menyukai Tono. Tono menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
