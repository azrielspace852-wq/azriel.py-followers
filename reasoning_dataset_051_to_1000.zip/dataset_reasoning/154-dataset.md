# Dataset Reasoning 154

Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Joko belajar selama dua minggu. Apakah Joko akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Jika 21 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
Q: Wati memiliki 10 kunci. Dia memberikan 1 kepada Andi. Kemudian membeli 8 kunci. Setelah itu memberikan 11 kepada Candra. Berapa kunci Wati sekarang?
A: 6.
Q: Nanda menyukai Udin. Udin menyukai Kartika. Apakah Nanda menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Joko lebih cepat dari Candra. Candra lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Joko menyukai Wati. Wati menyukai Gita. Apakah Joko menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
