# Dataset Reasoning 398

Q: Wati lebih tinggi dari Eka. Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Fajar. Fajar lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Dewi lebih tua dari Sari. Sari lebih tua dari Udin. Udin lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Berapa 9 ditambah 11 dikali 15?
A: 174.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Budi menyukai Lina. Lina menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin lebih cepat dari Hadi. Hadi lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Indra menyukai Lina. Lina menyukai Fajar. Apakah Indra menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih cepat dari Hadi. Hadi lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Candra memiliki 16 bola. Dia memberikan 9 kepada Nanda. Kemudian membeli 2 bola. Setelah itu memberikan 4 kepada Rina. Berapa bola Candra sekarang?
A: 5.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Gita lebih tinggi dari Wati. Wati lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Rina lebih tinggi dari Tono. Tono lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
