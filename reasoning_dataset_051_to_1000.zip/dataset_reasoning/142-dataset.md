# Dataset Reasoning 142

Q: Dewi memiliki 24 kemeja. Dia memberikan 20 kepada Tono. Kemudian membeli 8 kemeja. Setelah itu memberikan 2 kepada Gita. Berapa kemeja Dewi sekarang?
A: 10.
Q: Berapa hasil dari 10 dikali 3 ditambah 12?
A: 42.
Q: Udin memiliki 10 kunci. Dia memberikan 1 kepada Candra. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Hadi. Berapa kunci Udin sekarang?
A: 10.
Q: Hadi lebih tinggi dari Lina. Lina lebih tinggi dari Joko. Joko lebih tinggi dari Fajar. Fajar lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Budi menyukai Lina. Lina menyukai Hadi. Apakah Budi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Andi. Andi lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Dewi yang paling tua.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Indra lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Indra lebih tinggi dari Lina.
Q: Gita menyukai Eka. Eka menyukai Andi. Apakah Gita menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Kartika lebih cepat dari Maya. Fajar lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
