# Dataset Reasoning 448

Q: Wati lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Kartika.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Udin lebih cepat dari Tono. Tono lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Sari memiliki 15 kunci. Dia memberikan 10 kepada Putri. Kemudian membeli 2 kunci. Setelah itu memberikan 6 kepada Andi. Berapa kunci Sari sekarang?
A: 1.
Q: Hadi memiliki 8 hp. Dia memberikan 2 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 3 kepada Andi. Berapa hp Hadi sekarang?
A: 5.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Eka lebih tua dari Maya. Maya lebih tua dari Tono. Tono lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Eka yang paling tua.
Q: Dewi memiliki 13 buku. Dia memberikan 1 kepada Maya. Kemudian membeli 6 buku. Setelah itu memberikan 16 kepada Rina. Berapa buku Dewi sekarang?
A: 2.
Q: Putri lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Hadi lebih tinggi dari Candra. Candra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Eka tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Eka tidak datang.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
