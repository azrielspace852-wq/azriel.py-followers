# Dataset Reasoning 259

Q: Hadi memiliki 10 celana. Dia memberikan 4 kepada Candra. Kemudian membeli 12 celana. Setelah itu memberikan 10 kepada Nanda. Berapa celana Hadi sekarang?
A: 8.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Maya lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Maya yang paling tua.
Q: Putri tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Gita memiliki 14 kemeja. Dia memberikan 2 kepada Wati. Kemudian membeli 9 kemeja. Setelah itu memberikan 3 kepada Andi. Berapa kemeja Gita sekarang?
A: 18.
Q: Tono lebih cepat dari Indra. Indra lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Jika 48 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Udin lebih cepat dari Tono. Tono lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Dewi lebih cepat dari Eka. Eka lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
