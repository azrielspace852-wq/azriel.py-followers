# Dataset Reasoning 381

Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Joko lebih tua dari Hadi. Hadi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Eka lebih tinggi dari Joko. Joko lebih tinggi dari Putri. Putri lebih tinggi dari Kartika. Kartika lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Gita memiliki 14 kemeja. Dia memberikan 2 kepada Wati. Kemudian membeli 9 kemeja. Setelah itu memberikan 3 kepada Andi. Berapa kemeja Gita sekarang?
A: 18.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Udin memiliki 8 kemeja. Dia memberikan 3 kepada Rina. Kemudian membeli 6 kemeja. Setelah itu memberikan 10 kepada Eka. Berapa kemeja Udin sekarang?
A: 1.
Q: Indra menyukai Maya. Maya menyukai Kartika. Apakah Indra menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Hadi memiliki 10 celana. Dia memberikan 4 kepada Candra. Kemudian membeli 12 celana. Setelah itu memberikan 10 kepada Nanda. Berapa celana Hadi sekarang?
A: 8.
