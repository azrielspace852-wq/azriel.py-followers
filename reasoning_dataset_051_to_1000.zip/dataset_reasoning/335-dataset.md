# Dataset Reasoning 335

Q: Dewi memiliki 17 bola. Dia memberikan 4 kepada Maya. Kemudian membeli 8 bola. Setelah itu memberikan 16 kepada Udin. Berapa bola Dewi sekarang?
A: 5.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Rina memiliki 20 apel. Dia memberikan 12 kepada Wati. Kemudian membeli 3 apel. Setelah itu memberikan 4 kepada Tono. Berapa apel Rina sekarang?
A: 7.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra memiliki 25 bola. Dia memberikan 1 kepada Dewi. Kemudian membeli 10 bola. Setelah itu memberikan 27 kepada Putri. Berapa bola Candra sekarang?
A: 7.
Q: Rina lebih tinggi dari Candra. Candra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Tono lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Andi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Dewi memiliki 13 buku. Dia memberikan 1 kepada Maya. Kemudian membeli 6 buku. Setelah itu memberikan 16 kepada Rina. Berapa buku Dewi sekarang?
A: 2.
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Rina lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Rina yang paling tua.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Rina menyukai Putri. Putri menyukai Indra. Apakah Rina menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
