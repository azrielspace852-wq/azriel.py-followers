# Dataset Reasoning 336

Q: Tono lebih tinggi dari Dewi. Dewi lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Hadi lebih cepat dari Eka. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Maya diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Dewi lebih tua dari Andi. Andi lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Jika 41 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 1.
Q: Nanda lebih cepat dari Maya. Fajar lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Budi tidak datang.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Tono lebih cepat dari Gita. Gita lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Andi. Andi lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Dewi yang paling tua.
