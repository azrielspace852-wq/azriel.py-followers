# Dataset Reasoning 292

Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Joko lebih tinggi dari Hadi. Hadi lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Nanda menyukai Maya. Maya menyukai Fajar. Apakah Nanda menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasil dari 11 dikali 12 ditambah 13?
A: 145.
Q: Budi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Sari menyukai Kartika. Kartika menyukai Candra. Apakah Sari menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Fajar lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Fajar lebih tinggi dari Sari.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Gita lebih tinggi dari Hadi. Hadi lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Lina lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
