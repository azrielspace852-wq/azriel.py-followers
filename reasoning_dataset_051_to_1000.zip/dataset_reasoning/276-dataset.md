# Dataset Reasoning 276

Q: Putri lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Sari.
Q: Fajar tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Fajar tidak datang.
Q: Udin lebih cepat dari Maya. Maya lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Wati lebih tinggi dari Candra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Candra.
Q: Hadi lebih cepat dari Indra. Nanda lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Nanda?
A: Tidak dapat dipastikan.
Q: Hadi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Candra lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Tono lebih cepat dari Putri. Fajar lebih cepat dari Tono. Siapa yang paling cepat antara Putri dan Fajar?
A: Tidak dapat dipastikan.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Joko lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Joko lebih tinggi dari Wati.
Q: Hadi memiliki 8 hp. Dia memberikan 2 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 3 kepada Andi. Berapa hp Hadi sekarang?
A: 5.
Q: Putri lebih cepat dari Candra. Joko lebih cepat dari Putri. Siapa yang paling cepat antara Candra dan Joko?
A: Tidak dapat dipastikan.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Fajar lebih tua dari Sari. Sari lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
