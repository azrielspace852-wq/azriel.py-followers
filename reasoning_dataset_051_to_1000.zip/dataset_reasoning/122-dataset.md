# Dataset Reasoning 122

Q: Joko lebih tua dari Hadi. Hadi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Kartika menyukai Tono. Tono menyukai Candra. Apakah Kartika menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Candra menyukai Nanda. Nanda menyukai Eka. Apakah Candra menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kartika lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Tono.
Q: Berapa 8 ditambah 7 dikali 15?
A: 113.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Eka lebih tua dari Lina. Lina lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Lina lebih tinggi dari Indra. Indra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Maya lebih cepat dari Candra. Candra lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Kartika lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Maya.
