# Dataset Reasoning 496

Q: Fajar menyukai Candra. Candra menyukai Joko. Apakah Fajar menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi lebih tua dari Budi. Budi lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Rina lebih cepat dari Candra. Candra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Putri lebih tinggi dari Tono. Tono lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Udin memiliki 9 kunci. Dia memberikan 2 kepada Putri. Kemudian membeli 6 kunci. Setelah itu memberikan 10 kepada Dewi. Berapa kunci Udin sekarang?
A: 3.
Q: Candra lebih tua dari Udin. Udin lebih tua dari Eka. Eka lebih tua dari Lina. Siapa yang paling muda dan siapa yang paling tua?
A: Lina yang paling muda, Candra yang paling tua.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
