# Dataset Reasoning 526

Q: Putri lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Kartika lebih cepat dari Maya. Indra lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Indra?
A: Tidak dapat dipastikan.
Q: Dewi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Fajar. Fajar lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Joko. Joko lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Indra menyukai Maya. Maya menyukai Kartika. Apakah Indra menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar menyukai Sari. Sari menyukai Putri. Apakah Fajar menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
