# Dataset Reasoning 175

Q: Putri lebih cepat dari Fajar. Budi lebih cepat dari Putri. Siapa yang paling cepat antara Fajar dan Budi?
A: Tidak dapat dipastikan.
Q: Fajar memiliki 14 kunci. Dia memberikan 5 kepada Andi. Kemudian membeli 5 kunci. Setelah itu memberikan 6 kepada Tono. Berapa kunci Fajar sekarang?
A: 8.
Q: Rina menyukai Hadi. Hadi menyukai Indra. Apakah Rina menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Joko memiliki 23 celana. Dia memberikan 10 kepada Joko. Kemudian membeli 2 celana. Setelah itu memberikan 4 kepada Putri. Berapa celana Joko sekarang?
A: 11.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Dewi lebih tua dari Hadi. Hadi lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Hadi lebih cepat dari Eka. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Jika 31 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 3.
