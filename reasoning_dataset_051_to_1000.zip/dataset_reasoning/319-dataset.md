# Dataset Reasoning 319

Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Fajar lebih tinggi dari Sari. Sari lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Jika 34 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 2.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Kartika lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Maya.
Q: Putri lebih cepat dari Tono. Tono lebih cepat dari Dewi. Siapa yang paling lambat?
A: Dewi.
Q: Fajar lebih tua dari Putri. Putri lebih tua dari Lina. Lina lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Fajar yang paling tua.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Candra lebih tua dari Wati. Wati lebih tua dari Sari. Sari lebih tua dari Maya. Siapa yang paling muda dan siapa yang paling tua?
A: Maya yang paling muda, Candra yang paling tua.
Q: Rina memiliki 18 dompet. Dia memberikan 13 kepada Budi. Kemudian membeli 7 dompet. Setelah itu memberikan 11 kepada Wati. Berapa dompet Rina sekarang?
A: 1.
Q: Maya menyukai Eka. Eka menyukai Gita. Apakah Maya menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
