# Dataset Reasoning 280

Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Eka menyukai Rina. Rina menyukai Dewi. Apakah Eka menyukai Dewi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda lebih cepat dari Hadi. Hadi lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Putri menyukai Sari. Sari menyukai Tono. Apakah Putri menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Kartika memiliki 12 hp. Dia memberikan 2 kepada Maya. Kemudian membeli 9 hp. Setelah itu memberikan 9 kepada Candra. Berapa hp Kartika sekarang?
A: 10.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
