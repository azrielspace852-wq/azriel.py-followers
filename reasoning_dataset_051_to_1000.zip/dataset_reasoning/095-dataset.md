# Dataset Reasoning 095

Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Putri lebih cepat dari Sari. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Sari dan Tono?
A: Tidak dapat dipastikan.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Fajar lebih cepat dari Sari. Putri lebih cepat dari Fajar. Siapa yang paling cepat antara Sari dan Putri?
A: Tidak dapat dipastikan.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Gita memiliki 14 kemeja. Dia memberikan 2 kepada Wati. Kemudian membeli 9 kemeja. Setelah itu memberikan 3 kepada Andi. Berapa kemeja Gita sekarang?
A: 18.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Putri lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Rina lebih cepat dari Andi. Tono lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Tono?
A: Tidak dapat dipastikan.
Q: Lina lebih tua dari Wati. Wati lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
