# Dataset Reasoning 356

Q: Dewi lebih tinggi dari Budi. Budi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Kartika menyukai Tono. Tono menyukai Candra. Apakah Kartika menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Rina menyukai Hadi. Hadi menyukai Indra. Apakah Rina menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Joko memiliki 11 apel. Dia memberikan 2 kepada Budi. Kemudian membeli 9 apel. Setelah itu memberikan 6 kepada Kartika. Berapa apel Joko sekarang?
A: 12.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Fajar lebih tinggi dari Nanda. Nanda lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Budi lebih tinggi dari Dewi. Dewi lebih tinggi dari Nanda. Nanda lebih tinggi dari Lina. Lina lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Putri lebih cepat dari Eka. Eka lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Indra lebih tinggi dari Tono. Tono lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
