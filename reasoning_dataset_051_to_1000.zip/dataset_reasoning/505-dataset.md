# Dataset Reasoning 505

Q: Dewi lebih tinggi dari Hadi. Hadi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Rina lebih tua dari Tono. Tono lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Dewi lebih tinggi dari Nanda. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Dewi lebih tinggi dari Nanda.
Q: Nanda lebih tinggi dari Budi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Budi.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Nanda lebih cepat dari Maya. Fajar lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Dewi belajar selama dua minggu. Apakah Dewi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Joko lebih tinggi dari Lina. Lina lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Tono menyukai Hadi. Hadi menyukai Rina. Apakah Tono menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
