# Dataset Reasoning 432

Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Tono diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih tinggi dari Nanda. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Dewi lebih tinggi dari Nanda.
Q: Berapa 4 ditambah 4 dikali 20?
A: 84.
Q: Wati lebih cepat dari Sari. Nanda lebih cepat dari Wati. Siapa yang paling cepat antara Sari dan Nanda?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 7 dikali 4 ditambah 12?
A: 40.
Q: Putri lebih tua dari Sari. Sari lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Kartika lebih cepat dari Maya. Indra lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Indra?
A: Tidak dapat dipastikan.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Putri lebih tinggi dari Fajar. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Fajar.
