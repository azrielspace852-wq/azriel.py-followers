# Dataset Reasoning 412

Q: Gita lebih cepat dari Putri. Kartika lebih cepat dari Gita. Siapa yang paling cepat antara Putri dan Kartika?
A: Tidak dapat dipastikan.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Jika 20 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 0.
Q: Maya tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Putri lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Tono lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
