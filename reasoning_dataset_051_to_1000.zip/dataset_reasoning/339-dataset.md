# Dataset Reasoning 339

Q: Hadi lebih cepat dari Candra. Candra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Putri menyukai Eka. Eka menyukai Tono. Apakah Putri menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Candra lebih tua dari Joko. Joko lebih tua dari Putri. Putri lebih tua dari Tono. Siapa yang paling muda dan siapa yang paling tua?
A: Tono yang paling muda, Candra yang paling tua.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Gita lebih cepat dari Rina. Rina lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Gita lebih tinggi dari Wati. Wati lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
