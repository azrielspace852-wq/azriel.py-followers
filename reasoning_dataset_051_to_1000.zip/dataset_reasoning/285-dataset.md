# Dataset Reasoning 285

Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Tono memiliki 21 tas. Dia memberikan 6 kepada Sari. Kemudian membeli 5 tas. Setelah itu memberikan 5 kepada Sari. Berapa tas Tono sekarang?
A: 15.
Q: Berapa hasil dari 8 dikali 10 ditambah 20?
A: 100.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Tono lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Joko diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Gita lebih cepat dari Eka. Andi lebih cepat dari Gita. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
