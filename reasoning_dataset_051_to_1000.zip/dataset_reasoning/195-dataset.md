# Dataset Reasoning 195

Q: Udin memiliki 10 kemeja. Dia memberikan 4 kepada Gita. Kemudian membeli 6 kemeja. Setelah itu memberikan 11 kepada Nanda. Berapa kemeja Udin sekarang?
A: 1.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Hadi lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Tono lebih tinggi dari Indra. Indra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Gita tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Gita tidak datang.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih tinggi dari Candra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Candra.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Hadi memiliki 10 celana. Dia memberikan 4 kepada Candra. Kemudian membeli 12 celana. Setelah itu memberikan 10 kepada Nanda. Berapa celana Hadi sekarang?
A: 8.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Wati lebih tua dari Kartika. Kartika lebih tua dari Rina. Siapa yang paling muda?
A: Rina.
