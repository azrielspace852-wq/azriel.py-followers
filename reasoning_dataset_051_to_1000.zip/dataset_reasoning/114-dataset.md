# Dataset Reasoning 114

Q: Berapa hasil dari 8 dikali 7 ditambah 15?
A: 71.
Q: Candra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Jika 36 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
Q: Jika 37 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 2.
Q: Fajar tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Fajar tidak datang.
Q: Joko lebih cepat dari Wati. Gita lebih cepat dari Joko. Siapa yang paling cepat antara Wati dan Gita?
A: Tidak dapat dipastikan.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Eka lebih cepat dari Wati. Hadi lebih cepat dari Eka. Siapa yang paling cepat antara Wati dan Hadi?
A: Tidak dapat dipastikan.
Q: Dewi lebih tinggi dari Hadi. Hadi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Sari lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Sari lebih tinggi dari Kartika.
