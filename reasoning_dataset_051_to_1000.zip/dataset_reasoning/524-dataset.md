# Dataset Reasoning 524

Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Joko lebih tua dari Sari. Sari lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Dewi lebih cepat dari Budi. Budi lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Berapa hasil dari 9 dikali 11 ditambah 15?
A: 114.
Q: Candra memiliki 10 pensil. Dia memberikan 6 kepada Indra. Kemudian membeli 11 pensil. Setelah itu memberikan 3 kepada Wati. Berapa pensil Candra sekarang?
A: 12.
Q: Candra memiliki 13 jam. Dia memberikan 10 kepada Lina. Kemudian membeli 8 jam. Setelah itu memberikan 8 kepada Nanda. Berapa jam Candra sekarang?
A: 3.
Q: Dewi menyukai Putri. Putri menyukai Eka. Apakah Dewi menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jika 24 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Gita lebih cepat dari Rina. Rina lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Berapa hasil dari 10 dikali 3 ditambah 12?
A: 42.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
