# Dataset Reasoning 382

Q: Indra lebih cepat dari Sari. Sari lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Dewi menyukai Putri. Putri menyukai Eka. Apakah Dewi menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Sari menyukai Kartika. Kartika menyukai Candra. Apakah Sari menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi lebih cepat dari Eka. Eka lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Nanda lebih tinggi dari Tono. Tono lebih tinggi dari Rina. Rina lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Wati lebih cepat dari Kartika. Kartika lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Fajar lebih cepat dari Indra. Indra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Gita lebih tinggi dari Hadi. Hadi lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Lina lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Dewi lebih tinggi dari Andi. Andi lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
