# Dataset Reasoning 472

Q: Lina lebih tua dari Wati. Wati lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Tono menyukai Putri. Putri menyukai Fajar. Apakah Tono menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Tono lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Udin lebih tua dari Maya. Maya lebih tua dari Nanda. Nanda lebih tua dari Joko. Siapa yang paling muda dan siapa yang paling tua?
A: Joko yang paling muda, Udin yang paling tua.
Q: Fajar memiliki 18 bola. Dia memberikan 4 kepada Gita. Kemudian membeli 10 bola. Setelah itu memberikan 23 kepada Rina. Berapa bola Fajar sekarang?
A: 1.
Q: Rina menyukai Andi. Andi menyukai Maya. Apakah Rina menyukai Maya?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Rina lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Putri.
Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Gita lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Eka.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Dewi lebih cepat dari Putri. Eka lebih cepat dari Dewi. Siapa yang paling cepat antara Putri dan Eka?
A: Tidak dapat dipastikan.
