# Dataset Reasoning 494

Q: Berapa hasil dari 8 dikali 9 ditambah 8?
A: 80.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Rina lebih cepat dari Andi. Tono lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Tono?
A: Tidak dapat dipastikan.
Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Budi tidak datang.
Q: Hadi lebih tua dari Maya. Maya lebih tua dari Budi. Budi lebih tua dari Andi. Siapa yang paling muda dan siapa yang paling tua?
A: Andi yang paling muda, Hadi yang paling tua.
Q: Udin menyukai Gita. Gita menyukai Putri. Apakah Udin menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasil dari 3 dikali 10 ditambah 7?
A: 37.
Q: Joko memiliki 23 celana. Dia memberikan 10 kepada Joko. Kemudian membeli 2 celana. Setelah itu memberikan 4 kepada Putri. Berapa celana Joko sekarang?
A: 11.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Dewi lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Udin. Udin lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Joko lebih cepat dari Lina. Lina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Jika 44 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 4.
