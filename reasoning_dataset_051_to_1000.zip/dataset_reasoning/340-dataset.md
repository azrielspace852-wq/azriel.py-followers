# Dataset Reasoning 340

Q: Berapa 4 ditambah 4 dikali 20?
A: 84.
Q: Dewi lebih tua dari Sari. Sari lebih tua dari Udin. Udin lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Berapa hasil dari 2 dikali 11 ditambah 18?
A: 40.
Q: Nanda lebih tinggi dari Tono. Tono lebih tinggi dari Rina. Rina lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Berapa 10 ditambah 7 dikali 4?
A: 38.
Q: Tono lebih tua dari Hadi. Hadi lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Dewi belajar selama dua minggu. Apakah Dewi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
