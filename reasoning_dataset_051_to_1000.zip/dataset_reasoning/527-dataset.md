# Dataset Reasoning 527

Q: Jika 48 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Berapa hasil dari 8 dikali 7 ditambah 14?
A: 70.
Q: Fajar lebih cepat dari Candra. Joko lebih cepat dari Fajar. Siapa yang paling cepat antara Candra dan Joko?
A: Tidak dapat dipastikan.
Q: Nanda lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Maya.
Q: Nanda lebih tua dari Hadi. Hadi lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Maya lebih tinggi dari Putri. Putri lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Budi lebih tinggi dari Sari. Sari lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Fajar lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Kartika menyukai Maya. Maya menyukai Fajar. Apakah Kartika menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jika 49 dibagi 6, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 1.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 8 ditambah 10 dikali 20?
A: 208.
