# Dataset Reasoning 400

Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Berapa hasil dari 2 dikali 11 ditambah 18?
A: 40.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Putri lebih cepat dari Candra. Joko lebih cepat dari Putri. Siapa yang paling cepat antara Candra dan Joko?
A: Tidak dapat dipastikan.
Q: Rina lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Hadi.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Candra lebih cepat dari Sari. Sari lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Udin memiliki 9 kunci. Dia memberikan 2 kepada Putri. Kemudian membeli 6 kunci. Setelah itu memberikan 10 kepada Dewi. Berapa kunci Udin sekarang?
A: 3.
Q: Nanda lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Maya.
Q: Fajar lebih cepat dari Candra. Joko lebih cepat dari Fajar. Siapa yang paling cepat antara Candra dan Joko?
A: Tidak dapat dipastikan.
Q: Lina memiliki 11 apel. Dia memberikan 6 kepada Maya. Kemudian membeli 10 apel. Setelah itu memberikan 11 kepada Indra. Berapa apel Lina sekarang?
A: 4.
