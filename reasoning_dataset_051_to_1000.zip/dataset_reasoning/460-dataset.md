# Dataset Reasoning 460

Q: Nanda lebih tua dari Fajar. Fajar lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Sari lebih tua dari Fajar. Fajar lebih tua dari Lina. Lina lebih tua dari Tono. Siapa yang paling muda dan siapa yang paling tua?
A: Tono yang paling muda, Sari yang paling tua.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Lina memiliki 18 kunci. Dia memberikan 6 kepada Kartika. Kemudian membeli 9 kunci. Setelah itu memberikan 7 kepada Indra. Berapa kunci Lina sekarang?
A: 14.
Q: Maya tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Budi lebih tinggi dari Andi. Andi lebih tinggi dari Kartika. Kartika lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Gita memiliki 14 kemeja. Dia memberikan 2 kepada Wati. Kemudian membeli 9 kemeja. Setelah itu memberikan 3 kepada Andi. Berapa kemeja Gita sekarang?
A: 18.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
