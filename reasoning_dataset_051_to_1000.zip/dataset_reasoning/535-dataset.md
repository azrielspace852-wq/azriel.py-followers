# Dataset Reasoning 535

Q: Eka lebih tua dari Lina. Lina lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Nanda menyukai Indra. Indra menyukai Candra. Apakah Nanda menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih tinggi dari Eka. Eka lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Putri memiliki 22 kunci. Dia memberikan 9 kepada Tono. Kemudian membeli 12 kunci. Setelah itu memberikan 1 kepada Fajar. Berapa kunci Putri sekarang?
A: 24.
Q: Joko lebih tinggi dari Sari. Sari lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Udin lebih tinggi dari Tono. Tono lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Jika 38 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 19, sisa 0.
Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
