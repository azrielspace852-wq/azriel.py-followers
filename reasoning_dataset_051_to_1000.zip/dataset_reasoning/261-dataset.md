# Dataset Reasoning 261

Q: Wati lebih cepat dari Kartika. Kartika lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Wati lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Eka.
Q: Hadi menyukai Indra. Indra menyukai Sari. Apakah Hadi menyukai Sari?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Putri lebih tinggi dari Lina. Lina lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Eka. Eka lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Joko yang paling tua.
Q: Rina lebih tinggi dari Tono. Tono lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Putri yang paling tua.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Andi lebih cepat dari Maya. Wati lebih cepat dari Andi. Siapa yang paling cepat antara Maya dan Wati?
A: Tidak dapat dipastikan.
Q: Jika 39 dibagi 6, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 3.
