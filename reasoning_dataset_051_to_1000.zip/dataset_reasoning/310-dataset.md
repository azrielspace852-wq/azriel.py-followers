# Dataset Reasoning 310

Q: Sari memiliki 12 hp. Dia memberikan 8 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 2 kepada Dewi. Berapa hp Sari sekarang?
A: 4.
Q: Dewi belajar selama dua minggu. Apakah Dewi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa hasil dari 2 dikali 11 ditambah 9?
A: 31.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Udin menyukai Gita. Gita menyukai Putri. Apakah Udin menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tono memiliki 23 pensil. Dia memberikan 16 kepada Maya. Kemudian membeli 5 pensil. Setelah itu memberikan 8 kepada Gita. Berapa pensil Tono sekarang?
A: 4.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Indra lebih cepat dari Lina. Fajar lebih cepat dari Indra. Siapa yang paling cepat antara Lina dan Fajar?
A: Tidak dapat dipastikan.
Q: Jika 29 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 1.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Berapa 7 ditambah 4 dikali 18?
A: 79.
Q: Candra lebih tinggi dari Rina. Rina lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
