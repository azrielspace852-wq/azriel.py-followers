# Dataset Reasoning 374

Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Dewi menyukai Nanda. Nanda menyukai Hadi. Apakah Dewi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Tono lebih cepat dari Dewi. Dewi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Fajar lebih tua dari Eka. Eka lebih tua dari Candra. Candra lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Fajar yang paling tua.
Q: Udin lebih tua dari Maya. Maya lebih tua dari Nanda. Nanda lebih tua dari Joko. Siapa yang paling muda dan siapa yang paling tua?
A: Joko yang paling muda, Udin yang paling tua.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Berapa hasil dari 8 dikali 8 ditambah 4?
A: 68.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
