# Dataset Reasoning 181

Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Rina lebih tinggi dari Andi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Andi.
Q: Rina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Berapa hasil dari 6 dikali 11 ditambah 8?
A: 74.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Gita lebih cepat dari Dewi. Dewi lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Putri lebih tua dari Sari. Sari lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
