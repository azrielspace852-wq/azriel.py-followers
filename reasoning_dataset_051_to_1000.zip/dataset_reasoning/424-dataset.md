# Dataset Reasoning 424

Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Andi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Berapa hasil dari 6 dikali 11 ditambah 8?
A: 74.
Q: Candra lebih tinggi dari Budi. Budi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Nanda lebih tua dari Lina. Lina lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
