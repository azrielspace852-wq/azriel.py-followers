# Dataset Reasoning 194

Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Jika 25 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 2, sisa 7.
Q: Tono memiliki 21 tas. Dia memberikan 6 kepada Sari. Kemudian membeli 5 tas. Setelah itu memberikan 5 kepada Sari. Berapa tas Tono sekarang?
A: 15.
Q: Kartika lebih tua dari Fajar. Fajar lebih tua dari Candra. Candra lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Kartika yang paling tua.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Jika 37 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 2.
Q: Jika 19 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 3.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Putri memiliki 22 kunci. Dia memberikan 9 kepada Tono. Kemudian membeli 12 kunci. Setelah itu memberikan 1 kepada Fajar. Berapa kunci Putri sekarang?
A: 24.
Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Putri menyukai Candra. Candra menyukai Joko. Apakah Putri menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
