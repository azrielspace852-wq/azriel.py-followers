# Dataset Reasoning 414

Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Jika 11 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 1, sisa 4.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Dewi lebih tua dari Andi. Andi lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Rina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Berapa 11 ditambah 10 dikali 7?
A: 81.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Budi lebih tinggi dari Rina. Rina lebih tinggi dari Hadi. Hadi lebih tinggi dari Gita. Gita lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Putri tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Lina lebih tua dari Wati. Wati lebih tua dari Eka. Eka lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Lina yang paling tua.
Q: Lina lebih cepat dari Indra. Indra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
