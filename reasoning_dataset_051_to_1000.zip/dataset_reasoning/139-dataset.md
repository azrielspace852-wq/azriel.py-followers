# Dataset Reasoning 139

Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Lina lebih tinggi dari Wati. Wati lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Joko memiliki 17 kemeja. Dia memberikan 4 kepada Udin. Kemudian membeli 8 kemeja. Setelah itu memberikan 8 kepada Lina. Berapa kemeja Joko sekarang?
A: 13.
Q: Berapa 4 ditambah 12 dikali 16?
A: 196.
Q: Hadi lebih tinggi dari Udin. Udin lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Indra lebih tinggi dari Tono. Tono lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Candra lebih cepat dari Budi. Andi lebih cepat dari Candra. Siapa yang paling cepat antara Budi dan Andi?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 9 dikali 11 ditambah 15?
A: 114.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Candra lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
