# Dataset Reasoning 446

Q: Andi memiliki 22 celana. Dia memberikan 4 kepada Eka. Kemudian membeli 10 celana. Setelah itu memberikan 15 kepada Nanda. Berapa celana Andi sekarang?
A: 13.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Gita diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
Q: Jika 48 dibagi 8, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Sari belajar selama dua minggu. Apakah Sari akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Fajar lebih tua dari Nanda. Nanda lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Candra memiliki 13 jam. Dia memberikan 10 kepada Lina. Kemudian membeli 8 jam. Setelah itu memberikan 8 kepada Nanda. Berapa jam Candra sekarang?
A: 3.
Q: Nanda lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Udin.
Q: Wati lebih cepat dari Candra. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Candra dan Putri?
A: Tidak dapat dipastikan.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Berapa hasil dari 3 dikali 10 ditambah 7?
A: 37.
