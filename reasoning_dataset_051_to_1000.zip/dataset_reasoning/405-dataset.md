# Dataset Reasoning 405

Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Nanda memiliki 13 dompet. Dia memberikan 5 kepada Dewi. Kemudian membeli 2 dompet. Setelah itu memberikan 3 kepada Candra. Berapa dompet Nanda sekarang?
A: 7.
Q: Budi lebih tinggi dari Sari. Sari lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Fajar lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Andi lebih tinggi dari Candra. Candra lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Hadi lebih cepat dari Candra. Candra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Fajar memiliki 18 tas. Dia memberikan 11 kepada Nanda. Kemudian membeli 12 tas. Setelah itu memberikan 4 kepada Rina. Berapa tas Fajar sekarang?
A: 15.
Q: Eka memiliki 22 buku. Dia memberikan 2 kepada Joko. Kemudian membeli 11 buku. Setelah itu memberikan 12 kepada Kartika. Berapa buku Eka sekarang?
A: 19.
Q: Nanda lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Udin.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
