# Dataset Reasoning 427

Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Jika 24 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 0.
Q: Berapa 3 ditambah 4 dikali 1?
A: 7.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Tono lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Andi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Nanda lebih cepat dari Budi. Gita lebih cepat dari Nanda. Siapa yang paling cepat antara Budi dan Gita?
A: Tidak dapat dipastikan.
Q: Hadi lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Berapa 7 ditambah 4 dikali 18?
A: 79.
