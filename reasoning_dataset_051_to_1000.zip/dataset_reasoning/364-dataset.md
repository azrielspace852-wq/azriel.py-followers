# Dataset Reasoning 364

Q: Berapa 11 ditambah 12 dikali 13?
A: 167.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Maya lebih tinggi dari Putri. Putri lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Putri menyukai Candra. Candra menyukai Joko. Apakah Putri menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih cepat dari Eka. Eka lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Hadi lebih cepat dari Eka. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Sari tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Sari tidak datang.
