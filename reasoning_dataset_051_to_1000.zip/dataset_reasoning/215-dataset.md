# Dataset Reasoning 215

Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Putri memiliki 9 jam. Dia memberikan 6 kepada Hadi. Kemudian membeli 7 jam. Setelah itu memberikan 4 kepada Lina. Berapa jam Putri sekarang?
A: 6.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Udin lebih tinggi dari Indra. Indra lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Jika 28 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 9, sisa 1.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Berapa 3 ditambah 8 dikali 4?
A: 35.
Q: Hadi lebih tua dari Maya. Maya lebih tua dari Budi. Budi lebih tua dari Andi. Siapa yang paling muda dan siapa yang paling tua?
A: Andi yang paling muda, Hadi yang paling tua.
Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Nanda lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra lebih cepat dari Sari. Sari lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Joko. Siapa yang paling lambat?
A: Joko.
