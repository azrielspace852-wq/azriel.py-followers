# Dataset Reasoning 190

Q: Gita diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Berapa hasil dari 4 dikali 4 ditambah 20?
A: 36.
Q: Berapa 11 ditambah 12 dikali 18?
A: 227.
Q: Putri lebih tua dari Tono. Tono lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Udin lebih cepat dari Maya. Rina lebih cepat dari Udin. Siapa yang paling cepat antara Maya dan Rina?
A: Tidak dapat dipastikan.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Rina lebih tua dari Sari. Sari lebih tua dari Joko. Joko lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Rina yang paling tua.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Dewi lebih cepat dari Eka. Eka lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Nanda lebih tinggi dari Sari. Sari lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
