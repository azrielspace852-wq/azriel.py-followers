# Dataset Reasoning 200

Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Candra lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Kartika lebih cepat dari Maya. Indra lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Indra?
A: Tidak dapat dipastikan.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tono menyukai Hadi. Hadi menyukai Rina. Apakah Tono menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Fajar lebih tinggi dari Indra. Indra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
