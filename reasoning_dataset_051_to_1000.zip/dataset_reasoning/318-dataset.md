# Dataset Reasoning 318

Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Rina lebih tua dari Candra. Candra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Udin lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Berapa 8 ditambah 7 dikali 14?
A: 106.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda lebih tua dari Hadi. Hadi lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Joko. Siapa yang paling muda?
A: Joko.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Andi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Andi lebih tinggi dari Lina.
Q: Berapa 2 ditambah 4 dikali 9?
A: 38.
