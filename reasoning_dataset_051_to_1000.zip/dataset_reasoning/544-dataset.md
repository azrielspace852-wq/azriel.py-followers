# Dataset Reasoning 544

Q: Nanda lebih tua dari Lina. Lina lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Berapa hasil dari 10 dikali 7 ditambah 4?
A: 74.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Nanda memiliki 10 celana. Dia memberikan 8 kepada Indra. Kemudian membeli 7 celana. Setelah itu memberikan 5 kepada Putri. Berapa celana Nanda sekarang?
A: 4.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Berapa 6 ditambah 7 dikali 12?
A: 90.
Q: Wati menyukai Sari. Sari menyukai Nanda. Apakah Wati menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jika 37 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 2.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Jika 26 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 13, sisa 0.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Kartika lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Maya.
