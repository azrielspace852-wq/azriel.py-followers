# Dataset Reasoning 218

Q: Berapa hasil dari 11 dikali 3 ditambah 2?
A: 35.
Q: Berapa 10 ditambah 7 dikali 4?
A: 38.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Nanda memiliki 9 pensil. Dia memberikan 3 kepada Hadi. Kemudian membeli 7 pensil. Setelah itu memberikan 6 kepada Sari. Berapa pensil Nanda sekarang?
A: 7.
Q: Nanda menyukai Budi. Budi menyukai Gita. Apakah Nanda menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Budi lebih cepat dari Hadi. Rina lebih cepat dari Budi. Siapa yang paling cepat antara Hadi dan Rina?
A: Tidak dapat dipastikan.
Q: Jika 23 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 2.
Q: Rina lebih cepat dari Hadi. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Hadi dan Indra?
A: Tidak dapat dipastikan.
Q: Maya lebih tua dari Putri. Putri lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Lina lebih tinggi dari Wati. Wati lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Fajar lebih cepat dari Nanda. Nanda lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
