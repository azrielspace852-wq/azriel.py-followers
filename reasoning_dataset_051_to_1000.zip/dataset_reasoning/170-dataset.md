# Dataset Reasoning 170

Q: Berapa 2 ditambah 12 dikali 3?
A: 38.
Q: Putri lebih tua dari Candra. Candra lebih tua dari Kartika. Kartika lebih tua dari Nanda. Siapa yang paling muda dan siapa yang paling tua?
A: Nanda yang paling muda, Putri yang paling tua.
Q: Nanda lebih cepat dari Lina. Lina lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Tono menyukai Putri. Putri menyukai Fajar. Apakah Tono menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Lina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Eka tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Eka tidak datang.
Q: Rina memiliki 16 kunci. Dia memberikan 14 kepada Kartika. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Rina sekarang?
A: 3.
Q: Putri menyukai Wati. Wati menyukai Udin. Apakah Putri menyukai Udin?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih tinggi dari Joko. Joko lebih tinggi dari Lina. Lina lebih tinggi dari Wati. Wati lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Nanda menyukai Maya. Maya menyukai Fajar. Apakah Nanda menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Gita lebih cepat dari Sari. Rina lebih cepat dari Gita. Siapa yang paling cepat antara Sari dan Rina?
A: Tidak dapat dipastikan.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
