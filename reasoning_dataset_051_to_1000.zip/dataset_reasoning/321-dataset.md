# Dataset Reasoning 321

Q: Andi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Hadi lebih cepat dari Eka. Eka lebih cepat dari Sari. Siapa yang paling lambat?
A: Sari.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Maya.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
