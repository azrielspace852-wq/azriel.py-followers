# Dataset Reasoning 529

Q: Berapa hasil dari 3 dikali 4 ditambah 1?
A: 13.
Q: Berapa 2 ditambah 6 dikali 20?
A: 122.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Andi memiliki 22 celana. Dia memberikan 4 kepada Eka. Kemudian membeli 10 celana. Setelah itu memberikan 15 kepada Nanda. Berapa celana Andi sekarang?
A: 13.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Indra lebih cepat dari Maya. Kartika lebih cepat dari Indra. Siapa yang paling cepat antara Maya dan Kartika?
A: Tidak dapat dipastikan.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Indra lebih cepat dari Candra. Candra lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda lebih cepat dari Maya. Andi lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Andi?
A: Tidak dapat dipastikan.
Q: Dewi lebih tinggi dari Budi. Budi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
