# Dataset Reasoning 210

Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Rina lebih cepat dari Andi. Tono lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Tono?
A: Tidak dapat dipastikan.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati menyukai Kartika. Kartika menyukai Putri. Apakah Wati menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tono lebih cepat dari Putri. Fajar lebih cepat dari Tono. Siapa yang paling cepat antara Putri dan Fajar?
A: Tidak dapat dipastikan.
Q: Hadi lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Berapa 8 ditambah 3 dikali 10?
A: 38.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Rina lebih cepat dari Andi. Maya lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Maya?
A: Tidak dapat dipastikan.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
