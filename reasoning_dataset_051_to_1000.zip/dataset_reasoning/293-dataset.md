# Dataset Reasoning 293

Q: Kartika lebih cepat dari Maya. Fajar lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Andi lebih tinggi dari Indra. Indra lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Wati menyukai Udin. Udin menyukai Joko. Apakah Wati menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Maya lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Tono.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Joko lebih tua dari Indra. Indra lebih tua dari Eka. Eka lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
Q: Kartika lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Tono.
Q: Joko lebih cepat dari Lina. Lina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Berapa hasil dari 6 dikali 7 ditambah 19?
A: 61.
Q: Andi lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
