# Dataset Reasoning 396

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Joko memiliki 11 jam. Dia memberikan 3 kepada Dewi. Kemudian membeli 2 jam. Setelah itu memberikan 1 kepada Dewi. Berapa jam Joko sekarang?
A: 9.
Q: Kartika lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Tono.
Q: Jika 44 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 4.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 12 ditambah 6 dikali 12?
A: 84.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Fajar lebih tinggi dari Indra. Indra lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Maya tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Joko memiliki 17 hp. Dia memberikan 14 kepada Wati. Kemudian membeli 11 hp. Setelah itu memberikan 7 kepada Budi. Berapa hp Joko sekarang?
A: 7.
Q: Fajar memiliki 18 bola. Dia memberikan 4 kepada Gita. Kemudian membeli 10 bola. Setelah itu memberikan 23 kepada Rina. Berapa bola Fajar sekarang?
A: 1.
