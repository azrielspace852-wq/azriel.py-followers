# Dataset Reasoning 418

Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Dewi lebih cepat dari Budi. Budi lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Joko memiliki 17 kemeja. Dia memberikan 4 kepada Udin. Kemudian membeli 8 kemeja. Setelah itu memberikan 8 kepada Lina. Berapa kemeja Joko sekarang?
A: 13.
Q: Fajar memiliki 21 pensil. Dia memberikan 19 kepada Fajar. Kemudian membeli 12 pensil. Setelah itu memberikan 13 kepada Candra. Berapa pensil Fajar sekarang?
A: 1.
Q: Joko lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Joko lebih tinggi dari Wati.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Udin menyukai Gita. Gita menyukai Putri. Apakah Udin menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Nanda menyukai Maya. Maya menyukai Andi. Apakah Nanda menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Wati lebih cepat dari Kartika. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Kartika dan Putri?
A: Tidak dapat dipastikan.
Q: Hadi lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
