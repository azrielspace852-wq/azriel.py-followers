# Dataset Reasoning 110

Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Dewi lebih tinggi dari Joko. Joko lebih tinggi dari Sari. Sari lebih tinggi dari Udin. Udin lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Putri diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Eka menyukai Rina. Rina menyukai Dewi. Apakah Eka menyukai Dewi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Nanda menyukai Indra. Indra menyukai Candra. Apakah Nanda menyukai Candra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih tua dari Rina. Rina lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Nanda lebih cepat dari Maya. Andi lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Andi?
A: Tidak dapat dipastikan.
Q: Jika 29 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 1.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati lebih cepat dari Udin. Joko lebih cepat dari Wati. Siapa yang paling cepat antara Udin dan Joko?
A: Tidak dapat dipastikan.
