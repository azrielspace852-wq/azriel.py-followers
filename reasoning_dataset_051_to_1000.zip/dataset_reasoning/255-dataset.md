# Dataset Reasoning 255

Q: Indra lebih cepat dari Tono. Tono lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Andi lebih tua dari Rina. Rina lebih tua dari Nanda. Nanda lebih tua dari Fajar. Siapa yang paling muda dan siapa yang paling tua?
A: Fajar yang paling muda, Andi yang paling tua.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Dewi lebih cepat dari Tono. Tono lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Dewi menyukai Nanda. Nanda menyukai Hadi. Apakah Dewi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Putri lebih tua dari Lina. Lina lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Andi memiliki 15 kemeja. Dia memberikan 11 kepada Indra. Kemudian membeli 11 kemeja. Setelah itu memberikan 10 kepada Udin. Berapa kemeja Andi sekarang?
A: 5.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Udin lebih tinggi dari Wati. Wati lebih tinggi dari Sari. Sari lebih tinggi dari Kartika. Kartika lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Berapa hasil dari 3 dikali 4 ditambah 1?
A: 13.
Q: Hadi lebih cepat dari Gita. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Gita dan Andi?
A: Tidak dapat dipastikan.
Q: Lina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
