# Dataset Reasoning 099

Q: Putri lebih cepat dari Wati. Udin lebih cepat dari Putri. Siapa yang paling cepat antara Wati dan Udin?
A: Tidak dapat dipastikan.
Q: Indra belajar selama dua minggu. Apakah Indra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Berapa hasil dari 8 dikali 3 ditambah 10?
A: 34.
Q: Kartika lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Maya diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Sari lebih tinggi dari Indra. Indra lebih tinggi dari Eka. Eka lebih tinggi dari Lina. Lina lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Gita lebih cepat dari Wati. Wati lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Nanda lebih cepat dari Indra. Candra lebih cepat dari Nanda. Siapa yang paling cepat antara Indra dan Candra?
A: Tidak dapat dipastikan.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Budi lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Tono.
Q: Jika 46 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
