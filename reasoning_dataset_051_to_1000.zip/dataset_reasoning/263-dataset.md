# Dataset Reasoning 263

Q: Sari lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Sari lebih tinggi dari Kartika.
Q: Berapa hasil dari 11 dikali 10 ditambah 7?
A: 117.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Putri lebih cepat dari Wati. Udin lebih cepat dari Putri. Siapa yang paling cepat antara Wati dan Udin?
A: Tidak dapat dipastikan.
Q: Indra lebih tua dari Tono. Tono lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Nanda lebih cepat dari Candra. Candra lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Kartika menyukai Maya. Maya menyukai Indra. Apakah Kartika menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
