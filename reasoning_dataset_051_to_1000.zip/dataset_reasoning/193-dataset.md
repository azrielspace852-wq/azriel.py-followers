# Dataset Reasoning 193

Q: Rina lebih tua dari Tono. Tono lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Eka memiliki 11 kunci. Dia memberikan 9 kepada Eka. Kemudian membeli 5 kunci. Setelah itu memberikan 6 kepada Candra. Berapa kunci Eka sekarang?
A: 1.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Candra lebih tinggi dari Nanda. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Candra lebih tinggi dari Nanda.
Q: Udin lebih tinggi dari Nanda. Nanda lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Putri lebih tinggi dari Lina. Lina lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Dewi lebih tua dari Eka. Eka lebih tua dari Indra. Indra lebih tua dari Gita. Siapa yang paling muda dan siapa yang paling tua?
A: Gita yang paling muda, Dewi yang paling tua.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Indra lebih tinggi dari Joko. Joko lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
