# Dataset Reasoning 086

Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Budi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Lina.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Berapa 10 ditambah 7 dikali 4?
A: 38.
Q: Kartika belajar selama dua minggu. Apakah Kartika akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 8 ditambah 9 dikali 8?
A: 80.
Q: Eka memiliki 22 buku. Dia memberikan 2 kepada Joko. Kemudian membeli 11 buku. Setelah itu memberikan 12 kepada Kartika. Berapa buku Eka sekarang?
A: 19.
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Candra lebih tua dari Udin. Udin lebih tua dari Eka. Eka lebih tua dari Lina. Siapa yang paling muda dan siapa yang paling tua?
A: Lina yang paling muda, Candra yang paling tua.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Dewi lebih tinggi dari Eka. Eka lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
