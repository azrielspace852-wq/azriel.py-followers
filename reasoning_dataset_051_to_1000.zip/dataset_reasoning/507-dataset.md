# Dataset Reasoning 507

Q: Putri memiliki 18 celana. Dia memberikan 8 kepada Joko. Kemudian membeli 12 celana. Setelah itu memberikan 3 kepada Nanda. Berapa celana Putri sekarang?
A: 19.
Q: Andi lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Udin lebih tua dari Indra. Indra lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Tono memiliki 23 pensil. Dia memberikan 16 kepada Maya. Kemudian membeli 5 pensil. Setelah itu memberikan 8 kepada Gita. Berapa pensil Tono sekarang?
A: 4.
Q: Andi memiliki 15 kemeja. Dia memberikan 11 kepada Indra. Kemudian membeli 11 kemeja. Setelah itu memberikan 10 kepada Udin. Berapa kemeja Andi sekarang?
A: 5.
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Hadi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Putri lebih cepat dari Sari. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Sari dan Tono?
A: Tidak dapat dipastikan.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
