# Dataset Reasoning 436

Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Tono lebih cepat dari Andi. Andi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Indra lebih cepat dari Maya. Kartika lebih cepat dari Indra. Siapa yang paling cepat antara Maya dan Kartika?
A: Tidak dapat dipastikan.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Hadi memiliki 23 celana. Dia memberikan 4 kepada Fajar. Kemudian membeli 2 celana. Setelah itu memberikan 20 kepada Joko. Berapa celana Hadi sekarang?
A: 1.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Kartika lebih cepat dari Dewi. Dewi lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Jika 29 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 1.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
