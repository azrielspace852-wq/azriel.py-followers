# Dataset Reasoning 513

Q: Eka memiliki 22 buku. Dia memberikan 2 kepada Joko. Kemudian membeli 11 buku. Setelah itu memberikan 12 kepada Kartika. Berapa buku Eka sekarang?
A: 19.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Putri menyukai Fajar. Fajar menyukai Budi. Apakah Putri menyukai Budi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Fajar lebih cepat dari Nanda. Nanda lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Maya lebih tinggi dari Candra. Candra lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Dewi lebih cepat dari Nanda. Hadi lebih cepat dari Dewi. Siapa yang paling cepat antara Nanda dan Hadi?
A: Tidak dapat dipastikan.
Q: Budi lebih tinggi dari Rina. Rina lebih tinggi dari Hadi. Hadi lebih tinggi dari Gita. Gita lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Andi lebih cepat dari Maya. Wati lebih cepat dari Andi. Siapa yang paling cepat antara Maya dan Wati?
A: Tidak dapat dipastikan.
Q: Rina lebih cepat dari Tono. Tono lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Hadi menyukai Eka. Eka menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
