# Dataset Reasoning 169

Q: Fajar lebih tinggi dari Putri. Putri lebih tinggi dari Tono. Tono lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Gita lebih tua dari Rina. Rina lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Berapa 12 ditambah 12 dikali 19?
A: 240.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Jika 43 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 14, sisa 1.
Q: Maya lebih tua dari Budi. Budi lebih tua dari Nanda. Nanda lebih tua dari Andi. Siapa yang paling muda dan siapa yang paling tua?
A: Andi yang paling muda, Maya yang paling tua.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kartika lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Kartika lebih tinggi dari Tono.
Q: Maya memiliki 18 dompet. Dia memberikan 9 kepada Andi. Kemudian membeli 7 dompet. Setelah itu memberikan 2 kepada Tono. Berapa dompet Maya sekarang?
A: 14.
Q: Wati menyukai Sari. Sari menyukai Nanda. Apakah Wati menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
