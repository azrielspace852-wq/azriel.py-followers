# Dataset Reasoning 196

Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Berapa hasil dari 3 dikali 10 ditambah 7?
A: 37.
Q: Putri lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Maya diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Andi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Andi tidak datang.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Andi. Andi lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Dewi yang paling tua.
Q: Udin lebih cepat dari Nanda. Nanda lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Fajar memiliki 15 apel. Dia memberikan 3 kepada Nanda. Kemudian membeli 10 apel. Setelah itu memberikan 3 kepada Putri. Berapa apel Fajar sekarang?
A: 19.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Hadi menyukai Indra. Indra menyukai Kartika. Apakah Hadi menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
