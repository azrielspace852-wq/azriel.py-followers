# Dataset Reasoning 201

Q: Rina lebih tinggi dari Candra. Candra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Fajar memiliki 21 pensil. Dia memberikan 19 kepada Fajar. Kemudian membeli 12 pensil. Setelah itu memberikan 13 kepada Candra. Berapa pensil Fajar sekarang?
A: 1.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Eka lebih cepat dari Rina. Dewi lebih cepat dari Eka. Siapa yang paling cepat antara Rina dan Dewi?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 6 dikali 7 ditambah 19?
A: 61.
Q: Berapa hasil dari 12 dikali 6 ditambah 12?
A: 84.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Berapa hasil dari 2 dikali 4 ditambah 9?
A: 17.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Nanda lebih tinggi dari Budi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Budi.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Putri lebih tinggi dari Tono. Tono lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Kartika memiliki 22 dompet. Dia memberikan 18 kepada Tono. Kemudian membeli 9 dompet. Setelah itu memberikan 6 kepada Maya. Berapa dompet Kartika sekarang?
A: 7.
