# Dataset Reasoning 492

Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Hadi lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Hadi lebih cepat dari Indra. Sari lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Sari?
A: Tidak dapat dipastikan.
Q: Budi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Lina.
Q: Dewi memiliki 17 bola. Dia memberikan 4 kepada Maya. Kemudian membeli 8 bola. Setelah itu memberikan 16 kepada Udin. Berapa bola Dewi sekarang?
A: 5.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Berapa hasil dari 5 dikali 3 ditambah 12?
A: 27.
Q: Nanda lebih cepat dari Indra. Candra lebih cepat dari Nanda. Siapa yang paling cepat antara Indra dan Candra?
A: Tidak dapat dipastikan.
Q: Budi lebih tua dari Hadi. Hadi lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Joko diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Candra lebih cepat dari Gita. Gita lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
