# Dataset Reasoning 416

Q: Maya lebih cepat dari Rina. Wati lebih cepat dari Maya. Siapa yang paling cepat antara Rina dan Wati?
A: Tidak dapat dipastikan.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Berapa 11 ditambah 3 dikali 2?
A: 17.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Nanda lebih cepat dari Lina. Lina lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Tono lebih tinggi dari Hadi. Hadi lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Berapa hasil dari 7 dikali 8 ditambah 11?
A: 67.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Berapa 8 ditambah 3 dikali 10?
A: 38.
