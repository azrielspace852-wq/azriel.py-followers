# Dataset Reasoning 426

Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Udin lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Berapa hasil dari 6 dikali 9 ditambah 14?
A: 68.
Q: Berapa hasil dari 11 dikali 12 ditambah 13?
A: 145.
Q: Candra memiliki 25 bola. Dia memberikan 1 kepada Dewi. Kemudian membeli 10 bola. Setelah itu memberikan 27 kepada Putri. Berapa bola Candra sekarang?
A: 7.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Rina memiliki 11 jam. Dia memberikan 1 kepada Putri. Kemudian membeli 11 jam. Setelah itu memberikan 10 kepada Kartika. Berapa jam Rina sekarang?
A: 11.
Q: Rina lebih tua dari Candra. Candra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Udin lebih tua dari Hadi. Hadi lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
