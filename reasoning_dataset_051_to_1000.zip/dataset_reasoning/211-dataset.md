# Dataset Reasoning 211

Q: Maya lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Eka.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Hadi memiliki 23 celana. Dia memberikan 4 kepada Fajar. Kemudian membeli 2 celana. Setelah itu memberikan 20 kepada Joko. Berapa celana Hadi sekarang?
A: 1.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Udin lebih cepat dari Maya. Maya lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Andi lebih tinggi dari Dewi. Dewi lebih tinggi dari Indra. Indra lebih tinggi dari Fajar. Fajar lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Nanda lebih cepat dari Udin. Kartika lebih cepat dari Nanda. Siapa yang paling cepat antara Udin dan Kartika?
A: Tidak dapat dipastikan.
Q: Tono diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Hadi. Siapa yang paling pendek?
A: Hadi.
Q: Berapa hasil dari 8 dikali 9 ditambah 8?
A: 80.
