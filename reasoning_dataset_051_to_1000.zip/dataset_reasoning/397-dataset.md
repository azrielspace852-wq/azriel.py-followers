# Dataset Reasoning 397

Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Nanda. Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Dewi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Hadi lebih cepat dari Wati. Wati lebih cepat dari Eka. Siapa yang paling lambat?
A: Eka.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Eka. Eka lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Joko yang paling tua.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Hadi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Dewi lebih cepat dari Tono. Tono lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Hadi menyukai Indra. Indra menyukai Nanda. Apakah Hadi menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Hadi memiliki 9 hp. Dia memberikan 5 kepada Lina. Kemudian membeli 9 hp. Setelah itu memberikan 5 kepada Hadi. Berapa hp Hadi sekarang?
A: 8.
Q: Jika 38 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 19, sisa 0.
Q: Dewi lebih cepat dari Tono. Tono lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
