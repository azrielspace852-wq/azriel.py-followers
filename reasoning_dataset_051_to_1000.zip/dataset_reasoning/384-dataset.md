# Dataset Reasoning 384

Q: Hadi lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Hadi yang paling tua.
Q: Berapa 11 ditambah 12 dikali 18?
A: 227.
Q: Joko lebih cepat dari Lina. Lina lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Gita lebih cepat dari Tono. Tono lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Eka lebih cepat dari Wati. Hadi lebih cepat dari Eka. Siapa yang paling cepat antara Wati dan Hadi?
A: Tidak dapat dipastikan.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Candra menyukai Budi. Budi menyukai Andi. Apakah Candra menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Maya lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
