# Dataset Reasoning 380

Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Dewi memiliki 24 kemeja. Dia memberikan 20 kepada Tono. Kemudian membeli 8 kemeja. Setelah itu memberikan 2 kepada Gita. Berapa kemeja Dewi sekarang?
A: 10.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa 2 ditambah 12 dikali 3?
A: 38.
Q: Putri lebih tua dari Tono. Tono lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Jika 26 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 13, sisa 0.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
