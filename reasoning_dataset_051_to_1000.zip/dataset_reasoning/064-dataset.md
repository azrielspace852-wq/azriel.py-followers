# Dataset Reasoning 064

Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Tono. Tono lebih tua dari Maya. Siapa yang paling muda dan siapa yang paling tua?
A: Maya yang paling muda, Kartika yang paling tua.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Maya lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Maya yang paling tua.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Udin lebih tua dari Maya. Maya lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Dewi lebih cepat dari Andi. Andi lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Rina lebih cepat dari Putri. Indra lebih cepat dari Rina. Siapa yang paling cepat antara Putri dan Indra?
A: Tidak dapat dipastikan.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Berapa hasil dari 11 dikali 12 ditambah 18?
A: 150.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Tono lebih tua dari Dewi. Dewi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
