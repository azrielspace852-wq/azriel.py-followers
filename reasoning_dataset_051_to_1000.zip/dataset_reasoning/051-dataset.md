# Dataset Reasoning 051

Q: Hadi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Hadi tidak datang.
Q: Berapa hasil dari 3 dikali 3 ditambah 3?
A: 12.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Wati tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Kartika lebih cepat dari Tono. Candra lebih cepat dari Kartika. Siapa yang paling cepat antara Tono dan Candra?
A: Tidak dapat dipastikan.
Q: Andi lebih tua dari Rina. Rina lebih tua dari Nanda. Nanda lebih tua dari Fajar. Siapa yang paling muda dan siapa yang paling tua?
A: Fajar yang paling muda, Andi yang paling tua.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Indra menyukai Maya. Maya menyukai Kartika. Apakah Indra menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Gita lebih tua dari Dewi. Dewi lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
