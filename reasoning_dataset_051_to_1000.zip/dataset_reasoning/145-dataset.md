# Dataset Reasoning 145

Q: Tono diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Kartika menyukai Maya. Maya menyukai Fajar. Apakah Kartika menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Andi memiliki 15 kemeja. Dia memberikan 11 kepada Indra. Kemudian membeli 11 kemeja. Setelah itu memberikan 10 kepada Udin. Berapa kemeja Andi sekarang?
A: 5.
Q: Dewi memiliki 17 bola. Dia memberikan 4 kepada Maya. Kemudian membeli 8 bola. Setelah itu memberikan 16 kepada Udin. Berapa bola Dewi sekarang?
A: 5.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Gita lebih tua dari Rina. Rina lebih tua dari Maya. Siapa yang paling muda?
A: Maya.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Maya memiliki 22 dompet. Dia memberikan 3 kepada Lina. Kemudian membeli 4 dompet. Setelah itu memberikan 8 kepada Candra. Berapa dompet Maya sekarang?
A: 15.
Q: Lina lebih tua dari Indra. Indra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
