# Dataset Reasoning 367

Q: Joko lebih cepat dari Sari. Sari lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Hadi lebih tua dari Maya. Maya lebih tua dari Budi. Budi lebih tua dari Andi. Siapa yang paling muda dan siapa yang paling tua?
A: Andi yang paling muda, Hadi yang paling tua.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Dewi memiliki 14 kemeja. Dia memberikan 10 kepada Budi. Kemudian membeli 6 kemeja. Setelah itu memberikan 3 kepada Joko. Berapa kemeja Dewi sekarang?
A: 7.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Maya lebih tinggi dari Rina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Rina.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa hasil dari 8 dikali 10 ditambah 20?
A: 100.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
