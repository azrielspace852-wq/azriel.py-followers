# Dataset Reasoning 449

Q: Lina lebih tua dari Wati. Wati lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Andi lebih tua dari Rina. Rina lebih tua dari Nanda. Nanda lebih tua dari Fajar. Siapa yang paling muda dan siapa yang paling tua?
A: Fajar yang paling muda, Andi yang paling tua.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Maya diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Andi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda lebih tinggi dari Candra. Candra lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Maya lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Hadi. Siapa yang paling muda dan siapa yang paling tua?
A: Hadi yang paling muda, Maya yang paling tua.
Q: Wati diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa 5 ditambah 3 dikali 12?
A: 41.
Q: Fajar lebih tua dari Putri. Putri lebih tua dari Lina. Lina lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Fajar yang paling tua.
Q: Gita lebih tua dari Wati. Wati lebih tua dari Tono. Siapa yang paling muda?
A: Tono.
