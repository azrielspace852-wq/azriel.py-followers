# Dataset Reasoning 480

Q: Tono lebih tinggi dari Andi. Andi lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Tono memiliki 17 apel. Dia memberikan 11 kepada Putri. Kemudian membeli 8 apel. Setelah itu memberikan 13 kepada Candra. Berapa apel Tono sekarang?
A: 1.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Berapa hasil dari 6 dikali 9 ditambah 14?
A: 68.
Q: Hadi memiliki 22 hp. Dia memberikan 11 kepada Maya. Kemudian membeli 5 hp. Setelah itu memberikan 12 kepada Hadi. Berapa hp Hadi sekarang?
A: 4.
Q: Joko lebih cepat dari Maya. Maya lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Tono lebih tua dari Eka. Eka lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Joko lebih tua dari Lina. Lina lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Indra lebih cepat dari Tono. Tono lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Wati menyukai Dewi. Dewi menyukai Fajar. Apakah Wati menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
