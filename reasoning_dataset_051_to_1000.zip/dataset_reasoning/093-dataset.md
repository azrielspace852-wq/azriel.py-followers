# Dataset Reasoning 093

Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Candra lebih tua dari Rina. Rina lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Berapa 2 ditambah 11 dikali 18?
A: 200.
Q: Eka menyukai Wati. Wati menyukai Hadi. Apakah Eka menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasil dari 12 dikali 12 ditambah 19?
A: 163.
Q: Tono lebih cepat dari Dewi. Dewi lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Apa itu hukum Zenthara?
A: Saya tidak mengenal hukum atau konsep bernama Zenthara. Mohon berikan konteks atau sumber jika ada.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati lebih cepat dari Kartika. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Kartika dan Putri?
A: Tidak dapat dipastikan.
Q: Rina lebih tinggi dari Andi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Andi.
Q: Maya lebih cepat dari Eka. Gita lebih cepat dari Maya. Siapa yang paling cepat antara Eka dan Gita?
A: Tidak dapat dipastikan.
Q: Tono memiliki 17 apel. Dia memberikan 11 kepada Putri. Kemudian membeli 8 apel. Setelah itu memberikan 13 kepada Candra. Berapa apel Tono sekarang?
A: 1.
Q: Nanda lebih tua dari Hadi. Hadi lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
