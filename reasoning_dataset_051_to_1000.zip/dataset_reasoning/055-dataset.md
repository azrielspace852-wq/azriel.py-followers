# Dataset Reasoning 055

Q: Tono memiliki 23 pensil. Dia memberikan 16 kepada Maya. Kemudian membeli 5 pensil. Setelah itu memberikan 8 kepada Gita. Berapa pensil Tono sekarang?
A: 4.
Q: Tono lebih tua dari Gita. Gita lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Hadi lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Eka.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Candra lebih tinggi dari Budi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Candra lebih tinggi dari Budi.
Q: Berapa 2 ditambah 6 dikali 20?
A: 122.
Q: Andi lebih cepat dari Lina. Joko lebih cepat dari Andi. Siapa yang paling cepat antara Lina dan Joko?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 7 dikali 4 ditambah 12?
A: 40.
Q: Nanda lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Indra.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Dewi lebih tinggi dari Budi. Budi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
