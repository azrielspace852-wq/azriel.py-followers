# Dataset Reasoning 482

Q: Nanda memiliki 23 celana. Dia memberikan 18 kepada Tono. Kemudian membeli 10 celana. Setelah itu memberikan 6 kepada Kartika. Berapa celana Nanda sekarang?
A: 9.
Q: Udin lebih cepat dari Maya. Rina lebih cepat dari Udin. Siapa yang paling cepat antara Maya dan Rina?
A: Tidak dapat dipastikan.
Q: Dewi memiliki 14 kemeja. Dia memberikan 10 kepada Budi. Kemudian membeli 6 kemeja. Setelah itu memberikan 3 kepada Joko. Berapa kemeja Dewi sekarang?
A: 7.
Q: Nanda lebih tinggi dari Lina. Lina lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Eka tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Kartika lebih tua dari Fajar. Fajar lebih tua dari Candra. Candra lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Kartika yang paling tua.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Gita lebih tinggi dari Dewi. Dewi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Wati lebih cepat dari Kartika. Putri lebih cepat dari Wati. Siapa yang paling cepat antara Kartika dan Putri?
A: Tidak dapat dipastikan.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Gita lebih tua dari Tono. Tono lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Budi lebih cepat dari Tono. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Tono dan Hadi?
A: Tidak dapat dipastikan.
