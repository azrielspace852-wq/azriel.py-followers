# Dataset Reasoning 076

Q: Andi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Andi tidak datang.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Andi memiliki 22 celana. Dia memberikan 4 kepada Eka. Kemudian membeli 10 celana. Setelah itu memberikan 15 kepada Nanda. Berapa celana Andi sekarang?
A: 13.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Candra lebih cepat dari Kartika. Kartika lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Budi lebih tinggi dari Rina. Rina lebih tinggi dari Hadi. Hadi lebih tinggi dari Gita. Gita lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Tono lebih tua dari Indra. Indra lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
