# Dataset Reasoning 349

Q: Udin lebih tinggi dari Hadi. Hadi lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Lina lebih tinggi dari Nanda. Nanda lebih tinggi dari Candra. Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Dewi lebih cepat dari Budi. Budi lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Fajar memiliki 21 pensil. Dia memberikan 19 kepada Fajar. Kemudian membeli 12 pensil. Setelah itu memberikan 13 kepada Candra. Berapa pensil Fajar sekarang?
A: 1.
Q: Nanda lebih cepat dari Budi. Gita lebih cepat dari Nanda. Siapa yang paling cepat antara Budi dan Gita?
A: Tidak dapat dipastikan.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Rina memiliki 11 jam. Dia memberikan 1 kepada Putri. Kemudian membeli 11 jam. Setelah itu memberikan 10 kepada Kartika. Berapa jam Rina sekarang?
A: 11.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Tono diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
