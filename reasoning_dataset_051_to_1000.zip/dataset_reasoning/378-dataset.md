# Dataset Reasoning 378

Q: Udin lebih tua dari Nanda. Nanda lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Hadi lebih tua dari Eka. Eka lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Hadi lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Kartika lebih cepat dari Tono. Putri lebih cepat dari Kartika. Siapa yang paling cepat antara Tono dan Putri?
A: Tidak dapat dipastikan.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Budi lebih tua dari Hadi. Hadi lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Nanda memiliki 23 celana. Dia memberikan 18 kepada Tono. Kemudian membeli 10 celana. Setelah itu memberikan 6 kepada Kartika. Berapa celana Nanda sekarang?
A: 9.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
