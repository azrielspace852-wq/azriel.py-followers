# Dataset Reasoning 269

Q: Rina lebih cepat dari Candra. Candra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Tono. Tono lebih tua dari Maya. Siapa yang paling muda dan siapa yang paling tua?
A: Maya yang paling muda, Kartika yang paling tua.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Hadi lebih cepat dari Wati. Wati lebih cepat dari Eka. Siapa yang paling lambat?
A: Eka.
Q: Jika 38 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 3.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Fajar lebih cepat dari Nanda. Nanda lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Budi lebih tinggi dari Joko. Joko lebih tinggi dari Lina. Lina lebih tinggi dari Wati. Wati lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
