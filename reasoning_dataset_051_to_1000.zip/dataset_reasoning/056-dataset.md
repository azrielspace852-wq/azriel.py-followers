# Dataset Reasoning 056

Q: Putri tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Putri tidak datang.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Rina memiliki 25 jam. Dia memberikan 8 kepada Andi. Kemudian membeli 9 jam. Setelah itu memberikan 21 kepada Candra. Berapa jam Rina sekarang?
A: 5.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Hadi menyukai Indra. Indra menyukai Kartika. Apakah Hadi menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Berapa 6 ditambah 7 dikali 4?
A: 34.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Berapa 6 ditambah 11 dikali 8?
A: 94.
Q: Putri lebih tua dari Tono. Tono lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Indra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Indra tidak datang.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
