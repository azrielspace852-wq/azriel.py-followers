# Dataset Reasoning 213

Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Berapa 8 ditambah 6 dikali 7?
A: 50.
Q: Indra lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Tono lebih tinggi dari Dewi. Dewi lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Putri lebih tinggi dari Sari. Sari lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Gita lebih tua dari Dewi. Dewi lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Udin belajar selama dua minggu. Apakah Udin akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
