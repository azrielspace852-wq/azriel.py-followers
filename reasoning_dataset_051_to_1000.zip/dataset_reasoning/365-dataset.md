# Dataset Reasoning 365

Q: Tono lebih tinggi dari Indra. Indra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Udin lebih cepat dari Indra. Indra lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Tono lebih tua dari Eka. Eka lebih tua dari Rina. Siapa yang paling muda?
A: Rina.
Q: Kartika memiliki 12 hp. Dia memberikan 2 kepada Maya. Kemudian membeli 9 hp. Setelah itu memberikan 9 kepada Candra. Berapa hp Kartika sekarang?
A: 10.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Gita lebih tinggi dari Maya. Maya lebih tinggi dari Kartika. Kartika lebih tinggi dari Indra. Indra lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Berapa 3 ditambah 10 dikali 7?
A: 73.
Q: Andi lebih cepat dari Lina. Joko lebih cepat dari Andi. Siapa yang paling cepat antara Lina dan Joko?
A: Tidak dapat dipastikan.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Kartika menyukai Maya. Maya menyukai Fajar. Apakah Kartika menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih cepat dari Sari. Sari lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
