# Dataset Reasoning 463

Q: Fajar lebih tua dari Sari. Sari lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Nanda lebih tinggi dari Sari. Sari lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Maya lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Jika 19 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 3.
Q: Dewi lebih cepat dari Hadi. Hadi lebih cepat dari Udin. Siapa yang paling lambat?
A: Udin.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Candra. Siapa yang paling muda?
A: Candra.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Dewi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Maya memiliki 22 dompet. Dia memberikan 3 kepada Lina. Kemudian membeli 4 dompet. Setelah itu memberikan 8 kepada Candra. Berapa dompet Maya sekarang?
A: 15.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Udin lebih tinggi dari Wati. Wati lebih tinggi dari Sari. Sari lebih tinggi dari Kartika. Kartika lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Dewi lebih tua dari Andi. Andi lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Maya lebih cepat dari Nanda. Tono lebih cepat dari Maya. Siapa yang paling cepat antara Nanda dan Tono?
A: Tidak dapat dipastikan.
