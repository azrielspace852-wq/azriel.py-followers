# Dataset Reasoning 470

Q: Berapa hasil dari 6 dikali 7 ditambah 4?
A: 46.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Putri memiliki 15 tas. Dia memberikan 9 kepada Tono. Kemudian membeli 4 tas. Setelah itu memberikan 7 kepada Nanda. Berapa tas Putri sekarang?
A: 3.
Q: Dewi lebih tua dari Tono. Tono lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
Q: Indra lebih tinggi dari Budi. Budi lebih tinggi dari Candra. Candra lebih tinggi dari Nanda. Nanda lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Putri yang paling tua.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Jika 29 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 2.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
