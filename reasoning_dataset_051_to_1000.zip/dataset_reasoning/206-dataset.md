# Dataset Reasoning 206

Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Tono lebih tua dari Gita. Gita lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Eka lebih tinggi dari Joko. Joko lebih tinggi dari Putri. Putri lebih tinggi dari Kartika. Kartika lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Hadi lebih cepat dari Candra. Candra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Putri lebih cepat dari Wati. Udin lebih cepat dari Putri. Siapa yang paling cepat antara Wati dan Udin?
A: Tidak dapat dipastikan.
Q: Tono lebih tinggi dari Hadi. Hadi lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Andi lebih cepat dari Maya. Wati lebih cepat dari Andi. Siapa yang paling cepat antara Maya dan Wati?
A: Tidak dapat dipastikan.
Q: Putri menyukai Fajar. Fajar menyukai Budi. Apakah Putri menyukai Budi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Joko lebih tua dari Hadi. Hadi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Dewi lebih cepat dari Putri. Eka lebih cepat dari Dewi. Siapa yang paling cepat antara Putri dan Eka?
A: Tidak dapat dipastikan.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Gita lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Putri.
