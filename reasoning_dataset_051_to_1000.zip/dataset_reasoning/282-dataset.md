# Dataset Reasoning 282

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Berapa 6 ditambah 11 dikali 8?
A: 94.
Q: Berapa 2 ditambah 6 dikali 20?
A: 122.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Jika 29 dibagi 9, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 2.
Q: Jika 31 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 3.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Maya menyukai Rina. Rina menyukai Wati. Apakah Maya menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Hadi lebih tinggi dari Rina. Rina lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Andi lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Andi lebih tinggi dari Maya.
Q: Berapa harga Bitcoin sekarang?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
