# Dataset Reasoning 239

Q: Budi lebih cepat dari Lina. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Lina dan Hadi?
A: Tidak dapat dipastikan.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Wati tidak datang.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Berapa hasil dari 11 dikali 10 ditambah 7?
A: 117.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Joko. Siapa yang paling muda?
A: Joko.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Tono lebih tua dari Dewi. Dewi lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Udin lebih tua dari Maya. Maya lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Udin lebih cepat dari Hadi. Hadi lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
