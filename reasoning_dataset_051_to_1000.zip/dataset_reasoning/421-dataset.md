# Dataset Reasoning 421

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Candra lebih cepat dari Rina. Rina lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Putri menyukai Wati. Wati menyukai Udin. Apakah Putri menyukai Udin?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Hadi lebih tinggi dari Indra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Hadi lebih tinggi dari Indra.
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Candra lebih tua dari Wati. Wati lebih tua dari Sari. Sari lebih tua dari Maya. Siapa yang paling muda dan siapa yang paling tua?
A: Maya yang paling muda, Candra yang paling tua.
