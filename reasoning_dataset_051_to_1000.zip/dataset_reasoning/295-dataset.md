# Dataset Reasoning 295

Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Hadi lebih cepat dari Indra. Kartika lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Kartika?
A: Tidak dapat dipastikan.
Q: Hadi lebih tua dari Putri. Putri lebih tua dari Udin. Udin lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Hadi yang paling tua.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Berapa harga produk terbaru dari merek itu?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut dengan akurat.
Q: Wati lebih tinggi dari Kartika. Kartika lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Udin lebih tua dari Budi. Budi lebih tua dari Lina. Lina lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Udin yang paling tua.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Nanda lebih tinggi dari Candra. Candra lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Berapa hasil dari 6 dikali 7 ditambah 4?
A: 46.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
