# Dataset Reasoning 288

Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Andi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Rina memiliki 16 kunci. Dia memberikan 14 kepada Kartika. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Rina sekarang?
A: 3.
Q: Rina lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Putri.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Udin lebih cepat dari Maya. Rina lebih cepat dari Udin. Siapa yang paling cepat antara Maya dan Rina?
A: Tidak dapat dipastikan.
Q: Fajar lebih cepat dari Indra. Indra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Rina memiliki 25 jam. Dia memberikan 8 kepada Andi. Kemudian membeli 9 jam. Setelah itu memberikan 21 kepada Candra. Berapa jam Rina sekarang?
A: 5.
Q: Gita lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Putri.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Putri memiliki 22 kunci. Dia memberikan 9 kepada Tono. Kemudian membeli 12 kunci. Setelah itu memberikan 1 kepada Fajar. Berapa kunci Putri sekarang?
A: 24.
Q: Budi lebih tinggi dari Sari. Sari lebih tinggi dari Candra. Candra lebih tinggi dari Fajar. Fajar lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Nanda lebih cepat dari Lina. Lina lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
