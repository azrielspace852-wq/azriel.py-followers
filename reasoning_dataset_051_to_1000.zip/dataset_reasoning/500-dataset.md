# Dataset Reasoning 500

Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Gita lebih cepat dari Tono. Tono lebih cepat dari Wati. Siapa yang paling lambat?
A: Wati.
Q: Eka lebih tinggi dari Hadi. Hadi lebih tinggi dari Tono. Siapa yang paling pendek?
A: Tono.
Q: Putri menyukai Wati. Wati menyukai Udin. Apakah Putri menyukai Udin?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Sari memiliki 22 dompet. Dia memberikan 10 kepada Rina. Kemudian membeli 8 dompet. Setelah itu memberikan 9 kepada Putri. Berapa dompet Sari sekarang?
A: 11.
Q: Sari memiliki 22 tas. Dia memberikan 14 kepada Wati. Kemudian membeli 2 tas. Setelah itu memberikan 4 kepada Rina. Berapa tas Sari sekarang?
A: 6.
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Eka lebih cepat dari Wati. Hadi lebih cepat dari Eka. Siapa yang paling cepat antara Wati dan Hadi?
A: Tidak dapat dipastikan.
Q: Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Fajar. Fajar lebih tinggi dari Kartika. Kartika lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Candra lebih cepat dari Nanda. Udin lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Udin?
A: Tidak dapat dipastikan.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Wati lebih cepat dari Kartika. Kartika lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Berapa 11 ditambah 10 dikali 7?
A: 81.
