# Dataset Reasoning 071

Q: Kartika memiliki 12 hp. Dia memberikan 2 kepada Maya. Kemudian membeli 9 hp. Setelah itu memberikan 9 kepada Candra. Berapa hp Kartika sekarang?
A: 10.
Q: Eka lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Hadi lebih tinggi dari Sari. Sari lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Jika 43 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 14, sisa 1.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Berapa hasil dari 6 dikali 7 ditambah 4?
A: 46.
Q: Wati menyukai Candra. Candra menyukai Putri. Apakah Wati menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Fajar lebih tua dari Eka. Eka lebih tua dari Candra. Candra lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Fajar yang paling tua.
Q: Fajar memiliki 18 bola. Dia memberikan 4 kepada Gita. Kemudian membeli 10 bola. Setelah itu memberikan 23 kepada Rina. Berapa bola Fajar sekarang?
A: 1.
