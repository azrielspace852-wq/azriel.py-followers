# Dataset Reasoning 434

Q: Wati lebih tua dari Budi. Budi lebih tua dari Kartika. Kartika lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Wati yang paling tua.
Q: Wati menyukai Eka. Eka menyukai Hadi. Apakah Wati menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Hadi lebih cepat dari Indra. Nanda lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Nanda?
A: Tidak dapat dipastikan.
Q: Sari lebih tua dari Tono. Tono lebih tua dari Lina. Lina lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Sari yang paling tua.
Q: Hadi lebih cepat dari Indra. Kartika lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Kartika?
A: Tidak dapat dipastikan.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Berapa hasil dari 8 dikali 8 ditambah 15?
A: 79.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Gita menyukai Eka. Eka menyukai Andi. Apakah Gita menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
