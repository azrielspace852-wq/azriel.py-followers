# Dataset Reasoning 208

Q: Andi memiliki 22 celana. Dia memberikan 4 kepada Eka. Kemudian membeli 10 celana. Setelah itu memberikan 15 kepada Nanda. Berapa celana Andi sekarang?
A: 13.
Q: Eka memiliki 22 buku. Dia memberikan 2 kepada Joko. Kemudian membeli 11 buku. Setelah itu memberikan 12 kepada Kartika. Berapa buku Eka sekarang?
A: 19.
Q: Kartika menyukai Maya. Maya menyukai Indra. Apakah Kartika menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih tinggi dari Lina. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Lina.
Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Gita lebih cepat dari Rina. Rina lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Gita menyukai Putri. Putri menyukai Kartika. Apakah Gita menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Dewi lebih tinggi dari Hadi. Hadi lebih tinggi dari Udin. Siapa yang paling pendek?
A: Udin.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Jika 19 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 1.
Q: Maya lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Tono.
