# Dataset Reasoning 304

Q: Rina memiliki 12 hp. Dia memberikan 7 kepada Nanda. Kemudian membeli 12 hp. Setelah itu memberikan 4 kepada Indra. Berapa hp Rina sekarang?
A: 13.
Q: Wati menyukai Eka. Eka menyukai Hadi. Apakah Wati menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Fajar diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Putri lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Putri lebih tinggi dari Wati.
Q: Nanda lebih tua dari Dewi. Dewi lebih tua dari Hadi. Hadi lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Nanda yang paling tua.
Q: Berapa 2 ditambah 4 dikali 5?
A: 22.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Berapa 7 ditambah 4 dikali 12?
A: 55.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Joko lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Fajar. Fajar lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Jika 22 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 1.
