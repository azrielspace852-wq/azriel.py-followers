# Dataset Reasoning 103

Q: Wati memiliki 25 dompet. Dia memberikan 23 kepada Joko. Kemudian membeli 7 dompet. Setelah itu memberikan 7 kepada Putri. Berapa dompet Wati sekarang?
A: 2.
Q: Hadi lebih cepat dari Eka. Andi lebih cepat dari Hadi. Siapa yang paling cepat antara Eka dan Andi?
A: Tidak dapat dipastikan.
Q: Gita lebih cepat dari Rina. Rina lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Wati lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Kartika.
Q: Dewi menyukai Nanda. Nanda menyukai Hadi. Apakah Dewi menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Hadi memiliki 22 hp. Dia memberikan 11 kepada Maya. Kemudian membeli 5 hp. Setelah itu memberikan 12 kepada Hadi. Berapa hp Hadi sekarang?
A: 4.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Jika 31 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 7, sisa 3.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
