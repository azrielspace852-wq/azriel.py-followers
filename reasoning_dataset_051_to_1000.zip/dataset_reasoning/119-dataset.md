# Dataset Reasoning 119

Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
Q: Fajar lebih tinggi dari Nanda. Nanda lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Lina tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Lina tidak datang.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Berapa 8 ditambah 6 dikali 7?
A: 50.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Udin tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Dewi lebih cepat dari Putri. Eka lebih cepat dari Dewi. Siapa yang paling cepat antara Putri dan Eka?
A: Tidak dapat dipastikan.
Q: Nanda lebih cepat dari Candra. Candra lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
