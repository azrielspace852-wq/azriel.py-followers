# Dataset Reasoning 499

Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Maya memiliki 18 dompet. Dia memberikan 9 kepada Andi. Kemudian membeli 7 dompet. Setelah itu memberikan 2 kepada Tono. Berapa dompet Maya sekarang?
A: 14.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Tono. Tono lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Putri yang paling tua.
Q: Wati lebih tinggi dari Candra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Candra.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Gita lebih tua dari Dewi. Dewi lebih tua dari Udin. Siapa yang paling muda?
A: Udin.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Eka lebih tinggi dari Lina. Lina lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Hadi memiliki 25 tas. Dia memberikan 7 kepada Eka. Kemudian membeli 11 tas. Setelah itu memberikan 7 kepada Wati. Berapa tas Hadi sekarang?
A: 22.
Q: Joko lebih tua dari Indra. Indra lebih tua dari Eka. Eka lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Joko yang paling tua.
