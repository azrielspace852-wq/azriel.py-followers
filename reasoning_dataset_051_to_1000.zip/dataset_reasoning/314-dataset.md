# Dataset Reasoning 314

Q: Udin lebih cepat dari Indra. Indra lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Dewi lebih tinggi dari Andi. Andi lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Berapa 12 ditambah 6 dikali 12?
A: 84.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Kartika lebih tua dari Fajar. Fajar lebih tua dari Candra. Candra lebih tua dari Sari. Siapa yang paling muda dan siapa yang paling tua?
A: Sari yang paling muda, Kartika yang paling tua.
Q: Tono lebih tua dari Hadi. Hadi lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Wati diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Dewi lebih cepat dari Putri. Eka lebih cepat dari Dewi. Siapa yang paling cepat antara Putri dan Eka?
A: Tidak dapat dipastikan.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Indra lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
