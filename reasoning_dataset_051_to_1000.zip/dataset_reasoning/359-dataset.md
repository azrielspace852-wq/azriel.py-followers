# Dataset Reasoning 359

Q: Eka lebih tua dari Lina. Lina lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Kenapa es lebih berat dari air?
A: Premis tersebut tidak benar. Es kurang padat daripada air sehingga mengapung.
Q: Indra lebih tua dari Rina. Rina lebih tua dari Gita. Siapa yang paling muda?
A: Gita.
Q: Gita lebih tinggi dari Tono. Tono lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Budi lebih tinggi dari Wati. Wati lebih tinggi dari Rina. Rina lebih tinggi dari Sari. Sari lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Joko. Joko lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
