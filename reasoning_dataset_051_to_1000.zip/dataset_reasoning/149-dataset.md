# Dataset Reasoning 149

Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Wati lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Sari.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Maya lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Rina lebih tinggi dari Tono. Tono lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Udin lebih cepat dari Nanda. Nanda lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Wati menyukai Dewi. Dewi menyukai Fajar. Apakah Wati menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih tinggi dari Hadi. Hadi lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
