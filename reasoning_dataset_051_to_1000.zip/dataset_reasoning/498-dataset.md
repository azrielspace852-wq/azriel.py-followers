# Dataset Reasoning 498

Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Berapa hasil dari 2 dikali 11 ditambah 9?
A: 31.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Udin belajar selama dua minggu. Apakah Udin akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Hadi menyukai Indra. Indra menyukai Nanda. Apakah Hadi menyukai Nanda?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Rina lebih tua dari Candra. Candra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Maya lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Maya lebih tinggi dari Eka.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Udin lebih tua dari Tono. Tono lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Dewi memiliki 20 jam. Dia memberikan 1 kepada Lina. Kemudian membeli 6 jam. Setelah itu memberikan 18 kepada Indra. Berapa jam Dewi sekarang?
A: 7.
