# Dataset Reasoning 420

Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Udin diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Indra lebih tua dari Joko. Joko lebih tua dari Kartika. Kartika lebih tua dari Dewi. Siapa yang paling muda dan siapa yang paling tua?
A: Dewi yang paling muda, Indra yang paling tua.
Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Joko tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Hadi lebih cepat dari Joko. Wati lebih cepat dari Hadi. Siapa yang paling cepat antara Joko dan Wati?
A: Tidak dapat dipastikan.
Q: Budi lebih tua dari Wati. Wati lebih tua dari Lina. Lina lebih tua dari Joko. Siapa yang paling muda dan siapa yang paling tua?
A: Joko yang paling muda, Budi yang paling tua.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
