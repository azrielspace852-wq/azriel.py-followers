# Dataset Reasoning 070

Q: Tono belajar selama dua minggu. Apakah Tono akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Candra lebih cepat dari Nanda. Eka lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Eka?
A: Tidak dapat dipastikan.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Nanda memiliki 24 tas. Dia memberikan 5 kepada Sari. Kemudian membeli 3 tas. Setelah itu memberikan 9 kepada Indra. Berapa tas Nanda sekarang?
A: 13.
Q: Nanda lebih tinggi dari Fajar. Fajar lebih tinggi dari Putri. Siapa yang paling pendek?
A: Putri.
Q: Hadi lebih cepat dari Indra. Nanda lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Nanda?
A: Tidak dapat dipastikan.
Q: Berapa 8 ditambah 7 dikali 14?
A: 106.
Q: Tono tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Tono tidak datang.
Q: Eka lebih tua dari Hadi. Hadi lebih tua dari Tono. Siapa yang paling muda?
A: Tono.
Q: Kartika lebih tua dari Dewi. Dewi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
Q: Maya lebih tua dari Putri. Putri lebih tua dari Sari. Siapa yang paling muda?
A: Sari.
Q: Budi belajar selama dua minggu. Apakah Budi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
