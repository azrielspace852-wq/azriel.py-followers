# Dataset Reasoning 332

Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Lina lebih tua dari Indra. Indra lebih tua dari Budi. Siapa yang paling muda?
A: Budi.
Q: Fajar memiliki 18 tas. Dia memberikan 11 kepada Nanda. Kemudian membeli 12 tas. Setelah itu memberikan 4 kepada Rina. Berapa tas Fajar sekarang?
A: 15.
Q: Candra menyukai Nanda. Nanda menyukai Udin. Apakah Candra menyukai Udin?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Dewi memiliki 24 kemeja. Dia memberikan 20 kepada Tono. Kemudian membeli 8 kemeja. Setelah itu memberikan 2 kepada Gita. Berapa kemeja Dewi sekarang?
A: 10.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Putri memiliki 18 celana. Dia memberikan 8 kepada Joko. Kemudian membeli 12 celana. Setelah itu memberikan 3 kepada Nanda. Berapa celana Putri sekarang?
A: 19.
Q: Eka lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
