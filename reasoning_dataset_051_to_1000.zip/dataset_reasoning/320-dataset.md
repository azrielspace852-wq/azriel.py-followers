# Dataset Reasoning 320

Q: Maya memiliki 22 tas. Dia memberikan 19 kepada Andi. Kemudian membeli 11 tas. Setelah itu memberikan 11 kepada Rina. Berapa tas Maya sekarang?
A: 3.
Q: Rina lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Hadi.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Gita lebih tua dari Wati. Wati lebih tua dari Tono. Siapa yang paling muda?
A: Tono.
Q: Sari tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Sari tidak datang.
Q: Rina lebih cepat dari Tono. Tono lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Lina memiliki 11 apel. Dia memberikan 6 kepada Maya. Kemudian membeli 10 apel. Setelah itu memberikan 11 kepada Indra. Berapa apel Lina sekarang?
A: 4.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Wati lebih cepat dari Dewi. Fajar lebih cepat dari Wati. Siapa yang paling cepat antara Dewi dan Fajar?
A: Tidak dapat dipastikan.
