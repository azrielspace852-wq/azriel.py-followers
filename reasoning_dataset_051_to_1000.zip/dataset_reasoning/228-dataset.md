# Dataset Reasoning 228

Q: Siapa presiden Indonesia sekarang?
A: Saya perlu mencari informasi terbaru untuk memastikan jawaban yang akurat.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Semua siswa lulus. Andi adalah siswa. Apakah Andi lulus?
A: Ya, berdasarkan premis tersebut Andi lulus.
Q: Candra memiliki 10 pensil. Dia memberikan 6 kepada Indra. Kemudian membeli 11 pensil. Setelah itu memberikan 3 kepada Wati. Berapa pensil Candra sekarang?
A: 12.
Q: Dewi memiliki 20 jam. Dia memberikan 1 kepada Lina. Kemudian membeli 6 jam. Setelah itu memberikan 18 kepada Indra. Berapa jam Dewi sekarang?
A: 7.
Q: Fajar menyukai Candra. Candra menyukai Joko. Apakah Fajar menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kartika lebih tua dari Eka. Eka lebih tua dari Putri. Putri lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Kartika yang paling tua.
Q: Candra lebih tua dari Sari. Sari lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Nanda lebih tinggi dari Andi. Andi lebih tinggi dari Fajar. Fajar lebih tinggi dari Kartika. Kartika lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Hadi memiliki 22 hp. Dia memberikan 11 kepada Maya. Kemudian membeli 5 hp. Setelah itu memberikan 12 kepada Hadi. Berapa hp Hadi sekarang?
A: 4.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
