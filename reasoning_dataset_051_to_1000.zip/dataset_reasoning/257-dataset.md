# Dataset Reasoning 257

Q: Nanda lebih tua dari Fajar. Fajar lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Tono lebih tua dari Eka. Eka lebih tua dari Rina. Siapa yang paling muda?
A: Rina.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Eka tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Eka tidak datang.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Apakah saya akan sukses tahun depan?
A: Saya tidak dapat memastikan masa depan seseorang.
Q: Dewi lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Dewi lebih tinggi dari Putri.
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Hadi lebih cepat dari Rina. Rina lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
