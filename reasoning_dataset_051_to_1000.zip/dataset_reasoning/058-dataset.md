# Dataset Reasoning 058

Q: Jika 19 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 4, sisa 3.
Q: Andi lebih cepat dari Dewi. Dewi lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Joko lebih cepat dari Candra. Candra lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Nanda tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Andi lebih cepat dari Maya. Wati lebih cepat dari Andi. Siapa yang paling cepat antara Maya dan Wati?
A: Tidak dapat dipastikan.
Q: Tono tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Joko diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Nanda tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Nanda tidak datang.
Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya apa yang Anda makan.
Q: Putri lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Joko memiliki 11 jam. Dia memberikan 3 kepada Dewi. Kemudian membeli 2 jam. Setelah itu memberikan 1 kepada Dewi. Berapa jam Joko sekarang?
A: 9.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Berapa 3 ditambah 10 dikali 7?
A: 73.
