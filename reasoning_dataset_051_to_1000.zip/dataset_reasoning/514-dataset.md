# Dataset Reasoning 514

Q: Berapa hasil dari 11 dikali 3 ditambah 2?
A: 35.
Q: Tono memiliki 8 kunci. Dia memberikan 3 kepada Fajar. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Tono sekarang?
A: 6.
Q: Hadi menyukai Indra. Indra menyukai Sari. Apakah Hadi menyukai Sari?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Joko lebih cepat dari Wati. Gita lebih cepat dari Joko. Siapa yang paling cepat antara Wati dan Gita?
A: Tidak dapat dipastikan.
Q: Dewi lebih tua dari Maya. Maya lebih tua dari Andi. Andi lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Dewi yang paling tua.
Q: Wati belajar selama dua minggu. Apakah Wati akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tono memiliki 12 kunci. Dia memberikan 5 kepada Eka. Kemudian membeli 2 kunci. Setelah itu memberikan 1 kepada Rina. Berapa kunci Tono sekarang?
A: 8.
Q: Berapa 2 ditambah 11 dikali 18?
A: 200.
Q: Hitung dong.
A: Bisa. Apa yang ingin dihitung?
Q: Maya lebih cepat dari Putri. Putri lebih cepat dari Sari. Siapa yang paling lambat?
A: Sari.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Budi lebih tinggi dari Wati. Wati lebih tinggi dari Rina. Rina lebih tinggi dari Sari. Sari lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tono lebih cepat dari Hadi. Rina lebih cepat dari Tono. Siapa yang paling cepat antara Hadi dan Rina?
A: Tidak dapat dipastikan.
