# Dataset Reasoning 077

Q: Jika 28 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 9, sisa 1.
Q: Fajar memiliki 21 pensil. Dia memberikan 19 kepada Fajar. Kemudian membeli 12 pensil. Setelah itu memberikan 13 kepada Candra. Berapa pensil Fajar sekarang?
A: 1.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Indra lebih tinggi dari Joko. Joko lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Putri memiliki 15 tas. Dia memberikan 9 kepada Tono. Kemudian membeli 4 tas. Setelah itu memberikan 7 kepada Nanda. Berapa tas Putri sekarang?
A: 3.
Q: Lina tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Udin lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Udin lebih tinggi dari Maya.
Q: Berapa 2 ditambah 4 dikali 9?
A: 38.
