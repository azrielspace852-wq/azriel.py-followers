# Dataset Reasoning 493

Q: Fajar lebih cepat dari Indra. Indra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Hadi lebih cepat dari Wati. Wati lebih cepat dari Eka. Siapa yang paling lambat?
A: Eka.
Q: Berapa hasil dari 8 dikali 8 ditambah 15?
A: 79.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Udin lebih cepat dari Gita. Putri lebih cepat dari Udin. Siapa yang paling cepat antara Gita dan Putri?
A: Tidak dapat dipastikan.
Q: Gita lebih tinggi dari Sari. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Gita lebih tinggi dari Sari.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Hadi lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Wati tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Wati tidak datang.
Q: Wati lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Udin.
Q: Candra lebih tinggi dari Kartika. Kartika lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Putri lebih cepat dari Lina. Lina lebih cepat dari Fajar. Siapa yang paling lambat?
A: Fajar.
Q: Berapa hasil dari 3 dikali 8 ditambah 4?
A: 28.
