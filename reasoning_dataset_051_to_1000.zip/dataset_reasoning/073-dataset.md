# Dataset Reasoning 073

Q: Rina lebih cepat dari Candra. Candra lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Kartika memiliki 22 dompet. Dia memberikan 18 kepada Tono. Kemudian membeli 9 dompet. Setelah itu memberikan 6 kepada Maya. Berapa dompet Kartika sekarang?
A: 7.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Joko lebih tinggi dari Wati. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Joko lebih tinggi dari Wati.
Q: Hadi menyukai Joko. Joko menyukai Wati. Apakah Hadi menyukai Wati?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin lebih cepat dari Gita. Putri lebih cepat dari Udin. Siapa yang paling cepat antara Gita dan Putri?
A: Tidak dapat dipastikan.
Q: Berapa 7 ditambah 8 dikali 11?
A: 95.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tono lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Tono lebih tinggi dari Hadi.
Q: Putri lebih cepat dari Candra. Joko lebih cepat dari Putri. Siapa yang paling cepat antara Candra dan Joko?
A: Tidak dapat dipastikan.
Q: Wati lebih tua dari Budi. Budi lebih tua dari Kartika. Kartika lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Wati yang paling tua.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Maya menyukai Nanda. Nanda menyukai Tono. Apakah Maya menyukai Tono?
A: Tidak dapat disimpulkan dari informasi tersebut.
