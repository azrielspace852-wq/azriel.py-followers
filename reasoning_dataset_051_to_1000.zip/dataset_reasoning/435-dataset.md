# Dataset Reasoning 435

Q: Maya lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Fajar. Fajar lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Nanda lebih cepat dari Maya. Fajar lebih cepat dari Nanda. Siapa yang paling cepat antara Maya dan Fajar?
A: Tidak dapat dipastikan.
Q: Mengapa matahari mengelilingi bumi?
A: Premis pertanyaan tersebut salah. Bumi yang mengelilingi matahari, bukan sebaliknya.
Q: Gita lebih tua dari Tono. Tono lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Budi menyukai Hadi. Hadi menyukai Rina. Apakah Budi menyukai Rina?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Eka memiliki 20 bola. Dia memberikan 8 kepada Putri. Kemudian membeli 9 bola. Setelah itu memberikan 19 kepada Indra. Berapa bola Eka sekarang?
A: 2.
Q: Rina lebih cepat dari Andi. Maya lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Maya?
A: Tidak dapat dipastikan.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Hadi lebih tinggi dari Wati. Wati lebih tinggi dari Eka. Siapa yang paling pendek?
A: Eka.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
