# Dataset Reasoning 522

Q: Maya lebih tua dari Candra. Candra lebih tua dari Tono. Siapa yang paling muda?
A: Tono.
Q: Udin lebih tinggi dari Maya. Maya lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Andi menyukai Lina. Lina menyukai Joko. Apakah Andi menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Maya lebih cepat dari Dewi. Dewi lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Siapa yang memenangkan pertandingan sepak bola kemarin?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Maya belajar selama dua minggu. Apakah Maya akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Tono lebih cepat dari Sari. Sari lebih cepat dari Andi. Siapa yang paling lambat?
A: Andi.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
