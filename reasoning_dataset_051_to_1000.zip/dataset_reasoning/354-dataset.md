# Dataset Reasoning 354

Q: Andi lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Indra lebih tinggi dari Putri. Putri lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Candra lebih cepat dari Sari. Sari lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Indra lebih tinggi dari Tono. Tono lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Bandingkan keduanya.
A: Bisa. Kedua hal apa yang ingin dibandingkan?
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Kartika lebih tua dari Eka. Eka lebih tua dari Putri. Putri lebih tua dari Candra. Siapa yang paling muda dan siapa yang paling tua?
A: Candra yang paling muda, Kartika yang paling tua.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Candra menyukai Budi. Budi menyukai Andi. Apakah Candra menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Ceritakan lebih detail.
A: Bisa. Tentang topik apa yang ingin diceritakan lebih detail?
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Jika 21 dibagi 4, berapa hasilnya dan sisanya?
A: Hasil bagi 5, sisa 1.
