# Dataset Reasoning 062

Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Lina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Fajar lebih tua dari Nanda. Nanda lebih tua dari Kartika. Siapa yang paling muda?
A: Kartika.
Q: Berapa nomor telepon saya?
A: Saya tidak tahu nomor telepon Anda.
Q: Tono menyukai Putri. Putri menyukai Fajar. Apakah Tono menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Tono lebih tinggi dari Indra. Indra lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Rina memiliki 16 kunci. Dia memberikan 14 kepada Kartika. Kemudian membeli 4 kunci. Setelah itu memberikan 3 kepada Dewi. Berapa kunci Rina sekarang?
A: 3.
Q: Putri menyukai Fajar. Fajar menyukai Budi. Apakah Putri menyukai Budi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Berapa hasil dari 3 dikali 10 ditambah 7?
A: 37.
Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Budi tidak datang.
Q: Fajar lebih cepat dari Indra. Indra lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
