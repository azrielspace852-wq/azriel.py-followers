# Dataset Reasoning 113

Q: Maya lebih tua dari Budi. Budi lebih tua dari Nanda. Nanda lebih tua dari Andi. Siapa yang paling muda dan siapa yang paling tua?
A: Andi yang paling muda, Maya yang paling tua.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Eka memiliki 20 bola. Dia memberikan 8 kepada Putri. Kemudian membeli 9 bola. Setelah itu memberikan 19 kepada Indra. Berapa bola Eka sekarang?
A: 2.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Fajar lebih tua dari Indra. Indra lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Apakah website pemerintah sedang down?
A: Saya perlu memeriksa status terbaru melalui pencarian eksternal.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Andi lebih tinggi dari Putri. Putri lebih tinggi dari Dewi. Dewi lebih tinggi dari Candra. Candra lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Candra lebih cepat dari Sari. Sari lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Hadi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Lina lebih tinggi dari Joko. Joko lebih tinggi dari Hadi. Hadi lebih tinggi dari Tono. Tono lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Rina diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
