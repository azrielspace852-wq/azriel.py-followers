# Dataset Reasoning 214

Q: Hadi lebih tinggi dari Eka. Eka lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Joko lebih tua dari Maya. Maya lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Berapa hasil dari 7 dikali 4 ditambah 18?
A: 46.
Q: Indra diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Indra tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Dewi memiliki 24 kemeja. Dia memberikan 20 kepada Tono. Kemudian membeli 8 kemeja. Setelah itu memberikan 2 kepada Gita. Berapa kemeja Dewi sekarang?
A: 10.
Q: Wati lebih cepat dari Dewi. Fajar lebih cepat dari Wati. Siapa yang paling cepat antara Dewi dan Fajar?
A: Tidak dapat dipastikan.
Q: Joko memiliki 17 kemeja. Dia memberikan 4 kepada Udin. Kemudian membeli 8 kemeja. Setelah itu memberikan 8 kepada Lina. Berapa kemeja Joko sekarang?
A: 13.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Maya memiliki 22 dompet. Dia memberikan 3 kepada Lina. Kemudian membeli 4 dompet. Setelah itu memberikan 8 kepada Candra. Berapa dompet Maya sekarang?
A: 15.
Q: Hadi memiliki 9 hp. Dia memberikan 5 kepada Lina. Kemudian membeli 9 hp. Setelah itu memberikan 5 kepada Hadi. Berapa hp Hadi sekarang?
A: 8.
