# Dataset Reasoning 373

Q: Tono lebih cepat dari Hadi. Hadi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Wati lebih tinggi dari Eka. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Eka.
Q: Maya memiliki 22 dompet. Dia memberikan 3 kepada Lina. Kemudian membeli 4 dompet. Setelah itu memberikan 8 kepada Candra. Berapa dompet Maya sekarang?
A: 15.
Q: Nanda lebih cepat dari Udin. Kartika lebih cepat dari Nanda. Siapa yang paling cepat antara Udin dan Kartika?
A: Tidak dapat dipastikan.
Q: Semua siswa di kelas ini lulus. Tidak semua yang lulus adalah siswa di kelas ini. Apakah semua yang lulus adalah siswa di kelas ini?
A: Tidak.
Q: Fajar lebih tinggi dari Sari. Sari lebih tinggi dari Dewi. Siapa yang paling pendek?
A: Dewi.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Hadi lebih tua dari Candra. Candra lebih tua dari Putri. Siapa yang paling muda?
A: Putri.
Q: Indra lebih tinggi dari Sari. Sari lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
Q: Wati lebih tua dari Rina. Rina lebih tua dari Sari. Sari lebih tua dari Eka. Siapa yang paling muda dan siapa yang paling tua?
A: Eka yang paling muda, Wati yang paling tua.
Q: Budi lebih tinggi dari Andi. Andi lebih tinggi dari Kartika. Kartika lebih tinggi dari Eka. Eka lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Tidak ada burung yang bisa berenang. Penguin adalah burung. Apakah penguin bisa berenang?
A: Berdasarkan premis formal, tidak. Namun premis tersebut bertentangan dengan fakta bahwa penguin bisa berenang.
Q: Tono lebih tinggi dari Putri. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Tono lebih tinggi dari Putri.
Q: Kartika lebih tua dari Maya. Maya lebih tua dari Indra. Siapa yang paling muda?
A: Indra.
