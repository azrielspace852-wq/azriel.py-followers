# Dataset Reasoning 080

Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Sari memiliki 22 tas. Dia memberikan 14 kepada Wati. Kemudian membeli 2 tas. Setelah itu memberikan 4 kepada Rina. Berapa tas Sari sekarang?
A: 6.
Q: Budi lebih tua dari Putri. Putri lebih tua dari Dewi. Dewi lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Budi yang paling tua.
Q: Hadi lebih tinggi dari Indra. Indra lebih tinggi dari Fajar. Fajar lebih tinggi dari Dewi. Dewi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Indra lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Wati lebih cepat dari Sari. Nanda lebih cepat dari Wati. Siapa yang paling cepat antara Sari dan Nanda?
A: Tidak dapat dipastikan.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Apa warna baju yang saya pakai?
A: Saya tidak tahu. Anda belum memberikan informasi atau gambar yang memungkinkan saya mengetahui warna baju Anda.
Q: Sari memiliki 11 sepatu. Dia memberikan 9 kepada Putri. Kemudian membeli 8 sepatu. Setelah itu memberikan 4 kepada Putri. Berapa sepatu Sari sekarang?
A: 6.
Q: Rina menyukai Putri. Putri menyukai Indra. Apakah Rina menyukai Indra?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Sari tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Sari tidak datang.
Q: Udin memiliki 8 kemeja. Dia memberikan 3 kepada Rina. Kemudian membeli 6 kemeja. Setelah itu memberikan 10 kepada Eka. Berapa kemeja Udin sekarang?
A: 1.
