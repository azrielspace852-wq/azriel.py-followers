# Dataset Reasoning 388

Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Semua kucing adalah mamalia. Tidak semua mamalia adalah kucing. Apakah semua mamalia adalah kucing?
A: Tidak.
Q: Dewi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Dewi tidak datang.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Fajar menyukai Sari. Sari menyukai Putri. Apakah Fajar menyukai Putri?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Dewi lebih cepat dari Maya. Maya lebih cepat dari Indra. Siapa yang paling lambat?
A: Indra.
Q: Lina memiliki 18 kunci. Dia memberikan 6 kepada Kartika. Kemudian membeli 9 kunci. Setelah itu memberikan 7 kepada Indra. Berapa kunci Lina sekarang?
A: 14.
Q: Candra lebih tua dari Joko. Joko lebih tua dari Putri. Putri lebih tua dari Tono. Siapa yang paling muda dan siapa yang paling tua?
A: Tono yang paling muda, Candra yang paling tua.
Q: Berapa 7 ditambah 4 dikali 12?
A: 55.
Q: Hadi memiliki 22 hp. Dia memberikan 11 kepada Maya. Kemudian membeli 5 hp. Setelah itu memberikan 12 kepada Hadi. Berapa hp Hadi sekarang?
A: 4.
Q: Kartika lebih tinggi dari Dewi. Dewi lebih tinggi dari Joko. Siapa yang paling pendek?
A: Joko.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Berapa hasilnya?
A: Bisa. Hasil dari perhitungan atau soal yang mana?
