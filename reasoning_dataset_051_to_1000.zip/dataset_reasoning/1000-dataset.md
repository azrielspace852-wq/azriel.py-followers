# Dataset Reasoning 1000

Q: Indra memiliki 11 tas. Dia memberikan 4 kepada Lina. Kemudian membeli 3 apel. Setelah itu memberikan 3 kepada Tono. Berapa sekarang?
A: 7.
Q: Eka lebih cepat dari Wati. Wati lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Hadi memiliki 13 kunci. Dia memberikan 4 kepada Putri. Kemudian membeli 7 tas. Setelah itu memberikan 1 kepada Wati. Berapa sekarang?
A: 15.
Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Tidak dapat disimpulkan bahwa semua A adalah C.
Q: Andi memiliki 16 apel. Dia memberikan 3 kepada Sari. Kemudian membeli 7 kunci. Setelah itu memberikan 4 kepada Gita. Berapa sekarang?
A: 16.
Q: Andi lebih cepat dari Fajar. Fajar lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Kartika lebih cepat dari Gita. Gita lebih cepat dari Hadi. Siapa yang paling lambat?
A: Hadi.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Maya lebih cepat dari Gita. Gita lebih cepat dari Budi. Siapa yang paling lambat?
A: Budi.
Q: Jelaskan teori Xylarion.
A: Saya tidak mengenali teori Xylarion sebagai konsep yang dapat saya pastikan. Jika Anda memberikan sumber atau konteksnya, saya bisa membantu menganalisisnya.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Eka lebih tinggi dari Putri. Putri lebih tinggi dari Fajar. Siapa yang paling pendek?
A: Fajar.
Q: Kartika lebih tinggi dari Eka. Eka lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
Q: Candra lebih tinggi dari Putri. Putri lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
