# Dataset Reasoning 390

Q: Andi lebih tua dari Dewi. Dewi lebih tua dari Lina. Siapa yang paling muda?
A: Lina.
Q: Berapa hasil dari 7 dikali 4 ditambah 18?
A: 46.
Q: Berapa hasil dari 12 dikali 12 ditambah 19?
A: 163.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Wati menyukai Dewi. Dewi menyukai Fajar. Apakah Wati menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Apakah hujan akan turun minggu depan di kota saya?
A: Saya tidak dapat memastikan prakiraan cuaca jauh ke depan tanpa data terbaru, dan cuaca tetap bersifat probabilistik.
Q: Bukannya Indonesia terletak di Eropa?
A: Tidak. Indonesia terletak di Asia Tenggara.
Q: Rina lebih tua dari Sari. Sari lebih tua dari Joko. Joko lebih tua dari Budi. Siapa yang paling muda dan siapa yang paling tua?
A: Budi yang paling muda, Rina yang paling tua.
Q: Tono lebih tinggi dari Eka. Eka lebih tinggi dari Rina. Siapa yang paling pendek?
A: Rina.
Q: Rina lebih tinggi dari Candra. Candra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Nanda belajar selama dua minggu. Apakah Nanda akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda memiliki 24 tas. Dia memberikan 5 kepada Sari. Kemudian membeli 3 tas. Setelah itu memberikan 9 kepada Indra. Berapa tas Nanda sekarang?
A: 13.
Q: Indra lebih tua dari Candra. Candra lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Putri lebih tua dari Udin. Udin lebih tua dari Gita. Gita lebih tua dari Kartika. Siapa yang paling muda dan siapa yang paling tua?
A: Kartika yang paling muda, Putri yang paling tua.
