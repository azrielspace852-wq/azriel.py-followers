# Dataset Reasoning 353

Q: Hadi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Andi lebih tinggi dari Putri. Putri lebih tinggi dari Dewi. Dewi lebih tinggi dari Candra. Candra lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Joko belajar selama dua minggu. Apakah Joko akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Joko. Joko lebih tinggi dari Eka. Eka lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Fajar lebih tinggi dari Candra. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Fajar lebih tinggi dari Candra.
Q: Hadi menyukai Gita. Gita menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jika 19 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 1.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Lina lebih tinggi dari Indra. Indra lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Andi lebih cepat dari Lina. Joko lebih cepat dari Andi. Siapa yang paling cepat antara Lina dan Joko?
A: Tidak dapat dipastikan.
Q: Apa yang sedang dilakukan orang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Kenapa air mendidih pada 50 derajat Celsius?
A: Premis tersebut tidak tepat. Air murni mendidih pada sekitar 100 derajat Celsius di tekanan standar.
Q: Hadi lebih tinggi dari Fajar. Fajar lebih tinggi dari Nanda. Nanda lebih tinggi dari Rina. Rina lebih tinggi dari Sari. Siapa yang paling pendek?
A: Sari.
