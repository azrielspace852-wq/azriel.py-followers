# Dataset Reasoning 123

Q: Nanda lebih tua dari Dewi. Dewi lebih tua dari Hadi. Hadi lebih tua dari Wati. Siapa yang paling muda dan siapa yang paling tua?
A: Wati yang paling muda, Nanda yang paling tua.
Q: Tono lebih tua dari Eka. Eka lebih tua dari Rina. Siapa yang paling muda?
A: Rina.
Q: Andi lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Candra memiliki 25 bola. Dia memberikan 1 kepada Dewi. Kemudian membeli 10 bola. Setelah itu memberikan 27 kepada Putri. Berapa bola Candra sekarang?
A: 7.
Q: Gita lebih cepat dari Sari. Rina lebih cepat dari Gita. Siapa yang paling cepat antara Sari dan Rina?
A: Tidak dapat dipastikan.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Wati menyukai Eka. Eka menyukai Hadi. Apakah Wati menyukai Hadi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Nanda memiliki 13 dompet. Dia memberikan 5 kepada Dewi. Kemudian membeli 2 dompet. Setelah itu memberikan 3 kepada Candra. Berapa dompet Nanda sekarang?
A: 7.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Nanda menyukai Udin. Udin menyukai Gita. Apakah Nanda menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Jelaskan fenomena Atmosfera Biru Kuantum.
A: Saya tidak mengenali fenomena tersebut sebagai konsep ilmiah yang dapat dipastikan. Jika ada sumber, silakan bagikan.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
