# Dataset Reasoning 100

Q: Apakah toko tersebut buka sekarang?
A: Saya tidak dapat memastikan statusnya saat ini tanpa informasi terbaru atau pencarian eksternal.
Q: Sari memiliki 22 dompet. Dia memberikan 10 kepada Rina. Kemudian membeli 8 dompet. Setelah itu memberikan 9 kepada Putri. Berapa dompet Sari sekarang?
A: 11.
Q: Candra lebih tinggi dari Rina. Rina lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Joko lebih cepat dari Sari. Sari lebih cepat dari Gita. Siapa yang paling lambat?
A: Gita.
Q: Gita lebih tua dari Wati. Wati lebih tua dari Tono. Siapa yang paling muda?
A: Tono.
Q: Putri lebih cepat dari Eka. Eka lebih cepat dari Nanda. Siapa yang paling lambat?
A: Nanda.
Q: Joko tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Joko tidak datang.
Q: Gita belajar selama dua minggu. Apakah Gita akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Tolong jelaskan itu.
A: Bisa. Maksud Anda itu yang mana? Mohon beri konteks lebih lanjut.
Q: Nanda memiliki 23 celana. Dia memberikan 18 kepada Tono. Kemudian membeli 10 celana. Setelah itu memberikan 6 kepada Kartika. Berapa celana Nanda sekarang?
A: 9.
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Semua buah apel berwarna merah. Tidak semua yang berwarna merah adalah apel. Apakah semua yang berwarna merah adalah apel?
A: Tidak.
Q: Rina lebih cepat dari Andi. Maya lebih cepat dari Rina. Siapa yang paling cepat antara Andi dan Maya?
A: Tidak dapat dipastikan.
