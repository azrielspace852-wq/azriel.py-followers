# Dataset Reasoning 306

Q: Hadi menyukai Indra. Indra menyukai Kartika. Apakah Hadi menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Fajar belajar selama dua minggu. Apakah Fajar akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Wati lebih tinggi dari Kartika. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Wati lebih tinggi dari Kartika.
Q: Dewi lebih tinggi dari Tono. Tono lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Nanda lebih tinggi dari Udin. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Udin.
Q: Mengapa manusia hanya punya tiga jari?
A: Premis pertanyaan salah. Manusia normal memiliki lima jari di setiap tangan.
Q: Jika 38 dibagi 2, berapa hasilnya dan sisanya?
A: Hasil bagi 19, sisa 0.
Q: Gita lebih cepat dari Wati. Wati lebih cepat dari Tono. Siapa yang paling lambat?
A: Tono.
Q: Budi lebih cepat dari Tono. Hadi lebih cepat dari Budi. Siapa yang paling cepat antara Tono dan Hadi?
A: Tidak dapat dipastikan.
Q: Putri belajar selama dua minggu. Apakah Putri akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Hadi belajar selama dua minggu. Apakah Hadi akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Hadi lebih tua dari Rina. Rina lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu apa yang sedang Anda pikirkan.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
