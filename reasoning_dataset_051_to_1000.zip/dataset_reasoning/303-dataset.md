# Dataset Reasoning 303

Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Dewi menyukai Putri. Putri menyukai Eka. Apakah Dewi menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Siapa penemu mesin Quorvex?
A: Saya tidak memiliki informasi tentang mesin atau penemu bernama Quorvex.
Q: Rina belajar selama dua minggu. Apakah Rina akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Jika 43 dibagi 3, berapa hasilnya dan sisanya?
A: Hasil bagi 14, sisa 1.
Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Jika belajar maka lulus. Andi lulus. Apakah Andi belajar?
A: Tidak dapat disimpulkan. Ada kemungkinan cara lain untuk lulus.
Q: Budi diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Indra menyukai Maya. Maya menyukai Kartika. Apakah Indra menyukai Kartika?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Tono lebih tinggi dari Andi. Andi lebih tinggi dari Candra. Siapa yang paling pendek?
A: Candra.
Q: Kartika tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Kartika tidak datang.
Q: Jika 44 dibagi 5, berapa hasilnya dan sisanya?
A: Hasil bagi 8, sisa 4.
