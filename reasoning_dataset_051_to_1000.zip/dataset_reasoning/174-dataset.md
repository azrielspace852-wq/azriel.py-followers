# Dataset Reasoning 174

Q: Hadi tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Candra lebih tua dari Udin. Udin lebih tua dari Eka. Eka lebih tua dari Lina. Siapa yang paling muda dan siapa yang paling tua?
A: Lina yang paling muda, Candra yang paling tua.
Q: Hadi menyukai Gita. Gita menyukai Andi. Apakah Hadi menyukai Andi?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Sari diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Jika 39 dibagi 6, berapa hasilnya dan sisanya?
A: Hasil bagi 6, sisa 3.
Q: Hadi memiliki 8 hp. Dia memberikan 2 kepada Kartika. Kemudian membeli 2 hp. Setelah itu memberikan 3 kepada Andi. Berapa hp Hadi sekarang?
A: 5.
Q: Bukannya air membeku di 100 derajat?
A: Tidak. Air membeku di sekitar 0 derajat Celsius. 100 derajat adalah titik didih.
Q: Dewi lebih tinggi dari Candra. Candra lebih tinggi dari Eka. Eka lebih tinggi dari Budi. Budi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Joko diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
