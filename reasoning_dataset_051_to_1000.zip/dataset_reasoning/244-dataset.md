# Dataset Reasoning 244

Q: Berapa 3 ditambah 4 dikali 1?
A: 7.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Joko lebih tinggi dari Lina. Lina lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Semua burung bisa terbang. Tidak semua yang bisa terbang adalah burung. Apakah semua yang bisa terbang adalah burung?
A: Tidak.
Q: Berapa hasil dari 7 dikali 8 ditambah 11?
A: 67.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Semua dokter adalah orang pintar. Tidak semua orang pintar adalah dokter. Apakah semua orang pintar adalah dokter?
A: Tidak.
Q: Nanda lebih tinggi dari Putri. Putri lebih tinggi dari Budi. Siapa yang paling pendek?
A: Budi.
Q: Hadi lebih cepat dari Indra. Nanda lebih cepat dari Hadi. Siapa yang paling cepat antara Indra dan Nanda?
A: Tidak dapat dipastikan.
Q: Wati tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Wati tidak datang.
Q: Rina menyukai Andi. Andi menyukai Maya. Apakah Rina menyukai Maya?
A: Tidak dapat disimpulkan dari informasi tersebut.
