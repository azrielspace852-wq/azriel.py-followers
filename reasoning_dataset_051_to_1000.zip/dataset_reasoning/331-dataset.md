# Dataset Reasoning 331

Q: Jika 23 dibagi 7, berapa hasilnya dan sisanya?
A: Hasil bagi 3, sisa 2.
Q: Di mana saya menyimpan kunci saya?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.
Q: Andi menyukai Lina. Lina menyukai Joko. Apakah Andi menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Putri lebih tua dari Tono. Tono lebih tua dari Dewi. Siapa yang paling muda?
A: Dewi.
Q: Berapa hasil dari 2 dikali 4 ditambah 5?
A: 13.
Q: Berapa 9 ditambah 11 dikali 15?
A: 174.
Q: Budi lebih tinggi dari Hadi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Hadi.
Q: Joko lebih tinggi dari Gita. Gita lebih tinggi dari Budi. Budi lebih tinggi dari Tono. Tono lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Eka memiliki 20 bola. Dia memberikan 8 kepada Putri. Kemudian membeli 9 bola. Setelah itu memberikan 19 kepada Indra. Berapa bola Eka sekarang?
A: 2.
Q: Tono lebih cepat dari Eka. Eka lebih cepat dari Rina. Siapa yang paling lambat?
A: Rina.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Joko lebih cepat dari Maya. Maya lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Nanda lebih tinggi dari Lina. Lina lebih tinggi dari Wati. Siapa yang paling pendek?
A: Wati.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
