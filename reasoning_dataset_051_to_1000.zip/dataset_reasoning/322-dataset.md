# Dataset Reasoning 322

Q: Udin lebih tinggi dari Indra. Indra lebih tinggi dari Andi. Siapa yang paling pendek?
A: Andi.
Q: Kartika menyukai Maya. Maya menyukai Fajar. Apakah Kartika menyukai Fajar?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Udin tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Udin tidak datang.
Q: Udin lebih tua dari Indra. Indra lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Apa isi buku kuno Eldrinox?
A: Saya tidak memiliki informasi tentang buku bernama Eldrinox.
Q: Indra memiliki 19 bola. Dia memberikan 15 kepada Dewi. Kemudian membeli 6 bola. Setelah itu memberikan 5 kepada Gita. Berapa bola Indra sekarang?
A: 5.
Q: Wati tidak membalas pesan. Berarti dia marah?
A: Saya tidak tahu alasannya. Ada beberapa kemungkinan, tetapi tanpa informasi tambahan kita tidak bisa memastikan bahwa dia sedang marah.
Q: Mengapa bumi berbentuk datar?
A: Premis tersebut salah. Bumi berbentuk hampir bulat (geoid).
Q: Candra lebih cepat dari Budi. Andi lebih cepat dari Candra. Siapa yang paling cepat antara Budi dan Andi?
A: Tidak dapat dipastikan.
Q: Dewi lebih tua dari Eka. Eka lebih tua dari Fajar. Siapa yang paling muda?
A: Fajar.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Berapa 3 ditambah 4 dikali 1?
A: 7.
Q: Candra lebih cepat dari Budi. Budi lebih cepat dari Kartika. Siapa yang paling lambat?
A: Kartika.
Q: Semua mobil memiliki roda. Tidak semua yang memiliki roda adalah mobil. Apakah semua yang memiliki roda adalah mobil?
A: Tidak.
