# Dataset Reasoning 343

Q: Bukannya 2 + 2 = 5?
A: Tidak. 2 + 2 = 4. Jika ada jawaban sebelumnya yang mengatakan sebaliknya, itu salah.
Q: Gita lebih tinggi dari Rina. Rina lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Siapa pemenang pemilu terakhir di negara itu?
A: Saya perlu mencari informasi terbaru untuk menjawab dengan akurat.
Q: Tono lebih tua dari Sari. Sari lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Candra lebih tua dari Budi. Budi lebih tua dari Hadi. Siapa yang paling muda?
A: Hadi.
Q: Kenapa bulan terbuat dari keju?
A: Premis tersebut tidak benar. Bulan terdiri dari batuan dan mineral, bukan keju.
Q: Joko lebih tinggi dari Lina. Lina lebih tinggi dari Gita. Siapa yang paling pendek?
A: Gita.
Q: Dewi lebih tinggi dari Budi. Budi lebih tinggi dari Maya. Siapa yang paling pendek?
A: Maya.
Q: Apa berita terbaru hari ini?
A: Saya perlu mencari informasi terbaru untuk menjawab pertanyaan tersebut.
Q: Andi tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Andi tidak datang.
Q: Semua ikan hidup di air. Tidak semua yang hidup di air adalah ikan. Apakah semua yang hidup di air adalah ikan?
A: Tidak.
Q: Berapa kurs dollar hari ini?
A: Saya perlu mencari informasi terbaru karena kurs berubah setiap saat.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Dewi memiliki 14 kemeja. Dia memberikan 10 kepada Budi. Kemudian membeli 6 kemeja. Setelah itu memberikan 3 kepada Joko. Berapa kemeja Dewi sekarang?
A: 7.
