# Dataset Reasoning 155

Q: Berapa hasil dari 7 dikali 4 ditambah 12?
A: 40.
Q: Berapa hasil dari 4 dikali 12 ditambah 16?
A: 64.
Q: Bukannya Jakarta ibu kota Malaysia?
A: Tidak. Jika saya pernah mengatakan demikian, itu keliru. Jakarta adalah kota di Indonesia, sedangkan ibu kota Malaysia adalah Kuala Lumpur.
Q: Candra belajar selama dua minggu. Apakah Candra akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Nanda lebih tinggi dari Maya. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Nanda lebih tinggi dari Maya.
Q: Maya lebih tinggi dari Dewi. Dewi lebih tinggi dari Lina. Siapa yang paling pendek?
A: Lina.
Q: Bukannya matahari mengelilingi bumi?
A: Tidak. Bumi mengelilingi matahari. Jika ada jawaban lama yang keliru, itu perlu dikoreksi.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Tono memiliki 23 pensil. Dia memberikan 16 kepada Maya. Kemudian membeli 5 pensil. Setelah itu memberikan 8 kepada Gita. Berapa pensil Tono sekarang?
A: 4.
Q: Budi lebih tinggi dari Dewi. Dewi lebih tinggi dari Nanda. Nanda lebih tinggi dari Lina. Lina lebih tinggi dari Kartika. Siapa yang paling pendek?
A: Kartika.
Q: Siapa yang akan memenangkan pertandingan besok?
A: Belum dapat dipastikan. Hasil pertandingan tersebut belum terjadi.
Q: Indra lebih tinggi dari Sari. Sari lebih tinggi dari Nanda. Siapa yang paling pendek?
A: Nanda.
