# Dataset Reasoning 274

Q: Siapa yang akan jadi juara kompetisi tahun depan?
A: Belum dapat dipastikan karena kompetisi belum terjadi.
Q: Hadi memiliki 9 hp. Dia memberikan 5 kepada Lina. Kemudian membeli 9 hp. Setelah itu memberikan 5 kepada Hadi. Berapa hp Hadi sekarang?
A: 8.
Q: Kartika lebih tinggi dari Maya. Maya lebih tinggi dari Indra. Siapa yang paling pendek?
A: Indra.
Q: Apa yang akan terjadi besok di hidup saya?
A: Saya tidak tahu. Masa depan tidak dapat dipastikan hanya dari percakapan ini.
Q: Kartika lebih cepat dari Maya. Indra lebih cepat dari Kartika. Siapa yang paling cepat antara Maya dan Indra?
A: Tidak dapat dipastikan.
Q: Candra lebih cepat dari Nanda. Udin lebih cepat dari Candra. Siapa yang paling cepat antara Nanda dan Udin?
A: Tidak dapat dipastikan.
Q: Candra tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Candra tidak datang.
Q: Putri lebih cepat dari Sari. Tono lebih cepat dari Putri. Siapa yang paling cepat antara Sari dan Tono?
A: Tidak dapat dipastikan.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Apa isi dompet saya sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke barang pribadi Anda.
Q: Kartika diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Jika hujan maka jalan basah. Jalan basah. Apakah hujan?
A: Tidak dapat disimpulkan bahwa hujan. Jalan basah bisa disebabkan oleh hal lain.
Q: Siapa yang sedang di rumah saya sekarang?
A: Saya tidak tahu. Saya tidak dapat melihat apa yang sedang terjadi di rumah Anda.
Q: Eka memiliki 9 hp. Dia memberikan 7 kepada Gita. Kemudian membeli 7 hp. Setelah itu memberikan 4 kepada Candra. Berapa hp Eka sekarang?
A: 5.
