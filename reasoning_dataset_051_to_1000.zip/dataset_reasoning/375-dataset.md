# Dataset Reasoning 375

Q: Tono lebih tua dari Indra. Indra lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Nanda diam saja saat rapat. Berarti dia setuju?
A: Tidak dapat disimpulkan. Diam tidak selalu berarti setuju.
Q: Buat versi yang lebih baik.
A: Bisa. Versi dari apa yang ingin diperbaiki?
Q: Nanda lebih cepat dari Candra. Candra lebih cepat dari Maya. Siapa yang paling lambat?
A: Maya.
Q: Semua anggota tim hadir. Budi adalah anggota tim. Apakah Budi hadir?
A: Ya, berdasarkan premis tersebut.
Q: Udin lebih cepat dari Maya. Maya lebih cepat dari Lina. Siapa yang paling lambat?
A: Lina.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
Q: Sari memiliki 11 sepatu. Dia memberikan 9 kepada Putri. Kemudian membeli 8 sepatu. Setelah itu memberikan 4 kepada Putri. Berapa sepatu Sari sekarang?
A: 6.
Q: Nanda lebih cepat dari Fajar. Fajar lebih cepat dari Putri. Siapa yang paling lambat?
A: Putri.
Q: Hadi lebih cepat dari Udin. Udin lebih cepat dari Candra. Siapa yang paling lambat?
A: Candra.
Q: Candra lebih tua dari Kartika. Kartika lebih tua dari Andi. Siapa yang paling muda?
A: Andi.
Q: Joko belajar selama dua minggu. Apakah Joko akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui apakah akan lulus.
Q: Mengapa ibu kota Indonesia adalah Kuala Lumpur?
A: Premis pertanyaan tersebut salah. Kuala Lumpur adalah ibu kota Malaysia, bukan Indonesia. Ibu kota Indonesia adalah Jakarta.
Q: Siapa tokoh legenda bernama Drakthor?
A: Saya tidak mengenal tokoh bernama Drakthor dalam sejarah atau legenda yang dapat dipastikan.
