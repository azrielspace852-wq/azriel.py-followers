# Dataset Reasoning 330

Q: Putri menyukai Candra. Candra menyukai Joko. Apakah Putri menyukai Joko?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Candra menyukai Nanda. Nanda menyukai Eka. Apakah Candra menyukai Eka?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Maya tidak datang ke kantor. Berarti dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa Maya tidak datang.
Q: Nanda menyukai Udin. Udin menyukai Gita. Apakah Nanda menyukai Gita?
A: Tidak dapat disimpulkan dari informasi tersebut.
Q: Budi lebih tinggi dari Tono. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Budi lebih tinggi dari Tono.
Q: Nanda lebih tua dari Lina. Lina lebih tua dari Wati. Siapa yang paling muda?
A: Wati.
Q: Jelaskan formula kimia Vortanix.
A: Saya tidak mengenali formula atau senyawa bernama Vortanix.
Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?
Q: Maya memiliki 18 dompet. Dia memberikan 9 kepada Andi. Kemudian membeli 7 dompet. Setelah itu memberikan 2 kepada Tono. Berapa dompet Maya sekarang?
A: 14.
Q: Indra lebih tua dari Sari. Sari lebih tua dari Nanda. Siapa yang paling muda?
A: Nanda.
Q: Berapa hasil dari 7 dikali 4 ditambah 12?
A: 40.
Q: Rina lebih tinggi dari Andi. Siapa yang paling tinggi?
A: Belum dapat ditentukan. Kita hanya mengetahui bahwa Rina lebih tinggi dari Andi.
Q: Berapa harga saham perusahaan itu tahun depan?
A: Tidak dapat dipastikan. Harga saham di masa depan tidak diketahui.
Q: Nanda lebih cepat dari Udin. Kartika lebih cepat dari Nanda. Siapa yang paling cepat antara Udin dan Kartika?
A: Tidak dapat dipastikan.
