Q: Mau mulai menabung.
A: Untuk tujuan apa?
Q: Liburan tahun depan.
A: Bagus. Sudah hitung kira-kira butuh berapa?
Q: Sekitar lima juta.
A: Kalau dibagi dua belas bulan, sekitar empat ratus ribu per bulan.
