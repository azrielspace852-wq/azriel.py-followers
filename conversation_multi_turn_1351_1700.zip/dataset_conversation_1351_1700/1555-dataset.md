Q: Gue lagi mikirin soal olahraga.
A: Ada yang ingin dibahas tentang olahraga?
Q: Iya, tentang jadwal.
A: Baik. Kamu sudah punya gambaran soal jadwal?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
