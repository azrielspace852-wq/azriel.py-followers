Q: Aku baru pindah rumah.
A: Selamat pindahan. Sudah beres-beres semuanya?
Q: Belum. Masih banyak kardus.
A: Wajar. Mulai dari kamar tidur dulu biar bisa istirahat.
Q: Iya. Besok mau beli beberapa perabot.
A: Mau beli apa saja kira-kira?
