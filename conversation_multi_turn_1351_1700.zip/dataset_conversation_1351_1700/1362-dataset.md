Q: Mau coba hobi baru.
A: Mau coba apa?
Q: Fotografi.
A: Bagus. Sudah punya kamera atau pakai ponsel dulu?
Q: Pakai ponsel dulu aja.
A: Bagus. Mulai dari komposisi sederhana dan cahaya natural.
Q: Nanti coba foto pemandangan.
A: Bagus. Perhatikan garis horizon dan waktu golden hour.
Q: Oke. Nanti kirim hasilnya.
A: Siap. Saya tunggu.
