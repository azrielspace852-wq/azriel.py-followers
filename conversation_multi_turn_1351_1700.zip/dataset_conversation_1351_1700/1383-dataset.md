Q: Lagi ada proyek kelompok.
A: Topiknya apa?
Q: Aplikasi sederhana.
A: Sudah bagi tugas antar anggota?
Q: Sudah. Aku bagian antarmuka.
A: Bagus. Yang lain bagian data dan logika?
Q: Iya. Deadline dua minggu lagi.
A: Mulai dari kerangka antarmuka dulu supaya bisa diuji bersama.
Q: Oke. Nanti update progres.
A: Siap. Kalau ada yang macet, tanya saja.
