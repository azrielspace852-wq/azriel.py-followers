Q: Semester ini ambil berapa mata kuliah?
A: Berapa yang kamu ambil?
Q: Enam. Agak padat.
A: Iya. Ada yang paling berat?
Q: Statistika sama pemrograman.
A: Fokus ke dua itu dulu di awal minggu.
Q: Iya. Nanti buat jadwal detail.
A: Bagus. Sisakan waktu untuk istirahat juga.
