Q: Mau beli laptop baru.
A: Untuk keperluan apa utamanya?
Q: Kuliah dan desain ringan.
A: Anggaran berapa kira-kira?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Sekitar tujuh sampai sembilan juta.
A: Di rentang itu banyak pilihan dengan prosesor cukup dan ram delapan giga.
Q: Ram delapan cukup ya?
A: Untuk kuliah dan desain ringan biasanya cukup. Kalau sering buka banyak tab, dua belas lebih nyaman.
