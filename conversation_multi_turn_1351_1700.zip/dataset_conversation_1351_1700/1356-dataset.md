Q: Aku baru pindah rumah.
A: Selamat pindahan. Sudah beres-beres semuanya?
Q: Belum. Masih banyak kardus.
A: Wajar. Mulai dari kamar tidur dulu biar bisa istirahat.
Q: Iya. Besok mau beli beberapa perabot.
A: Mau beli apa saja kira-kira?
Q: Meja kecil sama lampu belajar.
A: Bagus. Cek ukuran ruangan dulu supaya pas.
Q: Iya. Nanti kalau ada waktu bantu liatin ya.
A: Siap. Kirim foto ruangannya saja nanti.
