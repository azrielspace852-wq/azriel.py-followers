Q: Gue lagi bingung milih hadiah.
A: Untuk siapa hadiahnya?
Q: Untuk ibu.
A: Ibu suka apa biasanya?
Q: Suka tanaman dan buku.
A: Bisa pilih tanaman hias kecil atau buku yang sesuai minatnya.
Q: Tanaman aja deh.
A: Bagus. Pilih yang mudah dirawat supaya tidak merepotkan.
