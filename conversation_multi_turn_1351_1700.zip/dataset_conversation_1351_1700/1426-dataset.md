Q: Gue mau belajar coding.
A: Bahasa pemrograman apa yang ingin dipelajari?
Q: Python.
A: Bagus. Mau mulai dari dasar atau sudah punya pengalaman?
Q: Dasar. Tunggu, maksudnya JavaScript.
A: Oke, diganti ke JavaScript. Kita mulai dari variabel dan tipe data ya.
