Q: Aku lagi susun jadwal minggu ini.
A: Hari apa yang paling padat?
Q: Senin dan Rabu.
A: Senin ada apa saja?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Kuliah pagi, lalu rapat sore.
A: Rabu bagaimana?
