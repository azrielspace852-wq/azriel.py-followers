Q: Laptopku lemot banget.
A: Sudah coba restart belum?
Q: Sudah. Masih lemot.
A: Coba cek aplikasi yang berjalan di belakang.
Q: Banyak banget yang kebuka.
A: Tutup yang tidak perlu dulu, lalu cek penyimpanan.
Q: Penyimpanannya hampir penuh.
A: Pindahkan file besar ke penyimpanan eksternal atau hapus yang tidak terpakai.
