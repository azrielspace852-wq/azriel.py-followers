Q: Setelah nasi goreng, mau coba masak ayam goreng.
A: Bagus. Sudah punya resepnya?
Q: Belum. Minta langkah sederhana.
A: Pertama marinasi ayam dengan bumbu, diamkan minimal tiga puluh menit.
Q: Lalu digoreng langsung?
A: Lebih baik setelah marinasi, baru digoreng dengan api sedang.
Q: Berapa lama kira-kira?
A: Sekitar delapan sampai sepuluh menit sampai berwarna keemasan.
