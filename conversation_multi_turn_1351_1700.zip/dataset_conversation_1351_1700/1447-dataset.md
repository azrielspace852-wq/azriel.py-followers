Q: Aku mau coba olahraga di rumah.
A: Mau olahraga apa yang bisa di rumah?
Q: Push up dan squat.
A: Bagus. Mulai dari jumlah sedikit dulu.
Q: Oke. Sepuluh kali dulu.
A: Iya. Fokus ke bentuk gerakan yang benar.
