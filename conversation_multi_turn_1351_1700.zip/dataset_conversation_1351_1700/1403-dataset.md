Q: Mau mulai persiapan ujian.
A: Bagus. Sudah punya gambaran soal materi?
Q: Belum terlalu. Masih bingung materi.
A: Kita mulai dari materi dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan jadwal?
A: Setelah materi dikuasai, lanjut ke jadwal.
Q: Nanti latihan soal juga penting ya?
A: Iya. Latihan soal membantu memperkuat yang sudah dipelajari.
