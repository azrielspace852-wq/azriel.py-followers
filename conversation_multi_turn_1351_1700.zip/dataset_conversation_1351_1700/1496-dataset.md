Q: Kemarin kamu saranin saya kurangi layar sebelum tidur.
A: Iya. Bagaimana hasilnya?
Q: Sudah coba tiga hari. Agak lebih mudah tidur.
A: Bagus. Lanjutkan konsisten ya.
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Iya. Sekarang mau tambah kebiasaan lain.
A: Mau tambah apa?
Q: Olahraga ringan pagi.
A: Cocok. Bisa jalan kaki atau stretching dulu.
