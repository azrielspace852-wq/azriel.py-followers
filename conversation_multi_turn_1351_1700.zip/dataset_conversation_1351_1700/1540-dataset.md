Q: Mau liburan akhir pekan.
A: Mau ke mana kira-kira?
Q: Ke pantai dekat sini.
A: Bagus. Sudah cek cuaca belum?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum. Nanti cek.
A: Iya. Bawa sunsreen dan air minum juga.
Q: Oke. Mau berangkat pagi.
A: Bagus. Berangkat lebih awal biar tidak macet.
Q: Iya. Nanti fotoin pemandangannya.
A: Siap. Saya tunggu fotonya.
