Q: Mau perbaiki postur duduk.
A: Sudah berapa lama duduk di depan komputer?
Q: Hampir seharian.
A: Coba atur tinggi kursi dan layar sejajar mata.
Q: Oke. Nanti coba.
A: Setiap empat puluh lima menit berdiri sebentar juga membantu.
Q: Iya. Sering sakit punggung.
A: Kalau berlanjut, pertimbangkan konsultasi ke ahli.
Q: Makasih sarannya.
A: Sama-sama. Jaga postur ya.
