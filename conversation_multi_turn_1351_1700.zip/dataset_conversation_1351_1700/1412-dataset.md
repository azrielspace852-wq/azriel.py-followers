Q: Besok ada presentasi di kampus.
A: Sudah siap materinya?
Q: Sudah hampir. Masih kurang bagian penutup.
A: Bisa ditutup dengan ringkasan poin utama dan saran tindak lanjut.
Q: Oke. Nanti latihan di depan temen.
A: Bagus. Minta feedback tentang suara dan kontak mata juga.
Q: Iya. Takut gugup nanti.
A: Wajar. Tarik napas dalam-dalam sebelum mulai, dan lihat ke audiens secara bergantian.
