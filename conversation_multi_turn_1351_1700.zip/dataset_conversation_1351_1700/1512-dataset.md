Q: Gue mau mulai membersihkan kamar.
A: Bagus. Sudah punya gambaran soal urutan?
Q: Belum terlalu. Masih bingung urutan.
A: Kita mulai dari urutan dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan alat?
A: Setelah urutan dikuasai, lanjut ke alat.
Q: Nanti hasil juga penting ya?
A: Iya. hasil membantu memperkuat yang sudah dipelajari.
Q: Siap. Nanti update.
A: Saya tunggu kabar progresnya.
