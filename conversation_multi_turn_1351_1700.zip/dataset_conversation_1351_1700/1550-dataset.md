Q: Gue lagi mikirin soal masak.
A: Ada yang ingin dibahas tentang masak?
Q: Iya, tentang resep.
A: Baik. Kamu sudah punya gambaran soal resep?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
