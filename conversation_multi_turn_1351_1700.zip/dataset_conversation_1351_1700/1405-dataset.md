Q: Mau mulai merencanakan liburan.
A: Bagus. Sudah punya gambaran soal tujuan?
Q: Belum terlalu. Masih bingung tujuan.
A: Kita mulai dari tujuan dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan anggaran?
A: Setelah tujuan dikuasai, lanjut ke anggaran.
