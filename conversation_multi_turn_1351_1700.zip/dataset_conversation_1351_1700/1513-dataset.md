Q: Gue mau mulai persiapan ujian.
A: Bagus. Sudah punya gambaran soal materi?
Q: Belum terlalu. Masih bingung materi.
A: Kita mulai dari materi dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan jadwal?
A: Setelah materi dikuasai, lanjut ke jadwal.
