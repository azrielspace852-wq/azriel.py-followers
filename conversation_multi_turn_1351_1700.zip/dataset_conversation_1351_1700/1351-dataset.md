Q: Gue mau belajar masak nasi goreng.
A: Boleh. Kamu sudah pernah masak sebelumnya atau baru mulai?
Q: Baru mulai.
A: Kalau begitu kita mulai dari bahan dasar dulu. Kamu punya beras, bawang, dan telur?
Q: Punya semua.
A: Bagus. Pertama cuci beras, lalu potong bawang. Setelah itu goreng bawang sampai harum.
