Q: Gue lagi mikirin soal belajar.
A: Ada yang ingin dibahas tentang belajar?
Q: Iya, tentang materi.
A: Baik. Kamu sudah punya gambaran soal materi?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian latihan.
A: Oke. Saya jelaskan langkah sederhana untuk latihan.
