Q: Lagi nonton film bagus.
A: Judulnya apa?
Q: Yang tentang perjalanan waktu.
A: Menarik. Ceritanya mudah diikuti atau rumit?
Q: Agak rumit di tengah.
A: Biasanya bagian tengah memang padat. Nanti di akhir biasanya lebih jelas.
Q: Iya. Nanti kalau selesai cerita sedikit.
A: Siap. Jangan spoiler bagian penting ya.
