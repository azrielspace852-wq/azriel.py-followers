Q: Mau liburan akhir pekan.
A: Mau ke mana kira-kira?
Q: Ke pantai dekat sini.
A: Bagus. Sudah cek cuaca belum?
Q: Belum. Nanti cek.
A: Iya. Bawa sunsreen dan air minum juga.
