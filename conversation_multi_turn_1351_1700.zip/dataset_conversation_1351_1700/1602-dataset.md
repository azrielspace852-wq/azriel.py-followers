Q: Aku lagi susun jadwal minggu ini.
A: Hari apa yang paling padat?
Q: Senin dan Rabu.
A: Senin ada apa saja?
Q: Kuliah pagi, lalu rapat sore.
A: Rabu bagaimana?
