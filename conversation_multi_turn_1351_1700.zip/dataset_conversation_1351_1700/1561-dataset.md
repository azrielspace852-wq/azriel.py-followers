Q: Gue lagi mikirin soal hobi.
A: Ada yang ingin dibahas tentang hobi?
Q: Iya, tentang kegiatan.
A: Baik. Kamu sudah punya gambaran soal kegiatan?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
