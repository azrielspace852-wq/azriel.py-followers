Q: Akhir-akhir ini susah tidur.
A: Sudah coba kurangi layar sebelum tidur?
Q: Belum konsisten.
A: Coba mulai dari tiga puluh menit sebelum tidur tanpa ponsel.
Q: Oke. Nanti coba.
A: Bisa ditambah teh hangat atau baca buku ringan.
