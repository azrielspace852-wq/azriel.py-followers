Q: Rencana naik gunung minggu depan.
A: Gunung mana?
Q: Yang dekat kota saja.
A: Sudah pernah naik sebelumnya?
Q: Pernah sekali.
A: Bagus. Siapkan jaket, air, dan sepatu yang nyaman.
Q: Iya. Nanti cek jalur dulu.
A: Betul. Cek juga cuaca dan izin masuknya.
Q: Oke. Makasih pengingatnya.
A: Sama-sama. Hati-hati di perjalanan.
