Q: Mau mulai memilih sepatu.
A: Bagus. Sudah punya gambaran soal kenyamanan?
Q: Belum terlalu. Masih bingung kenyamanan.
A: Kita mulai dari kenyamanan dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan ukuran?
A: Setelah kenyamanan dikuasai, lanjut ke ukuran.
Q: Nanti kegunaan juga penting ya?
A: Iya. Kegunaan membantu memperkuat yang sudah dipelajari.
Q: Siap. Nanti update.
A: Saya tunggu kabar progresnya.
