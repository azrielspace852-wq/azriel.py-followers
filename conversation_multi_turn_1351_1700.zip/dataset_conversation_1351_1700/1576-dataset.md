Q: Gue lagi mikirin soal keuangan.
A: Ada yang ingin dibahas tentang keuangan?
Q: Iya, tentang anggaran.
A: Baik. Kamu sudah punya gambaran soal anggaran?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian belanja.
A: Oke. Saya jelaskan langkah sederhana untuk belanja.
