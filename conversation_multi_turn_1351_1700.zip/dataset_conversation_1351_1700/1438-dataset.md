Q: Lagi ada proyek kelompok.
A: Topiknya apa?
Q: Aplikasi sederhana.
A: Sudah bagi tugas antar anggota?
Q: Sudah. Aku bagian antarmuka.
A: Bagus. Yang lain bagian data dan logika?
