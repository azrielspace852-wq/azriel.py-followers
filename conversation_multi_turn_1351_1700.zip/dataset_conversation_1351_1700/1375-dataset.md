Q: Buatkan yang bagus dong.
A: Bisa. Yang ingin dibuat apa?
Q: Jadwal belajar.
A: Baik. Untuk berapa hari dan mata pelajaran apa saja?
Q: Satu minggu. Matematika dan bahasa.
A: Oke. Mau dibagi pagi dan sore atau fleksibel?
