Q: Gue lagi baca novel.
A: Genrenya apa?
Q: Misteri.
A: Seru. Sudah nebak pelakunya belum?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum. Masih di bab tengah.
A: Bagus. Jangan baca spoiler di internet.
