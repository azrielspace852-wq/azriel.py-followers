Q: Lagi bingung atur keuangan.
A: Mau mulai dari mana?
Q: Catat pengeluaran dulu.
A: Bagus. Catat semua selama satu minggu.
Q: Oke. Nanti lihat mana yang bisa dikurangi.
A: Iya. Biasanya ada pengeluaran kecil yang menumpuk.
Q: Setelah itu buat anggaran bulanan.
A: Betul. Sisihkan dulu untuk kebutuhan pokok dan tabungan.
