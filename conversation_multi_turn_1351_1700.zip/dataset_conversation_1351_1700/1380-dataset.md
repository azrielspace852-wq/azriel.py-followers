Q: Besok wawancara kerja.
A: Sudah siap jawab pertanyaan umum?
Q: Sudah. Tapi takut ditanya pengalaman.
A: Siapkan contoh singkat dari proyek atau kegiatan sebelumnya.
Q: Oke. Nanti latihan di depan kaca.
A: Bagus. Perhatikan nada suara dan postur juga.
Q: Iya. Datang jam berapa sebaiknya?
A: Datang lima belas sampai dua puluh menit lebih awal.
Q: Makasih. Semoga diterima.
A: Semoga lancar. Kabari hasilnya nanti.
