Q: Gue lagi lapar banget.
A: Mau makan apa? Sudah ada ide atau masih mikir?
Q: Pengen mie.
A: Mie instan atau mie goreng biasa?
Q: Mie instan aja. Tapi takut pedas.
A: Pilih yang level pedasnya rendah saja. Atau kurangi bumbu pedasnya.
