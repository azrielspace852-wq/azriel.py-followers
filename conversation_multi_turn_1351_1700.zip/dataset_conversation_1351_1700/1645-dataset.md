Q: Lagi nonton film bagus.
A: Judulnya apa?
Q: Yang tentang perjalanan waktu.
A: Menarik. Ceritanya mudah diikuti atau rumit?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Agak rumit di tengah.
A: Biasanya bagian tengah memang padat. Nanti di akhir biasanya lebih jelas.
