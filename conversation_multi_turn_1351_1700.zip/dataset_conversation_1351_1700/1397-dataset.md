Q: Mau mulai merawat tanaman.
A: Bagus. Sudah punya gambaran soal penyiraman?
Q: Belum terlalu. Masih bingung penyiraman.
A: Kita mulai dari penyiraman dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan cahaya?
A: Setelah penyiraman dikuasai, lanjut ke cahaya.
Q: Nanti pupuk juga penting ya?
A: Iya. Pupuk membantu memperkuat yang sudah dipelajari.
