Q: Mau beli laptop baru.
A: Untuk keperluan apa utamanya?
Q: Kuliah dan desain ringan.
A: Anggaran berapa kira-kira?
Q: Sekitar tujuh sampai sembilan juta.
A: Di rentang itu banyak pilihan dengan prosesor cukup dan ram delapan giga.
Q: Ram delapan cukup ya?
A: Untuk kuliah dan desain ringan biasanya cukup. Kalau sering buka banyak tab, dua belas lebih nyaman.
Q: Oke. Nanti cek toko dulu.
A: Bagus. Bandingkan spesifikasi dan garansi juga.
