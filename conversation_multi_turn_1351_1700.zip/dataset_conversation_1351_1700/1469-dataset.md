Q: Kerjaanku lagi numpuk banget.
A: Mulai dari mana? Yang paling mendesak dulu atau yang mudah dulu?
Q: Yang mendesak dulu deh.
A: Bagus. Buat daftar singkat prioritas biar tidak kacau.
Q: Iya. Nanti sore harus kirim laporan.
A: Kalau begitu kerjakan laporan itu dulu sebelum yang lain.
Q: Oke. Setelah itu baru bales email.
A: Betul. Satu per satu biar tidak kewalahan.
