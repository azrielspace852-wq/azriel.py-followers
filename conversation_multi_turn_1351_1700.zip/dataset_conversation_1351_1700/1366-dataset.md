Q: Gue lagi bingung milih hadiah.
A: Untuk siapa hadiahnya?
Q: Untuk ibu.
A: Ibu suka apa biasanya?
Q: Suka tanaman dan buku.
A: Bisa pilih tanaman hias kecil atau buku yang sesuai minatnya.
