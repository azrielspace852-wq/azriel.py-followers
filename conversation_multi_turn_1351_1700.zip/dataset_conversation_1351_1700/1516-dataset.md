Q: Gue mau belajar masak nasi goreng.
A: Boleh. Kamu sudah pernah masak sebelumnya atau baru mulai?
Q: Baru mulai.
A: Kalau begitu kita mulai dari bahan dasar dulu. Kamu punya beras, bawang, dan telur?
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Punya semua.
A: Bagus. Pertama cuci beras, lalu potong bawang. Setelah itu goreng bawang sampai harum.
Q: Habis goreng bawang lanjut apa?
A: Masukkan beras yang sudah dicuci, aduk rata, lalu masukkan telur.
