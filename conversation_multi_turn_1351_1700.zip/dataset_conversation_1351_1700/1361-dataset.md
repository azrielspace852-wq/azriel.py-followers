Q: Gue lagi baca novel.
A: Genrenya apa?
Q: Misteri.
A: Seru. Sudah nebak pelakunya belum?
Q: Belum. Masih di bab tengah.
A: Bagus. Jangan baca spoiler di internet.
Q: Iya. Nanti kalau selesai bahas sedikit.
A: Siap. Ceritakan kesanmu saja tanpa bocoran besar.
