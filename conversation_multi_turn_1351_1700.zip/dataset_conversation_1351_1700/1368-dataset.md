Q: Printerku error terus.
A: Pesan errornya apa?
Q: Kertas macet katanya.
A: Matikan dulu, cabut kertas yang macet pelan-pelan.
Q: Sudah. Masih error.
A: Coba cek apakah kertasnya sesuai spesifikasi dan tidak terlalu tebal.
Q: Kertas biasa kok.
A: Kalau begitu coba restart printer dan komputer, lalu coba cetak halaman uji.
Q: Oke. Nanti kabari.
A: Siap. Semoga cepat selesai.
