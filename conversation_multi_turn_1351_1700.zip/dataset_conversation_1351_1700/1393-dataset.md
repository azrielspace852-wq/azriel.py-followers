Q: Besok ada rapat penting.
A: Sudah siap materinya?
Q: Sudah. Tapi masih nervous.
A: Wajar. Latihan singkat di depan kaca membantu.
Q: Iya. Nanti coba.
A: Datang lebih awal juga biar tenang.
