Q: Gue lagi mikirin soal teknologi.
A: Ada yang ingin dibahas tentang teknologi?
Q: Iya, tentang perangkat.
A: Baik. Kamu sudah punya gambaran soal perangkat?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian masalah.
A: Oke. Saya jelaskan langkah sederhana untuk masalah.
