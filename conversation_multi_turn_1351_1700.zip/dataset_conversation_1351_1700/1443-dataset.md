Q: Aku bilang kemarin mau beli tanaman untuk ibu.
A: Iya. Sudah jadi beli?
Q: Belum. Masih pilih jenisnya.
A: Mau yang berbunga atau yang hijau saja?
Q: Yang hijau saja, mudah rawat.
A: Bagus. Pilih yang tahan di dalam ruangan.
Q: Oke. Nanti sekalian beli pot.
A: Iya. Pastikan pot ada lubang drainase.
Q: Siap. Makasih ingatannya.
A: Sama-sama. Semoga ibu senang.
