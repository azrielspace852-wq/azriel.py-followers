Q: Gue lagi mikirin soal kerja.
A: Ada yang ingin dibahas tentang kerja?
Q: Iya, tentang tugas.
A: Baik. Kamu sudah punya gambaran soal tugas?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian deadline.
A: Oke. Saya jelaskan langkah sederhana untuk deadline.
