Q: Gue mau olahraga.
A: Mau olahraga apa?
Q: Lari. Tapi tunggu, mungkin berenang dulu.
A: Oke, berenang. Sudah pernah berenang rutin?
Q: Pernah dulu. Sekarang mau mulai lagi.
A: Bagus. Mulai dari jarak pendek atau durasi singkat dulu.
Q: Iya. Nanti coba tiga puluh menit.
A: Bagus. Jangan lupa pemanasan di tepi kolam.
