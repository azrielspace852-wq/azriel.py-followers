Q: Mau mulai membersihkan kamar.
A: Bagus. Sudah punya gambaran soal urutan?
Q: Belum terlalu. Masih bingung urutan.
A: Kita mulai dari urutan dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan alat?
A: Setelah urutan dikuasai, lanjut ke alat.
Q: Nanti hasil juga penting ya?
A: Iya. Hasil membantu memperkuat yang sudah dipelajari.
