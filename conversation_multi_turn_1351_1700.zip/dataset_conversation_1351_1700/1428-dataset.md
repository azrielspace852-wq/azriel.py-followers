Q: Aku lagi susun jadwal minggu ini.
A: Hari apa yang paling padat?
Q: Senin dan Rabu.
A: Senin ada apa saja?
Q: Kuliah pagi, lalu rapat sore.
A: Rabu bagaimana?
Q: Kuliah siang dan tugas kelompok.
A: Kalau begitu Selasa dan Kamis bisa dipakai untuk istirahat atau kerjakan tugas.
Q: Iya. Jumat libur kan?
A: Kalau tidak ada jadwal, iya. Bisa dipakai untuk review materi.
