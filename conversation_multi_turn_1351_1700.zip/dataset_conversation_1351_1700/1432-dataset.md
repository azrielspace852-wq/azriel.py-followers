Q: Kemarin masak nasi goreng, kurang enak.
A: Kurang apa rasanya?
Q: Kurang gurih.
A: Coba tambah sedikit garam atau kecap asin lain kali.
Q: Oke. Nanti coba lagi.
A: Bisa juga tambah sedikit minyak wijen di akhir.
