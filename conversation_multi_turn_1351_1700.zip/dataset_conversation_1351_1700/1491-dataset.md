Q: Mau mulai menabung.
A: Untuk tujuan apa?
Q: Liburan tahun depan.
A: Bagus. Sudah hitung kira-kira butuh berapa?
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Sekitar lima juta.
A: Kalau dibagi dua belas bulan, sekitar empat ratus ribu per bulan.
Q: Bisa. Nanti potong dari gaji.
A: Bagus. Sisihkan dulu sebelum pengeluaran lain.
