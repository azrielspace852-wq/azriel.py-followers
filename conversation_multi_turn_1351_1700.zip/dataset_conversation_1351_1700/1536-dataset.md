Q: Gue mau belajar coding.
A: Bahasa pemrograman apa yang ingin dipelajari?
Q: Python.
A: Bagus. Mau mulai dari dasar atau sudah punya pengalaman?
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Dasar. Tunggu, maksudnya JavaScript.
A: Oke, diganti ke JavaScript. Kita mulai dari variabel dan tipe data ya.
Q: Iya. Variabel dulu.
A: Di JavaScript variabel bisa dideklarasikan dengan let atau const.
