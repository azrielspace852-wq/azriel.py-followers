Q: Gue mau mulai belajar bahasa Inggris.
A: Bagus. Sudah punya gambaran soal kosakata?
Q: Belum terlalu. Masih bingung kosakata.
A: Kita mulai dari kosakata dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan percakapan?
A: Setelah kosakata dikuasai, lanjut ke percakapan.
Q: Nanti latihan berbicara juga penting ya?
A: Iya. Latihan berbicara membantu memperkuat yang sudah dipelajari.
