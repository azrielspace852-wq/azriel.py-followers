Q: Gue pengen belajar masak simple.
A: Boleh. Mau masak apa dulu?
Q: Nasi goreng aja.
A: Oke. Sudah punya bahan dasar?
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Sudah. Beras, telur, bawang.
A: Bagus. Mulai dari goreng bawang sampai harum.
Q: Habis itu masukin beras ya?
A: Iya, lalu aduk rata dan masukkan telur.
