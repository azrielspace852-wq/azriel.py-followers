Q: Aku sering begadang.
A: Sudah berapa lama kebiasaan itu?
Q: Hampir setahun.
A: Coba geser jam tidur bertahap, misalnya tiga puluh menit lebih awal tiap beberapa hari.
Q: Susah banget.
A: Mulai dari matikan notifikasi malam. Itu sudah membantu.
Q: Oke. Nanti coba.
A: Kalau perlu, pasang alarm untuk mengingatkan waktu tidur.
