Q: Aku ingin belajar gitar.
A: Bagus. Kamu sudah punya gitar atau belum?
Q: Sudah punya.
A: Bagus. Mau mulai dari chord dasar atau teknik petik dulu?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Chord dasar aja.
A: Oke. Kita mulai dari chord C, G, dan Am. Kamu siap coba sekarang?
