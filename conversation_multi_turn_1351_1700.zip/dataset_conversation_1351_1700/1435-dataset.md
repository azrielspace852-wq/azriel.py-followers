Q: Besok wawancara kerja.
A: Sudah siap jawab pertanyaan umum?
Q: Sudah. Tapi takut ditanya pengalaman.
A: Siapkan contoh singkat dari proyek atau kegiatan sebelumnya.
Q: Oke. Nanti latihan di depan kaca.
A: Bagus. Perhatikan nada suara dan postur juga.
