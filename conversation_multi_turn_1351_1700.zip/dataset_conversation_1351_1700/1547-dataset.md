Q: Buatkan yang bagus dong.
A: Bisa. Yang ingin dibuat apa?
Q: Jadwal belajar.
A: Baik. Untuk berapa hari dan mata pelajaran apa saja?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Satu minggu. Matematika dan bahasa.
A: Oke. Mau dibagi pagi dan sore atau fleksibel?
