Q: Gue lagi mikirin soal sosial.
A: Ada yang ingin dibahas tentang sosial?
Q: Iya, tentang teman.
A: Baik. Kamu sudah punya gambaran soal teman?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
