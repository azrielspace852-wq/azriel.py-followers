Q: Mau mulai menulis jurnal.
A: Bagus. Sudah punya gambaran soal kebiasaan?
Q: Belum terlalu. Masih bingung kebiasaan.
A: Kita mulai dari kebiasaan dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan topik?
A: Setelah kebiasaan dikuasai, lanjut ke topik.
