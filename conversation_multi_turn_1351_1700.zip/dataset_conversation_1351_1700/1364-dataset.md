Q: Mau mulai olahraga lagi.
A: Mau olahraga apa?
Q: Lari pagi.
A: Bagus. Mulai dari jarak pendek dulu biar tidak cedera.
Q: Iya. Nanti coba dua kilometer.
A: Bagus. Jangan lupa pemanasan dan pendinginan.
Q: Oke. Kalau hujan bagaimana?
A: Bisa diganti jalan kaki di dalam rumah atau stretching.
