Q: Mau mulai makan lebih sehat.
A: Bagus. Mulai dari mana?
Q: Kurangi makanan gorengan dulu.
A: Iya. Ganti dengan kukus atau rebus sesekali.
Q: Oke. Nanti tambah sayur tiap hari.
A: Bagus. Pilih sayur yang kamu suka supaya tahan lama.
