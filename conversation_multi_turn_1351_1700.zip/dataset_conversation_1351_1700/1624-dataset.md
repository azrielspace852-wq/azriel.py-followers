Q: Gue lagi mikirin soal perjalanan.
A: Ada yang ingin dibahas tentang perjalanan?
Q: Iya, tentang tujuan.
A: Baik. Kamu sudah punya gambaran soal tujuan?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian persiapan.
A: Oke. Saya jelaskan langkah sederhana untuk persiapan.
