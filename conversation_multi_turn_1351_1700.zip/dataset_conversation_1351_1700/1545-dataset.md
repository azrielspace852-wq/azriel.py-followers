Q: Aku lagi susun jadwal minggu ini.
A: Hari apa yang paling padat?
Q: Senin dan Rabu.
A: Senin ada apa saja?
Q: Kuliah pagi, lalu rapat sore.
A: Rabu bagaimana?
Q: Kuliah siang dan tugas kelompok.
A: Kalau begitu selasa dan kamis bisa dipakai untuk istirahat atau kerjakan tugas.
