Q: Tolong buatkan.
A: Buatkan apa?
Q: Ringkasan materi.
A: Materi apa yang ingin diringkas?
Q: Sejarah Indonesia masa kemerdekaan.
A: Baik. Mau ringkasan singkat atau lebih detail?
