Q: Gue lagi mikirin soal kesehatan.
A: Ada yang ingin dibahas tentang kesehatan?
Q: Iya, tentang tidur.
A: Baik. Kamu sudah punya gambaran soal tidur?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian makan.
A: Oke. Saya jelaskan langkah sederhana untuk makan.
Q: Lalu setelah itu olahraga bagaimana?
A: Setelah makan selesai, lanjut ke olahraga secara bertahap.
