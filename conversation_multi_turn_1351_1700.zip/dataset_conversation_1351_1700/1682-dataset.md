Q: Gue lagi mikirin soal perjalanan.
A: Ada yang ingin dibahas tentang perjalanan?
Q: Iya, tentang tujuan.
A: Baik. Kamu sudah punya gambaran soal tujuan?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
