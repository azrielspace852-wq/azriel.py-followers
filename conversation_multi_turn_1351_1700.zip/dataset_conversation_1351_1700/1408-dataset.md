Q: Mau belajar bahasa Jepang nih.
A: Boleh. Mau mulai dari huruf hiragana atau percakapan sederhana dulu?
Q: Hiragana dulu.
A: Baik. Hiragana ada empat puluh enam huruf dasar. Kita mulai dari a, i, u, e, o ya.
Q: Oke. a itu bagaimana tulisannya?
A: a ditulis seperti huruf yang miring ke kiri dengan garis lengkung di bawah.
