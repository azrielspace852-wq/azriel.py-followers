Q: Mau mulai latihan pernapasan.
A: Bagus. Sudah punya gambaran soal teknik?
Q: Belum terlalu. Masih bingung teknik.
A: Kita mulai dari teknik dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan waktu?
A: Setelah teknik dikuasai, lanjut ke waktu.
Q: Nanti manfaat juga penting ya?
A: Iya. Manfaat membantu memperkuat yang sudah dipelajari.
Q: Siap. Nanti update.
A: Saya tunggu kabar progresnya.
