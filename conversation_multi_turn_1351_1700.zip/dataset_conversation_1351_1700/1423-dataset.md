Q: Printerku error terus.
A: Pesan errornya apa?
Q: Kertas macet katanya.
A: Matikan dulu, cabut kertas yang macet pelan-pelan.
Q: Sudah. Masih error.
A: Coba cek apakah kertasnya sesuai spesifikasi dan tidak terlalu tebal.
