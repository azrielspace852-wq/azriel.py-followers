Q: Kemarin kamu saranin saya kurangi layar sebelum tidur.
A: Iya. Bagaimana hasilnya?
Q: Sudah coba tiga hari. Agak lebih mudah tidur.
A: Bagus. Lanjutkan konsisten ya.
Q: Iya. Sekarang mau tambah kebiasaan lain.
A: Mau tambah apa?
