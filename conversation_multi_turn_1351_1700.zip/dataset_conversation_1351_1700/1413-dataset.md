Q: Lagi ngerjain tugas laporan.
A: Topiknya apa?
Q: Tentang perubahan iklim.
A: Sudah dapat sumbernya?
Q: Sudah beberapa. Masih kurang data lokal.
A: Coba cari laporan resmi dari lembaga terkait di Indonesia.
Q: Oke. Nanti kalau stuck tanya lagi ya.
A: Silakan. Kirim bagian yang bingung saja.
Q: Bagus. Terima kasih.
A: Sama-sama. Semangat.
