Q: Besok ketemu temen lama.
A: Sudah lama tidak ketemu ya?
Q: Iya, hampir dua tahun.
A: Seru pasti. Mau ngobrol di mana?
Q: Di kafe dekat stasiun.
A: Bagus. Sudah janji jam berapa?
