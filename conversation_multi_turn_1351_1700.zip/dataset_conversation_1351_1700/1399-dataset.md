Q: Mau mulai mengatur waktu.
A: Bagus. Sudah punya gambaran soal prioritas?
Q: Belum terlalu. Masih bingung prioritas.
A: Kita mulai dari prioritas dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan jadwal?
A: Setelah prioritas dikuasai, lanjut ke jadwal.
