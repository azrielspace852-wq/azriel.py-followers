Q: Gue lagi mikirin soal hobi.
A: Ada yang ingin dibahas tentang hobi?
Q: Iya, tentang kegiatan.
A: Baik. Kamu sudah punya gambaran soal kegiatan?
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian alat.
A: Oke. Saya jelaskan langkah sederhana untuk alat.
Q: Lalu setelah itu hasil bagaimana?
A: Setelah alat selesai, lanjut ke hasil secara bertahap.
