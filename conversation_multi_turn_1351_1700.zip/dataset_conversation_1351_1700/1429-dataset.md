Q: Mau beli laptop baru.
A: Untuk keperluan apa utamanya?
Q: Kuliah dan desain ringan.
A: Anggaran berapa kira-kira?
Q: Sekitar tujuh sampai sembilan juta.
A: Di rentang itu banyak pilihan dengan prosesor cukup dan ram delapan giga.
