Q: Aku mau coba olahraga di rumah.
A: Mau olahraga apa yang bisa di rumah?
Q: Push up dan squat.
A: Bagus. Mulai dari jumlah sedikit dulu.
Q: Oke. Sepuluh kali dulu.
A: Iya. Fokus ke bentuk gerakan yang benar.
Q: Kalau sudah biasa tambah jumlahnya?
A: Betul. Naikkan secara bertahap setiap minggu.
Q: Siap. Nanti catat progress.
A: Bagus. Konsistensi lebih penting dari jumlah besar.
