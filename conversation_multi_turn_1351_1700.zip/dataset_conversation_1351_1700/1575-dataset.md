Q: Gue lagi mikirin soal sosial.
A: Ada yang ingin dibahas tentang sosial?
Q: Iya, tentang teman.
A: Baik. Kamu sudah punya gambaran soal teman?
Q: Yang tadi kamu bilang yang pertama apa lagi?
A: Yang pertama adalah langkah awal yang sudah saya sebutkan sebelumnya.
Q: Belum terlalu jelas.
A: Kita mulai dari dasar saja. Apa yang paling membingungkan?
Q: Bagian acara.
A: Oke. Saya jelaskan langkah sederhana untuk acara.
Q: Lalu setelah itu rencana bagaimana?
A: Setelah acara selesai, lanjut ke rencana secara bertahap.
