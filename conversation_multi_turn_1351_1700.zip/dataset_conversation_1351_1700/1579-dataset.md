Q: Gue mau belajar masak nasi goreng.
A: Boleh. Kamu sudah pernah masak sebelumnya atau baru mulai?
Q: Baru mulai.
A: Kalau begitu kita mulai dari bahan dasar dulu ya. Kamu punya beras, bawang, dan telur?
Q: Punya semua.
A: Bagus. Pertama cuci beras, lalu potong bawang. Setelah itu goreng bawang sampai harum.
Q: Habis goreng bawang lanjut apa?
A: Masukkan beras yang sudah dicuci, aduk rata, lalu masukkan telur.
Q: Berapa lama digoreng?
A: Biasanya tiga sampai lima menit sampai matang merata.
