Q: Gue mau mulai latihan pernapasan.
A: Bagus. Sudah punya gambaran soal teknik?
Q: Belum terlalu. Masih bingung teknik.
A: Kita mulai dari teknik dulu secara sederhana.
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Oke. Lalu bagaimana dengan waktu?
A: Setelah teknik dikuasai, lanjut ke waktu.
Q: Nanti manfaat juga penting ya?
A: Iya. manfaat membantu memperkuat yang sudah dipelajari.
