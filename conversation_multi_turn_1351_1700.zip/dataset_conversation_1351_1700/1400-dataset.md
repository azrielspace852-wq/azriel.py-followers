Q: Mau mulai memasak sayur.
A: Bagus. Sudah punya gambaran soal bumbu?
Q: Belum terlalu. Masih bingung bumbu.
A: Kita mulai dari bumbu dulu secara sederhana.
Q: Oke. Lalu bagaimana dengan teknik?
A: Setelah bumbu dikuasai, lanjut ke teknik.
Q: Nanti penyajian juga penting ya?
A: Iya. Penyajian membantu memperkuat yang sudah dipelajari.
