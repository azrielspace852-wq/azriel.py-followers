Q: Hari ini cuaca di sini hujan terus.
A: Iya, hujan deras ya. Kamu sudah bawa payung?
Q: Enggak. Makanya basah kuyup.
A: Aduh. Nanti pulang hati-hati ya, jalanan licin.
Q: Iya. Besok kira-kira masih hujan nggak?
A: Saya tidak bisa pastikan cuaca besok. Lebih baik siapkan payung saja.
