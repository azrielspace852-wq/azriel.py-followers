Q: Besok ada ujian matematika.
A: Materi apa yang keluar?
Q: Aljabar. Eh tunggu, geometri.
A: Oke, geometri. Fokus ke luas dan volume dulu.
Q: Iya. Rumus luas segitiga apa lagi?
A: Setengah kali alas kali tinggi.
Q: Oke. Nanti latihan soal.
A: Bagus. Kerjakan dari yang mudah dulu.
Q: Siap. Makasih.
A: Sama-sama. Semangat ujiannya.
