Q: Aku ingin belajar gitar.
A: Bagus. Kamu sudah punya gitar atau belum?
Q: Sudah punya.
A: Bagus. Mau mulai dari chord dasar atau teknik petik dulu?
Q: Chord dasar aja.
A: Oke. Kita mulai dari chord C, G, dan Am. Kamu siap coba sekarang?
Q: Siap. Chord C bagaimana posisinya?
A: Jari telunjuk di senar dua fret satu, jari tengah di senar empat fret dua, jari manis di senar lima fret tiga.
Q: Susah banget.
A: Wajar. Latihan pelan-pelan saja, ulangi beberapa kali sampai jari terbiasa.
