Q: Tadi kamu bilang ram delapan cukup untuk desain.
A: Iya, untuk desain ringan biasanya cukup.
Q: Tapi aku sering buka banyak program sekaligus.
A: Kalau begitu, lebih aman pilih yang ram dua belas atau enam belas.
Q: Oke. Jadi rekomendasi berubah ya?
A: Ya, berdasarkan kebiasaanmu yang baru disebutkan, ram lebih besar lebih nyaman.
