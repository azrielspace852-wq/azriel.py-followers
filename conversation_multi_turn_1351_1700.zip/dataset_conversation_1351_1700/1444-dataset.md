Q: Lagi belajar chord gitar yang kemarin.
A: Chord C, G, dan Am ya?
Q: Iya. Chord C masih kaku.
A: Latihan ganti chord dari C ke G berulang-ulang pelan.
Q: Oke. Berapa kali kira-kira sehari?
A: Mulai dari sepuluh sampai lima belas menit fokus saja.
