Q: Gue lagi bingung milih hadiah.
A: Untuk siapa hadiahnya?
Q: Untuk ibu.
A: Ibu suka apa biasanya?
Q: Yang kamu sebutkan tadi yang pertama apa lagi?
A: Yang pertama adalah langkah atau poin yang sudah saya jelaskan di awal.
Q: Suka tanaman dan buku.
A: Bisa pilih tanaman hias kecil atau buku yang sesuai minatnya.
Q: Tanaman aja deh.
A: Bagus. Pilih yang mudah dirawat supaya tidak merepotkan.
