# Dataset Verifikasi Diri 1838

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 89 apel. Dia memberikan 17 kepada teman. Kemudian menang 14 apel. Setelah itu membagi 12 kepada orang lain. Berapa apel Andi sekarang?
A: Andi sekarang memiliki 89 - 17 + 14 - 12 = 74 apel.

Verifikasi: Perhitungan: 89 - 17 = 72, 72 + 14 = 86, 86 - 12 = 74. Benar.

Jawaban akhir: 74 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Dedi memiliki 23 kertas. Dia memberikan 5 kepada teman. Kemudian membeli 10 kertas. Setelah itu memberikan 9 kepada orang lain. Berapa kertas Dedi sekarang?
A: Dedi sekarang memiliki 23 - 5 + 10 - 9 = 19 kertas.

Verifikasi: Perhitungan: 23 - 5 = 18, 18 + 10 = 28, 28 - 9 = 19. Benar.

Jawaban akhir: 19 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Siti memiliki 37 stiker. Dia memberikan 9 kepada teman. Kemudian mendapat 8 stiker. Setelah itu meminjamkan 12 kepada orang lain. Berapa stiker Siti sekarang?
A: Siti sekarang memiliki 37 - 9 + 8 - 12 = 24 stiker.

Verifikasi: Perhitungan: 37 - 9 = 28, 28 + 8 = 36, 36 - 12 = 24. Benar.

Jawaban akhir: 24 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
