# Dataset Verifikasi Diri 1747

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 46 pulpen. Dia meminjamkan 3 kepada teman. Kemudian mendapat 11 pulpen. Setelah itu meminjamkan 9 kepada orang lain. Berapa pulpen Zaki sekarang?
A: Zaki sekarang memiliki 46 - 3 + 11 - 9 = 47 pulpen.

Verifikasi: Perhitungan yang benar: 46 - 3 = 43, 43 + 11 = 54, 54 - 9 = 45. Jawaban awal salah.

Jawaban akhir: 45 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 89 pulpen. Dia membagi 26 kepada teman. Kemudian menang 4 pulpen. Setelah itu membagi 1 kepada orang lain. Berapa pulpen Udin sekarang?
A: Udin sekarang memiliki 89 - 26 + 4 - 1 = 66 pulpen.

Verifikasi: Perhitungan: 89 - 26 = 63, 63 + 4 = 67, 67 - 1 = 66. Benar.

Jawaban akhir: 66 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Tono memiliki 98 spidol. Dia memberikan 15 kepada teman. Kemudian menerima 11 spidol. Setelah itu membagi 4 kepada orang lain. Berapa spidol Tono sekarang?
A: Tono sekarang memiliki 98 - 15 + 11 - 4 = 90 spidol.

Verifikasi: Perhitungan: 98 - 15 = 83, 83 + 11 = 94, 94 - 4 = 90. Benar.

Jawaban akhir: 90 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
