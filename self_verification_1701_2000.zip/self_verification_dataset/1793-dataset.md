# Dataset Verifikasi Diri 1793

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 36 buku tulis. Dia meminjamkan 5 kepada teman. Kemudian menang 13 buku tulis. Setelah itu memberikan 6 kepada orang lain. Berapa buku tulis Candra sekarang?
A: Candra sekarang memiliki 36 - 5 + 13 - 6 = 41 buku tulis.

Verifikasi: Perhitungan yang benar: 36 - 5 = 31, 31 + 13 = 44, 44 - 6 = 38. Jawaban awal salah.

Jawaban akhir: 38 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Rina memiliki 32 buku tulis. Dia memberikan 8 kepada teman. Kemudian menang 15 buku tulis. Setelah itu memberikan 4 kepada orang lain. Berapa buku tulis Rina sekarang?
A: Rina sekarang memiliki 32 - 8 + 15 - 4 = 35 buku tulis.

Verifikasi: Perhitungan: 32 - 8 = 24, 24 + 15 = 39, 39 - 4 = 35. Benar.

Jawaban akhir: 35 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Andi memiliki 93 pensil. Dia memberikan 3 kepada teman. Kemudian membeli 13 pensil. Setelah itu membagi 5 kepada orang lain. Berapa pensil Andi sekarang?
A: Andi sekarang memiliki 93 - 3 + 13 - 5 = 98 pensil.

Verifikasi: Perhitungan: 93 - 3 = 90, 90 + 13 = 103, 103 - 5 = 98. Benar.

Jawaban akhir: 98 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
