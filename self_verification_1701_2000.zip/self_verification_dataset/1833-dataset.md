# Dataset Verifikasi Diri 1833

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 79 kartu. Dia membagi 8 kepada teman. Kemudian menerima 18 kartu. Setelah itu meminjamkan 3 kepada orang lain. Berapa kartu Nina sekarang?
A: Nina sekarang memiliki 79 - 8 + 18 - 3 = 86 kartu.

Verifikasi: Perhitungan: 79 - 8 = 71, 71 + 18 = 89, 89 - 3 = 86. Benar.

Jawaban akhir: 86 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 65 kertas. Dia meminjamkan 18 kepada teman. Kemudian menang 5 kertas. Setelah itu membagi 7 kepada orang lain. Berapa kertas Udin sekarang?
A: Udin sekarang memiliki 65 - 18 + 5 - 7 = 46 kertas.

Verifikasi: Perhitungan yang benar: 65 - 18 = 47, 47 + 5 = 52, 52 - 7 = 45. Jawaban awal salah.

Jawaban akhir: 45 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Wati memiliki 100 kartu. Dia meminjamkan 7 kepada teman. Kemudian mendapat 4 kartu. Setelah itu memberikan 2 kepada orang lain. Berapa kartu Wati sekarang?
A: Wati sekarang memiliki 100 - 7 + 4 - 2 = 95 kartu.

Verifikasi: Perhitungan: 100 - 7 = 93, 93 + 4 = 97, 97 - 2 = 95. Benar.

Jawaban akhir: 95 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
