# Dataset Verifikasi Diri 1796

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 47 penghapus. Dia membagi 3 kepada teman. Kemudian menerima 20 penghapus. Setelah itu meminjamkan 13 kepada orang lain. Berapa penghapus Yudi sekarang?
A: Yudi sekarang memiliki 47 - 3 + 20 - 13 = 54 penghapus.

Verifikasi: Perhitungan yang benar: 47 - 3 = 44, 44 + 20 = 64, 64 - 13 = 51. Jawaban awal salah.

Jawaban akhir: 51 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Nina memiliki 100 penggaris. Dia meminjamkan 25 kepada teman. Kemudian mendapat 1 penggaris. Setelah itu memberikan 5 kepada orang lain. Berapa penggaris Nina sekarang?
A: Nina sekarang memiliki 100 - 25 + 1 - 5 = 71 penggaris.

Verifikasi: Perhitungan: 100 - 25 = 75, 75 + 1 = 76, 76 - 5 = 71. Benar.

Jawaban akhir: 71 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Siti memiliki 91 pensil. Dia membagi 1 kepada teman. Kemudian mendapat 11 pensil. Setelah itu memberikan 1 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 91 - 1 + 11 - 1 = 100 pensil.

Verifikasi: Perhitungan: 91 - 1 = 90, 90 + 11 = 101, 101 - 1 = 100. Benar.

Jawaban akhir: 100 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
