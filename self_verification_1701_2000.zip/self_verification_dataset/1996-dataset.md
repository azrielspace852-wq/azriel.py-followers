# Dataset Verifikasi Diri 1996

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 34 apel. Dia membagi 10 kepada teman. Kemudian membeli 17 apel. Setelah itu membagi 4 kepada orang lain. Berapa apel Udin sekarang?
A: Udin sekarang memiliki 34 - 10 + 17 - 4 = 37 apel.

Verifikasi: Perhitungan: 34 - 10 = 24, 24 + 17 = 41, 41 - 4 = 37. Benar.

Jawaban akhir: 37 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 15 buku. Dia meminjamkan 5 kepada teman. Kemudian mendapat 12 buku. Setelah itu membagi 15 kepada orang lain. Berapa buku Lina sekarang?
A: Lina sekarang memiliki 15 - 5 + 12 - 15 = 6 buku.

Verifikasi: Perhitungan yang benar: 15 - 5 = 10, 10 + 12 = 22, 22 - 15 = 7. Jawaban awal salah.

Jawaban akhir: 7 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 98 apel. Dia meminjamkan 7 kepada teman. Kemudian mendapat 20 apel. Setelah itu memberikan 12 kepada orang lain. Berapa apel Oscar sekarang?
A: Oscar sekarang memiliki 98 - 7 + 20 - 12 = 102 apel.

Verifikasi: Perhitungan yang benar: 98 - 7 = 91, 91 + 20 = 111, 111 - 12 = 99. Jawaban awal salah.

Jawaban akhir: 99 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
