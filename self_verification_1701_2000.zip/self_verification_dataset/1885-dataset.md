# Dataset Verifikasi Diri 1885

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 21 kelereng. Dia memberikan 4 kepada teman. Kemudian membeli 10 kelereng. Setelah itu meminjamkan 9 kepada orang lain. Berapa kelereng Zaki sekarang?
A: Zaki sekarang memiliki 21 - 4 + 10 - 9 = 18 kelereng.

Verifikasi: Perhitungan: 21 - 4 = 17, 17 + 10 = 27, 27 - 9 = 18. Benar.

Jawaban akhir: 18 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Maya memiliki 10 kelereng. Dia memberikan 1 kepada teman. Kemudian menerima 4 kelereng. Setelah itu membagi 6 kepada orang lain. Berapa kelereng Maya sekarang?
A: Maya sekarang memiliki 10 - 1 + 4 - 6 = 7 kelereng.

Verifikasi: Perhitungan: 10 - 1 = 9, 9 + 4 = 13, 13 - 6 = 7. Benar.

Jawaban akhir: 7 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Dedi memiliki 95 spidol. Dia memberikan 18 kepada teman. Kemudian mendapat 18 spidol. Setelah itu memberikan 10 kepada orang lain. Berapa spidol Dedi sekarang?
A: Dedi sekarang memiliki 95 - 18 + 18 - 10 = 85 spidol.

Verifikasi: Perhitungan: 95 - 18 = 77, 77 + 18 = 95, 95 - 10 = 85. Benar.

Jawaban akhir: 85 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
