# Dataset Verifikasi Diri 1962

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 81 kartu. Dia membagi 6 kepada teman. Kemudian membeli 7 kartu. Setelah itu membagi 1 kepada orang lain. Berapa kartu Candra sekarang?
A: Candra sekarang memiliki 81 - 6 + 7 - 1 = 81 kartu.

Verifikasi: Perhitungan: 81 - 6 = 75, 75 + 7 = 82, 82 - 1 = 81. Benar.

Jawaban akhir: 81 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Budi memiliki 87 pensil. Dia membagi 24 kepada teman. Kemudian menerima 12 pensil. Setelah itu membagi 7 kepada orang lain. Berapa pensil Budi sekarang?
A: Budi sekarang memiliki 87 - 24 + 12 - 7 = 68 pensil.

Verifikasi: Perhitungan: 87 - 24 = 63, 63 + 12 = 75, 75 - 7 = 68. Benar.

Jawaban akhir: 68 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Vina memiliki 37 kartu. Dia memberikan 12 kepada teman. Kemudian menerima 18 kartu. Setelah itu memberikan 1 kepada orang lain. Berapa kartu Vina sekarang?
A: Vina sekarang memiliki 37 - 12 + 18 - 1 = 42 kartu.

Verifikasi: Perhitungan: 37 - 12 = 25, 25 + 18 = 43, 43 - 1 = 42. Benar.

Jawaban akhir: 42 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
