# Dataset Verifikasi Diri 1752

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 44 stiker. Dia membagi 7 kepada teman. Kemudian menang 11 stiker. Setelah itu meminjamkan 14 kepada orang lain. Berapa stiker Lina sekarang?
A: Lina sekarang memiliki 44 - 7 + 11 - 14 = 36 stiker.

Verifikasi: Perhitungan yang benar: 44 - 7 = 37, 37 + 11 = 48, 48 - 14 = 34. Jawaban awal salah.

Jawaban akhir: 34 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Indra memiliki 71 penghapus. Dia membagi 2 kepada teman. Kemudian membeli 19 penghapus. Setelah itu meminjamkan 13 kepada orang lain. Berapa penghapus Indra sekarang?
A: Indra sekarang memiliki 71 - 2 + 19 - 13 = 75 penghapus.

Verifikasi: Perhitungan: 71 - 2 = 69, 69 + 19 = 88, 88 - 13 = 75. Benar.

Jawaban akhir: 75 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 26 pensil. Dia membagi 7 kepada teman. Kemudian menang 15 pensil. Setelah itu membagi 13 kepada orang lain. Berapa pensil Candra sekarang?
A: Candra sekarang memiliki 26 - 7 + 15 - 13 = 21 pensil.

Verifikasi: Perhitungan: 26 - 7 = 19, 19 + 15 = 34, 34 - 13 = 21. Benar.

Jawaban akhir: 21 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
