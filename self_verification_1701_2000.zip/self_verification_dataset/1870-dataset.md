# Dataset Verifikasi Diri 1870

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 86 penggaris. Dia memberikan 11 kepada teman. Kemudian mendapat 18 penggaris. Setelah itu meminjamkan 5 kepada orang lain. Berapa penggaris Udin sekarang?
A: Udin sekarang memiliki 86 - 11 + 18 - 5 = 88 penggaris.

Verifikasi: Perhitungan: 86 - 11 = 75, 75 + 18 = 93, 93 - 5 = 88. Benar.

Jawaban akhir: 88 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Siti memiliki 20 penghapus. Dia meminjamkan 6 kepada teman. Kemudian mendapat 16 penghapus. Setelah itu membagi 7 kepada orang lain. Berapa penghapus Siti sekarang?
A: Siti sekarang memiliki 20 - 6 + 16 - 7 = 26 penghapus.

Verifikasi: Perhitungan yang benar: 20 - 6 = 14, 14 + 16 = 30, 30 - 7 = 23. Jawaban awal salah.

Jawaban akhir: 23 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 83 kertas. Dia meminjamkan 2 kepada teman. Kemudian membeli 12 kertas. Setelah itu membagi 5 kepada orang lain. Berapa kertas Joko sekarang?
A: Joko sekarang memiliki 83 - 2 + 12 - 5 = 87 kertas.

Verifikasi: Perhitungan yang benar: 83 - 2 = 81, 81 + 12 = 93, 93 - 5 = 88. Jawaban awal salah.

Jawaban akhir: 88 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
