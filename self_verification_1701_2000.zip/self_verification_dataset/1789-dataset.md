# Dataset Verifikasi Diri 1789

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 22 pulpen. Dia memberikan 5 kepada teman. Kemudian menang 6 pulpen. Setelah itu memberikan 11 kepada orang lain. Berapa pulpen Indra sekarang?
A: Indra sekarang memiliki 22 - 5 + 6 - 11 = 10 pulpen.

Verifikasi: Perhitungan yang benar: 22 - 5 = 17, 17 + 6 = 23, 23 - 11 = 12. Jawaban awal salah.

Jawaban akhir: 12 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Andi memiliki 56 pulpen. Dia memberikan 10 kepada teman. Kemudian menerima 13 pulpen. Setelah itu membagi 2 kepada orang lain. Berapa pulpen Andi sekarang?
A: Andi sekarang memiliki 56 - 10 + 13 - 2 = 55 pulpen.

Verifikasi: Perhitungan yang benar: 56 - 10 = 46, 46 + 13 = 59, 59 - 2 = 57. Jawaban awal salah.

Jawaban akhir: 57 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Indra memiliki 88 spidol. Dia membagi 4 kepada teman. Kemudian menang 4 spidol. Setelah itu meminjamkan 7 kepada orang lain. Berapa spidol Indra sekarang?
A: Indra sekarang memiliki 88 - 4 + 4 - 7 = 81 spidol.

Verifikasi: Perhitungan: 88 - 4 = 84, 84 + 4 = 88, 88 - 7 = 81. Benar.

Jawaban akhir: 81 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
