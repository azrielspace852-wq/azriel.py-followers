# Dataset Verifikasi Diri 1703

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 60 stiker. Dia meminjamkan 2 kepada teman. Kemudian menang 6 stiker. Setelah itu memberikan 6 kepada orang lain. Berapa stiker Gita sekarang?
A: Gita sekarang memiliki 60 - 2 + 6 - 6 = 58 stiker.

Verifikasi: Perhitungan: 60 - 2 = 58, 58 + 6 = 64, 64 - 6 = 58. Benar.

Jawaban akhir: 58 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Oscar memiliki 73 kartu. Dia memberikan 18 kepada teman. Kemudian mendapat 14 kartu. Setelah itu meminjamkan 15 kepada orang lain. Berapa kartu Oscar sekarang?
A: Oscar sekarang memiliki 73 - 18 + 14 - 15 = 54 kartu.

Verifikasi: Perhitungan: 73 - 18 = 55, 55 + 14 = 69, 69 - 15 = 54. Benar.

Jawaban akhir: 54 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 38 buku tulis. Dia meminjamkan 10 kepada teman. Kemudian membeli 6 buku tulis. Setelah itu meminjamkan 1 kepada orang lain. Berapa buku tulis Fajar sekarang?
A: Fajar sekarang memiliki 38 - 10 + 6 - 1 = 36 buku tulis.

Verifikasi: Perhitungan yang benar: 38 - 10 = 28, 28 + 6 = 34, 34 - 1 = 33. Jawaban awal salah.

Jawaban akhir: 33 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
