# Dataset Verifikasi Diri 1701

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 92 apel. Dia memberikan 18 kepada teman. Kemudian mendapat 16 apel. Setelah itu meminjamkan 1 kepada orang lain. Berapa apel Hani sekarang?
A: Hani sekarang memiliki 92 - 18 + 16 - 1 = 89 apel.

Verifikasi: Perhitungan: 92 - 18 = 74, 74 + 16 = 90, 90 - 1 = 89. Benar.

Jawaban akhir: 89 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 25 rupiah. Dia membagi 8 kepada teman. Kemudian mendapat 8 rupiah. Setelah itu memberikan 7 kepada orang lain. Berapa rupiah Gita sekarang?
A: Gita sekarang memiliki 25 - 8 + 8 - 7 = 21 rupiah.

Verifikasi: Perhitungan yang benar: 25 - 8 = 17, 17 + 8 = 25, 25 - 7 = 18. Jawaban awal salah.

Jawaban akhir: 18 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Siti memiliki 53 pensil. Dia membagi 10 kepada teman. Kemudian membeli 18 pensil. Setelah itu membagi 1 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 53 - 10 + 18 - 1 = 60 pensil.

Verifikasi: Perhitungan: 53 - 10 = 43, 43 + 18 = 61, 61 - 1 = 60. Benar.

Jawaban akhir: 60 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
