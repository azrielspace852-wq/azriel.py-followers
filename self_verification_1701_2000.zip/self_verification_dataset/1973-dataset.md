# Dataset Verifikasi Diri 1973

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 43 kertas. Dia memberikan 9 kepada teman. Kemudian menang 14 kertas. Setelah itu meminjamkan 10 kepada orang lain. Berapa kertas Tono sekarang?
A: Tono sekarang memiliki 43 - 9 + 14 - 10 = 38 kertas.

Verifikasi: Perhitungan: 43 - 9 = 34, 34 + 14 = 48, 48 - 10 = 38. Benar.

Jawaban akhir: 38 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Putri memiliki 100 kelereng. Dia meminjamkan 18 kepada teman. Kemudian mendapat 10 kelereng. Setelah itu membagi 2 kepada orang lain. Berapa kelereng Putri sekarang?
A: Putri sekarang memiliki 100 - 18 + 10 - 2 = 90 kelereng.

Verifikasi: Perhitungan: 100 - 18 = 82, 82 + 10 = 92, 92 - 2 = 90. Benar.

Jawaban akhir: 90 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 20 rupiah. Dia memberikan 2 kepada teman. Kemudian menang 3 rupiah. Setelah itu membagi 8 kepada orang lain. Berapa rupiah Vina sekarang?
A: Vina sekarang memiliki 20 - 2 + 3 - 8 = 11 rupiah.

Verifikasi: Perhitungan yang benar: 20 - 2 = 18, 18 + 3 = 21, 21 - 8 = 13. Jawaban awal salah.

Jawaban akhir: 13 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
