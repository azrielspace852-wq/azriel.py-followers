# Dataset Verifikasi Diri 1978

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 67 pulpen. Dia membagi 12 kepada teman. Kemudian menerima 12 pulpen. Setelah itu membagi 12 kepada orang lain. Berapa pulpen Rina sekarang?
A: Rina sekarang memiliki 67 - 12 + 12 - 12 = 58 pulpen.

Verifikasi: Perhitungan yang benar: 67 - 12 = 55, 55 + 12 = 67, 67 - 12 = 55. Jawaban awal salah.

Jawaban akhir: 55 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Siti memiliki 59 kelereng. Dia memberikan 13 kepada teman. Kemudian membeli 16 kelereng. Setelah itu meminjamkan 13 kepada orang lain. Berapa kelereng Siti sekarang?
A: Siti sekarang memiliki 59 - 13 + 16 - 13 = 49 kelereng.

Verifikasi: Perhitungan: 59 - 13 = 46, 46 + 16 = 62, 62 - 13 = 49. Benar.

Jawaban akhir: 49 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Oscar memiliki 63 stiker. Dia meminjamkan 17 kepada teman. Kemudian membeli 7 stiker. Setelah itu memberikan 10 kepada orang lain. Berapa stiker Oscar sekarang?
A: Oscar sekarang memiliki 63 - 17 + 7 - 10 = 46 stiker.

Verifikasi: Perhitungan yang benar: 63 - 17 = 46, 46 + 7 = 53, 53 - 10 = 43. Jawaban awal salah.

Jawaban akhir: 43 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
