# Dataset Verifikasi Diri 1815

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 73 buku. Dia membagi 20 kepada teman. Kemudian menang 11 buku. Setelah itu memberikan 5 kepada orang lain. Berapa buku Candra sekarang?
A: Candra sekarang memiliki 73 - 20 + 11 - 5 = 59 buku.

Verifikasi: Perhitungan: 73 - 20 = 53, 53 + 11 = 64, 64 - 5 = 59. Benar.

Jawaban akhir: 59 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 31 buku tulis. Dia membagi 4 kepada teman. Kemudian menerima 6 buku tulis. Setelah itu meminjamkan 10 kepada orang lain. Berapa buku tulis Dedi sekarang?
A: Dedi sekarang memiliki 31 - 4 + 6 - 10 = 23 buku tulis.

Verifikasi: Perhitungan: 31 - 4 = 27, 27 + 6 = 33, 33 - 10 = 23. Benar.

Jawaban akhir: 23 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 51 penghapus. Dia membagi 6 kepada teman. Kemudian menerima 3 penghapus. Setelah itu memberikan 7 kepada orang lain. Berapa penghapus Joko sekarang?
A: Joko sekarang memiliki 51 - 6 + 3 - 7 = 41 penghapus.

Verifikasi: Perhitungan: 51 - 6 = 45, 45 + 3 = 48, 48 - 7 = 41. Benar.

Jawaban akhir: 41 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
