# Dataset Verifikasi Diri 1936

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 35 kelereng. Dia memberikan 4 kepada teman. Kemudian membeli 17 kelereng. Setelah itu membagi 14 kepada orang lain. Berapa kelereng Kiki sekarang?
A: Kiki sekarang memiliki 35 - 4 + 17 - 14 = 35 kelereng.

Verifikasi: Perhitungan yang benar: 35 - 4 = 31, 31 + 17 = 48, 48 - 14 = 34. Jawaban awal salah.

Jawaban akhir: 34 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 93 bola. Dia membagi 15 kepada teman. Kemudian menang 10 bola. Setelah itu memberikan 10 kepada orang lain. Berapa bola Rina sekarang?
A: Rina sekarang memiliki 93 - 15 + 10 - 10 = 78 bola.

Verifikasi: Perhitungan: 93 - 15 = 78, 78 + 10 = 88, 88 - 10 = 78. Benar.

Jawaban akhir: 78 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Nina memiliki 54 stiker. Dia membagi 5 kepada teman. Kemudian mendapat 7 stiker. Setelah itu memberikan 8 kepada orang lain. Berapa stiker Nina sekarang?
A: Nina sekarang memiliki 54 - 5 + 7 - 8 = 48 stiker.

Verifikasi: Perhitungan: 54 - 5 = 49, 49 + 7 = 56, 56 - 8 = 48. Benar.

Jawaban akhir: 48 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
