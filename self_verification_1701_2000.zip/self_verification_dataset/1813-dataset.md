# Dataset Verifikasi Diri 1813

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 21 spidol. Dia memberikan 6 kepada teman. Kemudian membeli 16 spidol. Setelah itu meminjamkan 1 kepada orang lain. Berapa spidol Dedi sekarang?
A: Dedi sekarang memiliki 21 - 6 + 16 - 1 = 30 spidol.

Verifikasi: Perhitungan: 21 - 6 = 15, 15 + 16 = 31, 31 - 1 = 30. Benar.

Jawaban akhir: 30 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 21 penghapus. Dia memberikan 3 kepada teman. Kemudian menang 1 penghapus. Setelah itu memberikan 11 kepada orang lain. Berapa penghapus Hani sekarang?
A: Hani sekarang memiliki 21 - 3 + 1 - 11 = 8 penghapus.

Verifikasi: Perhitungan: 21 - 3 = 18, 18 + 1 = 19, 19 - 11 = 8. Benar.

Jawaban akhir: 8 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 32 kertas. Dia meminjamkan 2 kepada teman. Kemudian menerima 13 kertas. Setelah itu memberikan 10 kepada orang lain. Berapa kertas Vina sekarang?
A: Vina sekarang memiliki 32 - 2 + 13 - 10 = 33 kertas.

Verifikasi: Perhitungan: 32 - 2 = 30, 30 + 13 = 43, 43 - 10 = 33. Benar.

Jawaban akhir: 33 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
