# Dataset Verifikasi Diri 1873

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 79 rupiah. Dia memberikan 24 kepada teman. Kemudian menerima 12 rupiah. Setelah itu membagi 12 kepada orang lain. Berapa rupiah Kiki sekarang?
A: Kiki sekarang memiliki 79 - 24 + 12 - 12 = 55 rupiah.

Verifikasi: Perhitungan: 79 - 24 = 55, 55 + 12 = 67, 67 - 12 = 55. Benar.

Jawaban akhir: 55 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Andi memiliki 37 kartu. Dia membagi 7 kepada teman. Kemudian menerima 1 kartu. Setelah itu membagi 11 kepada orang lain. Berapa kartu Andi sekarang?
A: Andi sekarang memiliki 37 - 7 + 1 - 11 = 23 kartu.

Verifikasi: Perhitungan yang benar: 37 - 7 = 30, 30 + 1 = 31, 31 - 11 = 20. Jawaban awal salah.

Jawaban akhir: 20 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 35 bola. Dia meminjamkan 4 kepada teman. Kemudian membeli 4 bola. Setelah itu membagi 2 kepada orang lain. Berapa bola Nina sekarang?
A: Nina sekarang memiliki 35 - 4 + 4 - 2 = 36 bola.

Verifikasi: Perhitungan yang benar: 35 - 4 = 31, 31 + 4 = 35, 35 - 2 = 33. Jawaban awal salah.

Jawaban akhir: 33 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
