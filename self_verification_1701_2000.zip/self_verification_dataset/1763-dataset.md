# Dataset Verifikasi Diri 1763

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 72 kue. Dia meminjamkan 1 kepada teman. Kemudian membeli 1 kue. Setelah itu meminjamkan 11 kepada orang lain. Berapa kue Eko sekarang?
A: Eko sekarang memiliki 72 - 1 + 1 - 11 = 61 kue.

Verifikasi: Perhitungan: 72 - 1 = 71, 71 + 1 = 72, 72 - 11 = 61. Benar.

Jawaban akhir: 61 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Vina memiliki 44 buku. Dia membagi 10 kepada teman. Kemudian menerima 17 buku. Setelah itu memberikan 6 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 44 - 10 + 17 - 6 = 44 buku.

Verifikasi: Perhitungan yang benar: 44 - 10 = 34, 34 + 17 = 51, 51 - 6 = 45. Jawaban awal salah.

Jawaban akhir: 45 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 98 kertas. Dia memberikan 6 kepada teman. Kemudian menerima 6 kertas. Setelah itu membagi 10 kepada orang lain. Berapa kertas Andi sekarang?
A: Andi sekarang memiliki 98 - 6 + 6 - 10 = 91 kertas.

Verifikasi: Perhitungan yang benar: 98 - 6 = 92, 92 + 6 = 98, 98 - 10 = 88. Jawaban awal salah.

Jawaban akhir: 88 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
