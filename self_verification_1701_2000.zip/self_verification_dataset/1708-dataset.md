# Dataset Verifikasi Diri 1708

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 11 bola. Dia membagi 2 kepada teman. Kemudian menerima 9 bola. Setelah itu membagi 14 kepada orang lain. Berapa bola Lina sekarang?
A: Lina sekarang memiliki 11 - 2 + 9 - 14 = 4 bola.

Verifikasi: Perhitungan: 11 - 2 = 9, 9 + 9 = 18, 18 - 14 = 4. Benar.

Jawaban akhir: 4 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Lina memiliki 24 pulpen. Dia membagi 4 kepada teman. Kemudian membeli 17 pulpen. Setelah itu membagi 8 kepada orang lain. Berapa pulpen Lina sekarang?
A: Lina sekarang memiliki 24 - 4 + 17 - 8 = 27 pulpen.

Verifikasi: Perhitungan yang benar: 24 - 4 = 20, 20 + 17 = 37, 37 - 8 = 29. Jawaban awal salah.

Jawaban akhir: 29 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Kiki memiliki 39 spidol. Dia meminjamkan 5 kepada teman. Kemudian mendapat 2 spidol. Setelah itu membagi 11 kepada orang lain. Berapa spidol Kiki sekarang?
A: Kiki sekarang memiliki 39 - 5 + 2 - 11 = 23 spidol.

Verifikasi: Perhitungan yang benar: 39 - 5 = 34, 34 + 2 = 36, 36 - 11 = 25. Jawaban awal salah.

Jawaban akhir: 25 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
