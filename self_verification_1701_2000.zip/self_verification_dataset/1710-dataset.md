# Dataset Verifikasi Diri 1710

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 33 penggaris. Dia meminjamkan 7 kepada teman. Kemudian menang 7 penggaris. Setelah itu membagi 13 kepada orang lain. Berapa penggaris Candra sekarang?
A: Candra sekarang memiliki 33 - 7 + 7 - 13 = 20 penggaris.

Verifikasi: Perhitungan: 33 - 7 = 26, 26 + 7 = 33, 33 - 13 = 20. Benar.

Jawaban akhir: 20 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 58 stiker. Dia meminjamkan 11 kepada teman. Kemudian mendapat 9 stiker. Setelah itu meminjamkan 1 kepada orang lain. Berapa stiker Indra sekarang?
A: Indra sekarang memiliki 58 - 11 + 9 - 1 = 54 stiker.

Verifikasi: Perhitungan yang benar: 58 - 11 = 47, 47 + 9 = 56, 56 - 1 = 55. Jawaban awal salah.

Jawaban akhir: 55 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 66 kartu. Dia meminjamkan 8 kepada teman. Kemudian membeli 3 kartu. Setelah itu memberikan 5 kepada orang lain. Berapa kartu Yudi sekarang?
A: Yudi sekarang memiliki 66 - 8 + 3 - 5 = 54 kartu.

Verifikasi: Perhitungan yang benar: 66 - 8 = 58, 58 + 3 = 61, 61 - 5 = 56. Jawaban awal salah.

Jawaban akhir: 56 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
