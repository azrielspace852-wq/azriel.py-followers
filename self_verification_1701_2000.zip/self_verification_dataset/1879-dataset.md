# Dataset Verifikasi Diri 1879

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 39 penggaris. Dia membagi 1 kepada teman. Kemudian menerima 9 penggaris. Setelah itu meminjamkan 7 kepada orang lain. Berapa penggaris Oscar sekarang?
A: Oscar sekarang memiliki 39 - 1 + 9 - 7 = 40 penggaris.

Verifikasi: Perhitungan: 39 - 1 = 38, 38 + 9 = 47, 47 - 7 = 40. Benar.

Jawaban akhir: 40 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Indra memiliki 17 bola. Dia meminjamkan 2 kepada teman. Kemudian menerima 2 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Indra sekarang?
A: Indra sekarang memiliki 17 - 2 + 2 - 9 = 11 bola.

Verifikasi: Perhitungan yang benar: 17 - 2 = 15, 15 + 2 = 17, 17 - 9 = 8. Jawaban awal salah.

Jawaban akhir: 8 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Lina memiliki 30 bola. Dia membagi 3 kepada teman. Kemudian menerima 6 bola. Setelah itu membagi 13 kepada orang lain. Berapa bola Lina sekarang?
A: Lina sekarang memiliki 30 - 3 + 6 - 13 = 22 bola.

Verifikasi: Perhitungan yang benar: 30 - 3 = 27, 27 + 6 = 33, 33 - 13 = 20. Jawaban awal salah.

Jawaban akhir: 20 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
