# Dataset Verifikasi Diri 1965

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 76 spidol. Dia membagi 10 kepada teman. Kemudian mendapat 14 spidol. Setelah itu meminjamkan 4 kepada orang lain. Berapa spidol Candra sekarang?
A: Candra sekarang memiliki 76 - 10 + 14 - 4 = 76 spidol.

Verifikasi: Perhitungan: 76 - 10 = 66, 66 + 14 = 80, 80 - 4 = 76. Benar.

Jawaban akhir: 76 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 43 kertas. Dia membagi 13 kepada teman. Kemudian membeli 16 kertas. Setelah itu meminjamkan 5 kepada orang lain. Berapa kertas Putri sekarang?
A: Putri sekarang memiliki 43 - 13 + 16 - 5 = 41 kertas.

Verifikasi: Perhitungan: 43 - 13 = 30, 30 + 16 = 46, 46 - 5 = 41. Benar.

Jawaban akhir: 41 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Budi memiliki 70 kelereng. Dia memberikan 14 kepada teman. Kemudian mendapat 14 kelereng. Setelah itu meminjamkan 1 kepada orang lain. Berapa kelereng Budi sekarang?
A: Budi sekarang memiliki 70 - 14 + 14 - 1 = 69 kelereng.

Verifikasi: Perhitungan: 70 - 14 = 56, 56 + 14 = 70, 70 - 1 = 69. Benar.

Jawaban akhir: 69 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
