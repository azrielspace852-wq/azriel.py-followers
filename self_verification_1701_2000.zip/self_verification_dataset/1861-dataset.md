# Dataset Verifikasi Diri 1861

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 14 kue. Dia membagi 3 kepada teman. Kemudian mendapat 14 kue. Setelah itu memberikan 10 kepada orang lain. Berapa kue Zaki sekarang?
A: Zaki sekarang memiliki 14 - 3 + 14 - 10 = 17 kue.

Verifikasi: Perhitungan yang benar: 14 - 3 = 11, 11 + 14 = 25, 25 - 10 = 15. Jawaban awal salah.

Jawaban akhir: 15 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 84 kertas. Dia meminjamkan 2 kepada teman. Kemudian menang 9 kertas. Setelah itu meminjamkan 5 kepada orang lain. Berapa kertas Lina sekarang?
A: Lina sekarang memiliki 84 - 2 + 9 - 5 = 89 kertas.

Verifikasi: Perhitungan yang benar: 84 - 2 = 82, 82 + 9 = 91, 91 - 5 = 86. Jawaban awal salah.

Jawaban akhir: 86 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 85 pulpen. Dia memberikan 27 kepada teman. Kemudian menerima 19 pulpen. Setelah itu memberikan 8 kepada orang lain. Berapa pulpen Eko sekarang?
A: Eko sekarang memiliki 85 - 27 + 19 - 8 = 69 pulpen.

Verifikasi: Perhitungan: 85 - 27 = 58, 58 + 19 = 77, 77 - 8 = 69. Benar.

Jawaban akhir: 69 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
