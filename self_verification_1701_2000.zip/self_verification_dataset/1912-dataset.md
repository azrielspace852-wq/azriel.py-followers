# Dataset Verifikasi Diri 1912

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 67 kelereng. Dia memberikan 16 kepada teman. Kemudian menang 14 kelereng. Setelah itu memberikan 12 kepada orang lain. Berapa kelereng Vina sekarang?
A: Vina sekarang memiliki 67 - 16 + 14 - 12 = 53 kelereng.

Verifikasi: Perhitungan: 67 - 16 = 51, 51 + 14 = 65, 65 - 12 = 53. Benar.

Jawaban akhir: 53 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Putri memiliki 97 spidol. Dia memberikan 10 kepada teman. Kemudian membeli 18 spidol. Setelah itu meminjamkan 3 kepada orang lain. Berapa spidol Putri sekarang?
A: Putri sekarang memiliki 97 - 10 + 18 - 3 = 102 spidol.

Verifikasi: Perhitungan: 97 - 10 = 87, 87 + 18 = 105, 105 - 3 = 102. Benar.

Jawaban akhir: 102 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 53 buku tulis. Dia meminjamkan 11 kepada teman. Kemudian membeli 9 buku tulis. Setelah itu memberikan 4 kepada orang lain. Berapa buku tulis Andi sekarang?
A: Andi sekarang memiliki 53 - 11 + 9 - 4 = 47 buku tulis.

Verifikasi: Perhitungan: 53 - 11 = 42, 42 + 9 = 51, 51 - 4 = 47. Benar.

Jawaban akhir: 47 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
