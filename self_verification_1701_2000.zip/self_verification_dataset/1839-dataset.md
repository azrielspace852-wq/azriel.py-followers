# Dataset Verifikasi Diri 1839

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 25 pensil. Dia membagi 6 kepada teman. Kemudian membeli 10 pensil. Setelah itu membagi 4 kepada orang lain. Berapa pensil Fajar sekarang?
A: Fajar sekarang memiliki 25 - 6 + 10 - 4 = 25 pensil.

Verifikasi: Perhitungan: 25 - 6 = 19, 19 + 10 = 29, 29 - 4 = 25. Benar.

Jawaban akhir: 25 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 34 bola. Dia meminjamkan 6 kepada teman. Kemudian mendapat 5 bola. Setelah itu memberikan 4 kepada orang lain. Berapa bola Udin sekarang?
A: Udin sekarang memiliki 34 - 6 + 5 - 4 = 29 bola.

Verifikasi: Perhitungan: 34 - 6 = 28, 28 + 5 = 33, 33 - 4 = 29. Benar.

Jawaban akhir: 29 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 25 apel. Dia memberikan 6 kepada teman. Kemudian menerima 5 apel. Setelah itu memberikan 8 kepada orang lain. Berapa apel Gita sekarang?
A: Gita sekarang memiliki 25 - 6 + 5 - 8 = 16 apel.

Verifikasi: Perhitungan: 25 - 6 = 19, 19 + 5 = 24, 24 - 8 = 16. Benar.

Jawaban akhir: 16 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
