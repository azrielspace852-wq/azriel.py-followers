# Dataset Verifikasi Diri 1955

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 94 spidol. Dia memberikan 23 kepada teman. Kemudian mendapat 8 spidol. Setelah itu memberikan 9 kepada orang lain. Berapa spidol Candra sekarang?
A: Candra sekarang memiliki 94 - 23 + 8 - 9 = 72 spidol.

Verifikasi: Perhitungan yang benar: 94 - 23 = 71, 71 + 8 = 79, 79 - 9 = 70. Jawaban awal salah.

Jawaban akhir: 70 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Kiki memiliki 95 penggaris. Dia membagi 21 kepada teman. Kemudian membeli 10 penggaris. Setelah itu membagi 6 kepada orang lain. Berapa penggaris Kiki sekarang?
A: Kiki sekarang memiliki 95 - 21 + 10 - 6 = 81 penggaris.

Verifikasi: Perhitungan yang benar: 95 - 21 = 74, 74 + 10 = 84, 84 - 6 = 78. Jawaban awal salah.

Jawaban akhir: 78 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 25 rupiah. Dia memberikan 4 kepada teman. Kemudian mendapat 19 rupiah. Setelah itu membagi 12 kepada orang lain. Berapa rupiah Putri sekarang?
A: Putri sekarang memiliki 25 - 4 + 19 - 12 = 28 rupiah.

Verifikasi: Perhitungan: 25 - 4 = 21, 21 + 19 = 40, 40 - 12 = 28. Benar.

Jawaban akhir: 28 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
