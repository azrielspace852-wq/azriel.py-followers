# Dataset Verifikasi Diri 1967

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 91 kartu. Dia membagi 8 kepada teman. Kemudian mendapat 3 kartu. Setelah itu membagi 10 kepada orang lain. Berapa kartu Andi sekarang?
A: Andi sekarang memiliki 91 - 8 + 3 - 10 = 76 kartu.

Verifikasi: Perhitungan: 91 - 8 = 83, 83 + 3 = 86, 86 - 10 = 76. Benar.

Jawaban akhir: 76 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Hani memiliki 48 kelereng. Dia memberikan 11 kepada teman. Kemudian menang 5 kelereng. Setelah itu memberikan 4 kepada orang lain. Berapa kelereng Hani sekarang?
A: Hani sekarang memiliki 48 - 11 + 5 - 4 = 40 kelereng.

Verifikasi: Perhitungan yang benar: 48 - 11 = 37, 37 + 5 = 42, 42 - 4 = 38. Jawaban awal salah.

Jawaban akhir: 38 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 17 penggaris. Dia memberikan 3 kepada teman. Kemudian menerima 5 penggaris. Setelah itu meminjamkan 14 kepada orang lain. Berapa penggaris Yudi sekarang?
A: Yudi sekarang memiliki 17 - 3 + 5 - 14 = 5 penggaris.

Verifikasi: Perhitungan: 17 - 3 = 14, 14 + 5 = 19, 19 - 14 = 5. Benar.

Jawaban akhir: 5 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
