# Dataset Verifikasi Diri 1985

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 70 kartu. Dia meminjamkan 17 kepada teman. Kemudian membeli 8 kartu. Setelah itu memberikan 10 kepada orang lain. Berapa kartu Gita sekarang?
A: Gita sekarang memiliki 70 - 17 + 8 - 10 = 51 kartu.

Verifikasi: Perhitungan: 70 - 17 = 53, 53 + 8 = 61, 61 - 10 = 51. Benar.

Jawaban akhir: 51 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Andi memiliki 97 kartu. Dia meminjamkan 28 kepada teman. Kemudian menerima 7 kartu. Setelah itu memberikan 2 kepada orang lain. Berapa kartu Andi sekarang?
A: Andi sekarang memiliki 97 - 28 + 7 - 2 = 72 kartu.

Verifikasi: Perhitungan yang benar: 97 - 28 = 69, 69 + 7 = 76, 76 - 2 = 74. Jawaban awal salah.

Jawaban akhir: 74 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 13 buku tulis. Dia meminjamkan 3 kepada teman. Kemudian menerima 13 buku tulis. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku tulis Yudi sekarang?
A: Yudi sekarang memiliki 13 - 3 + 13 - 11 = 12 buku tulis.

Verifikasi: Perhitungan: 13 - 3 = 10, 10 + 13 = 23, 23 - 11 = 12. Benar.

Jawaban akhir: 12 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
