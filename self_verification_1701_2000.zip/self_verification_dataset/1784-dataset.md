# Dataset Verifikasi Diri 1784

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 64 spidol. Dia memberikan 11 kepada teman. Kemudian menerima 3 spidol. Setelah itu meminjamkan 9 kepada orang lain. Berapa spidol Joko sekarang?
A: Joko sekarang memiliki 64 - 11 + 3 - 9 = 47 spidol.

Verifikasi: Perhitungan: 64 - 11 = 53, 53 + 3 = 56, 56 - 9 = 47. Benar.

Jawaban akhir: 47 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 61 kartu. Dia memberikan 11 kepada teman. Kemudian mendapat 5 kartu. Setelah itu membagi 15 kepada orang lain. Berapa kartu Indra sekarang?
A: Indra sekarang memiliki 61 - 11 + 5 - 15 = 40 kartu.

Verifikasi: Perhitungan: 61 - 11 = 50, 50 + 5 = 55, 55 - 15 = 40. Benar.

Jawaban akhir: 40 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Zaki memiliki 35 buku. Dia memberikan 3 kepada teman. Kemudian menang 16 buku. Setelah itu memberikan 7 kepada orang lain. Berapa buku Zaki sekarang?
A: Zaki sekarang memiliki 35 - 3 + 16 - 7 = 41 buku.

Verifikasi: Perhitungan: 35 - 3 = 32, 32 + 16 = 48, 48 - 7 = 41. Benar.

Jawaban akhir: 41 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
