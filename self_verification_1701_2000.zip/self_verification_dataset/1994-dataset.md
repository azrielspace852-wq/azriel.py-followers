# Dataset Verifikasi Diri 1994

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 55 pensil. Dia meminjamkan 18 kepada teman. Kemudian menerima 7 pensil. Setelah itu membagi 1 kepada orang lain. Berapa pensil Tono sekarang?
A: Tono sekarang memiliki 55 - 18 + 7 - 1 = 41 pensil.

Verifikasi: Perhitungan yang benar: 55 - 18 = 37, 37 + 7 = 44, 44 - 1 = 43. Jawaban awal salah.

Jawaban akhir: 43 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 89 buku tulis. Dia membagi 15 kepada teman. Kemudian menang 20 buku tulis. Setelah itu memberikan 13 kepada orang lain. Berapa buku tulis Fajar sekarang?
A: Fajar sekarang memiliki 89 - 15 + 20 - 13 = 81 buku tulis.

Verifikasi: Perhitungan: 89 - 15 = 74, 74 + 20 = 94, 94 - 13 = 81. Benar.

Jawaban akhir: 81 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Maya memiliki 52 kartu. Dia memberikan 3 kepada teman. Kemudian mendapat 5 kartu. Setelah itu meminjamkan 2 kepada orang lain. Berapa kartu Maya sekarang?
A: Maya sekarang memiliki 52 - 3 + 5 - 2 = 50 kartu.

Verifikasi: Perhitungan yang benar: 52 - 3 = 49, 49 + 5 = 54, 54 - 2 = 52. Jawaban awal salah.

Jawaban akhir: 52 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
