# Dataset Verifikasi Diri 1915

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 27 kartu. Dia memberikan 2 kepada teman. Kemudian menang 3 kartu. Setelah itu meminjamkan 4 kepada orang lain. Berapa kartu Siti sekarang?
A: Siti sekarang memiliki 27 - 2 + 3 - 4 = 26 kartu.

Verifikasi: Perhitungan yang benar: 27 - 2 = 25, 25 + 3 = 28, 28 - 4 = 24. Jawaban awal salah.

Jawaban akhir: 24 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Hani memiliki 20 spidol. Dia meminjamkan 6 kepada teman. Kemudian membeli 12 spidol. Setelah itu membagi 15 kepada orang lain. Berapa spidol Hani sekarang?
A: Hani sekarang memiliki 20 - 6 + 12 - 15 = 11 spidol.

Verifikasi: Perhitungan: 20 - 6 = 14, 14 + 12 = 26, 26 - 15 = 11. Benar.

Jawaban akhir: 11 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Siti memiliki 54 penggaris. Dia memberikan 11 kepada teman. Kemudian menerima 9 penggaris. Setelah itu meminjamkan 4 kepada orang lain. Berapa penggaris Siti sekarang?
A: Siti sekarang memiliki 54 - 11 + 9 - 4 = 48 penggaris.

Verifikasi: Perhitungan: 54 - 11 = 43, 43 + 9 = 52, 52 - 4 = 48. Benar.

Jawaban akhir: 48 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
