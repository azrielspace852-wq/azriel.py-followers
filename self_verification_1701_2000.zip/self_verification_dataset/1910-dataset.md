# Dataset Verifikasi Diri 1910

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 42 kelereng. Dia meminjamkan 12 kepada teman. Kemudian menang 15 kelereng. Setelah itu meminjamkan 6 kepada orang lain. Berapa kelereng Fajar sekarang?
A: Fajar sekarang memiliki 42 - 12 + 15 - 6 = 39 kelereng.

Verifikasi: Perhitungan: 42 - 12 = 30, 30 + 15 = 45, 45 - 6 = 39. Benar.

Jawaban akhir: 39 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 29 penggaris. Dia membagi 7 kepada teman. Kemudian menerima 16 penggaris. Setelah itu memberikan 9 kepada orang lain. Berapa penggaris Gita sekarang?
A: Gita sekarang memiliki 29 - 7 + 16 - 9 = 28 penggaris.

Verifikasi: Perhitungan yang benar: 29 - 7 = 22, 22 + 16 = 38, 38 - 9 = 29. Jawaban awal salah.

Jawaban akhir: 29 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Dedi memiliki 38 rupiah. Dia membagi 11 kepada teman. Kemudian menang 12 rupiah. Setelah itu membagi 13 kepada orang lain. Berapa rupiah Dedi sekarang?
A: Dedi sekarang memiliki 38 - 11 + 12 - 13 = 26 rupiah.

Verifikasi: Perhitungan: 38 - 11 = 27, 27 + 12 = 39, 39 - 13 = 26. Benar.

Jawaban akhir: 26 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
