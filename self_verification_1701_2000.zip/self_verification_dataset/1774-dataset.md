# Dataset Verifikasi Diri 1774

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 16 rupiah. Dia membagi 4 kepada teman. Kemudian membeli 3 rupiah. Setelah itu membagi 4 kepada orang lain. Berapa rupiah Vina sekarang?
A: Vina sekarang memiliki 16 - 4 + 3 - 4 = 11 rupiah.

Verifikasi: Perhitungan: 16 - 4 = 12, 12 + 3 = 15, 15 - 4 = 11. Benar.

Jawaban akhir: 11 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Eko memiliki 50 penggaris. Dia memberikan 14 kepada teman. Kemudian menang 16 penggaris. Setelah itu memberikan 14 kepada orang lain. Berapa penggaris Eko sekarang?
A: Eko sekarang memiliki 50 - 14 + 16 - 14 = 38 penggaris.

Verifikasi: Perhitungan: 50 - 14 = 36, 36 + 16 = 52, 52 - 14 = 38. Benar.

Jawaban akhir: 38 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Vina memiliki 23 kelereng. Dia membagi 3 kepada teman. Kemudian menerima 16 kelereng. Setelah itu memberikan 12 kepada orang lain. Berapa kelereng Vina sekarang?
A: Vina sekarang memiliki 23 - 3 + 16 - 12 = 24 kelereng.

Verifikasi: Perhitungan: 23 - 3 = 20, 20 + 16 = 36, 36 - 12 = 24. Benar.

Jawaban akhir: 24 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
