# Dataset Verifikasi Diri 1947

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 56 buku tulis. Dia memberikan 9 kepada teman. Kemudian menerima 6 buku tulis. Setelah itu meminjamkan 13 kepada orang lain. Berapa buku tulis Zaki sekarang?
A: Zaki sekarang memiliki 56 - 9 + 6 - 13 = 40 buku tulis.

Verifikasi: Perhitungan: 56 - 9 = 47, 47 + 6 = 53, 53 - 13 = 40. Benar.

Jawaban akhir: 40 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Hani memiliki 61 buku. Dia meminjamkan 11 kepada teman. Kemudian menang 2 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Hani sekarang?
A: Hani sekarang memiliki 61 - 11 + 2 - 15 = 37 buku.

Verifikasi: Perhitungan: 61 - 11 = 50, 50 + 2 = 52, 52 - 15 = 37. Benar.

Jawaban akhir: 37 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Lina memiliki 51 bola. Dia memberikan 6 kepada teman. Kemudian membeli 2 bola. Setelah itu membagi 7 kepada orang lain. Berapa bola Lina sekarang?
A: Lina sekarang memiliki 51 - 6 + 2 - 7 = 40 bola.

Verifikasi: Perhitungan: 51 - 6 = 45, 45 + 2 = 47, 47 - 7 = 40. Benar.

Jawaban akhir: 40 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
