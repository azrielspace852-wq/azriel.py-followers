# Dataset Verifikasi Diri 1953

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 20 pulpen. Dia memberikan 1 kepada teman. Kemudian membeli 7 pulpen. Setelah itu memberikan 14 kepada orang lain. Berapa pulpen Candra sekarang?
A: Candra sekarang memiliki 20 - 1 + 7 - 14 = 12 pulpen.

Verifikasi: Perhitungan: 20 - 1 = 19, 19 + 7 = 26, 26 - 14 = 12. Benar.

Jawaban akhir: 12 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Udin memiliki 57 kelereng. Dia membagi 18 kepada teman. Kemudian membeli 4 kelereng. Setelah itu memberikan 14 kepada orang lain. Berapa kelereng Udin sekarang?
A: Udin sekarang memiliki 57 - 18 + 4 - 14 = 29 kelereng.

Verifikasi: Perhitungan: 57 - 18 = 39, 39 + 4 = 43, 43 - 14 = 29. Benar.

Jawaban akhir: 29 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 88 stiker. Dia membagi 20 kepada teman. Kemudian menerima 7 stiker. Setelah itu meminjamkan 1 kepada orang lain. Berapa stiker Hani sekarang?
A: Hani sekarang memiliki 88 - 20 + 7 - 1 = 74 stiker.

Verifikasi: Perhitungan: 88 - 20 = 68, 68 + 7 = 75, 75 - 1 = 74. Benar.

Jawaban akhir: 74 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
