# Dataset Verifikasi Diri 1975

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 30 pulpen. Dia membagi 3 kepada teman. Kemudian menerima 18 pulpen. Setelah itu memberikan 1 kepada orang lain. Berapa pulpen Zaki sekarang?
A: Zaki sekarang memiliki 30 - 3 + 18 - 1 = 44 pulpen.

Verifikasi: Perhitungan: 30 - 3 = 27, 27 + 18 = 45, 45 - 1 = 44. Benar.

Jawaban akhir: 44 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Indra memiliki 72 kue. Dia membagi 21 kepada teman. Kemudian membeli 10 kue. Setelah itu memberikan 1 kepada orang lain. Berapa kue Indra sekarang?
A: Indra sekarang memiliki 72 - 21 + 10 - 1 = 60 kue.

Verifikasi: Perhitungan: 72 - 21 = 51, 51 + 10 = 61, 61 - 1 = 60. Benar.

Jawaban akhir: 60 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Lina memiliki 16 penghapus. Dia memberikan 4 kepada teman. Kemudian membeli 10 penghapus. Setelah itu meminjamkan 15 kepada orang lain. Berapa penghapus Lina sekarang?
A: Lina sekarang memiliki 16 - 4 + 10 - 15 = 7 penghapus.

Verifikasi: Perhitungan: 16 - 4 = 12, 12 + 10 = 22, 22 - 15 = 7. Benar.

Jawaban akhir: 7 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
