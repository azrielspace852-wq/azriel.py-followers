# Dataset Verifikasi Diri 1826

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 73 buku. Dia membagi 15 kepada teman. Kemudian menang 12 buku. Setelah itu memberikan 10 kepada orang lain. Berapa buku Dedi sekarang?
A: Dedi sekarang memiliki 73 - 15 + 12 - 10 = 60 buku.

Verifikasi: Perhitungan: 73 - 15 = 58, 58 + 12 = 70, 70 - 10 = 60. Benar.

Jawaban akhir: 60 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Budi memiliki 42 pulpen. Dia membagi 7 kepada teman. Kemudian menang 17 pulpen. Setelah itu memberikan 6 kepada orang lain. Berapa pulpen Budi sekarang?
A: Budi sekarang memiliki 42 - 7 + 17 - 6 = 46 pulpen.

Verifikasi: Perhitungan: 42 - 7 = 35, 35 + 17 = 52, 52 - 6 = 46. Benar.

Jawaban akhir: 46 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 14 bola. Dia memberikan 1 kepada teman. Kemudian menerima 14 bola. Setelah itu memberikan 7 kepada orang lain. Berapa bola Putri sekarang?
A: Putri sekarang memiliki 14 - 1 + 14 - 7 = 21 bola.

Verifikasi: Perhitungan yang benar: 14 - 1 = 13, 13 + 14 = 27, 27 - 7 = 20. Jawaban awal salah.

Jawaban akhir: 20 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
