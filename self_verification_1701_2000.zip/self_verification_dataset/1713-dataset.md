# Dataset Verifikasi Diri 1713

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 24 kue. Dia membagi 8 kepada teman. Kemudian menang 11 kue. Setelah itu memberikan 12 kepada orang lain. Berapa kue Maya sekarang?
A: Maya sekarang memiliki 24 - 8 + 11 - 12 = 16 kue.

Verifikasi: Perhitungan yang benar: 24 - 8 = 16, 16 + 11 = 27, 27 - 12 = 15. Jawaban awal salah.

Jawaban akhir: 15 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Andi memiliki 32 kelereng. Dia memberikan 7 kepada teman. Kemudian membeli 11 kelereng. Setelah itu membagi 14 kepada orang lain. Berapa kelereng Andi sekarang?
A: Andi sekarang memiliki 32 - 7 + 11 - 14 = 22 kelereng.

Verifikasi: Perhitungan: 32 - 7 = 25, 25 + 11 = 36, 36 - 14 = 22. Benar.

Jawaban akhir: 22 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 36 kartu. Dia memberikan 10 kepada teman. Kemudian menang 6 kartu. Setelah itu memberikan 8 kepada orang lain. Berapa kartu Eko sekarang?
A: Eko sekarang memiliki 36 - 10 + 6 - 8 = 24 kartu.

Verifikasi: Perhitungan: 36 - 10 = 26, 26 + 6 = 32, 32 - 8 = 24. Benar.

Jawaban akhir: 24 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
