# Dataset Verifikasi Diri 1872

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 62 pensil. Dia membagi 18 kepada teman. Kemudian menerima 11 pensil. Setelah itu meminjamkan 3 kepada orang lain. Berapa pensil Andi sekarang?
A: Andi sekarang memiliki 62 - 18 + 11 - 3 = 55 pensil.

Verifikasi: Perhitungan yang benar: 62 - 18 = 44, 44 + 11 = 55, 55 - 3 = 52. Jawaban awal salah.

Jawaban akhir: 52 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Maya memiliki 53 kue. Dia memberikan 1 kepada teman. Kemudian menerima 8 kue. Setelah itu membagi 2 kepada orang lain. Berapa kue Maya sekarang?
A: Maya sekarang memiliki 53 - 1 + 8 - 2 = 58 kue.

Verifikasi: Perhitungan: 53 - 1 = 52, 52 + 8 = 60, 60 - 2 = 58. Benar.

Jawaban akhir: 58 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Udin memiliki 79 buku tulis. Dia membagi 17 kepada teman. Kemudian mendapat 19 buku tulis. Setelah itu memberikan 1 kepada orang lain. Berapa buku tulis Udin sekarang?
A: Udin sekarang memiliki 79 - 17 + 19 - 1 = 80 buku tulis.

Verifikasi: Perhitungan: 79 - 17 = 62, 62 + 19 = 81, 81 - 1 = 80. Benar.

Jawaban akhir: 80 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
