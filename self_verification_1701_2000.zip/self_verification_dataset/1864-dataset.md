# Dataset Verifikasi Diri 1864

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 69 spidol. Dia meminjamkan 22 kepada teman. Kemudian menang 8 spidol. Setelah itu memberikan 7 kepada orang lain. Berapa spidol Oscar sekarang?
A: Oscar sekarang memiliki 69 - 22 + 8 - 7 = 48 spidol.

Verifikasi: Perhitungan: 69 - 22 = 47, 47 + 8 = 55, 55 - 7 = 48. Benar.

Jawaban akhir: 48 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 49 kue. Dia membagi 9 kepada teman. Kemudian membeli 16 kue. Setelah itu meminjamkan 12 kepada orang lain. Berapa kue Hani sekarang?
A: Hani sekarang memiliki 49 - 9 + 16 - 12 = 44 kue.

Verifikasi: Perhitungan: 49 - 9 = 40, 40 + 16 = 56, 56 - 12 = 44. Benar.

Jawaban akhir: 44 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 23 kartu. Dia meminjamkan 3 kepada teman. Kemudian menerima 14 kartu. Setelah itu membagi 5 kepada orang lain. Berapa kartu Joko sekarang?
A: Joko sekarang memiliki 23 - 3 + 14 - 5 = 28 kartu.

Verifikasi: Perhitungan yang benar: 23 - 3 = 20, 20 + 14 = 34, 34 - 5 = 29. Jawaban awal salah.

Jawaban akhir: 29 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
