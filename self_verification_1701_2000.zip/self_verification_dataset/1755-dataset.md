# Dataset Verifikasi Diri 1755

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 23 pulpen. Dia membagi 5 kepada teman. Kemudian menang 17 pulpen. Setelah itu memberikan 10 kepada orang lain. Berapa pulpen Candra sekarang?
A: Candra sekarang memiliki 23 - 5 + 17 - 10 = 25 pulpen.

Verifikasi: Perhitungan: 23 - 5 = 18, 18 + 17 = 35, 35 - 10 = 25. Benar.

Jawaban akhir: 25 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Kiki memiliki 55 buku. Dia meminjamkan 5 kepada teman. Kemudian menang 13 buku. Setelah itu meminjamkan 1 kepada orang lain. Berapa buku Kiki sekarang?
A: Kiki sekarang memiliki 55 - 5 + 13 - 1 = 62 buku.

Verifikasi: Perhitungan: 55 - 5 = 50, 50 + 13 = 63, 63 - 1 = 62. Benar.

Jawaban akhir: 62 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Indra memiliki 87 pulpen. Dia memberikan 23 kepada teman. Kemudian mendapat 13 pulpen. Setelah itu meminjamkan 2 kepada orang lain. Berapa pulpen Indra sekarang?
A: Indra sekarang memiliki 87 - 23 + 13 - 2 = 75 pulpen.

Verifikasi: Perhitungan: 87 - 23 = 64, 64 + 13 = 77, 77 - 2 = 75. Benar.

Jawaban akhir: 75 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
