# Dataset Verifikasi Diri 1779

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 59 kelereng. Dia meminjamkan 16 kepada teman. Kemudian menang 2 kelereng. Setelah itu memberikan 6 kepada orang lain. Berapa kelereng Vina sekarang?
A: Vina sekarang memiliki 59 - 16 + 2 - 6 = 39 kelereng.

Verifikasi: Perhitungan: 59 - 16 = 43, 43 + 2 = 45, 45 - 6 = 39. Benar.

Jawaban akhir: 39 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Eko memiliki 64 pulpen. Dia memberikan 15 kepada teman. Kemudian menang 13 pulpen. Setelah itu membagi 4 kepada orang lain. Berapa pulpen Eko sekarang?
A: Eko sekarang memiliki 64 - 15 + 13 - 4 = 58 pulpen.

Verifikasi: Perhitungan: 64 - 15 = 49, 49 + 13 = 62, 62 - 4 = 58. Benar.

Jawaban akhir: 58 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 80 penggaris. Dia membagi 4 kepada teman. Kemudian mendapat 5 penggaris. Setelah itu meminjamkan 10 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 80 - 4 + 5 - 10 = 71 penggaris.

Verifikasi: Perhitungan: 80 - 4 = 76, 76 + 5 = 81, 81 - 10 = 71. Benar.

Jawaban akhir: 71 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
