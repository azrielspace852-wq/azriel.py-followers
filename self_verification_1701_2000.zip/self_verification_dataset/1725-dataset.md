# Dataset Verifikasi Diri 1725

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 34 kartu. Dia memberikan 11 kepada teman. Kemudian menang 14 kartu. Setelah itu memberikan 12 kepada orang lain. Berapa kartu Nina sekarang?
A: Nina sekarang memiliki 34 - 11 + 14 - 12 = 25 kartu.

Verifikasi: Perhitungan: 34 - 11 = 23, 23 + 14 = 37, 37 - 12 = 25. Benar.

Jawaban akhir: 25 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Fajar memiliki 21 apel. Dia meminjamkan 2 kepada teman. Kemudian menerima 11 apel. Setelah itu meminjamkan 5 kepada orang lain. Berapa apel Fajar sekarang?
A: Fajar sekarang memiliki 21 - 2 + 11 - 5 = 25 apel.

Verifikasi: Perhitungan: 21 - 2 = 19, 19 + 11 = 30, 30 - 5 = 25. Benar.

Jawaban akhir: 25 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Zaki memiliki 49 penghapus. Dia meminjamkan 4 kepada teman. Kemudian membeli 5 penghapus. Setelah itu membagi 10 kepada orang lain. Berapa penghapus Zaki sekarang?
A: Zaki sekarang memiliki 49 - 4 + 5 - 10 = 40 penghapus.

Verifikasi: Perhitungan: 49 - 4 = 45, 45 + 5 = 50, 50 - 10 = 40. Benar.

Jawaban akhir: 40 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
