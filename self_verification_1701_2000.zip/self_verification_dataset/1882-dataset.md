# Dataset Verifikasi Diri 1882

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 50 buku. Dia membagi 15 kepada teman. Kemudian mendapat 15 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Zaki sekarang?
A: Zaki sekarang memiliki 50 - 15 + 15 - 15 = 34 buku.

Verifikasi: Perhitungan yang benar: 50 - 15 = 35, 35 + 15 = 50, 50 - 15 = 35. Jawaban awal salah.

Jawaban akhir: 35 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Rina memiliki 96 spidol. Dia meminjamkan 25 kepada teman. Kemudian membeli 12 spidol. Setelah itu memberikan 8 kepada orang lain. Berapa spidol Rina sekarang?
A: Rina sekarang memiliki 96 - 25 + 12 - 8 = 75 spidol.

Verifikasi: Perhitungan: 96 - 25 = 71, 71 + 12 = 83, 83 - 8 = 75. Benar.

Jawaban akhir: 75 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 95 pulpen. Dia memberikan 20 kepada teman. Kemudian mendapat 17 pulpen. Setelah itu membagi 1 kepada orang lain. Berapa pulpen Eko sekarang?
A: Eko sekarang memiliki 95 - 20 + 17 - 1 = 91 pulpen.

Verifikasi: Perhitungan: 95 - 20 = 75, 75 + 17 = 92, 92 - 1 = 91. Benar.

Jawaban akhir: 91 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
