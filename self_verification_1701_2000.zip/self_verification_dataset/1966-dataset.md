# Dataset Verifikasi Diri 1966

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 19 buku. Dia membagi 4 kepada teman. Kemudian menang 8 buku. Setelah itu membagi 3 kepada orang lain. Berapa buku Tono sekarang?
A: Tono sekarang memiliki 19 - 4 + 8 - 3 = 20 buku.

Verifikasi: Perhitungan: 19 - 4 = 15, 15 + 8 = 23, 23 - 3 = 20. Benar.

Jawaban akhir: 20 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Andi memiliki 11 kertas. Dia memberikan 1 kepada teman. Kemudian menerima 7 kertas. Setelah itu meminjamkan 14 kepada orang lain. Berapa kertas Andi sekarang?
A: Andi sekarang memiliki 11 - 1 + 7 - 14 = 3 kertas.

Verifikasi: Perhitungan: 11 - 1 = 10, 10 + 7 = 17, 17 - 14 = 3. Benar.

Jawaban akhir: 3 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 14 pulpen. Dia meminjamkan 2 kepada teman. Kemudian membeli 10 pulpen. Setelah itu membagi 1 kepada orang lain. Berapa pulpen Nina sekarang?
A: Nina sekarang memiliki 14 - 2 + 10 - 1 = 21 pulpen.

Verifikasi: Perhitungan: 14 - 2 = 12, 12 + 10 = 22, 22 - 1 = 21. Benar.

Jawaban akhir: 21 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
