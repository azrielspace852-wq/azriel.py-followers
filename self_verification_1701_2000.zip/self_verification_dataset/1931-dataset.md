# Dataset Verifikasi Diri 1931

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 12 kue. Dia membagi 4 kepada teman. Kemudian membeli 2 kue. Setelah itu membagi 8 kepada orang lain. Berapa kue Zaki sekarang?
A: Zaki sekarang memiliki 12 - 4 + 2 - 8 = 2 kue.

Verifikasi: Perhitungan: 12 - 4 = 8, 8 + 2 = 10, 10 - 8 = 2. Benar.

Jawaban akhir: 2 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Andi memiliki 86 pensil. Dia memberikan 22 kepada teman. Kemudian mendapat 5 pensil. Setelah itu meminjamkan 1 kepada orang lain. Berapa pensil Andi sekarang?
A: Andi sekarang memiliki 86 - 22 + 5 - 1 = 66 pensil.

Verifikasi: Perhitungan yang benar: 86 - 22 = 64, 64 + 5 = 69, 69 - 1 = 68. Jawaban awal salah.

Jawaban akhir: 68 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Hani memiliki 59 buku tulis. Dia meminjamkan 10 kepada teman. Kemudian menang 19 buku tulis. Setelah itu membagi 5 kepada orang lain. Berapa buku tulis Hani sekarang?
A: Hani sekarang memiliki 59 - 10 + 19 - 5 = 64 buku tulis.

Verifikasi: Perhitungan yang benar: 59 - 10 = 49, 49 + 19 = 68, 68 - 5 = 63. Jawaban awal salah.

Jawaban akhir: 63 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
