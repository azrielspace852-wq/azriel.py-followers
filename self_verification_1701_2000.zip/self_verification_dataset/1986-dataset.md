# Dataset Verifikasi Diri 1986

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 89 apel. Dia meminjamkan 27 kepada teman. Kemudian menang 19 apel. Setelah itu memberikan 9 kepada orang lain. Berapa apel Maya sekarang?
A: Maya sekarang memiliki 89 - 27 + 19 - 9 = 72 apel.

Verifikasi: Perhitungan: 89 - 27 = 62, 62 + 19 = 81, 81 - 9 = 72. Benar.

Jawaban akhir: 72 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 16 kue. Dia membagi 2 kepada teman. Kemudian mendapat 11 kue. Setelah itu membagi 15 kepada orang lain. Berapa kue Nina sekarang?
A: Nina sekarang memiliki 16 - 2 + 11 - 15 = 13 kue.

Verifikasi: Perhitungan yang benar: 16 - 2 = 14, 14 + 11 = 25, 25 - 15 = 10. Jawaban awal salah.

Jawaban akhir: 10 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 18 penggaris. Dia meminjamkan 3 kepada teman. Kemudian membeli 15 penggaris. Setelah itu memberikan 8 kepada orang lain. Berapa penggaris Rina sekarang?
A: Rina sekarang memiliki 18 - 3 + 15 - 8 = 22 penggaris.

Verifikasi: Perhitungan: 18 - 3 = 15, 15 + 15 = 30, 30 - 8 = 22. Benar.

Jawaban akhir: 22 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
