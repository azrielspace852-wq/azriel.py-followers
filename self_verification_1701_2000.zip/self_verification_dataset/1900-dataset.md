# Dataset Verifikasi Diri 1900

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 79 apel. Dia memberikan 3 kepada teman. Kemudian menerima 14 apel. Setelah itu memberikan 6 kepada orang lain. Berapa apel Oscar sekarang?
A: Oscar sekarang memiliki 79 - 3 + 14 - 6 = 84 apel.

Verifikasi: Perhitungan: 79 - 3 = 76, 76 + 14 = 90, 90 - 6 = 84. Benar.

Jawaban akhir: 84 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Joko memiliki 68 apel. Dia membagi 13 kepada teman. Kemudian menang 6 apel. Setelah itu memberikan 12 kepada orang lain. Berapa apel Joko sekarang?
A: Joko sekarang memiliki 68 - 13 + 6 - 12 = 49 apel.

Verifikasi: Perhitungan: 68 - 13 = 55, 55 + 6 = 61, 61 - 12 = 49. Benar.

Jawaban akhir: 49 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Putri memiliki 60 pensil. Dia meminjamkan 11 kepada teman. Kemudian menerima 8 pensil. Setelah itu meminjamkan 13 kepada orang lain. Berapa pensil Putri sekarang?
A: Putri sekarang memiliki 60 - 11 + 8 - 13 = 44 pensil.

Verifikasi: Perhitungan: 60 - 11 = 49, 49 + 8 = 57, 57 - 13 = 44. Benar.

Jawaban akhir: 44 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
