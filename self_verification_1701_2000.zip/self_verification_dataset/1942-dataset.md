# Dataset Verifikasi Diri 1942

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 40 buku tulis. Dia meminjamkan 8 kepada teman. Kemudian menang 12 buku tulis. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku tulis Hani sekarang?
A: Hani sekarang memiliki 40 - 8 + 12 - 11 = 33 buku tulis.

Verifikasi: Perhitungan: 40 - 8 = 32, 32 + 12 = 44, 44 - 11 = 33. Benar.

Jawaban akhir: 33 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Yudi memiliki 80 pulpen. Dia memberikan 15 kepada teman. Kemudian menerima 16 pulpen. Setelah itu membagi 10 kepada orang lain. Berapa pulpen Yudi sekarang?
A: Yudi sekarang memiliki 80 - 15 + 16 - 10 = 71 pulpen.

Verifikasi: Perhitungan: 80 - 15 = 65, 65 + 16 = 81, 81 - 10 = 71. Benar.

Jawaban akhir: 71 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Wati memiliki 69 kartu. Dia memberikan 19 kepada teman. Kemudian menerima 15 kartu. Setelah itu memberikan 4 kepada orang lain. Berapa kartu Wati sekarang?
A: Wati sekarang memiliki 69 - 19 + 15 - 4 = 61 kartu.

Verifikasi: Perhitungan: 69 - 19 = 50, 50 + 15 = 65, 65 - 4 = 61. Benar.

Jawaban akhir: 61 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
