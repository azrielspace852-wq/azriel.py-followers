# Dataset Verifikasi Diri 1831

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 90 spidol. Dia membagi 13 kepada teman. Kemudian membeli 5 spidol. Setelah itu memberikan 12 kepada orang lain. Berapa spidol Zaki sekarang?
A: Zaki sekarang memiliki 90 - 13 + 5 - 12 = 70 spidol.

Verifikasi: Perhitungan: 90 - 13 = 77, 77 + 5 = 82, 82 - 12 = 70. Benar.

Jawaban akhir: 70 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Tono memiliki 52 bola. Dia meminjamkan 14 kepada teman. Kemudian menang 8 bola. Setelah itu meminjamkan 6 kepada orang lain. Berapa bola Tono sekarang?
A: Tono sekarang memiliki 52 - 14 + 8 - 6 = 40 bola.

Verifikasi: Perhitungan: 52 - 14 = 38, 38 + 8 = 46, 46 - 6 = 40. Benar.

Jawaban akhir: 40 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Gita memiliki 48 kelereng. Dia membagi 12 kepada teman. Kemudian mendapat 7 kelereng. Setelah itu memberikan 2 kepada orang lain. Berapa kelereng Gita sekarang?
A: Gita sekarang memiliki 48 - 12 + 7 - 2 = 41 kelereng.

Verifikasi: Perhitungan: 48 - 12 = 36, 36 + 7 = 43, 43 - 2 = 41. Benar.

Jawaban akhir: 41 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
