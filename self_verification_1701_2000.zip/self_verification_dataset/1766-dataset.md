# Dataset Verifikasi Diri 1766

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 10 pensil. Dia meminjamkan 2 kepada teman. Kemudian membeli 5 pensil. Setelah itu membagi 15 kepada orang lain. Berapa pensil Indra sekarang?
A: Indra sekarang memiliki 10 - 2 + 5 - 15 = 1 pensil.

Verifikasi: Perhitungan yang benar: 10 - 2 = 8, 8 + 5 = 13, 13 - 15 = -2. Jawaban awal salah.

Jawaban akhir: -2 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Siti memiliki 66 buku tulis. Dia memberikan 22 kepada teman. Kemudian menang 3 buku tulis. Setelah itu membagi 11 kepada orang lain. Berapa buku tulis Siti sekarang?
A: Siti sekarang memiliki 66 - 22 + 3 - 11 = 36 buku tulis.

Verifikasi: Perhitungan: 66 - 22 = 44, 44 + 3 = 47, 47 - 11 = 36. Benar.

Jawaban akhir: 36 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 54 penggaris. Dia memberikan 5 kepada teman. Kemudian menang 13 penggaris. Setelah itu memberikan 5 kepada orang lain. Berapa penggaris Vina sekarang?
A: Vina sekarang memiliki 54 - 5 + 13 - 5 = 56 penggaris.

Verifikasi: Perhitungan yang benar: 54 - 5 = 49, 49 + 13 = 62, 62 - 5 = 57. Jawaban awal salah.

Jawaban akhir: 57 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
