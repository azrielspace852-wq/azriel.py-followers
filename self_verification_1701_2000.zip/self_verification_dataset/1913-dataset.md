# Dataset Verifikasi Diri 1913

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 45 spidol. Dia membagi 10 kepada teman. Kemudian mendapat 10 spidol. Setelah itu membagi 4 kepada orang lain. Berapa spidol Kiki sekarang?
A: Kiki sekarang memiliki 45 - 10 + 10 - 4 = 41 spidol.

Verifikasi: Perhitungan: 45 - 10 = 35, 35 + 10 = 45, 45 - 4 = 41. Benar.

Jawaban akhir: 41 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Fajar memiliki 94 kue. Dia membagi 3 kepada teman. Kemudian menerima 7 kue. Setelah itu memberikan 15 kepada orang lain. Berapa kue Fajar sekarang?
A: Fajar sekarang memiliki 94 - 3 + 7 - 15 = 83 kue.

Verifikasi: Perhitungan: 94 - 3 = 91, 91 + 7 = 98, 98 - 15 = 83. Benar.

Jawaban akhir: 83 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Oscar memiliki 25 bola. Dia meminjamkan 8 kepada teman. Kemudian menang 16 bola. Setelah itu memberikan 1 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 25 - 8 + 16 - 1 = 30 bola.

Verifikasi: Perhitungan yang benar: 25 - 8 = 17, 17 + 16 = 33, 33 - 1 = 32. Jawaban awal salah.

Jawaban akhir: 32 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
