# Dataset Verifikasi Diri 1990

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 84 buku. Dia meminjamkan 17 kepada teman. Kemudian menang 2 buku. Setelah itu membagi 10 kepada orang lain. Berapa buku Gita sekarang?
A: Gita sekarang memiliki 84 - 17 + 2 - 10 = 59 buku.

Verifikasi: Perhitungan: 84 - 17 = 67, 67 + 2 = 69, 69 - 10 = 59. Benar.

Jawaban akhir: 59 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Yudi memiliki 52 kartu. Dia memberikan 7 kepada teman. Kemudian membeli 16 kartu. Setelah itu meminjamkan 3 kepada orang lain. Berapa kartu Yudi sekarang?
A: Yudi sekarang memiliki 52 - 7 + 16 - 3 = 58 kartu.

Verifikasi: Perhitungan: 52 - 7 = 45, 45 + 16 = 61, 61 - 3 = 58. Benar.

Jawaban akhir: 58 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Zaki memiliki 78 rupiah. Dia meminjamkan 19 kepada teman. Kemudian mendapat 18 rupiah. Setelah itu meminjamkan 13 kepada orang lain. Berapa rupiah Zaki sekarang?
A: Zaki sekarang memiliki 78 - 19 + 18 - 13 = 67 rupiah.

Verifikasi: Perhitungan yang benar: 78 - 19 = 59, 59 + 18 = 77, 77 - 13 = 64. Jawaban awal salah.

Jawaban akhir: 64 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
