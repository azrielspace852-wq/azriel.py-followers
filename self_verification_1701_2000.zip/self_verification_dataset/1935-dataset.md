# Dataset Verifikasi Diri 1935

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 70 kue. Dia meminjamkan 18 kepada teman. Kemudian mendapat 18 kue. Setelah itu meminjamkan 14 kepada orang lain. Berapa kue Wati sekarang?
A: Wati sekarang memiliki 70 - 18 + 18 - 14 = 56 kue.

Verifikasi: Perhitungan: 70 - 18 = 52, 52 + 18 = 70, 70 - 14 = 56. Benar.

Jawaban akhir: 56 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 28 buku. Dia membagi 8 kepada teman. Kemudian menang 5 buku. Setelah itu membagi 14 kepada orang lain. Berapa buku Hani sekarang?
A: Hani sekarang memiliki 28 - 8 + 5 - 14 = 11 buku.

Verifikasi: Perhitungan: 28 - 8 = 20, 20 + 5 = 25, 25 - 14 = 11. Benar.

Jawaban akhir: 11 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Tono memiliki 27 kertas. Dia meminjamkan 9 kepada teman. Kemudian membeli 4 kertas. Setelah itu memberikan 8 kepada orang lain. Berapa kertas Tono sekarang?
A: Tono sekarang memiliki 27 - 9 + 4 - 8 = 14 kertas.

Verifikasi: Perhitungan: 27 - 9 = 18, 18 + 4 = 22, 22 - 8 = 14. Benar.

Jawaban akhir: 14 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
