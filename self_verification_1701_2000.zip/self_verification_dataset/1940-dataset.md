# Dataset Verifikasi Diri 1940

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 36 bola. Dia membagi 10 kepada teman. Kemudian menerima 18 bola. Setelah itu membagi 13 kepada orang lain. Berapa bola Fajar sekarang?
A: Fajar sekarang memiliki 36 - 10 + 18 - 13 = 34 bola.

Verifikasi: Perhitungan yang benar: 36 - 10 = 26, 26 + 18 = 44, 44 - 13 = 31. Jawaban awal salah.

Jawaban akhir: 31 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Putri memiliki 43 buku. Dia membagi 4 kepada teman. Kemudian menang 17 buku. Setelah itu meminjamkan 1 kepada orang lain. Berapa buku Putri sekarang?
A: Putri sekarang memiliki 43 - 4 + 17 - 1 = 55 buku.

Verifikasi: Perhitungan: 43 - 4 = 39, 39 + 17 = 56, 56 - 1 = 55. Benar.

Jawaban akhir: 55 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 60 kue. Dia memberikan 12 kepada teman. Kemudian mendapat 1 kue. Setelah itu meminjamkan 3 kepada orang lain. Berapa kue Oscar sekarang?
A: Oscar sekarang memiliki 60 - 12 + 1 - 3 = 49 kue.

Verifikasi: Perhitungan yang benar: 60 - 12 = 48, 48 + 1 = 49, 49 - 3 = 46. Jawaban awal salah.

Jawaban akhir: 46 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
