# Dataset Verifikasi Diri 1934

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 79 kue. Dia membagi 3 kepada teman. Kemudian membeli 4 kue. Setelah itu membagi 1 kepada orang lain. Berapa kue Maya sekarang?
A: Maya sekarang memiliki 79 - 3 + 4 - 1 = 78 kue.

Verifikasi: Perhitungan yang benar: 79 - 3 = 76, 76 + 4 = 80, 80 - 1 = 79. Jawaban awal salah.

Jawaban akhir: 79 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Rina memiliki 34 bola. Dia membagi 8 kepada teman. Kemudian mendapat 8 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Rina sekarang?
A: Rina sekarang memiliki 34 - 8 + 8 - 9 = 24 bola.

Verifikasi: Perhitungan yang benar: 34 - 8 = 26, 26 + 8 = 34, 34 - 9 = 25. Jawaban awal salah.

Jawaban akhir: 25 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 30 kue. Dia memberikan 9 kepada teman. Kemudian membeli 9 kue. Setelah itu meminjamkan 15 kepada orang lain. Berapa kue Zaki sekarang?
A: Zaki sekarang memiliki 30 - 9 + 9 - 15 = 18 kue.

Verifikasi: Perhitungan yang benar: 30 - 9 = 21, 21 + 9 = 30, 30 - 15 = 15. Jawaban awal salah.

Jawaban akhir: 15 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
