# Dataset Verifikasi Diri 1887

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 98 kertas. Dia membagi 2 kepada teman. Kemudian membeli 2 kertas. Setelah itu meminjamkan 6 kepada orang lain. Berapa kertas Dedi sekarang?
A: Dedi sekarang memiliki 98 - 2 + 2 - 6 = 92 kertas.

Verifikasi: Perhitungan: 98 - 2 = 96, 96 + 2 = 98, 98 - 6 = 92. Benar.

Jawaban akhir: 92 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 64 rupiah. Dia meminjamkan 18 kepada teman. Kemudian mendapat 17 rupiah. Setelah itu membagi 9 kepada orang lain. Berapa rupiah Fajar sekarang?
A: Fajar sekarang memiliki 64 - 18 + 17 - 9 = 54 rupiah.

Verifikasi: Perhitungan: 64 - 18 = 46, 46 + 17 = 63, 63 - 9 = 54. Benar.

Jawaban akhir: 54 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Kiki memiliki 17 kartu. Dia memberikan 1 kepada teman. Kemudian mendapat 8 kartu. Setelah itu membagi 10 kepada orang lain. Berapa kartu Kiki sekarang?
A: Kiki sekarang memiliki 17 - 1 + 8 - 10 = 13 kartu.

Verifikasi: Perhitungan yang benar: 17 - 1 = 16, 16 + 8 = 24, 24 - 10 = 14. Jawaban awal salah.

Jawaban akhir: 14 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
