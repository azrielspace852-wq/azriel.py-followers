# Dataset Verifikasi Diri 1907

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 26 pensil. Dia membagi 5 kepada teman. Kemudian menerima 14 pensil. Setelah itu meminjamkan 14 kepada orang lain. Berapa pensil Eko sekarang?
A: Eko sekarang memiliki 26 - 5 + 14 - 14 = 21 pensil.

Verifikasi: Perhitungan: 26 - 5 = 21, 21 + 14 = 35, 35 - 14 = 21. Benar.

Jawaban akhir: 21 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 43 stiker. Dia memberikan 7 kepada teman. Kemudian membeli 13 stiker. Setelah itu membagi 12 kepada orang lain. Berapa stiker Dedi sekarang?
A: Dedi sekarang memiliki 43 - 7 + 13 - 12 = 37 stiker.

Verifikasi: Perhitungan: 43 - 7 = 36, 36 + 13 = 49, 49 - 12 = 37. Benar.

Jawaban akhir: 37 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Wati memiliki 58 penggaris. Dia memberikan 17 kepada teman. Kemudian menang 3 penggaris. Setelah itu membagi 11 kepada orang lain. Berapa penggaris Wati sekarang?
A: Wati sekarang memiliki 58 - 17 + 3 - 11 = 33 penggaris.

Verifikasi: Perhitungan: 58 - 17 = 41, 41 + 3 = 44, 44 - 11 = 33. Benar.

Jawaban akhir: 33 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
