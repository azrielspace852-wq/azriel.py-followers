# Dataset Verifikasi Diri 1919

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 38 buku tulis. Dia membagi 1 kepada teman. Kemudian menang 19 buku tulis. Setelah itu membagi 15 kepada orang lain. Berapa buku tulis Dedi sekarang?
A: Dedi sekarang memiliki 38 - 1 + 19 - 15 = 41 buku tulis.

Verifikasi: Perhitungan: 38 - 1 = 37, 37 + 19 = 56, 56 - 15 = 41. Benar.

Jawaban akhir: 41 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Wati memiliki 63 kertas. Dia meminjamkan 21 kepada teman. Kemudian menang 17 kertas. Setelah itu meminjamkan 2 kepada orang lain. Berapa kertas Wati sekarang?
A: Wati sekarang memiliki 63 - 21 + 17 - 2 = 58 kertas.

Verifikasi: Perhitungan yang benar: 63 - 21 = 42, 42 + 17 = 59, 59 - 2 = 57. Jawaban awal salah.

Jawaban akhir: 57 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 36 apel. Dia memberikan 7 kepada teman. Kemudian menang 12 apel. Setelah itu membagi 1 kepada orang lain. Berapa apel Gita sekarang?
A: Gita sekarang memiliki 36 - 7 + 12 - 1 = 40 apel.

Verifikasi: Perhitungan: 36 - 7 = 29, 29 + 12 = 41, 41 - 1 = 40. Benar.

Jawaban akhir: 40 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
