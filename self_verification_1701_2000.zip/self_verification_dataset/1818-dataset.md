# Dataset Verifikasi Diri 1818

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 74 apel. Dia membagi 9 kepada teman. Kemudian membeli 7 apel. Setelah itu membagi 14 kepada orang lain. Berapa apel Eko sekarang?
A: Eko sekarang memiliki 74 - 9 + 7 - 14 = 58 apel.

Verifikasi: Perhitungan: 74 - 9 = 65, 65 + 7 = 72, 72 - 14 = 58. Benar.

Jawaban akhir: 58 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Dedi memiliki 46 apel. Dia memberikan 12 kepada teman. Kemudian menerima 8 apel. Setelah itu memberikan 7 kepada orang lain. Berapa apel Dedi sekarang?
A: Dedi sekarang memiliki 46 - 12 + 8 - 7 = 33 apel.

Verifikasi: Perhitungan yang benar: 46 - 12 = 34, 34 + 8 = 42, 42 - 7 = 35. Jawaban awal salah.

Jawaban akhir: 35 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 94 kelereng. Dia membagi 23 kepada teman. Kemudian menerima 7 kelereng. Setelah itu memberikan 2 kepada orang lain. Berapa kelereng Eko sekarang?
A: Eko sekarang memiliki 94 - 23 + 7 - 2 = 75 kelereng.

Verifikasi: Perhitungan yang benar: 94 - 23 = 71, 71 + 7 = 78, 78 - 2 = 76. Jawaban awal salah.

Jawaban akhir: 76 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
