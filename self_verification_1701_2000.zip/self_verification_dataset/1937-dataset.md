# Dataset Verifikasi Diri 1937

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 24 kertas. Dia membagi 1 kepada teman. Kemudian menerima 5 kertas. Setelah itu membagi 3 kepada orang lain. Berapa kertas Indra sekarang?
A: Indra sekarang memiliki 24 - 1 + 5 - 3 = 25 kertas.

Verifikasi: Perhitungan: 24 - 1 = 23, 23 + 5 = 28, 28 - 3 = 25. Benar.

Jawaban akhir: 25 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Wati memiliki 67 spidol. Dia meminjamkan 10 kepada teman. Kemudian mendapat 19 spidol. Setelah itu membagi 9 kepada orang lain. Berapa spidol Wati sekarang?
A: Wati sekarang memiliki 67 - 10 + 19 - 9 = 67 spidol.

Verifikasi: Perhitungan: 67 - 10 = 57, 57 + 19 = 76, 76 - 9 = 67. Benar.

Jawaban akhir: 67 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 71 bola. Dia memberikan 20 kepada teman. Kemudian menerima 6 bola. Setelah itu meminjamkan 8 kepada orang lain. Berapa bola Andi sekarang?
A: Andi sekarang memiliki 71 - 20 + 6 - 8 = 49 bola.

Verifikasi: Perhitungan: 71 - 20 = 51, 51 + 6 = 57, 57 - 8 = 49. Benar.

Jawaban akhir: 49 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
