# Dataset Verifikasi Diri 1991

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 44 kue. Dia membagi 4 kepada teman. Kemudian menerima 12 kue. Setelah itu memberikan 10 kepada orang lain. Berapa kue Joko sekarang?
A: Joko sekarang memiliki 44 - 4 + 12 - 10 = 42 kue.

Verifikasi: Perhitungan: 44 - 4 = 40, 40 + 12 = 52, 52 - 10 = 42. Benar.

Jawaban akhir: 42 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Nina memiliki 69 kartu. Dia memberikan 9 kepada teman. Kemudian menerima 7 kartu. Setelah itu memberikan 8 kepada orang lain. Berapa kartu Nina sekarang?
A: Nina sekarang memiliki 69 - 9 + 7 - 8 = 59 kartu.

Verifikasi: Perhitungan: 69 - 9 = 60, 60 + 7 = 67, 67 - 8 = 59. Benar.

Jawaban akhir: 59 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Udin memiliki 35 buku. Dia meminjamkan 11 kepada teman. Kemudian mendapat 3 buku. Setelah itu membagi 11 kepada orang lain. Berapa buku Udin sekarang?
A: Udin sekarang memiliki 35 - 11 + 3 - 11 = 17 buku.

Verifikasi: Perhitungan yang benar: 35 - 11 = 24, 24 + 3 = 27, 27 - 11 = 16. Jawaban awal salah.

Jawaban akhir: 16 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
