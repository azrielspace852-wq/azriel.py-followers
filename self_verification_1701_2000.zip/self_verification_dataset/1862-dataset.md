# Dataset Verifikasi Diri 1862

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 56 kertas. Dia membagi 9 kepada teman. Kemudian menang 2 kertas. Setelah itu membagi 10 kepada orang lain. Berapa kertas Zaki sekarang?
A: Zaki sekarang memiliki 56 - 9 + 2 - 10 = 39 kertas.

Verifikasi: Perhitungan: 56 - 9 = 47, 47 + 2 = 49, 49 - 10 = 39. Benar.

Jawaban akhir: 39 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 59 penghapus. Dia meminjamkan 2 kepada teman. Kemudian mendapat 16 penghapus. Setelah itu memberikan 7 kepada orang lain. Berapa penghapus Hani sekarang?
A: Hani sekarang memiliki 59 - 2 + 16 - 7 = 66 penghapus.

Verifikasi: Perhitungan: 59 - 2 = 57, 57 + 16 = 73, 73 - 7 = 66. Benar.

Jawaban akhir: 66 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 25 buku tulis. Dia memberikan 7 kepada teman. Kemudian menerima 7 buku tulis. Setelah itu memberikan 12 kepada orang lain. Berapa buku tulis Tono sekarang?
A: Tono sekarang memiliki 25 - 7 + 7 - 12 = 13 buku tulis.

Verifikasi: Perhitungan: 25 - 7 = 18, 18 + 7 = 25, 25 - 12 = 13. Benar.

Jawaban akhir: 13 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
