# Dataset Verifikasi Diri 1712

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 46 bola. Dia memberikan 14 kepada teman. Kemudian menang 10 bola. Setelah itu meminjamkan 7 kepada orang lain. Berapa bola Udin sekarang?
A: Udin sekarang memiliki 46 - 14 + 10 - 7 = 36 bola.

Verifikasi: Perhitungan yang benar: 46 - 14 = 32, 32 + 10 = 42, 42 - 7 = 35. Jawaban awal salah.

Jawaban akhir: 35 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Nina memiliki 74 buku tulis. Dia membagi 2 kepada teman. Kemudian mendapat 14 buku tulis. Setelah itu meminjamkan 6 kepada orang lain. Berapa buku tulis Nina sekarang?
A: Nina sekarang memiliki 74 - 2 + 14 - 6 = 82 buku tulis.

Verifikasi: Perhitungan yang benar: 74 - 2 = 72, 72 + 14 = 86, 86 - 6 = 80. Jawaban awal salah.

Jawaban akhir: 80 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Indra memiliki 61 spidol. Dia memberikan 1 kepada teman. Kemudian membeli 3 spidol. Setelah itu membagi 4 kepada orang lain. Berapa spidol Indra sekarang?
A: Indra sekarang memiliki 61 - 1 + 3 - 4 = 61 spidol.

Verifikasi: Perhitungan yang benar: 61 - 1 = 60, 60 + 3 = 63, 63 - 4 = 59. Jawaban awal salah.

Jawaban akhir: 59 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
