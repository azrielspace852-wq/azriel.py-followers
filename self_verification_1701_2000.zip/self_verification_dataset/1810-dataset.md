# Dataset Verifikasi Diri 1810

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 31 kartu. Dia memberikan 2 kepada teman. Kemudian menang 4 kartu. Setelah itu memberikan 12 kepada orang lain. Berapa kartu Zaki sekarang?
A: Zaki sekarang memiliki 31 - 2 + 4 - 12 = 21 kartu.

Verifikasi: Perhitungan: 31 - 2 = 29, 29 + 4 = 33, 33 - 12 = 21. Benar.

Jawaban akhir: 21 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Andi memiliki 76 rupiah. Dia meminjamkan 4 kepada teman. Kemudian menerima 16 rupiah. Setelah itu meminjamkan 4 kepada orang lain. Berapa rupiah Andi sekarang?
A: Andi sekarang memiliki 76 - 4 + 16 - 4 = 84 rupiah.

Verifikasi: Perhitungan: 76 - 4 = 72, 72 + 16 = 88, 88 - 4 = 84. Benar.

Jawaban akhir: 84 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 23 penggaris. Dia memberikan 5 kepada teman. Kemudian menerima 8 penggaris. Setelah itu meminjamkan 15 kepada orang lain. Berapa penggaris Andi sekarang?
A: Andi sekarang memiliki 23 - 5 + 8 - 15 = 11 penggaris.

Verifikasi: Perhitungan: 23 - 5 = 18, 18 + 8 = 26, 26 - 15 = 11. Benar.

Jawaban akhir: 11 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
