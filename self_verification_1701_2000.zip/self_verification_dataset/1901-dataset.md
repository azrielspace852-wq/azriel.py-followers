# Dataset Verifikasi Diri 1901

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 24 buku tulis. Dia membagi 7 kepada teman. Kemudian menerima 10 buku tulis. Setelah itu meminjamkan 8 kepada orang lain. Berapa buku tulis Eko sekarang?
A: Eko sekarang memiliki 24 - 7 + 10 - 8 = 19 buku tulis.

Verifikasi: Perhitungan: 24 - 7 = 17, 17 + 10 = 27, 27 - 8 = 19. Benar.

Jawaban akhir: 19 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Wati memiliki 11 apel. Dia memberikan 3 kepada teman. Kemudian membeli 9 apel. Setelah itu membagi 9 kepada orang lain. Berapa apel Wati sekarang?
A: Wati sekarang memiliki 11 - 3 + 9 - 9 = 7 apel.

Verifikasi: Perhitungan yang benar: 11 - 3 = 8, 8 + 9 = 17, 17 - 9 = 8. Jawaban awal salah.

Jawaban akhir: 8 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 73 penggaris. Dia membagi 8 kepada teman. Kemudian membeli 13 penggaris. Setelah itu memberikan 1 kepada orang lain. Berapa penggaris Fajar sekarang?
A: Fajar sekarang memiliki 73 - 8 + 13 - 1 = 77 penggaris.

Verifikasi: Perhitungan: 73 - 8 = 65, 65 + 13 = 78, 78 - 1 = 77. Benar.

Jawaban akhir: 77 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
