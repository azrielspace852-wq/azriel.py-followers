# Dataset Verifikasi Diri 1949

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 95 buku. Dia membagi 21 kepada teman. Kemudian membeli 9 buku. Setelah itu membagi 4 kepada orang lain. Berapa buku Zaki sekarang?
A: Zaki sekarang memiliki 95 - 21 + 9 - 4 = 79 buku.

Verifikasi: Perhitungan: 95 - 21 = 74, 74 + 9 = 83, 83 - 4 = 79. Benar.

Jawaban akhir: 79 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Oscar memiliki 75 pensil. Dia memberikan 3 kepada teman. Kemudian membeli 10 pensil. Setelah itu meminjamkan 2 kepada orang lain. Berapa pensil Oscar sekarang?
A: Oscar sekarang memiliki 75 - 3 + 10 - 2 = 79 pensil.

Verifikasi: Perhitungan yang benar: 75 - 3 = 72, 72 + 10 = 82, 82 - 2 = 80. Jawaban awal salah.

Jawaban akhir: 80 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 84 kertas. Dia meminjamkan 21 kepada teman. Kemudian mendapat 1 kertas. Setelah itu meminjamkan 10 kepada orang lain. Berapa kertas Candra sekarang?
A: Candra sekarang memiliki 84 - 21 + 1 - 10 = 54 kertas.

Verifikasi: Perhitungan: 84 - 21 = 63, 63 + 1 = 64, 64 - 10 = 54. Benar.

Jawaban akhir: 54 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
