# Dataset Verifikasi Diri 1992

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 62 bola. Dia meminjamkan 2 kepada teman. Kemudian mendapat 11 bola. Setelah itu memberikan 13 kepada orang lain. Berapa bola Putri sekarang?
A: Putri sekarang memiliki 62 - 2 + 11 - 13 = 61 bola.

Verifikasi: Perhitungan yang benar: 62 - 2 = 60, 60 + 11 = 71, 71 - 13 = 58. Jawaban awal salah.

Jawaban akhir: 58 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Oscar memiliki 31 penghapus. Dia meminjamkan 9 kepada teman. Kemudian menerima 12 penghapus. Setelah itu membagi 9 kepada orang lain. Berapa penghapus Oscar sekarang?
A: Oscar sekarang memiliki 31 - 9 + 12 - 9 = 23 penghapus.

Verifikasi: Perhitungan yang benar: 31 - 9 = 22, 22 + 12 = 34, 34 - 9 = 25. Jawaban awal salah.

Jawaban akhir: 25 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 87 kartu. Dia membagi 6 kepada teman. Kemudian mendapat 20 kartu. Setelah itu meminjamkan 4 kepada orang lain. Berapa kartu Rina sekarang?
A: Rina sekarang memiliki 87 - 6 + 20 - 4 = 97 kartu.

Verifikasi: Perhitungan: 87 - 6 = 81, 81 + 20 = 101, 101 - 4 = 97. Benar.

Jawaban akhir: 97 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
