# Dataset Verifikasi Diri 1733

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 22 kertas. Dia meminjamkan 2 kepada teman. Kemudian menerima 8 kertas. Setelah itu meminjamkan 14 kepada orang lain. Berapa kertas Siti sekarang?
A: Siti sekarang memiliki 22 - 2 + 8 - 14 = 14 kertas.

Verifikasi: Perhitungan: 22 - 2 = 20, 20 + 8 = 28, 28 - 14 = 14. Benar.

Jawaban akhir: 14 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Gita memiliki 47 pensil. Dia membagi 10 kepada teman. Kemudian mendapat 11 pensil. Setelah itu meminjamkan 7 kepada orang lain. Berapa pensil Gita sekarang?
A: Gita sekarang memiliki 47 - 10 + 11 - 7 = 41 pensil.

Verifikasi: Perhitungan: 47 - 10 = 37, 37 + 11 = 48, 48 - 7 = 41. Benar.

Jawaban akhir: 41 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 17 kertas. Dia membagi 1 kepada teman. Kemudian mendapat 10 kertas. Setelah itu meminjamkan 13 kepada orang lain. Berapa kertas Andi sekarang?
A: Andi sekarang memiliki 17 - 1 + 10 - 13 = 13 kertas.

Verifikasi: Perhitungan: 17 - 1 = 16, 16 + 10 = 26, 26 - 13 = 13. Benar.

Jawaban akhir: 13 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
