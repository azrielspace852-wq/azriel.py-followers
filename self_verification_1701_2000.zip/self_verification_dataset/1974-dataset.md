# Dataset Verifikasi Diri 1974

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 54 stiker. Dia membagi 15 kepada teman. Kemudian mendapat 14 stiker. Setelah itu membagi 3 kepada orang lain. Berapa stiker Lina sekarang?
A: Lina sekarang memiliki 54 - 15 + 14 - 3 = 48 stiker.

Verifikasi: Perhitungan yang benar: 54 - 15 = 39, 39 + 14 = 53, 53 - 3 = 50. Jawaban awal salah.

Jawaban akhir: 50 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 66 penggaris. Dia meminjamkan 12 kepada teman. Kemudian membeli 7 penggaris. Setelah itu memberikan 10 kepada orang lain. Berapa penggaris Indra sekarang?
A: Indra sekarang memiliki 66 - 12 + 7 - 10 = 50 penggaris.

Verifikasi: Perhitungan yang benar: 66 - 12 = 54, 54 + 7 = 61, 61 - 10 = 51. Jawaban awal salah.

Jawaban akhir: 51 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Tono memiliki 22 kartu. Dia memberikan 4 kepada teman. Kemudian mendapat 18 kartu. Setelah itu meminjamkan 11 kepada orang lain. Berapa kartu Tono sekarang?
A: Tono sekarang memiliki 22 - 4 + 18 - 11 = 25 kartu.

Verifikasi: Perhitungan: 22 - 4 = 18, 18 + 18 = 36, 36 - 11 = 25. Benar.

Jawaban akhir: 25 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
