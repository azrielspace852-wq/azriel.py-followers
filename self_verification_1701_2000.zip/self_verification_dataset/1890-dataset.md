# Dataset Verifikasi Diri 1890

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 75 bola. Dia memberikan 2 kepada teman. Kemudian menang 2 bola. Setelah itu meminjamkan 13 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 75 - 2 + 2 - 13 = 62 bola.

Verifikasi: Perhitungan: 75 - 2 = 73, 73 + 2 = 75, 75 - 13 = 62. Benar.

Jawaban akhir: 62 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Siti memiliki 21 kertas. Dia membagi 5 kepada teman. Kemudian menerima 3 kertas. Setelah itu meminjamkan 1 kepada orang lain. Berapa kertas Siti sekarang?
A: Siti sekarang memiliki 21 - 5 + 3 - 1 = 18 kertas.

Verifikasi: Perhitungan: 21 - 5 = 16, 16 + 3 = 19, 19 - 1 = 18. Benar.

Jawaban akhir: 18 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Vina memiliki 76 pensil. Dia memberikan 11 kepada teman. Kemudian membeli 5 pensil. Setelah itu memberikan 1 kepada orang lain. Berapa pensil Vina sekarang?
A: Vina sekarang memiliki 76 - 11 + 5 - 1 = 69 pensil.

Verifikasi: Perhitungan: 76 - 11 = 65, 65 + 5 = 70, 70 - 1 = 69. Benar.

Jawaban akhir: 69 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
