# Dataset Verifikasi Diri 1792

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 62 buku. Dia memberikan 20 kepada teman. Kemudian menang 16 buku. Setelah itu membagi 13 kepada orang lain. Berapa buku Tono sekarang?
A: Tono sekarang memiliki 62 - 20 + 16 - 13 = 46 buku.

Verifikasi: Perhitungan yang benar: 62 - 20 = 42, 42 + 16 = 58, 58 - 13 = 45. Jawaban awal salah.

Jawaban akhir: 45 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Joko memiliki 70 apel. Dia meminjamkan 17 kepada teman. Kemudian menang 20 apel. Setelah itu memberikan 2 kepada orang lain. Berapa apel Joko sekarang?
A: Joko sekarang memiliki 70 - 17 + 20 - 2 = 71 apel.

Verifikasi: Perhitungan: 70 - 17 = 53, 53 + 20 = 73, 73 - 2 = 71. Benar.

Jawaban akhir: 71 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 25 stiker. Dia memberikan 6 kepada teman. Kemudian membeli 2 stiker. Setelah itu membagi 2 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 25 - 6 + 2 - 2 = 19 stiker.

Verifikasi: Perhitungan: 25 - 6 = 19, 19 + 2 = 21, 21 - 2 = 19. Benar.

Jawaban akhir: 19 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
