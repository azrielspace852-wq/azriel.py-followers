# Dataset Verifikasi Diri 1777

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 56 kue. Dia membagi 3 kepada teman. Kemudian membeli 5 kue. Setelah itu meminjamkan 3 kepada orang lain. Berapa kue Wati sekarang?
A: Wati sekarang memiliki 56 - 3 + 5 - 3 = 55 kue.

Verifikasi: Perhitungan: 56 - 3 = 53, 53 + 5 = 58, 58 - 3 = 55. Benar.

Jawaban akhir: 55 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Zaki memiliki 23 pulpen. Dia meminjamkan 6 kepada teman. Kemudian mendapat 13 pulpen. Setelah itu membagi 15 kepada orang lain. Berapa pulpen Zaki sekarang?
A: Zaki sekarang memiliki 23 - 6 + 13 - 15 = 15 pulpen.

Verifikasi: Perhitungan: 23 - 6 = 17, 17 + 13 = 30, 30 - 15 = 15. Benar.

Jawaban akhir: 15 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Candra memiliki 29 kue. Dia memberikan 6 kepada teman. Kemudian mendapat 9 kue. Setelah itu membagi 13 kepada orang lain. Berapa kue Candra sekarang?
A: Candra sekarang memiliki 29 - 6 + 9 - 13 = 19 kue.

Verifikasi: Perhitungan: 29 - 6 = 23, 23 + 9 = 32, 32 - 13 = 19. Benar.

Jawaban akhir: 19 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
