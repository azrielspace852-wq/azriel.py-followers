# Dataset Verifikasi Diri 1930

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 95 penghapus. Dia meminjamkan 12 kepada teman. Kemudian menang 17 penghapus. Setelah itu meminjamkan 7 kepada orang lain. Berapa penghapus Tono sekarang?
A: Tono sekarang memiliki 95 - 12 + 17 - 7 = 93 penghapus.

Verifikasi: Perhitungan: 95 - 12 = 83, 83 + 17 = 100, 100 - 7 = 93. Benar.

Jawaban akhir: 93 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Siti memiliki 10 kelereng. Dia memberikan 2 kepada teman. Kemudian membeli 20 kelereng. Setelah itu membagi 12 kepada orang lain. Berapa kelereng Siti sekarang?
A: Siti sekarang memiliki 10 - 2 + 20 - 12 = 16 kelereng.

Verifikasi: Perhitungan: 10 - 2 = 8, 8 + 20 = 28, 28 - 12 = 16. Benar.

Jawaban akhir: 16 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Udin memiliki 28 kue. Dia membagi 4 kepada teman. Kemudian membeli 20 kue. Setelah itu membagi 6 kepada orang lain. Berapa kue Udin sekarang?
A: Udin sekarang memiliki 28 - 4 + 20 - 6 = 41 kue.

Verifikasi: Perhitungan yang benar: 28 - 4 = 24, 24 + 20 = 44, 44 - 6 = 38. Jawaban awal salah.

Jawaban akhir: 38 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
