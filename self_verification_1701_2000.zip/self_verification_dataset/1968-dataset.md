# Dataset Verifikasi Diri 1968

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 86 stiker. Dia meminjamkan 26 kepada teman. Kemudian mendapat 18 stiker. Setelah itu membagi 8 kepada orang lain. Berapa stiker Putri sekarang?
A: Putri sekarang memiliki 86 - 26 + 18 - 8 = 70 stiker.

Verifikasi: Perhitungan: 86 - 26 = 60, 60 + 18 = 78, 78 - 8 = 70. Benar.

Jawaban akhir: 70 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Maya memiliki 31 apel. Dia meminjamkan 1 kepada teman. Kemudian membeli 10 apel. Setelah itu memberikan 15 kepada orang lain. Berapa apel Maya sekarang?
A: Maya sekarang memiliki 31 - 1 + 10 - 15 = 25 apel.

Verifikasi: Perhitungan: 31 - 1 = 30, 30 + 10 = 40, 40 - 15 = 25. Benar.

Jawaban akhir: 25 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Zaki memiliki 61 pensil. Dia membagi 3 kepada teman. Kemudian membeli 3 pensil. Setelah itu memberikan 11 kepada orang lain. Berapa pensil Zaki sekarang?
A: Zaki sekarang memiliki 61 - 3 + 3 - 11 = 52 pensil.

Verifikasi: Perhitungan yang benar: 61 - 3 = 58, 58 + 3 = 61, 61 - 11 = 50. Jawaban awal salah.

Jawaban akhir: 50 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
