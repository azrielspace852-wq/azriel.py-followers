# Dataset Verifikasi Diri 1790

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 75 kartu. Dia meminjamkan 4 kepada teman. Kemudian mendapat 15 kartu. Setelah itu meminjamkan 12 kepada orang lain. Berapa kartu Siti sekarang?
A: Siti sekarang memiliki 75 - 4 + 15 - 12 = 73 kartu.

Verifikasi: Perhitungan yang benar: 75 - 4 = 71, 71 + 15 = 86, 86 - 12 = 74. Jawaban awal salah.

Jawaban akhir: 74 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Hani memiliki 72 buku. Dia memberikan 4 kepada teman. Kemudian membeli 4 buku. Setelah itu meminjamkan 15 kepada orang lain. Berapa buku Hani sekarang?
A: Hani sekarang memiliki 72 - 4 + 4 - 15 = 57 buku.

Verifikasi: Perhitungan: 72 - 4 = 68, 68 + 4 = 72, 72 - 15 = 57. Benar.

Jawaban akhir: 57 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 90 kertas. Dia meminjamkan 8 kepada teman. Kemudian menang 11 kertas. Setelah itu membagi 2 kepada orang lain. Berapa kertas Eko sekarang?
A: Eko sekarang memiliki 90 - 8 + 11 - 2 = 89 kertas.

Verifikasi: Perhitungan yang benar: 90 - 8 = 82, 82 + 11 = 93, 93 - 2 = 91. Jawaban awal salah.

Jawaban akhir: 91 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
