# Dataset Verifikasi Diri 1845

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 86 kue. Dia membagi 24 kepada teman. Kemudian menang 2 kue. Setelah itu meminjamkan 7 kepada orang lain. Berapa kue Eko sekarang?
A: Eko sekarang memiliki 86 - 24 + 2 - 7 = 57 kue.

Verifikasi: Perhitungan: 86 - 24 = 62, 62 + 2 = 64, 64 - 7 = 57. Benar.

Jawaban akhir: 57 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 15 buku. Dia memberikan 2 kepada teman. Kemudian mendapat 6 buku. Setelah itu membagi 15 kepada orang lain. Berapa buku Lina sekarang?
A: Lina sekarang memiliki 15 - 2 + 6 - 15 = 4 buku.

Verifikasi: Perhitungan: 15 - 2 = 13, 13 + 6 = 19, 19 - 15 = 4. Benar.

Jawaban akhir: 4 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 82 spidol. Dia membagi 25 kepada teman. Kemudian membeli 16 spidol. Setelah itu meminjamkan 7 kepada orang lain. Berapa spidol Eko sekarang?
A: Eko sekarang memiliki 82 - 25 + 16 - 7 = 66 spidol.

Verifikasi: Perhitungan: 82 - 25 = 57, 57 + 16 = 73, 73 - 7 = 66. Benar.

Jawaban akhir: 66 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
