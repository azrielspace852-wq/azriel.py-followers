# Dataset Verifikasi Diri 1824

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 15 stiker. Dia meminjamkan 1 kepada teman. Kemudian menang 17 stiker. Setelah itu memberikan 14 kepada orang lain. Berapa stiker Yudi sekarang?
A: Yudi sekarang memiliki 15 - 1 + 17 - 14 = 17 stiker.

Verifikasi: Perhitungan: 15 - 1 = 14, 14 + 17 = 31, 31 - 14 = 17. Benar.

Jawaban akhir: 17 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 45 kertas. Dia meminjamkan 2 kepada teman. Kemudian menerima 14 kertas. Setelah itu membagi 2 kepada orang lain. Berapa kertas Rina sekarang?
A: Rina sekarang memiliki 45 - 2 + 14 - 2 = 55 kertas.

Verifikasi: Perhitungan: 45 - 2 = 43, 43 + 14 = 57, 57 - 2 = 55. Benar.

Jawaban akhir: 55 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 98 penghapus. Dia memberikan 27 kepada teman. Kemudian menang 11 penghapus. Setelah itu membagi 1 kepada orang lain. Berapa penghapus Eko sekarang?
A: Eko sekarang memiliki 98 - 27 + 11 - 1 = 79 penghapus.

Verifikasi: Perhitungan yang benar: 98 - 27 = 71, 71 + 11 = 82, 82 - 1 = 81. Jawaban awal salah.

Jawaban akhir: 81 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
