# Dataset Verifikasi Diri 1707

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 96 penghapus. Dia memberikan 18 kepada teman. Kemudian mendapat 11 penghapus. Setelah itu membagi 14 kepada orang lain. Berapa penghapus Budi sekarang?
A: Budi sekarang memiliki 96 - 18 + 11 - 14 = 73 penghapus.

Verifikasi: Perhitungan yang benar: 96 - 18 = 78, 78 + 11 = 89, 89 - 14 = 75. Jawaban awal salah.

Jawaban akhir: 75 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Fajar memiliki 54 kertas. Dia memberikan 10 kepada teman. Kemudian menerima 11 kertas. Setelah itu memberikan 11 kepada orang lain. Berapa kertas Fajar sekarang?
A: Fajar sekarang memiliki 54 - 10 + 11 - 11 = 44 kertas.

Verifikasi: Perhitungan: 54 - 10 = 44, 44 + 11 = 55, 55 - 11 = 44. Benar.

Jawaban akhir: 44 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 94 penghapus. Dia meminjamkan 10 kepada teman. Kemudian membeli 16 penghapus. Setelah itu memberikan 12 kepada orang lain. Berapa penghapus Joko sekarang?
A: Joko sekarang memiliki 94 - 10 + 16 - 12 = 88 penghapus.

Verifikasi: Perhitungan: 94 - 10 = 84, 84 + 16 = 100, 100 - 12 = 88. Benar.

Jawaban akhir: 88 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
