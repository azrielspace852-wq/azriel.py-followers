# Dataset Verifikasi Diri 1771

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 68 rupiah. Dia membagi 19 kepada teman. Kemudian membeli 15 rupiah. Setelah itu meminjamkan 12 kepada orang lain. Berapa rupiah Maya sekarang?
A: Maya sekarang memiliki 68 - 19 + 15 - 12 = 52 rupiah.

Verifikasi: Perhitungan: 68 - 19 = 49, 49 + 15 = 64, 64 - 12 = 52. Benar.

Jawaban akhir: 52 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Eko memiliki 55 rupiah. Dia memberikan 10 kepada teman. Kemudian membeli 14 rupiah. Setelah itu meminjamkan 1 kepada orang lain. Berapa rupiah Eko sekarang?
A: Eko sekarang memiliki 55 - 10 + 14 - 1 = 61 rupiah.

Verifikasi: Perhitungan yang benar: 55 - 10 = 45, 45 + 14 = 59, 59 - 1 = 58. Jawaban awal salah.

Jawaban akhir: 58 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Oscar memiliki 32 kelereng. Dia memberikan 8 kepada teman. Kemudian menerima 5 kelereng. Setelah itu memberikan 7 kepada orang lain. Berapa kelereng Oscar sekarang?
A: Oscar sekarang memiliki 32 - 8 + 5 - 7 = 22 kelereng.

Verifikasi: Perhitungan: 32 - 8 = 24, 24 + 5 = 29, 29 - 7 = 22. Benar.

Jawaban akhir: 22 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
