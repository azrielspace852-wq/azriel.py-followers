# Dataset Verifikasi Diri 1984

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 11 kartu. Dia memberikan 2 kepada teman. Kemudian membeli 14 kartu. Setelah itu meminjamkan 1 kepada orang lain. Berapa kartu Indra sekarang?
A: Indra sekarang memiliki 11 - 2 + 14 - 1 = 23 kartu.

Verifikasi: Perhitungan yang benar: 11 - 2 = 9, 9 + 14 = 23, 23 - 1 = 22. Jawaban awal salah.

Jawaban akhir: 22 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Vina memiliki 36 penghapus. Dia membagi 9 kepada teman. Kemudian mendapat 4 penghapus. Setelah itu meminjamkan 13 kepada orang lain. Berapa penghapus Vina sekarang?
A: Vina sekarang memiliki 36 - 9 + 4 - 13 = 18 penghapus.

Verifikasi: Perhitungan: 36 - 9 = 27, 27 + 4 = 31, 31 - 13 = 18. Benar.

Jawaban akhir: 18 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Yudi memiliki 71 spidol. Dia membagi 16 kepada teman. Kemudian mendapat 20 spidol. Setelah itu membagi 12 kepada orang lain. Berapa spidol Yudi sekarang?
A: Yudi sekarang memiliki 71 - 16 + 20 - 12 = 63 spidol.

Verifikasi: Perhitungan: 71 - 16 = 55, 55 + 20 = 75, 75 - 12 = 63. Benar.

Jawaban akhir: 63 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
