# Dataset Verifikasi Diri 1806

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 63 spidol. Dia membagi 8 kepada teman. Kemudian menerima 16 spidol. Setelah itu meminjamkan 1 kepada orang lain. Berapa spidol Nina sekarang?
A: Nina sekarang memiliki 63 - 8 + 16 - 1 = 70 spidol.

Verifikasi: Perhitungan: 63 - 8 = 55, 55 + 16 = 71, 71 - 1 = 70. Benar.

Jawaban akhir: 70 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Putri memiliki 12 buku. Dia memberikan 3 kepada teman. Kemudian membeli 10 buku. Setelah itu memberikan 10 kepada orang lain. Berapa buku Putri sekarang?
A: Putri sekarang memiliki 12 - 3 + 10 - 10 = 9 buku.

Verifikasi: Perhitungan: 12 - 3 = 9, 9 + 10 = 19, 19 - 10 = 9. Benar.

Jawaban akhir: 9 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Indra memiliki 85 penghapus. Dia membagi 18 kepada teman. Kemudian menang 11 penghapus. Setelah itu memberikan 6 kepada orang lain. Berapa penghapus Indra sekarang?
A: Indra sekarang memiliki 85 - 18 + 11 - 6 = 75 penghapus.

Verifikasi: Perhitungan yang benar: 85 - 18 = 67, 67 + 11 = 78, 78 - 6 = 72. Jawaban awal salah.

Jawaban akhir: 72 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
