# Dataset Verifikasi Diri 1895

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 60 kertas. Dia meminjamkan 13 kepada teman. Kemudian membeli 11 kertas. Setelah itu membagi 12 kepada orang lain. Berapa kertas Vina sekarang?
A: Vina sekarang memiliki 60 - 13 + 11 - 12 = 46 kertas.

Verifikasi: Perhitungan: 60 - 13 = 47, 47 + 11 = 58, 58 - 12 = 46. Benar.

Jawaban akhir: 46 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Joko memiliki 90 bola. Dia memberikan 20 kepada teman. Kemudian mendapat 19 bola. Setelah itu memberikan 1 kepada orang lain. Berapa bola Joko sekarang?
A: Joko sekarang memiliki 90 - 20 + 19 - 1 = 86 bola.

Verifikasi: Perhitungan yang benar: 90 - 20 = 70, 70 + 19 = 89, 89 - 1 = 88. Jawaban awal salah.

Jawaban akhir: 88 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 90 kelereng. Dia memberikan 24 kepada teman. Kemudian mendapat 2 kelereng. Setelah itu meminjamkan 5 kepada orang lain. Berapa kelereng Oscar sekarang?
A: Oscar sekarang memiliki 90 - 24 + 2 - 5 = 63 kelereng.

Verifikasi: Perhitungan: 90 - 24 = 66, 66 + 2 = 68, 68 - 5 = 63. Benar.

Jawaban akhir: 63 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
