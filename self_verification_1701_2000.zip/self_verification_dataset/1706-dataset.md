# Dataset Verifikasi Diri 1706

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 45 buku. Dia memberikan 8 kepada teman. Kemudian mendapat 4 buku. Setelah itu membagi 1 kepada orang lain. Berapa buku Wati sekarang?
A: Wati sekarang memiliki 45 - 8 + 4 - 1 = 40 buku.

Verifikasi: Perhitungan: 45 - 8 = 37, 37 + 4 = 41, 41 - 1 = 40. Benar.

Jawaban akhir: 40 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Dedi memiliki 21 pulpen. Dia membagi 6 kepada teman. Kemudian mendapat 13 pulpen. Setelah itu meminjamkan 15 kepada orang lain. Berapa pulpen Dedi sekarang?
A: Dedi sekarang memiliki 21 - 6 + 13 - 15 = 13 pulpen.

Verifikasi: Perhitungan: 21 - 6 = 15, 15 + 13 = 28, 28 - 15 = 13. Benar.

Jawaban akhir: 13 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Andi memiliki 57 kelereng. Dia memberikan 1 kepada teman. Kemudian membeli 18 kelereng. Setelah itu membagi 10 kepada orang lain. Berapa kelereng Andi sekarang?
A: Andi sekarang memiliki 57 - 1 + 18 - 10 = 64 kelereng.

Verifikasi: Perhitungan: 57 - 1 = 56, 56 + 18 = 74, 74 - 10 = 64. Benar.

Jawaban akhir: 64 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
