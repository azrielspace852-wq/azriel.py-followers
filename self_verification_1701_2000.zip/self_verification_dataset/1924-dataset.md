# Dataset Verifikasi Diri 1924

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 79 penghapus. Dia memberikan 21 kepada teman. Kemudian menerima 9 penghapus. Setelah itu meminjamkan 2 kepada orang lain. Berapa penghapus Hani sekarang?
A: Hani sekarang memiliki 79 - 21 + 9 - 2 = 65 penghapus.

Verifikasi: Perhitungan: 79 - 21 = 58, 58 + 9 = 67, 67 - 2 = 65. Benar.

Jawaban akhir: 65 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 19 penggaris. Dia meminjamkan 4 kepada teman. Kemudian membeli 10 penggaris. Setelah itu memberikan 12 kepada orang lain. Berapa penggaris Nina sekarang?
A: Nina sekarang memiliki 19 - 4 + 10 - 12 = 13 penggaris.

Verifikasi: Perhitungan: 19 - 4 = 15, 15 + 10 = 25, 25 - 12 = 13. Benar.

Jawaban akhir: 13 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Wati memiliki 17 kelereng. Dia meminjamkan 4 kepada teman. Kemudian menang 1 kelereng. Setelah itu memberikan 4 kepada orang lain. Berapa kelereng Wati sekarang?
A: Wati sekarang memiliki 17 - 4 + 1 - 4 = 13 kelereng.

Verifikasi: Perhitungan yang benar: 17 - 4 = 13, 13 + 1 = 14, 14 - 4 = 10. Jawaban awal salah.

Jawaban akhir: 10 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
