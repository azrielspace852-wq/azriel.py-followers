# Dataset Verifikasi Diri 1906

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 36 bola. Dia meminjamkan 2 kepada teman. Kemudian membeli 11 bola. Setelah itu membagi 4 kepada orang lain. Berapa bola Maya sekarang?
A: Maya sekarang memiliki 36 - 2 + 11 - 4 = 41 bola.

Verifikasi: Perhitungan: 36 - 2 = 34, 34 + 11 = 45, 45 - 4 = 41. Benar.

Jawaban akhir: 41 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Maya memiliki 87 bola. Dia memberikan 6 kepada teman. Kemudian menang 2 bola. Setelah itu membagi 14 kepada orang lain. Berapa bola Maya sekarang?
A: Maya sekarang memiliki 87 - 6 + 2 - 14 = 69 bola.

Verifikasi: Perhitungan: 87 - 6 = 81, 81 + 2 = 83, 83 - 14 = 69. Benar.

Jawaban akhir: 69 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 89 spidol. Dia meminjamkan 25 kepada teman. Kemudian menang 9 spidol. Setelah itu memberikan 8 kepada orang lain. Berapa spidol Maya sekarang?
A: Maya sekarang memiliki 89 - 25 + 9 - 8 = 65 spidol.

Verifikasi: Perhitungan: 89 - 25 = 64, 64 + 9 = 73, 73 - 8 = 65. Benar.

Jawaban akhir: 65 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
