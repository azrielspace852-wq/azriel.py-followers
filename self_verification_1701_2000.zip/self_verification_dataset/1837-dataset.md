# Dataset Verifikasi Diri 1837

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 65 penghapus. Dia memberikan 10 kepada teman. Kemudian mendapat 16 penghapus. Setelah itu membagi 8 kepada orang lain. Berapa penghapus Udin sekarang?
A: Udin sekarang memiliki 65 - 10 + 16 - 8 = 63 penghapus.

Verifikasi: Perhitungan: 65 - 10 = 55, 55 + 16 = 71, 71 - 8 = 63. Benar.

Jawaban akhir: 63 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Candra memiliki 16 stiker. Dia memberikan 5 kepada teman. Kemudian menang 15 stiker. Setelah itu membagi 13 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 16 - 5 + 15 - 13 = 13 stiker.

Verifikasi: Perhitungan: 16 - 5 = 11, 11 + 15 = 26, 26 - 13 = 13. Benar.

Jawaban akhir: 13 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 76 stiker. Dia membagi 12 kepada teman. Kemudian membeli 12 stiker. Setelah itu memberikan 10 kepada orang lain. Berapa stiker Eko sekarang?
A: Eko sekarang memiliki 76 - 12 + 12 - 10 = 66 stiker.

Verifikasi: Perhitungan: 76 - 12 = 64, 64 + 12 = 76, 76 - 10 = 66. Benar.

Jawaban akhir: 66 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
