# Dataset Verifikasi Diri 1987

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 96 bola. Dia memberikan 20 kepada teman. Kemudian menerima 16 bola. Setelah itu meminjamkan 6 kepada orang lain. Berapa bola Budi sekarang?
A: Budi sekarang memiliki 96 - 20 + 16 - 6 = 85 bola.

Verifikasi: Perhitungan yang benar: 96 - 20 = 76, 76 + 16 = 92, 92 - 6 = 86. Jawaban awal salah.

Jawaban akhir: 86 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Maya memiliki 22 pensil. Dia membagi 7 kepada teman. Kemudian mendapat 6 pensil. Setelah itu memberikan 14 kepada orang lain. Berapa pensil Maya sekarang?
A: Maya sekarang memiliki 22 - 7 + 6 - 14 = 7 pensil.

Verifikasi: Perhitungan: 22 - 7 = 15, 15 + 6 = 21, 21 - 14 = 7. Benar.

Jawaban akhir: 7 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 30 buku. Dia meminjamkan 5 kepada teman. Kemudian mendapat 16 buku. Setelah itu meminjamkan 5 kepada orang lain. Berapa buku Hani sekarang?
A: Hani sekarang memiliki 30 - 5 + 16 - 5 = 35 buku.

Verifikasi: Perhitungan yang benar: 30 - 5 = 25, 25 + 16 = 41, 41 - 5 = 36. Jawaban awal salah.

Jawaban akhir: 36 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
