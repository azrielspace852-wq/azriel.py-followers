# Dataset Verifikasi Diri 1739

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 34 spidol. Dia membagi 7 kepada teman. Kemudian mendapat 1 spidol. Setelah itu membagi 8 kepada orang lain. Berapa spidol Joko sekarang?
A: Joko sekarang memiliki 34 - 7 + 1 - 8 = 20 spidol.

Verifikasi: Perhitungan: 34 - 7 = 27, 27 + 1 = 28, 28 - 8 = 20. Benar.

Jawaban akhir: 20 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 57 pensil. Dia membagi 7 kepada teman. Kemudian mendapat 11 pensil. Setelah itu memberikan 6 kepada orang lain. Berapa pensil Udin sekarang?
A: Udin sekarang memiliki 57 - 7 + 11 - 6 = 55 pensil.

Verifikasi: Perhitungan: 57 - 7 = 50, 50 + 11 = 61, 61 - 6 = 55. Benar.

Jawaban akhir: 55 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Hani memiliki 78 penghapus. Dia meminjamkan 13 kepada teman. Kemudian membeli 17 penghapus. Setelah itu membagi 11 kepada orang lain. Berapa penghapus Hani sekarang?
A: Hani sekarang memiliki 78 - 13 + 17 - 11 = 71 penghapus.

Verifikasi: Perhitungan: 78 - 13 = 65, 65 + 17 = 82, 82 - 11 = 71. Benar.

Jawaban akhir: 71 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
