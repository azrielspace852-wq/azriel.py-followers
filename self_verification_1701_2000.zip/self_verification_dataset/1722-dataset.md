# Dataset Verifikasi Diri 1722

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 30 kertas. Dia memberikan 2 kepada teman. Kemudian membeli 5 kertas. Setelah itu memberikan 2 kepada orang lain. Berapa kertas Oscar sekarang?
A: Oscar sekarang memiliki 30 - 2 + 5 - 2 = 31 kertas.

Verifikasi: Perhitungan: 30 - 2 = 28, 28 + 5 = 33, 33 - 2 = 31. Benar.

Jawaban akhir: 31 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Zaki memiliki 90 stiker. Dia membagi 12 kepada teman. Kemudian menang 3 stiker. Setelah itu meminjamkan 10 kepada orang lain. Berapa stiker Zaki sekarang?
A: Zaki sekarang memiliki 90 - 12 + 3 - 10 = 71 stiker.

Verifikasi: Perhitungan: 90 - 12 = 78, 78 + 3 = 81, 81 - 10 = 71. Benar.

Jawaban akhir: 71 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Tono memiliki 31 spidol. Dia membagi 8 kepada teman. Kemudian mendapat 13 spidol. Setelah itu memberikan 6 kepada orang lain. Berapa spidol Tono sekarang?
A: Tono sekarang memiliki 31 - 8 + 13 - 6 = 30 spidol.

Verifikasi: Perhitungan: 31 - 8 = 23, 23 + 13 = 36, 36 - 6 = 30. Benar.

Jawaban akhir: 30 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
