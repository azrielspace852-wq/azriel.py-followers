# Dataset Verifikasi Diri 1926

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 74 pensil. Dia membagi 14 kepada teman. Kemudian mendapat 5 pensil. Setelah itu meminjamkan 13 kepada orang lain. Berapa pensil Putri sekarang?
A: Putri sekarang memiliki 74 - 14 + 5 - 13 = 52 pensil.

Verifikasi: Perhitungan: 74 - 14 = 60, 60 + 5 = 65, 65 - 13 = 52. Benar.

Jawaban akhir: 52 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Indra memiliki 56 apel. Dia meminjamkan 7 kepada teman. Kemudian membeli 5 apel. Setelah itu membagi 8 kepada orang lain. Berapa apel Indra sekarang?
A: Indra sekarang memiliki 56 - 7 + 5 - 8 = 46 apel.

Verifikasi: Perhitungan: 56 - 7 = 49, 49 + 5 = 54, 54 - 8 = 46. Benar.

Jawaban akhir: 46 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 34 penggaris. Dia membagi 3 kepada teman. Kemudian mendapat 3 penggaris. Setelah itu membagi 2 kepada orang lain. Berapa penggaris Maya sekarang?
A: Maya sekarang memiliki 34 - 3 + 3 - 2 = 32 penggaris.

Verifikasi: Perhitungan: 34 - 3 = 31, 31 + 3 = 34, 34 - 2 = 32. Benar.

Jawaban akhir: 32 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
