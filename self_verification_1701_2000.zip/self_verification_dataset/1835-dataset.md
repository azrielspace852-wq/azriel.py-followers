# Dataset Verifikasi Diri 1835

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 92 kelereng. Dia memberikan 28 kepada teman. Kemudian menerima 7 kelereng. Setelah itu meminjamkan 14 kepada orang lain. Berapa kelereng Budi sekarang?
A: Budi sekarang memiliki 92 - 28 + 7 - 14 = 57 kelereng.

Verifikasi: Perhitungan: 92 - 28 = 64, 64 + 7 = 71, 71 - 14 = 57. Benar.

Jawaban akhir: 57 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Budi memiliki 78 pulpen. Dia membagi 7 kepada teman. Kemudian menang 11 pulpen. Setelah itu meminjamkan 8 kepada orang lain. Berapa pulpen Budi sekarang?
A: Budi sekarang memiliki 78 - 7 + 11 - 8 = 74 pulpen.

Verifikasi: Perhitungan: 78 - 7 = 71, 71 + 11 = 82, 82 - 8 = 74. Benar.

Jawaban akhir: 74 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 10 bola. Dia membagi 3 kepada teman. Kemudian mendapat 5 bola. Setelah itu meminjamkan 6 kepada orang lain. Berapa bola Putri sekarang?
A: Putri sekarang memiliki 10 - 3 + 5 - 6 = 9 bola.

Verifikasi: Perhitungan yang benar: 10 - 3 = 7, 7 + 5 = 12, 12 - 6 = 6. Jawaban awal salah.

Jawaban akhir: 6 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
