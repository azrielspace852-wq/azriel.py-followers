# Dataset Verifikasi Diri 1724

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 72 buku. Dia membagi 14 kepada teman. Kemudian menang 8 buku. Setelah itu memberikan 8 kepada orang lain. Berapa buku Siti sekarang?
A: Siti sekarang memiliki 72 - 14 + 8 - 8 = 58 buku.

Verifikasi: Perhitungan: 72 - 14 = 58, 58 + 8 = 66, 66 - 8 = 58. Benar.

Jawaban akhir: 58 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Zaki memiliki 17 apel. Dia membagi 4 kepada teman. Kemudian menang 19 apel. Setelah itu meminjamkan 14 kepada orang lain. Berapa apel Zaki sekarang?
A: Zaki sekarang memiliki 17 - 4 + 19 - 14 = 19 apel.

Verifikasi: Perhitungan yang benar: 17 - 4 = 13, 13 + 19 = 32, 32 - 14 = 18. Jawaban awal salah.

Jawaban akhir: 18 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Oscar memiliki 95 bola. Dia memberikan 12 kepada teman. Kemudian membeli 8 bola. Setelah itu membagi 1 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 95 - 12 + 8 - 1 = 90 bola.

Verifikasi: Perhitungan: 95 - 12 = 83, 83 + 8 = 91, 91 - 1 = 90. Benar.

Jawaban akhir: 90 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
