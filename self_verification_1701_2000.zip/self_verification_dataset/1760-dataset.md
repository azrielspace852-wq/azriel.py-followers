# Dataset Verifikasi Diri 1760

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 81 kelereng. Dia membagi 8 kepada teman. Kemudian membeli 2 kelereng. Setelah itu membagi 14 kepada orang lain. Berapa kelereng Hani sekarang?
A: Hani sekarang memiliki 81 - 8 + 2 - 14 = 61 kelereng.

Verifikasi: Perhitungan: 81 - 8 = 73, 73 + 2 = 75, 75 - 14 = 61. Benar.

Jawaban akhir: 61 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Yudi memiliki 43 penggaris. Dia membagi 8 kepada teman. Kemudian mendapat 17 penggaris. Setelah itu membagi 14 kepada orang lain. Berapa penggaris Yudi sekarang?
A: Yudi sekarang memiliki 43 - 8 + 17 - 14 = 38 penggaris.

Verifikasi: Perhitungan: 43 - 8 = 35, 35 + 17 = 52, 52 - 14 = 38. Benar.

Jawaban akhir: 38 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Budi memiliki 80 penggaris. Dia membagi 16 kepada teman. Kemudian menerima 18 penggaris. Setelah itu memberikan 9 kepada orang lain. Berapa penggaris Budi sekarang?
A: Budi sekarang memiliki 80 - 16 + 18 - 9 = 74 penggaris.

Verifikasi: Perhitungan yang benar: 80 - 16 = 64, 64 + 18 = 82, 82 - 9 = 73. Jawaban awal salah.

Jawaban akhir: 73 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
