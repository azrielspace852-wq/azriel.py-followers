# Dataset Verifikasi Diri 1923

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 69 spidol. Dia memberikan 9 kepada teman. Kemudian mendapat 3 spidol. Setelah itu membagi 14 kepada orang lain. Berapa spidol Fajar sekarang?
A: Fajar sekarang memiliki 69 - 9 + 3 - 14 = 49 spidol.

Verifikasi: Perhitungan: 69 - 9 = 60, 60 + 3 = 63, 63 - 14 = 49. Benar.

Jawaban akhir: 49 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 67 kartu. Dia membagi 14 kepada teman. Kemudian membeli 17 kartu. Setelah itu memberikan 10 kepada orang lain. Berapa kartu Gita sekarang?
A: Gita sekarang memiliki 67 - 14 + 17 - 10 = 60 kartu.

Verifikasi: Perhitungan: 67 - 14 = 53, 53 + 17 = 70, 70 - 10 = 60. Benar.

Jawaban akhir: 60 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Andi memiliki 51 penggaris. Dia meminjamkan 5 kepada teman. Kemudian menerima 1 penggaris. Setelah itu membagi 1 kepada orang lain. Berapa penggaris Andi sekarang?
A: Andi sekarang memiliki 51 - 5 + 1 - 1 = 46 penggaris.

Verifikasi: Perhitungan: 51 - 5 = 46, 46 + 1 = 47, 47 - 1 = 46. Benar.

Jawaban akhir: 46 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
