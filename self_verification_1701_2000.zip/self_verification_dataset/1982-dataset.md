# Dataset Verifikasi Diri 1982

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 18 rupiah. Dia memberikan 1 kepada teman. Kemudian menerima 18 rupiah. Setelah itu memberikan 4 kepada orang lain. Berapa rupiah Wati sekarang?
A: Wati sekarang memiliki 18 - 1 + 18 - 4 = 29 rupiah.

Verifikasi: Perhitungan yang benar: 18 - 1 = 17, 17 + 18 = 35, 35 - 4 = 31. Jawaban awal salah.

Jawaban akhir: 31 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 99 penghapus. Dia memberikan 3 kepada teman. Kemudian mendapat 20 penghapus. Setelah itu membagi 12 kepada orang lain. Berapa penghapus Nina sekarang?
A: Nina sekarang memiliki 99 - 3 + 20 - 12 = 103 penghapus.

Verifikasi: Perhitungan yang benar: 99 - 3 = 96, 96 + 20 = 116, 116 - 12 = 104. Jawaban awal salah.

Jawaban akhir: 104 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Udin memiliki 14 buku tulis. Dia membagi 2 kepada teman. Kemudian menang 8 buku tulis. Setelah itu memberikan 4 kepada orang lain. Berapa buku tulis Udin sekarang?
A: Udin sekarang memiliki 14 - 2 + 8 - 4 = 16 buku tulis.

Verifikasi: Perhitungan: 14 - 2 = 12, 12 + 8 = 20, 20 - 4 = 16. Benar.

Jawaban akhir: 16 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
