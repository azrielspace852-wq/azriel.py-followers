# Dataset Verifikasi Diri 1787

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 34 kue. Dia meminjamkan 5 kepada teman. Kemudian menang 12 kue. Setelah itu memberikan 13 kepada orang lain. Berapa kue Candra sekarang?
A: Candra sekarang memiliki 34 - 5 + 12 - 13 = 28 kue.

Verifikasi: Perhitungan: 34 - 5 = 29, 29 + 12 = 41, 41 - 13 = 28. Benar.

Jawaban akhir: 28 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Putri memiliki 16 stiker. Dia meminjamkan 4 kepada teman. Kemudian membeli 8 stiker. Setelah itu memberikan 2 kepada orang lain. Berapa stiker Putri sekarang?
A: Putri sekarang memiliki 16 - 4 + 8 - 2 = 18 stiker.

Verifikasi: Perhitungan: 16 - 4 = 12, 12 + 8 = 20, 20 - 2 = 18. Benar.

Jawaban akhir: 18 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Yudi memiliki 86 penghapus. Dia memberikan 2 kepada teman. Kemudian mendapat 18 penghapus. Setelah itu memberikan 14 kepada orang lain. Berapa penghapus Yudi sekarang?
A: Yudi sekarang memiliki 86 - 2 + 18 - 14 = 89 penghapus.

Verifikasi: Perhitungan yang benar: 86 - 2 = 84, 84 + 18 = 102, 102 - 14 = 88. Jawaban awal salah.

Jawaban akhir: 88 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
