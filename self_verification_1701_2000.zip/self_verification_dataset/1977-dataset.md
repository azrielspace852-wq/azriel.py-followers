# Dataset Verifikasi Diri 1977

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 58 buku tulis. Dia memberikan 13 kepada teman. Kemudian menang 5 buku tulis. Setelah itu memberikan 13 kepada orang lain. Berapa buku tulis Joko sekarang?
A: Joko sekarang memiliki 58 - 13 + 5 - 13 = 39 buku tulis.

Verifikasi: Perhitungan yang benar: 58 - 13 = 45, 45 + 5 = 50, 50 - 13 = 37. Jawaban awal salah.

Jawaban akhir: 37 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Nina memiliki 82 kelereng. Dia memberikan 7 kepada teman. Kemudian mendapat 20 kelereng. Setelah itu membagi 6 kepada orang lain. Berapa kelereng Nina sekarang?
A: Nina sekarang memiliki 82 - 7 + 20 - 6 = 89 kelereng.

Verifikasi: Perhitungan: 82 - 7 = 75, 75 + 20 = 95, 95 - 6 = 89. Benar.

Jawaban akhir: 89 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Maya memiliki 31 kartu. Dia membagi 8 kepada teman. Kemudian menerima 15 kartu. Setelah itu membagi 2 kepada orang lain. Berapa kartu Maya sekarang?
A: Maya sekarang memiliki 31 - 8 + 15 - 2 = 35 kartu.

Verifikasi: Perhitungan yang benar: 31 - 8 = 23, 23 + 15 = 38, 38 - 2 = 36. Jawaban awal salah.

Jawaban akhir: 36 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
