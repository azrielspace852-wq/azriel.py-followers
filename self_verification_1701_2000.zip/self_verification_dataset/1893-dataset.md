# Dataset Verifikasi Diri 1893

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 77 penghapus. Dia membagi 13 kepada teman. Kemudian menang 19 penghapus. Setelah itu memberikan 1 kepada orang lain. Berapa penghapus Tono sekarang?
A: Tono sekarang memiliki 77 - 13 + 19 - 1 = 82 penghapus.

Verifikasi: Perhitungan: 77 - 13 = 64, 64 + 19 = 83, 83 - 1 = 82. Benar.

Jawaban akhir: 82 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Fajar memiliki 100 kue. Dia meminjamkan 28 kepada teman. Kemudian mendapat 11 kue. Setelah itu membagi 10 kepada orang lain. Berapa kue Fajar sekarang?
A: Fajar sekarang memiliki 100 - 28 + 11 - 10 = 74 kue.

Verifikasi: Perhitungan yang benar: 100 - 28 = 72, 72 + 11 = 83, 83 - 10 = 73. Jawaban awal salah.

Jawaban akhir: 73 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 27 kelereng. Dia membagi 5 kepada teman. Kemudian menang 18 kelereng. Setelah itu membagi 15 kepada orang lain. Berapa kelereng Fajar sekarang?
A: Fajar sekarang memiliki 27 - 5 + 18 - 15 = 25 kelereng.

Verifikasi: Perhitungan: 27 - 5 = 22, 22 + 18 = 40, 40 - 15 = 25. Benar.

Jawaban akhir: 25 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
