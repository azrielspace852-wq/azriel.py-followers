# Dataset Verifikasi Diri 1846

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 88 pulpen. Dia meminjamkan 17 kepada teman. Kemudian mendapat 17 pulpen. Setelah itu meminjamkan 14 kepada orang lain. Berapa pulpen Oscar sekarang?
A: Oscar sekarang memiliki 88 - 17 + 17 - 14 = 74 pulpen.

Verifikasi: Perhitungan: 88 - 17 = 71, 71 + 17 = 88, 88 - 14 = 74. Benar.

Jawaban akhir: 74 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Udin memiliki 91 buku. Dia memberikan 8 kepada teman. Kemudian membeli 14 buku. Setelah itu memberikan 1 kepada orang lain. Berapa buku Udin sekarang?
A: Udin sekarang memiliki 91 - 8 + 14 - 1 = 96 buku.

Verifikasi: Perhitungan: 91 - 8 = 83, 83 + 14 = 97, 97 - 1 = 96. Benar.

Jawaban akhir: 96 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Andi memiliki 28 buku. Dia membagi 6 kepada teman. Kemudian membeli 19 buku. Setelah itu membagi 7 kepada orang lain. Berapa buku Andi sekarang?
A: Andi sekarang memiliki 28 - 6 + 19 - 7 = 34 buku.

Verifikasi: Perhitungan: 28 - 6 = 22, 22 + 19 = 41, 41 - 7 = 34. Benar.

Jawaban akhir: 34 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
