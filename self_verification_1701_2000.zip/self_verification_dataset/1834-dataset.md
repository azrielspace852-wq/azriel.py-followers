# Dataset Verifikasi Diri 1834

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 13 buku tulis. Dia meminjamkan 3 kepada teman. Kemudian menang 2 buku tulis. Setelah itu memberikan 15 kepada orang lain. Berapa buku tulis Tono sekarang?
A: Tono sekarang memiliki 13 - 3 + 2 - 15 = -2 buku tulis.

Verifikasi: Perhitungan yang benar: 13 - 3 = 10, 10 + 2 = 12, 12 - 15 = -3. Jawaban awal salah.

Jawaban akhir: -3 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Udin memiliki 43 rupiah. Dia memberikan 8 kepada teman. Kemudian menang 8 rupiah. Setelah itu meminjamkan 2 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 43 - 8 + 8 - 2 = 41 rupiah.

Verifikasi: Perhitungan: 43 - 8 = 35, 35 + 8 = 43, 43 - 2 = 41. Benar.

Jawaban akhir: 41 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Kiki memiliki 53 rupiah. Dia memberikan 6 kepada teman. Kemudian membeli 2 rupiah. Setelah itu memberikan 3 kepada orang lain. Berapa rupiah Kiki sekarang?
A: Kiki sekarang memiliki 53 - 6 + 2 - 3 = 48 rupiah.

Verifikasi: Perhitungan yang benar: 53 - 6 = 47, 47 + 2 = 49, 49 - 3 = 46. Jawaban awal salah.

Jawaban akhir: 46 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
