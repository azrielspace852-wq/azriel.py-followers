# Dataset Verifikasi Diri 1927

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 59 stiker. Dia memberikan 3 kepada teman. Kemudian menerima 19 stiker. Setelah itu membagi 5 kepada orang lain. Berapa stiker Lina sekarang?
A: Lina sekarang memiliki 59 - 3 + 19 - 5 = 68 stiker.

Verifikasi: Perhitungan yang benar: 59 - 3 = 56, 56 + 19 = 75, 75 - 5 = 70. Jawaban awal salah.

Jawaban akhir: 70 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 13 kue. Dia memberikan 2 kepada teman. Kemudian menang 4 kue. Setelah itu memberikan 12 kepada orang lain. Berapa kue Nina sekarang?
A: Nina sekarang memiliki 13 - 2 + 4 - 12 = 3 kue.

Verifikasi: Perhitungan: 13 - 2 = 11, 11 + 4 = 15, 15 - 12 = 3. Benar.

Jawaban akhir: 3 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Candra memiliki 43 buku tulis. Dia membagi 12 kepada teman. Kemudian menang 15 buku tulis. Setelah itu memberikan 9 kepada orang lain. Berapa buku tulis Candra sekarang?
A: Candra sekarang memiliki 43 - 12 + 15 - 9 = 36 buku tulis.

Verifikasi: Perhitungan yang benar: 43 - 12 = 31, 31 + 15 = 46, 46 - 9 = 37. Jawaban awal salah.

Jawaban akhir: 37 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
