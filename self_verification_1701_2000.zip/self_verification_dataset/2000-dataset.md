# Dataset Verifikasi Diri 2000

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 53 buku. Dia membagi 2 kepada teman. Kemudian menerima 19 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 53 - 2 + 19 - 15 = 55 buku.

Verifikasi: Perhitungan: 53 - 2 = 51, 51 + 19 = 70, 70 - 15 = 55. Benar.

Jawaban akhir: 55 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Andi memiliki 77 penggaris. Dia meminjamkan 4 kepada teman. Kemudian menang 18 penggaris. Setelah itu meminjamkan 9 kepada orang lain. Berapa penggaris Andi sekarang?
A: Andi sekarang memiliki 77 - 4 + 18 - 9 = 82 penggaris.

Verifikasi: Perhitungan: 77 - 4 = 73, 73 + 18 = 91, 91 - 9 = 82. Benar.

Jawaban akhir: 82 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 44 apel. Dia memberikan 1 kepada teman. Kemudian menerima 15 apel. Setelah itu memberikan 5 kepada orang lain. Berapa apel Joko sekarang?
A: Joko sekarang memiliki 44 - 1 + 15 - 5 = 55 apel.

Verifikasi: Perhitungan yang benar: 44 - 1 = 43, 43 + 15 = 58, 58 - 5 = 53. Jawaban awal salah.

Jawaban akhir: 53 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
