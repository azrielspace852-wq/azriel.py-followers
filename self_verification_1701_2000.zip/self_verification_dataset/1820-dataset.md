# Dataset Verifikasi Diri 1820

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 82 pulpen. Dia meminjamkan 25 kepada teman. Kemudian menerima 5 pulpen. Setelah itu membagi 8 kepada orang lain. Berapa pulpen Yudi sekarang?
A: Yudi sekarang memiliki 82 - 25 + 5 - 8 = 53 pulpen.

Verifikasi: Perhitungan yang benar: 82 - 25 = 57, 57 + 5 = 62, 62 - 8 = 54. Jawaban awal salah.

Jawaban akhir: 54 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 93 kue. Dia memberikan 29 kepada teman. Kemudian membeli 11 kue. Setelah itu meminjamkan 9 kepada orang lain. Berapa kue Dedi sekarang?
A: Dedi sekarang memiliki 93 - 29 + 11 - 9 = 66 kue.

Verifikasi: Perhitungan: 93 - 29 = 64, 64 + 11 = 75, 75 - 9 = 66. Benar.

Jawaban akhir: 66 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Indra memiliki 100 bola. Dia membagi 21 kepada teman. Kemudian membeli 19 bola. Setelah itu memberikan 8 kepada orang lain. Berapa bola Indra sekarang?
A: Indra sekarang memiliki 100 - 21 + 19 - 8 = 89 bola.

Verifikasi: Perhitungan yang benar: 100 - 21 = 79, 79 + 19 = 98, 98 - 8 = 90. Jawaban awal salah.

Jawaban akhir: 90 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
