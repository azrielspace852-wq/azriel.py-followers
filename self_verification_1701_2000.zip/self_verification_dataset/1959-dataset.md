# Dataset Verifikasi Diri 1959

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 47 apel. Dia membagi 3 kepada teman. Kemudian menang 17 apel. Setelah itu memberikan 12 kepada orang lain. Berapa apel Indra sekarang?
A: Indra sekarang memiliki 47 - 3 + 17 - 12 = 49 apel.

Verifikasi: Perhitungan: 47 - 3 = 44, 44 + 17 = 61, 61 - 12 = 49. Benar.

Jawaban akhir: 49 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Wati memiliki 53 buku. Dia meminjamkan 5 kepada teman. Kemudian membeli 20 buku. Setelah itu membagi 6 kepada orang lain. Berapa buku Wati sekarang?
A: Wati sekarang memiliki 53 - 5 + 20 - 6 = 63 buku.

Verifikasi: Perhitungan yang benar: 53 - 5 = 48, 48 + 20 = 68, 68 - 6 = 62. Jawaban awal salah.

Jawaban akhir: 62 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Zaki memiliki 65 pensil. Dia membagi 7 kepada teman. Kemudian menerima 3 pensil. Setelah itu meminjamkan 14 kepada orang lain. Berapa pensil Zaki sekarang?
A: Zaki sekarang memiliki 65 - 7 + 3 - 14 = 47 pensil.

Verifikasi: Perhitungan: 65 - 7 = 58, 58 + 3 = 61, 61 - 14 = 47. Benar.

Jawaban akhir: 47 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
