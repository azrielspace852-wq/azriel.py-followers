# Dataset Verifikasi Diri 1899

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 44 rupiah. Dia memberikan 2 kepada teman. Kemudian menang 19 rupiah. Setelah itu membagi 6 kepada orang lain. Berapa rupiah Nina sekarang?
A: Nina sekarang memiliki 44 - 2 + 19 - 6 = 53 rupiah.

Verifikasi: Perhitungan yang benar: 44 - 2 = 42, 42 + 19 = 61, 61 - 6 = 55. Jawaban awal salah.

Jawaban akhir: 55 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Wati memiliki 13 bola. Dia memberikan 4 kepada teman. Kemudian membeli 5 bola. Setelah itu memberikan 15 kepada orang lain. Berapa bola Wati sekarang?
A: Wati sekarang memiliki 13 - 4 + 5 - 15 = 0 bola.

Verifikasi: Perhitungan yang benar: 13 - 4 = 9, 9 + 5 = 14, 14 - 15 = -1. Jawaban awal salah.

Jawaban akhir: -1 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Udin memiliki 47 pensil. Dia membagi 12 kepada teman. Kemudian menerima 6 pensil. Setelah itu memberikan 4 kepada orang lain. Berapa pensil Udin sekarang?
A: Udin sekarang memiliki 47 - 12 + 6 - 4 = 38 pensil.

Verifikasi: Perhitungan yang benar: 47 - 12 = 35, 35 + 6 = 41, 41 - 4 = 37. Jawaban awal salah.

Jawaban akhir: 37 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
