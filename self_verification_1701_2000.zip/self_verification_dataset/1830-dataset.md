# Dataset Verifikasi Diri 1830

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 86 buku. Dia meminjamkan 17 kepada teman. Kemudian membeli 16 buku. Setelah itu membagi 9 kepada orang lain. Berapa buku Rina sekarang?
A: Rina sekarang memiliki 86 - 17 + 16 - 9 = 76 buku.

Verifikasi: Perhitungan: 86 - 17 = 69, 69 + 16 = 85, 85 - 9 = 76. Benar.

Jawaban akhir: 76 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 80 penghapus. Dia memberikan 1 kepada teman. Kemudian menang 10 penghapus. Setelah itu memberikan 4 kepada orang lain. Berapa penghapus Putri sekarang?
A: Putri sekarang memiliki 80 - 1 + 10 - 4 = 85 penghapus.

Verifikasi: Perhitungan: 80 - 1 = 79, 79 + 10 = 89, 89 - 4 = 85. Benar.

Jawaban akhir: 85 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Siti memiliki 26 penggaris. Dia membagi 2 kepada teman. Kemudian menerima 6 penggaris. Setelah itu membagi 13 kepada orang lain. Berapa penggaris Siti sekarang?
A: Siti sekarang memiliki 26 - 2 + 6 - 13 = 16 penggaris.

Verifikasi: Perhitungan yang benar: 26 - 2 = 24, 24 + 6 = 30, 30 - 13 = 17. Jawaban awal salah.

Jawaban akhir: 17 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
