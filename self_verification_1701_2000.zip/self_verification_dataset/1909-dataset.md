# Dataset Verifikasi Diri 1909

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 34 kue. Dia meminjamkan 7 kepada teman. Kemudian mendapat 15 kue. Setelah itu meminjamkan 8 kepada orang lain. Berapa kue Siti sekarang?
A: Siti sekarang memiliki 34 - 7 + 15 - 8 = 34 kue.

Verifikasi: Perhitungan: 34 - 7 = 27, 27 + 15 = 42, 42 - 8 = 34. Benar.

Jawaban akhir: 34 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 24 apel. Dia meminjamkan 8 kepada teman. Kemudian mendapat 9 apel. Setelah itu membagi 12 kepada orang lain. Berapa apel Udin sekarang?
A: Udin sekarang memiliki 24 - 8 + 9 - 12 = 13 apel.

Verifikasi: Perhitungan: 24 - 8 = 16, 16 + 9 = 25, 25 - 12 = 13. Benar.

Jawaban akhir: 13 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 96 penggaris. Dia membagi 25 kepada teman. Kemudian mendapat 2 penggaris. Setelah itu meminjamkan 2 kepada orang lain. Berapa penggaris Nina sekarang?
A: Nina sekarang memiliki 96 - 25 + 2 - 2 = 71 penggaris.

Verifikasi: Perhitungan: 96 - 25 = 71, 71 + 2 = 73, 73 - 2 = 71. Benar.

Jawaban akhir: 71 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
