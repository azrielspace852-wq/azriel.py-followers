# Dataset Verifikasi Diri 1769

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 69 stiker. Dia memberikan 19 kepada teman. Kemudian mendapat 12 stiker. Setelah itu membagi 13 kepada orang lain. Berapa stiker Yudi sekarang?
A: Yudi sekarang memiliki 69 - 19 + 12 - 13 = 50 stiker.

Verifikasi: Perhitungan yang benar: 69 - 19 = 50, 50 + 12 = 62, 62 - 13 = 49. Jawaban awal salah.

Jawaban akhir: 49 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 99 buku tulis. Dia membagi 8 kepada teman. Kemudian menang 17 buku tulis. Setelah itu membagi 4 kepada orang lain. Berapa buku tulis Putri sekarang?
A: Putri sekarang memiliki 99 - 8 + 17 - 4 = 104 buku tulis.

Verifikasi: Perhitungan: 99 - 8 = 91, 91 + 17 = 108, 108 - 4 = 104. Benar.

Jawaban akhir: 104 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Tono memiliki 82 pulpen. Dia meminjamkan 14 kepada teman. Kemudian menang 1 pulpen. Setelah itu meminjamkan 3 kepada orang lain. Berapa pulpen Tono sekarang?
A: Tono sekarang memiliki 82 - 14 + 1 - 3 = 67 pulpen.

Verifikasi: Perhitungan yang benar: 82 - 14 = 68, 68 + 1 = 69, 69 - 3 = 66. Jawaban awal salah.

Jawaban akhir: 66 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
