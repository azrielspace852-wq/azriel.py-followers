# Dataset Verifikasi Diri 1863

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 24 penghapus. Dia membagi 1 kepada teman. Kemudian menerima 11 penghapus. Setelah itu memberikan 11 kepada orang lain. Berapa penghapus Tono sekarang?
A: Tono sekarang memiliki 24 - 1 + 11 - 11 = 23 penghapus.

Verifikasi: Perhitungan: 24 - 1 = 23, 23 + 11 = 34, 34 - 11 = 23. Benar.

Jawaban akhir: 23 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Candra memiliki 36 penggaris. Dia membagi 7 kepada teman. Kemudian menang 11 penggaris. Setelah itu meminjamkan 15 kepada orang lain. Berapa penggaris Candra sekarang?
A: Candra sekarang memiliki 36 - 7 + 11 - 15 = 25 penggaris.

Verifikasi: Perhitungan: 36 - 7 = 29, 29 + 11 = 40, 40 - 15 = 25. Benar.

Jawaban akhir: 25 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Fajar memiliki 89 buku. Dia membagi 16 kepada teman. Kemudian membeli 1 buku. Setelah itu meminjamkan 10 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 89 - 16 + 1 - 10 = 64 buku.

Verifikasi: Perhitungan: 89 - 16 = 73, 73 + 1 = 74, 74 - 10 = 64. Benar.

Jawaban akhir: 64 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
