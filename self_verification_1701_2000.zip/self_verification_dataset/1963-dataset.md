# Dataset Verifikasi Diri 1963

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 12 spidol. Dia memberikan 3 kepada teman. Kemudian menerima 17 spidol. Setelah itu meminjamkan 8 kepada orang lain. Berapa spidol Maya sekarang?
A: Maya sekarang memiliki 12 - 3 + 17 - 8 = 19 spidol.

Verifikasi: Perhitungan yang benar: 12 - 3 = 9, 9 + 17 = 26, 26 - 8 = 18. Jawaban awal salah.

Jawaban akhir: 18 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Putri memiliki 77 penghapus. Dia meminjamkan 7 kepada teman. Kemudian menang 5 penghapus. Setelah itu memberikan 1 kepada orang lain. Berapa penghapus Putri sekarang?
A: Putri sekarang memiliki 77 - 7 + 5 - 1 = 74 penghapus.

Verifikasi: Perhitungan: 77 - 7 = 70, 70 + 5 = 75, 75 - 1 = 74. Benar.

Jawaban akhir: 74 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Hani memiliki 59 kertas. Dia membagi 3 kepada teman. Kemudian membeli 17 kertas. Setelah itu meminjamkan 12 kepada orang lain. Berapa kertas Hani sekarang?
A: Hani sekarang memiliki 59 - 3 + 17 - 12 = 59 kertas.

Verifikasi: Perhitungan yang benar: 59 - 3 = 56, 56 + 17 = 73, 73 - 12 = 61. Jawaban awal salah.

Jawaban akhir: 61 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
