# Dataset Verifikasi Diri 1917

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 99 pulpen. Dia memberikan 11 kepada teman. Kemudian menang 5 pulpen. Setelah itu membagi 12 kepada orang lain. Berapa pulpen Gita sekarang?
A: Gita sekarang memiliki 99 - 11 + 5 - 12 = 82 pulpen.

Verifikasi: Perhitungan yang benar: 99 - 11 = 88, 88 + 5 = 93, 93 - 12 = 81. Jawaban awal salah.

Jawaban akhir: 81 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Andi memiliki 50 penghapus. Dia membagi 1 kepada teman. Kemudian mendapat 10 penghapus. Setelah itu memberikan 12 kepada orang lain. Berapa penghapus Andi sekarang?
A: Andi sekarang memiliki 50 - 1 + 10 - 12 = 45 penghapus.

Verifikasi: Perhitungan yang benar: 50 - 1 = 49, 49 + 10 = 59, 59 - 12 = 47. Jawaban awal salah.

Jawaban akhir: 47 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Udin memiliki 40 rupiah. Dia meminjamkan 7 kepada teman. Kemudian menang 1 rupiah. Setelah itu memberikan 5 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 40 - 7 + 1 - 5 = 27 rupiah.

Verifikasi: Perhitungan yang benar: 40 - 7 = 33, 33 + 1 = 34, 34 - 5 = 29. Jawaban awal salah.

Jawaban akhir: 29 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
