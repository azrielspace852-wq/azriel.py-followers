# Dataset Verifikasi Diri 1749

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 87 spidol. Dia memberikan 16 kepada teman. Kemudian mendapat 17 spidol. Setelah itu meminjamkan 3 kepada orang lain. Berapa spidol Maya sekarang?
A: Maya sekarang memiliki 87 - 16 + 17 - 3 = 85 spidol.

Verifikasi: Perhitungan: 87 - 16 = 71, 71 + 17 = 88, 88 - 3 = 85. Benar.

Jawaban akhir: 85 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Andi memiliki 95 kue. Dia membagi 1 kepada teman. Kemudian menerima 13 kue. Setelah itu meminjamkan 12 kepada orang lain. Berapa kue Andi sekarang?
A: Andi sekarang memiliki 95 - 1 + 13 - 12 = 95 kue.

Verifikasi: Perhitungan: 95 - 1 = 94, 94 + 13 = 107, 107 - 12 = 95. Benar.

Jawaban akhir: 95 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Rina memiliki 73 pensil. Dia meminjamkan 9 kepada teman. Kemudian membeli 8 pensil. Setelah itu memberikan 10 kepada orang lain. Berapa pensil Rina sekarang?
A: Rina sekarang memiliki 73 - 9 + 8 - 10 = 62 pensil.

Verifikasi: Perhitungan: 73 - 9 = 64, 64 + 8 = 72, 72 - 10 = 62. Benar.

Jawaban akhir: 62 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
