# Dataset Verifikasi Diri 1972

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 55 bola. Dia meminjamkan 17 kepada teman. Kemudian mendapat 19 bola. Setelah itu membagi 12 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 55 - 17 + 19 - 12 = 45 bola.

Verifikasi: Perhitungan: 55 - 17 = 38, 38 + 19 = 57, 57 - 12 = 45. Benar.

Jawaban akhir: 45 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 28 kelereng. Dia meminjamkan 6 kepada teman. Kemudian menang 4 kelereng. Setelah itu membagi 1 kepada orang lain. Berapa kelereng Lina sekarang?
A: Lina sekarang memiliki 28 - 6 + 4 - 1 = 25 kelereng.

Verifikasi: Perhitungan: 28 - 6 = 22, 22 + 4 = 26, 26 - 1 = 25. Benar.

Jawaban akhir: 25 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Gita memiliki 61 penghapus. Dia meminjamkan 19 kepada teman. Kemudian membeli 4 penghapus. Setelah itu membagi 7 kepada orang lain. Berapa penghapus Gita sekarang?
A: Gita sekarang memiliki 61 - 19 + 4 - 7 = 39 penghapus.

Verifikasi: Perhitungan: 61 - 19 = 42, 42 + 4 = 46, 46 - 7 = 39. Benar.

Jawaban akhir: 39 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
