# Dataset Verifikasi Diri 1785

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 57 stiker. Dia memberikan 8 kepada teman. Kemudian menang 13 stiker. Setelah itu membagi 15 kepada orang lain. Berapa stiker Kiki sekarang?
A: Kiki sekarang memiliki 57 - 8 + 13 - 15 = 47 stiker.

Verifikasi: Perhitungan: 57 - 8 = 49, 49 + 13 = 62, 62 - 15 = 47. Benar.

Jawaban akhir: 47 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 67 kartu. Dia meminjamkan 19 kepada teman. Kemudian membeli 15 kartu. Setelah itu membagi 10 kepada orang lain. Berapa kartu Fajar sekarang?
A: Fajar sekarang memiliki 67 - 19 + 15 - 10 = 53 kartu.

Verifikasi: Perhitungan: 67 - 19 = 48, 48 + 15 = 63, 63 - 10 = 53. Benar.

Jawaban akhir: 53 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Joko memiliki 65 kelereng. Dia memberikan 11 kepada teman. Kemudian membeli 11 kelereng. Setelah itu membagi 5 kepada orang lain. Berapa kelereng Joko sekarang?
A: Joko sekarang memiliki 65 - 11 + 11 - 5 = 60 kelereng.

Verifikasi: Perhitungan: 65 - 11 = 54, 54 + 11 = 65, 65 - 5 = 60. Benar.

Jawaban akhir: 60 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
