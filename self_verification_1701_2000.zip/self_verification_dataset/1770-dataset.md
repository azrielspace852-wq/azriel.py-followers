# Dataset Verifikasi Diri 1770

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 61 bola. Dia meminjamkan 20 kepada teman. Kemudian menang 7 bola. Setelah itu membagi 2 kepada orang lain. Berapa bola Tono sekarang?
A: Tono sekarang memiliki 61 - 20 + 7 - 2 = 49 bola.

Verifikasi: Perhitungan yang benar: 61 - 20 = 41, 41 + 7 = 48, 48 - 2 = 46. Jawaban awal salah.

Jawaban akhir: 46 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Candra memiliki 43 pulpen. Dia membagi 3 kepada teman. Kemudian menerima 12 pulpen. Setelah itu membagi 7 kepada orang lain. Berapa pulpen Candra sekarang?
A: Candra sekarang memiliki 43 - 3 + 12 - 7 = 46 pulpen.

Verifikasi: Perhitungan yang benar: 43 - 3 = 40, 40 + 12 = 52, 52 - 7 = 45. Jawaban awal salah.

Jawaban akhir: 45 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 41 kertas. Dia membagi 7 kepada teman. Kemudian menang 12 kertas. Setelah itu membagi 8 kepada orang lain. Berapa kertas Gita sekarang?
A: Gita sekarang memiliki 41 - 7 + 12 - 8 = 38 kertas.

Verifikasi: Perhitungan: 41 - 7 = 34, 34 + 12 = 46, 46 - 8 = 38. Benar.

Jawaban akhir: 38 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
