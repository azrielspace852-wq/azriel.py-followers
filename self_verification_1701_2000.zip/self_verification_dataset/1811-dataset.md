# Dataset Verifikasi Diri 1811

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 96 stiker. Dia memberikan 16 kepada teman. Kemudian membeli 16 stiker. Setelah itu membagi 5 kepada orang lain. Berapa stiker Oscar sekarang?
A: Oscar sekarang memiliki 96 - 16 + 16 - 5 = 91 stiker.

Verifikasi: Perhitungan: 96 - 16 = 80, 80 + 16 = 96, 96 - 5 = 91. Benar.

Jawaban akhir: 91 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Wati memiliki 44 kue. Dia membagi 5 kepada teman. Kemudian membeli 10 kue. Setelah itu membagi 7 kepada orang lain. Berapa kue Wati sekarang?
A: Wati sekarang memiliki 44 - 5 + 10 - 7 = 44 kue.

Verifikasi: Perhitungan yang benar: 44 - 5 = 39, 39 + 10 = 49, 49 - 7 = 42. Jawaban awal salah.

Jawaban akhir: 42 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Joko memiliki 26 kelereng. Dia membagi 3 kepada teman. Kemudian menerima 2 kelereng. Setelah itu memberikan 14 kepada orang lain. Berapa kelereng Joko sekarang?
A: Joko sekarang memiliki 26 - 3 + 2 - 14 = 11 kelereng.

Verifikasi: Perhitungan: 26 - 3 = 23, 23 + 2 = 25, 25 - 14 = 11. Benar.

Jawaban akhir: 11 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
