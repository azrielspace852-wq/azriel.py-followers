# Dataset Verifikasi Diri 1819

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 37 kue. Dia memberikan 4 kepada teman. Kemudian mendapat 3 kue. Setelah itu memberikan 5 kepada orang lain. Berapa kue Andi sekarang?
A: Andi sekarang memiliki 37 - 4 + 3 - 5 = 31 kue.

Verifikasi: Perhitungan: 37 - 4 = 33, 33 + 3 = 36, 36 - 5 = 31. Benar.

Jawaban akhir: 31 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Andi memiliki 24 bola. Dia membagi 1 kepada teman. Kemudian menang 3 bola. Setelah itu memberikan 15 kepada orang lain. Berapa bola Andi sekarang?
A: Andi sekarang memiliki 24 - 1 + 3 - 15 = 11 bola.

Verifikasi: Perhitungan: 24 - 1 = 23, 23 + 3 = 26, 26 - 15 = 11. Benar.

Jawaban akhir: 11 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Maya memiliki 13 penghapus. Dia memberikan 3 kepada teman. Kemudian menang 15 penghapus. Setelah itu membagi 8 kepada orang lain. Berapa penghapus Maya sekarang?
A: Maya sekarang memiliki 13 - 3 + 15 - 8 = 18 penghapus.

Verifikasi: Perhitungan yang benar: 13 - 3 = 10, 10 + 15 = 25, 25 - 8 = 17. Jawaban awal salah.

Jawaban akhir: 17 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
