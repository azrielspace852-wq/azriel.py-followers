# Dataset Verifikasi Diri 1750

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 39 kue. Dia membagi 5 kepada teman. Kemudian mendapat 1 kue. Setelah itu memberikan 7 kepada orang lain. Berapa kue Maya sekarang?
A: Maya sekarang memiliki 39 - 5 + 1 - 7 = 28 kue.

Verifikasi: Perhitungan: 39 - 5 = 34, 34 + 1 = 35, 35 - 7 = 28. Benar.

Jawaban akhir: 28 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Siti memiliki 37 bola. Dia membagi 12 kepada teman. Kemudian mendapat 5 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Siti sekarang?
A: Siti sekarang memiliki 37 - 12 + 5 - 9 = 21 bola.

Verifikasi: Perhitungan: 37 - 12 = 25, 25 + 5 = 30, 30 - 9 = 21. Benar.

Jawaban akhir: 21 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 95 pensil. Dia meminjamkan 21 kepada teman. Kemudian menang 10 pensil. Setelah itu membagi 7 kepada orang lain. Berapa pensil Yudi sekarang?
A: Yudi sekarang memiliki 95 - 21 + 10 - 7 = 77 pensil.

Verifikasi: Perhitungan: 95 - 21 = 74, 74 + 10 = 84, 84 - 7 = 77. Benar.

Jawaban akhir: 77 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
