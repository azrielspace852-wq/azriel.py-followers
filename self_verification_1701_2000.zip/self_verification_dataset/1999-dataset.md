# Dataset Verifikasi Diri 1999

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 47 penghapus. Dia memberikan 8 kepada teman. Kemudian menang 8 penghapus. Setelah itu meminjamkan 3 kepada orang lain. Berapa penghapus Nina sekarang?
A: Nina sekarang memiliki 47 - 8 + 8 - 3 = 44 penghapus.

Verifikasi: Perhitungan: 47 - 8 = 39, 39 + 8 = 47, 47 - 3 = 44. Benar.

Jawaban akhir: 44 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 19 bola. Dia meminjamkan 4 kepada teman. Kemudian menerima 4 bola. Setelah itu memberikan 6 kepada orang lain. Berapa bola Fajar sekarang?
A: Fajar sekarang memiliki 19 - 4 + 4 - 6 = 13 bola.

Verifikasi: Perhitungan: 19 - 4 = 15, 15 + 4 = 19, 19 - 6 = 13. Benar.

Jawaban akhir: 13 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Putri memiliki 50 kue. Dia membagi 15 kepada teman. Kemudian menang 1 kue. Setelah itu meminjamkan 7 kepada orang lain. Berapa kue Putri sekarang?
A: Putri sekarang memiliki 50 - 15 + 1 - 7 = 29 kue.

Verifikasi: Perhitungan: 50 - 15 = 35, 35 + 1 = 36, 36 - 7 = 29. Benar.

Jawaban akhir: 29 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
