# Dataset Verifikasi Diri 1718

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 43 pulpen. Dia memberikan 8 kepada teman. Kemudian menerima 20 pulpen. Setelah itu memberikan 2 kepada orang lain. Berapa pulpen Putri sekarang?
A: Putri sekarang memiliki 43 - 8 + 20 - 2 = 54 pulpen.

Verifikasi: Perhitungan yang benar: 43 - 8 = 35, 35 + 20 = 55, 55 - 2 = 53. Jawaban awal salah.

Jawaban akhir: 53 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Vina memiliki 39 penggaris. Dia membagi 12 kepada teman. Kemudian menerima 9 penggaris. Setelah itu memberikan 9 kepada orang lain. Berapa penggaris Vina sekarang?
A: Vina sekarang memiliki 39 - 12 + 9 - 9 = 27 penggaris.

Verifikasi: Perhitungan: 39 - 12 = 27, 27 + 9 = 36, 36 - 9 = 27. Benar.

Jawaban akhir: 27 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 13 apel. Dia memberikan 3 kepada teman. Kemudian membeli 13 apel. Setelah itu meminjamkan 6 kepada orang lain. Berapa apel Eko sekarang?
A: Eko sekarang memiliki 13 - 3 + 13 - 6 = 17 apel.

Verifikasi: Perhitungan: 13 - 3 = 10, 10 + 13 = 23, 23 - 6 = 17. Benar.

Jawaban akhir: 17 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
