# Dataset Verifikasi Diri 1798

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 71 rupiah. Dia membagi 9 kepada teman. Kemudian menang 11 rupiah. Setelah itu meminjamkan 7 kepada orang lain. Berapa rupiah Joko sekarang?
A: Joko sekarang memiliki 71 - 9 + 11 - 7 = 66 rupiah.

Verifikasi: Perhitungan: 71 - 9 = 62, 62 + 11 = 73, 73 - 7 = 66. Benar.

Jawaban akhir: 66 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Joko memiliki 87 penggaris. Dia meminjamkan 26 kepada teman. Kemudian menerima 13 penggaris. Setelah itu memberikan 8 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 87 - 26 + 13 - 8 = 67 penggaris.

Verifikasi: Perhitungan yang benar: 87 - 26 = 61, 61 + 13 = 74, 74 - 8 = 66. Jawaban awal salah.

Jawaban akhir: 66 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 71 spidol. Dia membagi 1 kepada teman. Kemudian menang 14 spidol. Setelah itu meminjamkan 6 kepada orang lain. Berapa spidol Tono sekarang?
A: Tono sekarang memiliki 71 - 1 + 14 - 6 = 81 spidol.

Verifikasi: Perhitungan yang benar: 71 - 1 = 70, 70 + 14 = 84, 84 - 6 = 78. Jawaban awal salah.

Jawaban akhir: 78 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
