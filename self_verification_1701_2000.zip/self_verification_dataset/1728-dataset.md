# Dataset Verifikasi Diri 1728

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 74 bola. Dia memberikan 17 kepada teman. Kemudian membeli 17 bola. Setelah itu membagi 6 kepada orang lain. Berapa bola Dedi sekarang?
A: Dedi sekarang memiliki 74 - 17 + 17 - 6 = 68 bola.

Verifikasi: Perhitungan: 74 - 17 = 57, 57 + 17 = 74, 74 - 6 = 68. Benar.

Jawaban akhir: 68 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Oscar memiliki 14 buku. Dia memberikan 2 kepada teman. Kemudian menerima 13 buku. Setelah itu meminjamkan 4 kepada orang lain. Berapa buku Oscar sekarang?
A: Oscar sekarang memiliki 14 - 2 + 13 - 4 = 21 buku.

Verifikasi: Perhitungan: 14 - 2 = 12, 12 + 13 = 25, 25 - 4 = 21. Benar.

Jawaban akhir: 21 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Andi memiliki 54 buku. Dia memberikan 9 kepada teman. Kemudian membeli 16 buku. Setelah itu meminjamkan 13 kepada orang lain. Berapa buku Andi sekarang?
A: Andi sekarang memiliki 54 - 9 + 16 - 13 = 46 buku.

Verifikasi: Perhitungan yang benar: 54 - 9 = 45, 45 + 16 = 61, 61 - 13 = 48. Jawaban awal salah.

Jawaban akhir: 48 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
