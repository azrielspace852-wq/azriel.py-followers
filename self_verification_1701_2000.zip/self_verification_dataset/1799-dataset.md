# Dataset Verifikasi Diri 1799

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 76 buku. Dia meminjamkan 22 kepada teman. Kemudian menerima 13 buku. Setelah itu meminjamkan 5 kepada orang lain. Berapa buku Kiki sekarang?
A: Kiki sekarang memiliki 76 - 22 + 13 - 5 = 62 buku.

Verifikasi: Perhitungan: 76 - 22 = 54, 54 + 13 = 67, 67 - 5 = 62. Benar.

Jawaban akhir: 62 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Joko memiliki 16 kue. Dia membagi 1 kepada teman. Kemudian menang 10 kue. Setelah itu memberikan 9 kepada orang lain. Berapa kue Joko sekarang?
A: Joko sekarang memiliki 16 - 1 + 10 - 9 = 16 kue.

Verifikasi: Perhitungan: 16 - 1 = 15, 15 + 10 = 25, 25 - 9 = 16. Benar.

Jawaban akhir: 16 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 70 buku. Dia memberikan 23 kepada teman. Kemudian menerima 9 buku. Setelah itu membagi 11 kepada orang lain. Berapa buku Candra sekarang?
A: Candra sekarang memiliki 70 - 23 + 9 - 11 = 45 buku.

Verifikasi: Perhitungan: 70 - 23 = 47, 47 + 9 = 56, 56 - 11 = 45. Benar.

Jawaban akhir: 45 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
