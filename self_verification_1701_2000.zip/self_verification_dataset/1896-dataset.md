# Dataset Verifikasi Diri 1896

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 43 rupiah. Dia memberikan 2 kepada teman. Kemudian mendapat 11 rupiah. Setelah itu membagi 4 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 43 - 2 + 11 - 4 = 48 rupiah.

Verifikasi: Perhitungan: 43 - 2 = 41, 41 + 11 = 52, 52 - 4 = 48. Benar.

Jawaban akhir: 48 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Budi memiliki 82 penghapus. Dia meminjamkan 6 kepada teman. Kemudian menang 18 penghapus. Setelah itu memberikan 15 kepada orang lain. Berapa penghapus Budi sekarang?
A: Budi sekarang memiliki 82 - 6 + 18 - 15 = 82 penghapus.

Verifikasi: Perhitungan yang benar: 82 - 6 = 76, 76 + 18 = 94, 94 - 15 = 79. Jawaban awal salah.

Jawaban akhir: 79 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 92 pulpen. Dia memberikan 19 kepada teman. Kemudian menang 7 pulpen. Setelah itu memberikan 6 kepada orang lain. Berapa pulpen Andi sekarang?
A: Andi sekarang memiliki 92 - 19 + 7 - 6 = 74 pulpen.

Verifikasi: Perhitungan: 92 - 19 = 73, 73 + 7 = 80, 80 - 6 = 74. Benar.

Jawaban akhir: 74 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
