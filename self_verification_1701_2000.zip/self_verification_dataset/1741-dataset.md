# Dataset Verifikasi Diri 1741

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 57 buku. Dia membagi 7 kepada teman. Kemudian menerima 5 buku. Setelah itu memberikan 6 kepada orang lain. Berapa buku Wati sekarang?
A: Wati sekarang memiliki 57 - 7 + 5 - 6 = 49 buku.

Verifikasi: Perhitungan: 57 - 7 = 50, 50 + 5 = 55, 55 - 6 = 49. Benar.

Jawaban akhir: 49 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Vina memiliki 96 buku. Dia membagi 16 kepada teman. Kemudian membeli 10 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 96 - 16 + 10 - 15 = 75 buku.

Verifikasi: Perhitungan: 96 - 16 = 80, 80 + 10 = 90, 90 - 15 = 75. Benar.

Jawaban akhir: 75 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 61 buku tulis. Dia membagi 9 kepada teman. Kemudian menerima 7 buku tulis. Setelah itu membagi 10 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 61 - 9 + 7 - 10 = 50 buku tulis.

Verifikasi: Perhitungan yang benar: 61 - 9 = 52, 52 + 7 = 59, 59 - 10 = 49. Jawaban awal salah.

Jawaban akhir: 49 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
