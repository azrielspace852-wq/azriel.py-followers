# Dataset Verifikasi Diri 1704

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 40 pensil. Dia membagi 13 kepada teman. Kemudian menerima 12 pensil. Setelah itu membagi 11 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 40 - 13 + 12 - 11 = 27 pensil.

Verifikasi: Perhitungan yang benar: 40 - 13 = 27, 27 + 12 = 39, 39 - 11 = 28. Jawaban awal salah.

Jawaban akhir: 28 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 20 kartu. Dia memberikan 5 kepada teman. Kemudian membeli 2 kartu. Setelah itu meminjamkan 12 kepada orang lain. Berapa kartu Indra sekarang?
A: Indra sekarang memiliki 20 - 5 + 2 - 12 = 5 kartu.

Verifikasi: Perhitungan: 20 - 5 = 15, 15 + 2 = 17, 17 - 12 = 5. Benar.

Jawaban akhir: 5 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 90 pensil. Dia membagi 26 kepada teman. Kemudian menang 8 pensil. Setelah itu meminjamkan 15 kepada orang lain. Berapa pensil Nina sekarang?
A: Nina sekarang memiliki 90 - 26 + 8 - 15 = 57 pensil.

Verifikasi: Perhitungan: 90 - 26 = 64, 64 + 8 = 72, 72 - 15 = 57. Benar.

Jawaban akhir: 57 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
