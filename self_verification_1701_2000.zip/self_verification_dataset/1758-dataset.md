# Dataset Verifikasi Diri 1758

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 85 kue. Dia membagi 1 kepada teman. Kemudian membeli 14 kue. Setelah itu memberikan 5 kepada orang lain. Berapa kue Rina sekarang?
A: Rina sekarang memiliki 85 - 1 + 14 - 5 = 93 kue.

Verifikasi: Perhitungan: 85 - 1 = 84, 84 + 14 = 98, 98 - 5 = 93. Benar.

Jawaban akhir: 93 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Maya memiliki 81 spidol. Dia membagi 11 kepada teman. Kemudian membeli 14 spidol. Setelah itu membagi 12 kepada orang lain. Berapa spidol Maya sekarang?
A: Maya sekarang memiliki 81 - 11 + 14 - 12 = 72 spidol.

Verifikasi: Perhitungan: 81 - 11 = 70, 70 + 14 = 84, 84 - 12 = 72. Benar.

Jawaban akhir: 72 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Putri memiliki 95 pulpen. Dia memberikan 20 kepada teman. Kemudian mendapat 15 pulpen. Setelah itu membagi 5 kepada orang lain. Berapa pulpen Putri sekarang?
A: Putri sekarang memiliki 95 - 20 + 15 - 5 = 85 pulpen.

Verifikasi: Perhitungan: 95 - 20 = 75, 75 + 15 = 90, 90 - 5 = 85. Benar.

Jawaban akhir: 85 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
