# Dataset Verifikasi Diri 1993

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 44 penggaris. Dia memberikan 12 kepada teman. Kemudian menang 5 penggaris. Setelah itu memberikan 13 kepada orang lain. Berapa penggaris Dedi sekarang?
A: Dedi sekarang memiliki 44 - 12 + 5 - 13 = 25 penggaris.

Verifikasi: Perhitungan yang benar: 44 - 12 = 32, 32 + 5 = 37, 37 - 13 = 24. Jawaban awal salah.

Jawaban akhir: 24 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 25 apel. Dia membagi 2 kepada teman. Kemudian menerima 17 apel. Setelah itu memberikan 5 kepada orang lain. Berapa apel Fajar sekarang?
A: Fajar sekarang memiliki 25 - 2 + 17 - 5 = 35 apel.

Verifikasi: Perhitungan: 25 - 2 = 23, 23 + 17 = 40, 40 - 5 = 35. Benar.

Jawaban akhir: 35 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Zaki memiliki 36 stiker. Dia meminjamkan 3 kepada teman. Kemudian mendapat 9 stiker. Setelah itu meminjamkan 4 kepada orang lain. Berapa stiker Zaki sekarang?
A: Zaki sekarang memiliki 36 - 3 + 9 - 4 = 38 stiker.

Verifikasi: Perhitungan: 36 - 3 = 33, 33 + 9 = 42, 42 - 4 = 38. Benar.

Jawaban akhir: 38 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
