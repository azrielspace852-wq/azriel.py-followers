# Dataset Verifikasi Diri 1757

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 35 apel. Dia meminjamkan 7 kepada teman. Kemudian menang 20 apel. Setelah itu memberikan 11 kepada orang lain. Berapa apel Budi sekarang?
A: Budi sekarang memiliki 35 - 7 + 20 - 11 = 38 apel.

Verifikasi: Perhitungan yang benar: 35 - 7 = 28, 28 + 20 = 48, 48 - 11 = 37. Jawaban awal salah.

Jawaban akhir: 37 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 15 pulpen. Dia memberikan 4 kepada teman. Kemudian menang 12 pulpen. Setelah itu memberikan 5 kepada orang lain. Berapa pulpen Udin sekarang?
A: Udin sekarang memiliki 15 - 4 + 12 - 5 = 18 pulpen.

Verifikasi: Perhitungan: 15 - 4 = 11, 11 + 12 = 23, 23 - 5 = 18. Benar.

Jawaban akhir: 18 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 72 kartu. Dia membagi 7 kepada teman. Kemudian mendapat 1 kartu. Setelah itu meminjamkan 4 kepada orang lain. Berapa kartu Zaki sekarang?
A: Zaki sekarang memiliki 72 - 7 + 1 - 4 = 62 kartu.

Verifikasi: Perhitungan: 72 - 7 = 65, 65 + 1 = 66, 66 - 4 = 62. Benar.

Jawaban akhir: 62 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
