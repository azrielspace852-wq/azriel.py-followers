# Dataset Verifikasi Diri 1807

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 51 apel. Dia meminjamkan 4 kepada teman. Kemudian membeli 18 apel. Setelah itu meminjamkan 10 kepada orang lain. Berapa apel Siti sekarang?
A: Siti sekarang memiliki 51 - 4 + 18 - 10 = 55 apel.

Verifikasi: Perhitungan: 51 - 4 = 47, 47 + 18 = 65, 65 - 10 = 55. Benar.

Jawaban akhir: 55 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Fajar memiliki 72 pensil. Dia memberikan 8 kepada teman. Kemudian menang 4 pensil. Setelah itu membagi 10 kepada orang lain. Berapa pensil Fajar sekarang?
A: Fajar sekarang memiliki 72 - 8 + 4 - 10 = 60 pensil.

Verifikasi: Perhitungan yang benar: 72 - 8 = 64, 64 + 4 = 68, 68 - 10 = 58. Jawaban awal salah.

Jawaban akhir: 58 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 78 apel. Dia meminjamkan 3 kepada teman. Kemudian menerima 10 apel. Setelah itu meminjamkan 8 kepada orang lain. Berapa apel Indra sekarang?
A: Indra sekarang memiliki 78 - 3 + 10 - 8 = 77 apel.

Verifikasi: Perhitungan: 78 - 3 = 75, 75 + 10 = 85, 85 - 8 = 77. Benar.

Jawaban akhir: 77 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
