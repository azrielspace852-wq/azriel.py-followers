# Dataset Verifikasi Diri 1938

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 70 pensil. Dia meminjamkan 2 kepada teman. Kemudian menang 19 pensil. Setelah itu memberikan 7 kepada orang lain. Berapa pensil Yudi sekarang?
A: Yudi sekarang memiliki 70 - 2 + 19 - 7 = 80 pensil.

Verifikasi: Perhitungan: 70 - 2 = 68, 68 + 19 = 87, 87 - 7 = 80. Benar.

Jawaban akhir: 80 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Maya memiliki 64 rupiah. Dia memberikan 18 kepada teman. Kemudian membeli 9 rupiah. Setelah itu memberikan 6 kepada orang lain. Berapa rupiah Maya sekarang?
A: Maya sekarang memiliki 64 - 18 + 9 - 6 = 49 rupiah.

Verifikasi: Perhitungan: 64 - 18 = 46, 46 + 9 = 55, 55 - 6 = 49. Benar.

Jawaban akhir: 49 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Siti memiliki 23 apel. Dia meminjamkan 1 kepada teman. Kemudian menang 2 apel. Setelah itu meminjamkan 13 kepada orang lain. Berapa apel Siti sekarang?
A: Siti sekarang memiliki 23 - 1 + 2 - 13 = 11 apel.

Verifikasi: Perhitungan: 23 - 1 = 22, 22 + 2 = 24, 24 - 13 = 11. Benar.

Jawaban akhir: 11 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
