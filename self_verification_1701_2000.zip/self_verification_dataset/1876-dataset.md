# Dataset Verifikasi Diri 1876

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 49 stiker. Dia memberikan 6 kepada teman. Kemudian membeli 12 stiker. Setelah itu memberikan 8 kepada orang lain. Berapa stiker Eko sekarang?
A: Eko sekarang memiliki 49 - 6 + 12 - 8 = 47 stiker.

Verifikasi: Perhitungan: 49 - 6 = 43, 43 + 12 = 55, 55 - 8 = 47. Benar.

Jawaban akhir: 47 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 15 rupiah. Dia memberikan 4 kepada teman. Kemudian membeli 8 rupiah. Setelah itu memberikan 2 kepada orang lain. Berapa rupiah Dedi sekarang?
A: Dedi sekarang memiliki 15 - 4 + 8 - 2 = 17 rupiah.

Verifikasi: Perhitungan: 15 - 4 = 11, 11 + 8 = 19, 19 - 2 = 17. Benar.

Jawaban akhir: 17 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 82 bola. Dia memberikan 3 kepada teman. Kemudian membeli 10 bola. Setelah itu memberikan 5 kepada orang lain. Berapa bola Fajar sekarang?
A: Fajar sekarang memiliki 82 - 3 + 10 - 5 = 83 bola.

Verifikasi: Perhitungan yang benar: 82 - 3 = 79, 79 + 10 = 89, 89 - 5 = 84. Jawaban awal salah.

Jawaban akhir: 84 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
