# Dataset Verifikasi Diri 1828

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 24 penghapus. Dia membagi 5 kepada teman. Kemudian membeli 7 penghapus. Setelah itu memberikan 9 kepada orang lain. Berapa penghapus Putri sekarang?
A: Putri sekarang memiliki 24 - 5 + 7 - 9 = 16 penghapus.

Verifikasi: Perhitungan yang benar: 24 - 5 = 19, 19 + 7 = 26, 26 - 9 = 17. Jawaban awal salah.

Jawaban akhir: 17 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Tono memiliki 50 penghapus. Dia meminjamkan 8 kepada teman. Kemudian membeli 1 penghapus. Setelah itu membagi 8 kepada orang lain. Berapa penghapus Tono sekarang?
A: Tono sekarang memiliki 50 - 8 + 1 - 8 = 34 penghapus.

Verifikasi: Perhitungan yang benar: 50 - 8 = 42, 42 + 1 = 43, 43 - 8 = 35. Jawaban awal salah.

Jawaban akhir: 35 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 92 kertas. Dia meminjamkan 24 kepada teman. Kemudian mendapat 18 kertas. Setelah itu meminjamkan 4 kepada orang lain. Berapa kertas Vina sekarang?
A: Vina sekarang memiliki 92 - 24 + 18 - 4 = 82 kertas.

Verifikasi: Perhitungan: 92 - 24 = 68, 68 + 18 = 86, 86 - 4 = 82. Benar.

Jawaban akhir: 82 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
