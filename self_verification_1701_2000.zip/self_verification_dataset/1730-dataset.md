# Dataset Verifikasi Diri 1730

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 48 buku tulis. Dia meminjamkan 6 kepada teman. Kemudian menerima 8 buku tulis. Setelah itu meminjamkan 5 kepada orang lain. Berapa buku tulis Indra sekarang?
A: Indra sekarang memiliki 48 - 6 + 8 - 5 = 44 buku tulis.

Verifikasi: Perhitungan yang benar: 48 - 6 = 42, 42 + 8 = 50, 50 - 5 = 45. Jawaban awal salah.

Jawaban akhir: 45 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Maya memiliki 30 buku tulis. Dia membagi 1 kepada teman. Kemudian mendapat 4 buku tulis. Setelah itu memberikan 7 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 30 - 1 + 4 - 7 = 25 buku tulis.

Verifikasi: Perhitungan yang benar: 30 - 1 = 29, 29 + 4 = 33, 33 - 7 = 26. Jawaban awal salah.

Jawaban akhir: 26 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Putri memiliki 75 buku. Dia membagi 16 kepada teman. Kemudian menerima 9 buku. Setelah itu meminjamkan 10 kepada orang lain. Berapa buku Putri sekarang?
A: Putri sekarang memiliki 75 - 16 + 9 - 10 = 57 buku.

Verifikasi: Perhitungan yang benar: 75 - 16 = 59, 59 + 9 = 68, 68 - 10 = 58. Jawaban awal salah.

Jawaban akhir: 58 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
