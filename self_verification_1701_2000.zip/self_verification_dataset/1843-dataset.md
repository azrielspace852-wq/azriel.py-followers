# Dataset Verifikasi Diri 1843

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 30 apel. Dia memberikan 2 kepada teman. Kemudian mendapat 9 apel. Setelah itu membagi 2 kepada orang lain. Berapa apel Vina sekarang?
A: Vina sekarang memiliki 30 - 2 + 9 - 2 = 38 apel.

Verifikasi: Perhitungan yang benar: 30 - 2 = 28, 28 + 9 = 37, 37 - 2 = 35. Jawaban awal salah.

Jawaban akhir: 35 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Gita memiliki 89 kertas. Dia membagi 21 kepada teman. Kemudian membeli 14 kertas. Setelah itu membagi 6 kepada orang lain. Berapa kertas Gita sekarang?
A: Gita sekarang memiliki 89 - 21 + 14 - 6 = 76 kertas.

Verifikasi: Perhitungan: 89 - 21 = 68, 68 + 14 = 82, 82 - 6 = 76. Benar.

Jawaban akhir: 76 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Lina memiliki 21 apel. Dia meminjamkan 5 kepada teman. Kemudian menang 17 apel. Setelah itu meminjamkan 6 kepada orang lain. Berapa apel Lina sekarang?
A: Lina sekarang memiliki 21 - 5 + 17 - 6 = 30 apel.

Verifikasi: Perhitungan yang benar: 21 - 5 = 16, 16 + 17 = 33, 33 - 6 = 27. Jawaban awal salah.

Jawaban akhir: 27 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
