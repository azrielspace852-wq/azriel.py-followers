# Dataset Verifikasi Diri 1941

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 30 apel. Dia membagi 4 kepada teman. Kemudian membeli 7 apel. Setelah itu membagi 5 kepada orang lain. Berapa apel Tono sekarang?
A: Tono sekarang memiliki 30 - 4 + 7 - 5 = 30 apel.

Verifikasi: Perhitungan yang benar: 30 - 4 = 26, 26 + 7 = 33, 33 - 5 = 28. Jawaban awal salah.

Jawaban akhir: 28 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Andi memiliki 29 buku tulis. Dia memberikan 9 kepada teman. Kemudian menerima 12 buku tulis. Setelah itu meminjamkan 9 kepada orang lain. Berapa buku tulis Andi sekarang?
A: Andi sekarang memiliki 29 - 9 + 12 - 9 = 23 buku tulis.

Verifikasi: Perhitungan: 29 - 9 = 20, 20 + 12 = 32, 32 - 9 = 23. Benar.

Jawaban akhir: 23 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Wati memiliki 19 kelereng. Dia memberikan 3 kepada teman. Kemudian menang 17 kelereng. Setelah itu membagi 5 kepada orang lain. Berapa kelereng Wati sekarang?
A: Wati sekarang memiliki 19 - 3 + 17 - 5 = 26 kelereng.

Verifikasi: Perhitungan yang benar: 19 - 3 = 16, 16 + 17 = 33, 33 - 5 = 28. Jawaban awal salah.

Jawaban akhir: 28 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
