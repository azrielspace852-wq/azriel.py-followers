# Dataset Verifikasi Diri 1783

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 24 buku tulis. Dia memberikan 6 kepada teman. Kemudian menerima 8 buku tulis. Setelah itu memberikan 13 kepada orang lain. Berapa buku tulis Kiki sekarang?
A: Kiki sekarang memiliki 24 - 6 + 8 - 13 = 15 buku tulis.

Verifikasi: Perhitungan yang benar: 24 - 6 = 18, 18 + 8 = 26, 26 - 13 = 13. Jawaban awal salah.

Jawaban akhir: 13 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 35 spidol. Dia meminjamkan 8 kepada teman. Kemudian membeli 10 spidol. Setelah itu memberikan 10 kepada orang lain. Berapa spidol Gita sekarang?
A: Gita sekarang memiliki 35 - 8 + 10 - 10 = 27 spidol.

Verifikasi: Perhitungan: 35 - 8 = 27, 27 + 10 = 37, 37 - 10 = 27. Benar.

Jawaban akhir: 27 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Zaki memiliki 48 rupiah. Dia membagi 1 kepada teman. Kemudian mendapat 12 rupiah. Setelah itu membagi 5 kepada orang lain. Berapa rupiah Zaki sekarang?
A: Zaki sekarang memiliki 48 - 1 + 12 - 5 = 54 rupiah.

Verifikasi: Perhitungan: 48 - 1 = 47, 47 + 12 = 59, 59 - 5 = 54. Benar.

Jawaban akhir: 54 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
