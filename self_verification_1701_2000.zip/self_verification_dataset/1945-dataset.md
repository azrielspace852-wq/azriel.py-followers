# Dataset Verifikasi Diri 1945

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 11 kartu. Dia memberikan 2 kepada teman. Kemudian menerima 16 kartu. Setelah itu membagi 12 kepada orang lain. Berapa kartu Vina sekarang?
A: Vina sekarang memiliki 11 - 2 + 16 - 12 = 13 kartu.

Verifikasi: Perhitungan: 11 - 2 = 9, 9 + 16 = 25, 25 - 12 = 13. Benar.

Jawaban akhir: 13 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 87 kelereng. Dia memberikan 26 kepada teman. Kemudian menang 2 kelereng. Setelah itu meminjamkan 1 kepada orang lain. Berapa kelereng Vina sekarang?
A: Vina sekarang memiliki 87 - 26 + 2 - 1 = 60 kelereng.

Verifikasi: Perhitungan yang benar: 87 - 26 = 61, 61 + 2 = 63, 63 - 1 = 62. Jawaban awal salah.

Jawaban akhir: 62 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 33 kartu. Dia meminjamkan 2 kepada teman. Kemudian mendapat 15 kartu. Setelah itu membagi 5 kepada orang lain. Berapa kartu Fajar sekarang?
A: Fajar sekarang memiliki 33 - 2 + 15 - 5 = 39 kartu.

Verifikasi: Perhitungan yang benar: 33 - 2 = 31, 31 + 15 = 46, 46 - 5 = 41. Jawaban awal salah.

Jawaban akhir: 41 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
