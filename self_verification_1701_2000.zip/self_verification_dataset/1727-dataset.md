# Dataset Verifikasi Diri 1727

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 37 stiker. Dia meminjamkan 7 kepada teman. Kemudian membeli 13 stiker. Setelah itu membagi 7 kepada orang lain. Berapa stiker Vina sekarang?
A: Vina sekarang memiliki 37 - 7 + 13 - 7 = 38 stiker.

Verifikasi: Perhitungan yang benar: 37 - 7 = 30, 30 + 13 = 43, 43 - 7 = 36. Jawaban awal salah.

Jawaban akhir: 36 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Fajar memiliki 92 kartu. Dia membagi 20 kepada teman. Kemudian menerima 7 kartu. Setelah itu meminjamkan 13 kepada orang lain. Berapa kartu Fajar sekarang?
A: Fajar sekarang memiliki 92 - 20 + 7 - 13 = 66 kartu.

Verifikasi: Perhitungan: 92 - 20 = 72, 72 + 7 = 79, 79 - 13 = 66. Benar.

Jawaban akhir: 66 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Wati memiliki 39 rupiah. Dia memberikan 3 kepada teman. Kemudian membeli 3 rupiah. Setelah itu membagi 13 kepada orang lain. Berapa rupiah Wati sekarang?
A: Wati sekarang memiliki 39 - 3 + 3 - 13 = 26 rupiah.

Verifikasi: Perhitungan: 39 - 3 = 36, 36 + 3 = 39, 39 - 13 = 26. Benar.

Jawaban akhir: 26 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
