# Dataset Verifikasi Diri 1948

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 61 buku. Dia membagi 19 kepada teman. Kemudian menang 6 buku. Setelah itu meminjamkan 8 kepada orang lain. Berapa buku Rina sekarang?
A: Rina sekarang memiliki 61 - 19 + 6 - 8 = 40 buku.

Verifikasi: Perhitungan: 61 - 19 = 42, 42 + 6 = 48, 48 - 8 = 40. Benar.

Jawaban akhir: 40 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Gita memiliki 74 kartu. Dia membagi 24 kepada teman. Kemudian membeli 9 kartu. Setelah itu memberikan 14 kepada orang lain. Berapa kartu Gita sekarang?
A: Gita sekarang memiliki 74 - 24 + 9 - 14 = 45 kartu.

Verifikasi: Perhitungan: 74 - 24 = 50, 50 + 9 = 59, 59 - 14 = 45. Benar.

Jawaban akhir: 45 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 15 kue. Dia membagi 5 kepada teman. Kemudian membeli 11 kue. Setelah itu meminjamkan 10 kepada orang lain. Berapa kue Hani sekarang?
A: Hani sekarang memiliki 15 - 5 + 11 - 10 = 11 kue.

Verifikasi: Perhitungan: 15 - 5 = 10, 10 + 11 = 21, 21 - 10 = 11. Benar.

Jawaban akhir: 11 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
