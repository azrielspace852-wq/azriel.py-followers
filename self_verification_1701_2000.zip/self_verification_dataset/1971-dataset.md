# Dataset Verifikasi Diri 1971

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 42 kelereng. Dia memberikan 4 kepada teman. Kemudian menang 3 kelereng. Setelah itu memberikan 6 kepada orang lain. Berapa kelereng Siti sekarang?
A: Siti sekarang memiliki 42 - 4 + 3 - 6 = 38 kelereng.

Verifikasi: Perhitungan yang benar: 42 - 4 = 38, 38 + 3 = 41, 41 - 6 = 35. Jawaban awal salah.

Jawaban akhir: 35 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Tono memiliki 95 penghapus. Dia membagi 1 kepada teman. Kemudian mendapat 19 penghapus. Setelah itu meminjamkan 10 kepada orang lain. Berapa penghapus Tono sekarang?
A: Tono sekarang memiliki 95 - 1 + 19 - 10 = 103 penghapus.

Verifikasi: Perhitungan: 95 - 1 = 94, 94 + 19 = 113, 113 - 10 = 103. Benar.

Jawaban akhir: 103 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Siti memiliki 23 penghapus. Dia memberikan 2 kepada teman. Kemudian menerima 9 penghapus. Setelah itu memberikan 2 kepada orang lain. Berapa penghapus Siti sekarang?
A: Siti sekarang memiliki 23 - 2 + 9 - 2 = 28 penghapus.

Verifikasi: Perhitungan: 23 - 2 = 21, 21 + 9 = 30, 30 - 2 = 28. Benar.

Jawaban akhir: 28 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
