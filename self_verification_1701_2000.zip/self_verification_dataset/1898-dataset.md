# Dataset Verifikasi Diri 1898

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 47 kelereng. Dia meminjamkan 4 kepada teman. Kemudian membeli 7 kelereng. Setelah itu meminjamkan 13 kepada orang lain. Berapa kelereng Zaki sekarang?
A: Zaki sekarang memiliki 47 - 4 + 7 - 13 = 37 kelereng.

Verifikasi: Perhitungan: 47 - 4 = 43, 43 + 7 = 50, 50 - 13 = 37. Benar.

Jawaban akhir: 37 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Andi memiliki 92 kelereng. Dia membagi 22 kepada teman. Kemudian mendapat 6 kelereng. Setelah itu membagi 10 kepada orang lain. Berapa kelereng Andi sekarang?
A: Andi sekarang memiliki 92 - 22 + 6 - 10 = 68 kelereng.

Verifikasi: Perhitungan yang benar: 92 - 22 = 70, 70 + 6 = 76, 76 - 10 = 66. Jawaban awal salah.

Jawaban akhir: 66 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 44 stiker. Dia membagi 9 kepada teman. Kemudian membeli 8 stiker. Setelah itu membagi 12 kepada orang lain. Berapa stiker Rina sekarang?
A: Rina sekarang memiliki 44 - 9 + 8 - 12 = 31 stiker.

Verifikasi: Perhitungan: 44 - 9 = 35, 35 + 8 = 43, 43 - 12 = 31. Benar.

Jawaban akhir: 31 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
