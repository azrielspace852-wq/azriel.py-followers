# Dataset Verifikasi Diri 1981

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 91 spidol. Dia meminjamkan 5 kepada teman. Kemudian membeli 7 spidol. Setelah itu membagi 7 kepada orang lain. Berapa spidol Budi sekarang?
A: Budi sekarang memiliki 91 - 5 + 7 - 7 = 86 spidol.

Verifikasi: Perhitungan: 91 - 5 = 86, 86 + 7 = 93, 93 - 7 = 86. Benar.

Jawaban akhir: 86 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Yudi memiliki 39 kue. Dia memberikan 1 kepada teman. Kemudian membeli 15 kue. Setelah itu memberikan 11 kepada orang lain. Berapa kue Yudi sekarang?
A: Yudi sekarang memiliki 39 - 1 + 15 - 11 = 44 kue.

Verifikasi: Perhitungan yang benar: 39 - 1 = 38, 38 + 15 = 53, 53 - 11 = 42. Jawaban awal salah.

Jawaban akhir: 42 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 66 kartu. Dia membagi 15 kepada teman. Kemudian menerima 14 kartu. Setelah itu memberikan 1 kepada orang lain. Berapa kartu Putri sekarang?
A: Putri sekarang memiliki 66 - 15 + 14 - 1 = 64 kartu.

Verifikasi: Perhitungan: 66 - 15 = 51, 51 + 14 = 65, 65 - 1 = 64. Benar.

Jawaban akhir: 64 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
