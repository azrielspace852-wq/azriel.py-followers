# Dataset Verifikasi Diri 1732

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 55 penghapus. Dia meminjamkan 6 kepada teman. Kemudian menerima 18 penghapus. Setelah itu memberikan 2 kepada orang lain. Berapa penghapus Joko sekarang?
A: Joko sekarang memiliki 55 - 6 + 18 - 2 = 65 penghapus.

Verifikasi: Perhitungan: 55 - 6 = 49, 49 + 18 = 67, 67 - 2 = 65. Benar.

Jawaban akhir: 65 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Candra memiliki 58 rupiah. Dia memberikan 11 kepada teman. Kemudian menang 13 rupiah. Setelah itu meminjamkan 1 kepada orang lain. Berapa rupiah Candra sekarang?
A: Candra sekarang memiliki 58 - 11 + 13 - 1 = 61 rupiah.

Verifikasi: Perhitungan yang benar: 58 - 11 = 47, 47 + 13 = 60, 60 - 1 = 59. Jawaban awal salah.

Jawaban akhir: 59 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Wati memiliki 15 stiker. Dia memberikan 1 kepada teman. Kemudian membeli 5 stiker. Setelah itu membagi 5 kepada orang lain. Berapa stiker Wati sekarang?
A: Wati sekarang memiliki 15 - 1 + 5 - 5 = 12 stiker.

Verifikasi: Perhitungan yang benar: 15 - 1 = 14, 14 + 5 = 19, 19 - 5 = 14. Jawaban awal salah.

Jawaban akhir: 14 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
