# Dataset Verifikasi Diri 1767

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 19 apel. Dia memberikan 4 kepada teman. Kemudian mendapat 8 apel. Setelah itu membagi 11 kepada orang lain. Berapa apel Maya sekarang?
A: Maya sekarang memiliki 19 - 4 + 8 - 11 = 15 apel.

Verifikasi: Perhitungan yang benar: 19 - 4 = 15, 15 + 8 = 23, 23 - 11 = 12. Jawaban awal salah.

Jawaban akhir: 12 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 35 penghapus. Dia meminjamkan 9 kepada teman. Kemudian mendapat 3 penghapus. Setelah itu memberikan 9 kepada orang lain. Berapa penghapus Indra sekarang?
A: Indra sekarang memiliki 35 - 9 + 3 - 9 = 20 penghapus.

Verifikasi: Perhitungan: 35 - 9 = 26, 26 + 3 = 29, 29 - 9 = 20. Benar.

Jawaban akhir: 20 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 79 spidol. Dia membagi 9 kepada teman. Kemudian menang 6 spidol. Setelah itu meminjamkan 7 kepada orang lain. Berapa spidol Fajar sekarang?
A: Fajar sekarang memiliki 79 - 9 + 6 - 7 = 69 spidol.

Verifikasi: Perhitungan: 79 - 9 = 70, 70 + 6 = 76, 76 - 7 = 69. Benar.

Jawaban akhir: 69 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
