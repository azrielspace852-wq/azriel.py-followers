# Dataset Verifikasi Diri 1844

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 83 kelereng. Dia meminjamkan 10 kepada teman. Kemudian mendapat 7 kelereng. Setelah itu meminjamkan 6 kepada orang lain. Berapa kelereng Udin sekarang?
A: Udin sekarang memiliki 83 - 10 + 7 - 6 = 76 kelereng.

Verifikasi: Perhitungan yang benar: 83 - 10 = 73, 73 + 7 = 80, 80 - 6 = 74. Jawaban awal salah.

Jawaban akhir: 74 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 82 pulpen. Dia memberikan 6 kepada teman. Kemudian menang 10 pulpen. Setelah itu meminjamkan 10 kepada orang lain. Berapa pulpen Udin sekarang?
A: Udin sekarang memiliki 82 - 6 + 10 - 10 = 76 pulpen.

Verifikasi: Perhitungan: 82 - 6 = 76, 76 + 10 = 86, 86 - 10 = 76. Benar.

Jawaban akhir: 76 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Kiki memiliki 88 kartu. Dia memberikan 12 kepada teman. Kemudian mendapat 3 kartu. Setelah itu membagi 1 kepada orang lain. Berapa kartu Kiki sekarang?
A: Kiki sekarang memiliki 88 - 12 + 3 - 1 = 76 kartu.

Verifikasi: Perhitungan yang benar: 88 - 12 = 76, 76 + 3 = 79, 79 - 1 = 78. Jawaban awal salah.

Jawaban akhir: 78 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
