# Dataset Verifikasi Diri 1857

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 50 pulpen. Dia membagi 14 kepada teman. Kemudian menerima 18 pulpen. Setelah itu memberikan 6 kepada orang lain. Berapa pulpen Candra sekarang?
A: Candra sekarang memiliki 50 - 14 + 18 - 6 = 48 pulpen.

Verifikasi: Perhitungan: 50 - 14 = 36, 36 + 18 = 54, 54 - 6 = 48. Benar.

Jawaban akhir: 48 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Budi memiliki 23 penggaris. Dia memberikan 1 kepada teman. Kemudian menerima 11 penggaris. Setelah itu membagi 9 kepada orang lain. Berapa penggaris Budi sekarang?
A: Budi sekarang memiliki 23 - 1 + 11 - 9 = 25 penggaris.

Verifikasi: Perhitungan yang benar: 23 - 1 = 22, 22 + 11 = 33, 33 - 9 = 24. Jawaban awal salah.

Jawaban akhir: 24 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Oscar memiliki 29 spidol. Dia memberikan 2 kepada teman. Kemudian menerima 13 spidol. Setelah itu memberikan 14 kepada orang lain. Berapa spidol Oscar sekarang?
A: Oscar sekarang memiliki 29 - 2 + 13 - 14 = 26 spidol.

Verifikasi: Perhitungan: 29 - 2 = 27, 27 + 13 = 40, 40 - 14 = 26. Benar.

Jawaban akhir: 26 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
