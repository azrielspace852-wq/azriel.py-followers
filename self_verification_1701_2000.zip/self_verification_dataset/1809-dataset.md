# Dataset Verifikasi Diri 1809

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 38 kertas. Dia meminjamkan 7 kepada teman. Kemudian menerima 13 kertas. Setelah itu meminjamkan 12 kepada orang lain. Berapa kertas Budi sekarang?
A: Budi sekarang memiliki 38 - 7 + 13 - 12 = 34 kertas.

Verifikasi: Perhitungan yang benar: 38 - 7 = 31, 31 + 13 = 44, 44 - 12 = 32. Jawaban awal salah.

Jawaban akhir: 32 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Wati memiliki 84 pensil. Dia membagi 28 kepada teman. Kemudian mendapat 14 pensil. Setelah itu meminjamkan 15 kepada orang lain. Berapa pensil Wati sekarang?
A: Wati sekarang memiliki 84 - 28 + 14 - 15 = 55 pensil.

Verifikasi: Perhitungan: 84 - 28 = 56, 56 + 14 = 70, 70 - 15 = 55. Benar.

Jawaban akhir: 55 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Joko memiliki 33 bola. Dia membagi 7 kepada teman. Kemudian menerima 10 bola. Setelah itu memberikan 3 kepada orang lain. Berapa bola Joko sekarang?
A: Joko sekarang memiliki 33 - 7 + 10 - 3 = 36 bola.

Verifikasi: Perhitungan yang benar: 33 - 7 = 26, 26 + 10 = 36, 36 - 3 = 33. Jawaban awal salah.

Jawaban akhir: 33 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
