# Dataset Verifikasi Diri 1814

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 92 buku. Dia membagi 11 kepada teman. Kemudian mendapat 10 buku. Setelah itu membagi 2 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 92 - 11 + 10 - 2 = 89 buku.

Verifikasi: Perhitungan: 92 - 11 = 81, 81 + 10 = 91, 91 - 2 = 89. Benar.

Jawaban akhir: 89 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 22 buku. Dia membagi 5 kepada teman. Kemudian mendapat 20 buku. Setelah itu memberikan 3 kepada orang lain. Berapa buku Eko sekarang?
A: Eko sekarang memiliki 22 - 5 + 20 - 3 = 33 buku.

Verifikasi: Perhitungan yang benar: 22 - 5 = 17, 17 + 20 = 37, 37 - 3 = 34. Jawaban awal salah.

Jawaban akhir: 34 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 20 stiker. Dia memberikan 1 kepada teman. Kemudian menerima 16 stiker. Setelah itu membagi 14 kepada orang lain. Berapa stiker Hani sekarang?
A: Hani sekarang memiliki 20 - 1 + 16 - 14 = 22 stiker.

Verifikasi: Perhitungan yang benar: 20 - 1 = 19, 19 + 16 = 35, 35 - 14 = 21. Jawaban awal salah.

Jawaban akhir: 21 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
