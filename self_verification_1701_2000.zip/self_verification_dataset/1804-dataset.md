# Dataset Verifikasi Diri 1804

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 68 kartu. Dia membagi 19 kepada teman. Kemudian menang 11 kartu. Setelah itu meminjamkan 3 kepada orang lain. Berapa kartu Tono sekarang?
A: Tono sekarang memiliki 68 - 19 + 11 - 3 = 57 kartu.

Verifikasi: Perhitungan: 68 - 19 = 49, 49 + 11 = 60, 60 - 3 = 57. Benar.

Jawaban akhir: 57 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Budi memiliki 89 kelereng. Dia meminjamkan 1 kepada teman. Kemudian membeli 5 kelereng. Setelah itu meminjamkan 10 kepada orang lain. Berapa kelereng Budi sekarang?
A: Budi sekarang memiliki 89 - 1 + 5 - 10 = 84 kelereng.

Verifikasi: Perhitungan yang benar: 89 - 1 = 88, 88 + 5 = 93, 93 - 10 = 83. Jawaban awal salah.

Jawaban akhir: 83 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 88 kelereng. Dia memberikan 5 kepada teman. Kemudian menerima 19 kelereng. Setelah itu meminjamkan 2 kepada orang lain. Berapa kelereng Zaki sekarang?
A: Zaki sekarang memiliki 88 - 5 + 19 - 2 = 102 kelereng.

Verifikasi: Perhitungan yang benar: 88 - 5 = 83, 83 + 19 = 102, 102 - 2 = 100. Jawaban awal salah.

Jawaban akhir: 100 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
