# Dataset Verifikasi Diri 1717

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 96 kelereng. Dia meminjamkan 8 kepada teman. Kemudian mendapat 14 kelereng. Setelah itu membagi 8 kepada orang lain. Berapa kelereng Hani sekarang?
A: Hani sekarang memiliki 96 - 8 + 14 - 8 = 94 kelereng.

Verifikasi: Perhitungan: 96 - 8 = 88, 88 + 14 = 102, 102 - 8 = 94. Benar.

Jawaban akhir: 94 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Eko memiliki 12 kartu. Dia meminjamkan 3 kepada teman. Kemudian membeli 5 kartu. Setelah itu meminjamkan 8 kepada orang lain. Berapa kartu Eko sekarang?
A: Eko sekarang memiliki 12 - 3 + 5 - 8 = 6 kartu.

Verifikasi: Perhitungan: 12 - 3 = 9, 9 + 5 = 14, 14 - 8 = 6. Benar.

Jawaban akhir: 6 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Kiki memiliki 51 kelereng. Dia membagi 9 kepada teman. Kemudian menang 2 kelereng. Setelah itu meminjamkan 15 kepada orang lain. Berapa kelereng Kiki sekarang?
A: Kiki sekarang memiliki 51 - 9 + 2 - 15 = 29 kelereng.

Verifikasi: Perhitungan: 51 - 9 = 42, 42 + 2 = 44, 44 - 15 = 29. Benar.

Jawaban akhir: 29 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
