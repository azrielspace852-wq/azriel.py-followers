# Dataset Verifikasi Diri 1723

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 60 penghapus. Dia memberikan 13 kepada teman. Kemudian mendapat 11 penghapus. Setelah itu meminjamkan 10 kepada orang lain. Berapa penghapus Lina sekarang?
A: Lina sekarang memiliki 60 - 13 + 11 - 10 = 46 penghapus.

Verifikasi: Perhitungan yang benar: 60 - 13 = 47, 47 + 11 = 58, 58 - 10 = 48. Jawaban awal salah.

Jawaban akhir: 48 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 28 penggaris. Dia memberikan 8 kepada teman. Kemudian mendapat 10 penggaris. Setelah itu membagi 8 kepada orang lain. Berapa penggaris Vina sekarang?
A: Vina sekarang memiliki 28 - 8 + 10 - 8 = 22 penggaris.

Verifikasi: Perhitungan: 28 - 8 = 20, 20 + 10 = 30, 30 - 8 = 22. Benar.

Jawaban akhir: 22 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 16 penghapus. Dia memberikan 5 kepada teman. Kemudian menerima 13 penghapus. Setelah itu meminjamkan 1 kepada orang lain. Berapa penghapus Eko sekarang?
A: Eko sekarang memiliki 16 - 5 + 13 - 1 = 21 penghapus.

Verifikasi: Perhitungan yang benar: 16 - 5 = 11, 11 + 13 = 24, 24 - 1 = 23. Jawaban awal salah.

Jawaban akhir: 23 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
