# Dataset Verifikasi Diri 1775

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 52 spidol. Dia memberikan 17 kepada teman. Kemudian menerima 6 spidol. Setelah itu membagi 5 kepada orang lain. Berapa spidol Lina sekarang?
A: Lina sekarang memiliki 52 - 17 + 6 - 5 = 36 spidol.

Verifikasi: Perhitungan: 52 - 17 = 35, 35 + 6 = 41, 41 - 5 = 36. Benar.

Jawaban akhir: 36 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Gita memiliki 25 kue. Dia membagi 1 kepada teman. Kemudian menerima 20 kue. Setelah itu membagi 7 kepada orang lain. Berapa kue Gita sekarang?
A: Gita sekarang memiliki 25 - 1 + 20 - 7 = 37 kue.

Verifikasi: Perhitungan: 25 - 1 = 24, 24 + 20 = 44, 44 - 7 = 37. Benar.

Jawaban akhir: 37 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Andi memiliki 61 spidol. Dia memberikan 7 kepada teman. Kemudian mendapat 9 spidol. Setelah itu memberikan 13 kepada orang lain. Berapa spidol Andi sekarang?
A: Andi sekarang memiliki 61 - 7 + 9 - 13 = 50 spidol.

Verifikasi: Perhitungan: 61 - 7 = 54, 54 + 9 = 63, 63 - 13 = 50. Benar.

Jawaban akhir: 50 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
