# Dataset Verifikasi Diri 1827

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 85 buku tulis. Dia memberikan 2 kepada teman. Kemudian membeli 15 buku tulis. Setelah itu membagi 7 kepada orang lain. Berapa buku tulis Yudi sekarang?
A: Yudi sekarang memiliki 85 - 2 + 15 - 7 = 91 buku tulis.

Verifikasi: Perhitungan: 85 - 2 = 83, 83 + 15 = 98, 98 - 7 = 91. Benar.

Jawaban akhir: 91 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Fajar memiliki 67 penggaris. Dia memberikan 15 kepada teman. Kemudian menerima 13 penggaris. Setelah itu memberikan 8 kepada orang lain. Berapa penggaris Fajar sekarang?
A: Fajar sekarang memiliki 67 - 15 + 13 - 8 = 57 penggaris.

Verifikasi: Perhitungan: 67 - 15 = 52, 52 + 13 = 65, 65 - 8 = 57. Benar.

Jawaban akhir: 57 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Yudi memiliki 40 bola. Dia meminjamkan 6 kepada teman. Kemudian mendapat 11 bola. Setelah itu memberikan 4 kepada orang lain. Berapa bola Yudi sekarang?
A: Yudi sekarang memiliki 40 - 6 + 11 - 4 = 41 bola.

Verifikasi: Perhitungan: 40 - 6 = 34, 34 + 11 = 45, 45 - 4 = 41. Benar.

Jawaban akhir: 41 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
