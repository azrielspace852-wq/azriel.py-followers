# Dataset Verifikasi Diri 1853

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 79 penghapus. Dia memberikan 24 kepada teman. Kemudian menang 8 penghapus. Setelah itu meminjamkan 12 kepada orang lain. Berapa penghapus Yudi sekarang?
A: Yudi sekarang memiliki 79 - 24 + 8 - 12 = 51 penghapus.

Verifikasi: Perhitungan: 79 - 24 = 55, 55 + 8 = 63, 63 - 12 = 51. Benar.

Jawaban akhir: 51 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Eko memiliki 90 spidol. Dia memberikan 8 kepada teman. Kemudian menang 16 spidol. Setelah itu membagi 9 kepada orang lain. Berapa spidol Eko sekarang?
A: Eko sekarang memiliki 90 - 8 + 16 - 9 = 91 spidol.

Verifikasi: Perhitungan yang benar: 90 - 8 = 82, 82 + 16 = 98, 98 - 9 = 89. Jawaban awal salah.

Jawaban akhir: 89 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Fajar memiliki 27 kelereng. Dia membagi 7 kepada teman. Kemudian mendapat 16 kelereng. Setelah itu membagi 9 kepada orang lain. Berapa kelereng Fajar sekarang?
A: Fajar sekarang memiliki 27 - 7 + 16 - 9 = 28 kelereng.

Verifikasi: Perhitungan yang benar: 27 - 7 = 20, 20 + 16 = 36, 36 - 9 = 27. Jawaban awal salah.

Jawaban akhir: 27 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
