# Dataset Verifikasi Diri 1933

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 59 buku. Dia membagi 8 kepada teman. Kemudian mendapat 9 buku. Setelah itu meminjamkan 5 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 59 - 8 + 9 - 5 = 53 buku.

Verifikasi: Perhitungan yang benar: 59 - 8 = 51, 51 + 9 = 60, 60 - 5 = 55. Jawaban awal salah.

Jawaban akhir: 55 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Joko memiliki 98 buku. Dia meminjamkan 20 kepada teman. Kemudian membeli 5 buku. Setelah itu memberikan 9 kepada orang lain. Berapa buku Joko sekarang?
A: Joko sekarang memiliki 98 - 20 + 5 - 9 = 74 buku.

Verifikasi: Perhitungan: 98 - 20 = 78, 78 + 5 = 83, 83 - 9 = 74. Benar.

Jawaban akhir: 74 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Budi memiliki 99 penggaris. Dia meminjamkan 5 kepada teman. Kemudian menang 19 penggaris. Setelah itu membagi 10 kepada orang lain. Berapa penggaris Budi sekarang?
A: Budi sekarang memiliki 99 - 5 + 19 - 10 = 104 penggaris.

Verifikasi: Perhitungan yang benar: 99 - 5 = 94, 94 + 19 = 113, 113 - 10 = 103. Jawaban awal salah.

Jawaban akhir: 103 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
