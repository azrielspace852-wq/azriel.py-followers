# Dataset Verifikasi Diri 1720

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 73 kue. Dia meminjamkan 4 kepada teman. Kemudian membeli 14 kue. Setelah itu memberikan 6 kepada orang lain. Berapa kue Candra sekarang?
A: Candra sekarang memiliki 73 - 4 + 14 - 6 = 77 kue.

Verifikasi: Perhitungan: 73 - 4 = 69, 69 + 14 = 83, 83 - 6 = 77. Benar.

Jawaban akhir: 77 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Fajar memiliki 26 bola. Dia memberikan 7 kepada teman. Kemudian mendapat 13 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Fajar sekarang?
A: Fajar sekarang memiliki 26 - 7 + 13 - 9 = 24 bola.

Verifikasi: Perhitungan yang benar: 26 - 7 = 19, 19 + 13 = 32, 32 - 9 = 23. Jawaban awal salah.

Jawaban akhir: 23 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 91 kartu. Dia memberikan 10 kepada teman. Kemudian membeli 12 kartu. Setelah itu memberikan 15 kepada orang lain. Berapa kartu Nina sekarang?
A: Nina sekarang memiliki 91 - 10 + 12 - 15 = 78 kartu.

Verifikasi: Perhitungan: 91 - 10 = 81, 81 + 12 = 93, 93 - 15 = 78. Benar.

Jawaban akhir: 78 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
