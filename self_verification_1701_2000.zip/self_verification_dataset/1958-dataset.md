# Dataset Verifikasi Diri 1958

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 34 apel. Dia memberikan 3 kepada teman. Kemudian menang 11 apel. Setelah itu membagi 2 kepada orang lain. Berapa apel Nina sekarang?
A: Nina sekarang memiliki 34 - 3 + 11 - 2 = 38 apel.

Verifikasi: Perhitungan yang benar: 34 - 3 = 31, 31 + 11 = 42, 42 - 2 = 40. Jawaban awal salah.

Jawaban akhir: 40 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Yudi memiliki 10 buku tulis. Dia meminjamkan 3 kepada teman. Kemudian menang 17 buku tulis. Setelah itu memberikan 9 kepada orang lain. Berapa buku tulis Yudi sekarang?
A: Yudi sekarang memiliki 10 - 3 + 17 - 9 = 15 buku tulis.

Verifikasi: Perhitungan: 10 - 3 = 7, 7 + 17 = 24, 24 - 9 = 15. Benar.

Jawaban akhir: 15 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 55 buku. Dia meminjamkan 15 kepada teman. Kemudian menerima 4 buku. Setelah itu meminjamkan 8 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 55 - 15 + 4 - 8 = 36 buku.

Verifikasi: Perhitungan: 55 - 15 = 40, 40 + 4 = 44, 44 - 8 = 36. Benar.

Jawaban akhir: 36 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
