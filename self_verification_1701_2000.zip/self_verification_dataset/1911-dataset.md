# Dataset Verifikasi Diri 1911

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 79 pensil. Dia membagi 24 kepada teman. Kemudian mendapat 3 pensil. Setelah itu memberikan 15 kepada orang lain. Berapa pensil Vina sekarang?
A: Vina sekarang memiliki 79 - 24 + 3 - 15 = 43 pensil.

Verifikasi: Perhitungan: 79 - 24 = 55, 55 + 3 = 58, 58 - 15 = 43. Benar.

Jawaban akhir: 43 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 60 bola. Dia meminjamkan 8 kepada teman. Kemudian mendapat 16 bola. Setelah itu membagi 7 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 60 - 8 + 16 - 7 = 62 bola.

Verifikasi: Perhitungan yang benar: 60 - 8 = 52, 52 + 16 = 68, 68 - 7 = 61. Jawaban awal salah.

Jawaban akhir: 61 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 43 pulpen. Dia meminjamkan 12 kepada teman. Kemudian mendapat 16 pulpen. Setelah itu meminjamkan 9 kepada orang lain. Berapa pulpen Yudi sekarang?
A: Yudi sekarang memiliki 43 - 12 + 16 - 9 = 40 pulpen.

Verifikasi: Perhitungan yang benar: 43 - 12 = 31, 31 + 16 = 47, 47 - 9 = 38. Jawaban awal salah.

Jawaban akhir: 38 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
