# Dataset Verifikasi Diri 1964

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 37 stiker. Dia meminjamkan 11 kepada teman. Kemudian menerima 6 stiker. Setelah itu memberikan 12 kepada orang lain. Berapa stiker Indra sekarang?
A: Indra sekarang memiliki 37 - 11 + 6 - 12 = 18 stiker.

Verifikasi: Perhitungan yang benar: 37 - 11 = 26, 26 + 6 = 32, 32 - 12 = 20. Jawaban awal salah.

Jawaban akhir: 20 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Kiki memiliki 37 spidol. Dia memberikan 7 kepada teman. Kemudian mendapat 6 spidol. Setelah itu membagi 7 kepada orang lain. Berapa spidol Kiki sekarang?
A: Kiki sekarang memiliki 37 - 7 + 6 - 7 = 32 spidol.

Verifikasi: Perhitungan yang benar: 37 - 7 = 30, 30 + 6 = 36, 36 - 7 = 29. Jawaban awal salah.

Jawaban akhir: 29 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Budi memiliki 51 kue. Dia meminjamkan 10 kepada teman. Kemudian mendapat 9 kue. Setelah itu membagi 13 kepada orang lain. Berapa kue Budi sekarang?
A: Budi sekarang memiliki 51 - 10 + 9 - 13 = 37 kue.

Verifikasi: Perhitungan: 51 - 10 = 41, 41 + 9 = 50, 50 - 13 = 37. Benar.

Jawaban akhir: 37 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
