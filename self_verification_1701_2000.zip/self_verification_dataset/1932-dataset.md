# Dataset Verifikasi Diri 1932

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 68 bola. Dia memberikan 5 kepada teman. Kemudian mendapat 4 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Udin sekarang?
A: Udin sekarang memiliki 68 - 5 + 4 - 9 = 58 bola.

Verifikasi: Perhitungan: 68 - 5 = 63, 63 + 4 = 67, 67 - 9 = 58. Benar.

Jawaban akhir: 58 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Rina memiliki 99 bola. Dia memberikan 9 kepada teman. Kemudian menerima 10 bola. Setelah itu meminjamkan 11 kepada orang lain. Berapa bola Rina sekarang?
A: Rina sekarang memiliki 99 - 9 + 10 - 11 = 90 bola.

Verifikasi: Perhitungan yang benar: 99 - 9 = 90, 90 + 10 = 100, 100 - 11 = 89. Jawaban awal salah.

Jawaban akhir: 89 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Andi memiliki 20 buku. Dia memberikan 6 kepada teman. Kemudian menerima 2 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Andi sekarang?
A: Andi sekarang memiliki 20 - 6 + 2 - 15 = 1 buku.

Verifikasi: Perhitungan: 20 - 6 = 14, 14 + 2 = 16, 16 - 15 = 1. Benar.

Jawaban akhir: 1 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
