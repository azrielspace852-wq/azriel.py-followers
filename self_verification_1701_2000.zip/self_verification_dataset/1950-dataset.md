# Dataset Verifikasi Diri 1950

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 96 kelereng. Dia membagi 15 kepada teman. Kemudian menang 8 kelereng. Setelah itu meminjamkan 7 kepada orang lain. Berapa kelereng Siti sekarang?
A: Siti sekarang memiliki 96 - 15 + 8 - 7 = 82 kelereng.

Verifikasi: Perhitungan: 96 - 15 = 81, 81 + 8 = 89, 89 - 7 = 82. Benar.

Jawaban akhir: 82 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 90 kue. Dia memberikan 8 kepada teman. Kemudian menang 8 kue. Setelah itu meminjamkan 7 kepada orang lain. Berapa kue Putri sekarang?
A: Putri sekarang memiliki 90 - 8 + 8 - 7 = 83 kue.

Verifikasi: Perhitungan: 90 - 8 = 82, 82 + 8 = 90, 90 - 7 = 83. Benar.

Jawaban akhir: 83 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Candra memiliki 29 bola. Dia meminjamkan 6 kepada teman. Kemudian menang 4 bola. Setelah itu meminjamkan 6 kepada orang lain. Berapa bola Candra sekarang?
A: Candra sekarang memiliki 29 - 6 + 4 - 6 = 21 bola.

Verifikasi: Perhitungan: 29 - 6 = 23, 23 + 4 = 27, 27 - 6 = 21. Benar.

Jawaban akhir: 21 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
