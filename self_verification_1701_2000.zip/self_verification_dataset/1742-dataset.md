# Dataset Verifikasi Diri 1742

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 11 pulpen. Dia memberikan 2 kepada teman. Kemudian menang 9 pulpen. Setelah itu memberikan 1 kepada orang lain. Berapa pulpen Lina sekarang?
A: Lina sekarang memiliki 11 - 2 + 9 - 1 = 17 pulpen.

Verifikasi: Perhitungan: 11 - 2 = 9, 9 + 9 = 18, 18 - 1 = 17. Benar.

Jawaban akhir: 17 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Yudi memiliki 41 spidol. Dia memberikan 12 kepada teman. Kemudian menerima 9 spidol. Setelah itu memberikan 1 kepada orang lain. Berapa spidol Yudi sekarang?
A: Yudi sekarang memiliki 41 - 12 + 9 - 1 = 37 spidol.

Verifikasi: Perhitungan: 41 - 12 = 29, 29 + 9 = 38, 38 - 1 = 37. Benar.

Jawaban akhir: 37 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Joko memiliki 81 stiker. Dia memberikan 8 kepada teman. Kemudian mendapat 10 stiker. Setelah itu memberikan 3 kepada orang lain. Berapa stiker Joko sekarang?
A: Joko sekarang memiliki 81 - 8 + 10 - 3 = 80 stiker.

Verifikasi: Perhitungan: 81 - 8 = 73, 73 + 10 = 83, 83 - 3 = 80. Benar.

Jawaban akhir: 80 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
