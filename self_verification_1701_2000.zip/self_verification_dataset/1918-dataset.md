# Dataset Verifikasi Diri 1918

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 86 kertas. Dia meminjamkan 20 kepada teman. Kemudian membeli 17 kertas. Setelah itu memberikan 1 kepada orang lain. Berapa kertas Nina sekarang?
A: Nina sekarang memiliki 86 - 20 + 17 - 1 = 82 kertas.

Verifikasi: Perhitungan: 86 - 20 = 66, 66 + 17 = 83, 83 - 1 = 82. Benar.

Jawaban akhir: 82 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 87 kertas. Dia membagi 11 kepada teman. Kemudian menang 1 kertas. Setelah itu membagi 6 kepada orang lain. Berapa kertas Putri sekarang?
A: Putri sekarang memiliki 87 - 11 + 1 - 6 = 71 kertas.

Verifikasi: Perhitungan: 87 - 11 = 76, 76 + 1 = 77, 77 - 6 = 71. Benar.

Jawaban akhir: 71 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Dedi memiliki 23 pulpen. Dia meminjamkan 6 kepada teman. Kemudian menang 12 pulpen. Setelah itu membagi 15 kepada orang lain. Berapa pulpen Dedi sekarang?
A: Dedi sekarang memiliki 23 - 6 + 12 - 15 = 14 pulpen.

Verifikasi: Perhitungan: 23 - 6 = 17, 17 + 12 = 29, 29 - 15 = 14. Benar.

Jawaban akhir: 14 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
