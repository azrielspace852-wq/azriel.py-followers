# Dataset Verifikasi Diri 1716

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 43 pensil. Dia meminjamkan 10 kepada teman. Kemudian menang 6 pensil. Setelah itu meminjamkan 7 kepada orang lain. Berapa pensil Fajar sekarang?
A: Fajar sekarang memiliki 43 - 10 + 6 - 7 = 32 pensil.

Verifikasi: Perhitungan: 43 - 10 = 33, 33 + 6 = 39, 39 - 7 = 32. Benar.

Jawaban akhir: 32 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Joko memiliki 85 apel. Dia membagi 16 kepada teman. Kemudian mendapat 3 apel. Setelah itu meminjamkan 3 kepada orang lain. Berapa apel Joko sekarang?
A: Joko sekarang memiliki 85 - 16 + 3 - 3 = 69 apel.

Verifikasi: Perhitungan: 85 - 16 = 69, 69 + 3 = 72, 72 - 3 = 69. Benar.

Jawaban akhir: 69 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 72 bola. Dia memberikan 1 kepada teman. Kemudian menang 9 bola. Setelah itu membagi 5 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 72 - 1 + 9 - 5 = 75 bola.

Verifikasi: Perhitungan: 72 - 1 = 71, 71 + 9 = 80, 80 - 5 = 75. Benar.

Jawaban akhir: 75 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
