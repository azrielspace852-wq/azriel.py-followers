# Dataset Verifikasi Diri 1841

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 79 kelereng. Dia membagi 26 kepada teman. Kemudian membeli 7 kelereng. Setelah itu memberikan 10 kepada orang lain. Berapa kelereng Tono sekarang?
A: Tono sekarang memiliki 79 - 26 + 7 - 10 = 50 kelereng.

Verifikasi: Perhitungan: 79 - 26 = 53, 53 + 7 = 60, 60 - 10 = 50. Benar.

Jawaban akhir: 50 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 80 kartu. Dia memberikan 19 kepada teman. Kemudian menerima 12 kartu. Setelah itu membagi 15 kepada orang lain. Berapa kartu Lina sekarang?
A: Lina sekarang memiliki 80 - 19 + 12 - 15 = 57 kartu.

Verifikasi: Perhitungan yang benar: 80 - 19 = 61, 61 + 12 = 73, 73 - 15 = 58. Jawaban awal salah.

Jawaban akhir: 58 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Kiki memiliki 13 buku tulis. Dia meminjamkan 2 kepada teman. Kemudian menang 17 buku tulis. Setelah itu membagi 5 kepada orang lain. Berapa buku tulis Kiki sekarang?
A: Kiki sekarang memiliki 13 - 2 + 17 - 5 = 23 buku tulis.

Verifikasi: Perhitungan: 13 - 2 = 11, 11 + 17 = 28, 28 - 5 = 23. Benar.

Jawaban akhir: 23 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
