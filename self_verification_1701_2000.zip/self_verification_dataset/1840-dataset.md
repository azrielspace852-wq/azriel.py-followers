# Dataset Verifikasi Diri 1840

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 62 spidol. Dia membagi 2 kepada teman. Kemudian mendapat 3 spidol. Setelah itu membagi 1 kepada orang lain. Berapa spidol Dedi sekarang?
A: Dedi sekarang memiliki 62 - 2 + 3 - 1 = 63 spidol.

Verifikasi: Perhitungan yang benar: 62 - 2 = 60, 60 + 3 = 63, 63 - 1 = 62. Jawaban awal salah.

Jawaban akhir: 62 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Candra memiliki 91 bola. Dia membagi 6 kepada teman. Kemudian menang 2 bola. Setelah itu meminjamkan 7 kepada orang lain. Berapa bola Candra sekarang?
A: Candra sekarang memiliki 91 - 6 + 2 - 7 = 80 bola.

Verifikasi: Perhitungan: 91 - 6 = 85, 85 + 2 = 87, 87 - 7 = 80. Benar.

Jawaban akhir: 80 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 83 penghapus. Dia membagi 4 kepada teman. Kemudian mendapat 19 penghapus. Setelah itu membagi 15 kepada orang lain. Berapa penghapus Fajar sekarang?
A: Fajar sekarang memiliki 83 - 4 + 19 - 15 = 83 penghapus.

Verifikasi: Perhitungan: 83 - 4 = 79, 79 + 19 = 98, 98 - 15 = 83. Benar.

Jawaban akhir: 83 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
