# Dataset Verifikasi Diri 1735

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 21 buku. Dia membagi 4 kepada teman. Kemudian membeli 2 buku. Setelah itu meminjamkan 9 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 21 - 4 + 2 - 9 = 10 buku.

Verifikasi: Perhitungan: 21 - 4 = 17, 17 + 2 = 19, 19 - 9 = 10. Benar.

Jawaban akhir: 10 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 11 kue. Dia memberikan 1 kepada teman. Kemudian membeli 2 kue. Setelah itu meminjamkan 6 kepada orang lain. Berapa kue Vina sekarang?
A: Vina sekarang memiliki 11 - 1 + 2 - 6 = 5 kue.

Verifikasi: Perhitungan yang benar: 11 - 1 = 10, 10 + 2 = 12, 12 - 6 = 6. Jawaban awal salah.

Jawaban akhir: 6 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 82 kertas. Dia memberikan 20 kepada teman. Kemudian menang 20 kertas. Setelah itu memberikan 15 kepada orang lain. Berapa kertas Fajar sekarang?
A: Fajar sekarang memiliki 82 - 20 + 20 - 15 = 67 kertas.

Verifikasi: Perhitungan: 82 - 20 = 62, 62 + 20 = 82, 82 - 15 = 67. Benar.

Jawaban akhir: 67 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
