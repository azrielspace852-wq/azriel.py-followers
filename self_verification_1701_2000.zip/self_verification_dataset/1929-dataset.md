# Dataset Verifikasi Diri 1929

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 97 spidol. Dia meminjamkan 12 kepada teman. Kemudian mendapat 4 spidol. Setelah itu meminjamkan 14 kepada orang lain. Berapa spidol Budi sekarang?
A: Budi sekarang memiliki 97 - 12 + 4 - 14 = 75 spidol.

Verifikasi: Perhitungan: 97 - 12 = 85, 85 + 4 = 89, 89 - 14 = 75. Benar.

Jawaban akhir: 75 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Wati memiliki 34 kue. Dia meminjamkan 3 kepada teman. Kemudian menang 9 kue. Setelah itu membagi 10 kepada orang lain. Berapa kue Wati sekarang?
A: Wati sekarang memiliki 34 - 3 + 9 - 10 = 30 kue.

Verifikasi: Perhitungan: 34 - 3 = 31, 31 + 9 = 40, 40 - 10 = 30. Benar.

Jawaban akhir: 30 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Lina memiliki 61 kue. Dia meminjamkan 16 kepada teman. Kemudian membeli 12 kue. Setelah itu memberikan 11 kepada orang lain. Berapa kue Lina sekarang?
A: Lina sekarang memiliki 61 - 16 + 12 - 11 = 46 kue.

Verifikasi: Perhitungan: 61 - 16 = 45, 45 + 12 = 57, 57 - 11 = 46. Benar.

Jawaban akhir: 46 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
