# Dataset Verifikasi Diri 1850

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 20 penghapus. Dia memberikan 4 kepada teman. Kemudian menerima 12 penghapus. Setelah itu memberikan 4 kepada orang lain. Berapa penghapus Udin sekarang?
A: Udin sekarang memiliki 20 - 4 + 12 - 4 = 24 penghapus.

Verifikasi: Perhitungan: 20 - 4 = 16, 16 + 12 = 28, 28 - 4 = 24. Benar.

Jawaban akhir: 24 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Putri memiliki 90 kelereng. Dia memberikan 26 kepada teman. Kemudian mendapat 6 kelereng. Setelah itu membagi 6 kepada orang lain. Berapa kelereng Putri sekarang?
A: Putri sekarang memiliki 90 - 26 + 6 - 6 = 66 kelereng.

Verifikasi: Perhitungan yang benar: 90 - 26 = 64, 64 + 6 = 70, 70 - 6 = 64. Jawaban awal salah.

Jawaban akhir: 64 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Udin memiliki 100 kertas. Dia membagi 1 kepada teman. Kemudian menang 3 kertas. Setelah itu meminjamkan 11 kepada orang lain. Berapa kertas Udin sekarang?
A: Udin sekarang memiliki 100 - 1 + 3 - 11 = 94 kertas.

Verifikasi: Perhitungan yang benar: 100 - 1 = 99, 99 + 3 = 102, 102 - 11 = 91. Jawaban awal salah.

Jawaban akhir: 91 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
