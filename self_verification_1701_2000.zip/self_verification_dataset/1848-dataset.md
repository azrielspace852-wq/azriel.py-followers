# Dataset Verifikasi Diri 1848

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 91 buku. Dia meminjamkan 17 kepada teman. Kemudian membeli 6 buku. Setelah itu meminjamkan 4 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 91 - 17 + 6 - 4 = 76 buku.

Verifikasi: Perhitungan: 91 - 17 = 74, 74 + 6 = 80, 80 - 4 = 76. Benar.

Jawaban akhir: 76 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 75 stiker. Dia membagi 1 kepada teman. Kemudian mendapat 10 stiker. Setelah itu membagi 5 kepada orang lain. Berapa stiker Gita sekarang?
A: Gita sekarang memiliki 75 - 1 + 10 - 5 = 79 stiker.

Verifikasi: Perhitungan: 75 - 1 = 74, 74 + 10 = 84, 84 - 5 = 79. Benar.

Jawaban akhir: 79 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 56 stiker. Dia membagi 7 kepada teman. Kemudian membeli 2 stiker. Setelah itu meminjamkan 7 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 56 - 7 + 2 - 7 = 46 stiker.

Verifikasi: Perhitungan yang benar: 56 - 7 = 49, 49 + 2 = 51, 51 - 7 = 44. Jawaban awal salah.

Jawaban akhir: 44 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
