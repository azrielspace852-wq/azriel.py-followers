# Dataset Verifikasi Diri 1797

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 71 rupiah. Dia memberikan 2 kepada teman. Kemudian menang 14 rupiah. Setelah itu meminjamkan 3 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 71 - 2 + 14 - 3 = 80 rupiah.

Verifikasi: Perhitungan: 71 - 2 = 69, 69 + 14 = 83, 83 - 3 = 80. Benar.

Jawaban akhir: 80 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Kiki memiliki 69 pensil. Dia meminjamkan 1 kepada teman. Kemudian menang 18 pensil. Setelah itu memberikan 6 kepada orang lain. Berapa pensil Kiki sekarang?
A: Kiki sekarang memiliki 69 - 1 + 18 - 6 = 80 pensil.

Verifikasi: Perhitungan: 69 - 1 = 68, 68 + 18 = 86, 86 - 6 = 80. Benar.

Jawaban akhir: 80 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 85 kartu. Dia meminjamkan 11 kepada teman. Kemudian menerima 5 kartu. Setelah itu membagi 9 kepada orang lain. Berapa kartu Candra sekarang?
A: Candra sekarang memiliki 85 - 11 + 5 - 9 = 70 kartu.

Verifikasi: Perhitungan: 85 - 11 = 74, 74 + 5 = 79, 79 - 9 = 70. Benar.

Jawaban akhir: 70 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
