# Dataset Verifikasi Diri 1748

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 28 rupiah. Dia meminjamkan 7 kepada teman. Kemudian menang 4 rupiah. Setelah itu membagi 1 kepada orang lain. Berapa rupiah Fajar sekarang?
A: Fajar sekarang memiliki 28 - 7 + 4 - 1 = 24 rupiah.

Verifikasi: Perhitungan: 28 - 7 = 21, 21 + 4 = 25, 25 - 1 = 24. Benar.

Jawaban akhir: 24 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Wati memiliki 32 kertas. Dia meminjamkan 3 kepada teman. Kemudian menerima 15 kertas. Setelah itu membagi 10 kepada orang lain. Berapa kertas Wati sekarang?
A: Wati sekarang memiliki 32 - 3 + 15 - 10 = 34 kertas.

Verifikasi: Perhitungan: 32 - 3 = 29, 29 + 15 = 44, 44 - 10 = 34. Benar.

Jawaban akhir: 34 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Siti memiliki 64 buku tulis. Dia memberikan 8 kepada teman. Kemudian mendapat 19 buku tulis. Setelah itu membagi 3 kepada orang lain. Berapa buku tulis Siti sekarang?
A: Siti sekarang memiliki 64 - 8 + 19 - 3 = 72 buku tulis.

Verifikasi: Perhitungan: 64 - 8 = 56, 56 + 19 = 75, 75 - 3 = 72. Benar.

Jawaban akhir: 72 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
