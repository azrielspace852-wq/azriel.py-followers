# Dataset Verifikasi Diri 1823

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 67 buku tulis. Dia membagi 10 kepada teman. Kemudian mendapat 2 buku tulis. Setelah itu membagi 8 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 67 - 10 + 2 - 8 = 51 buku tulis.

Verifikasi: Perhitungan: 67 - 10 = 57, 57 + 2 = 59, 59 - 8 = 51. Benar.

Jawaban akhir: 51 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 33 kartu. Dia memberikan 4 kepada teman. Kemudian menang 1 kartu. Setelah itu memberikan 10 kepada orang lain. Berapa kartu Udin sekarang?
A: Udin sekarang memiliki 33 - 4 + 1 - 10 = 19 kartu.

Verifikasi: Perhitungan yang benar: 33 - 4 = 29, 29 + 1 = 30, 30 - 10 = 20. Jawaban awal salah.

Jawaban akhir: 20 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 15 penghapus. Dia meminjamkan 4 kepada teman. Kemudian membeli 5 penghapus. Setelah itu membagi 2 kepada orang lain. Berapa penghapus Candra sekarang?
A: Candra sekarang memiliki 15 - 4 + 5 - 2 = 14 penghapus.

Verifikasi: Perhitungan: 15 - 4 = 11, 11 + 5 = 16, 16 - 2 = 14. Benar.

Jawaban akhir: 14 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
