# Dataset Verifikasi Diri 1778

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 40 kartu. Dia meminjamkan 11 kepada teman. Kemudian menang 12 kartu. Setelah itu memberikan 10 kepada orang lain. Berapa kartu Candra sekarang?
A: Candra sekarang memiliki 40 - 11 + 12 - 10 = 32 kartu.

Verifikasi: Perhitungan yang benar: 40 - 11 = 29, 29 + 12 = 41, 41 - 10 = 31. Jawaban awal salah.

Jawaban akhir: 31 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Candra memiliki 47 rupiah. Dia meminjamkan 14 kepada teman. Kemudian menerima 18 rupiah. Setelah itu memberikan 7 kepada orang lain. Berapa rupiah Candra sekarang?
A: Candra sekarang memiliki 47 - 14 + 18 - 7 = 43 rupiah.

Verifikasi: Perhitungan yang benar: 47 - 14 = 33, 33 + 18 = 51, 51 - 7 = 44. Jawaban awal salah.

Jawaban akhir: 44 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 77 pulpen. Dia membagi 24 kepada teman. Kemudian mendapat 15 pulpen. Setelah itu meminjamkan 1 kepada orang lain. Berapa pulpen Tono sekarang?
A: Tono sekarang memiliki 77 - 24 + 15 - 1 = 69 pulpen.

Verifikasi: Perhitungan yang benar: 77 - 24 = 53, 53 + 15 = 68, 68 - 1 = 67. Jawaban awal salah.

Jawaban akhir: 67 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
