# Dataset Verifikasi Diri 1956

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 15 apel. Dia membagi 2 kepada teman. Kemudian menang 10 apel. Setelah itu meminjamkan 3 kepada orang lain. Berapa apel Lina sekarang?
A: Lina sekarang memiliki 15 - 2 + 10 - 3 = 20 apel.

Verifikasi: Perhitungan: 15 - 2 = 13, 13 + 10 = 23, 23 - 3 = 20. Benar.

Jawaban akhir: 20 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Maya memiliki 15 pulpen. Dia membagi 3 kepada teman. Kemudian mendapat 4 pulpen. Setelah itu meminjamkan 1 kepada orang lain. Berapa pulpen Maya sekarang?
A: Maya sekarang memiliki 15 - 3 + 4 - 1 = 13 pulpen.

Verifikasi: Perhitungan yang benar: 15 - 3 = 12, 12 + 4 = 16, 16 - 1 = 15. Jawaban awal salah.

Jawaban akhir: 15 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 11 kartu. Dia memberikan 3 kepada teman. Kemudian mendapat 18 kartu. Setelah itu memberikan 9 kepada orang lain. Berapa kartu Tono sekarang?
A: Tono sekarang memiliki 11 - 3 + 18 - 9 = 20 kartu.

Verifikasi: Perhitungan yang benar: 11 - 3 = 8, 8 + 18 = 26, 26 - 9 = 17. Jawaban awal salah.

Jawaban akhir: 17 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
