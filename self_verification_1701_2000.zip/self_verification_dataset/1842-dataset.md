# Dataset Verifikasi Diri 1842

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Vina memiliki 57 spidol. Dia memberikan 12 kepada teman. Kemudian menerima 11 spidol. Setelah itu membagi 7 kepada orang lain. Berapa spidol Vina sekarang?
A: Vina sekarang memiliki 57 - 12 + 11 - 7 = 49 spidol.

Verifikasi: Perhitungan: 57 - 12 = 45, 45 + 11 = 56, 56 - 7 = 49. Benar.

Jawaban akhir: 49 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 96 pensil. Dia meminjamkan 11 kepada teman. Kemudian menerima 14 pensil. Setelah itu memberikan 6 kepada orang lain. Berapa pensil Hani sekarang?
A: Hani sekarang memiliki 96 - 11 + 14 - 6 = 93 pensil.

Verifikasi: Perhitungan: 96 - 11 = 85, 85 + 14 = 99, 99 - 6 = 93. Benar.

Jawaban akhir: 93 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Vina memiliki 82 pulpen. Dia memberikan 25 kepada teman. Kemudian mendapat 2 pulpen. Setelah itu meminjamkan 15 kepada orang lain. Berapa pulpen Vina sekarang?
A: Vina sekarang memiliki 82 - 25 + 2 - 15 = 43 pulpen.

Verifikasi: Perhitungan yang benar: 82 - 25 = 57, 57 + 2 = 59, 59 - 15 = 44. Jawaban awal salah.

Jawaban akhir: 44 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
