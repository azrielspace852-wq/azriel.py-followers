# Dataset Verifikasi Diri 1855

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 33 kue. Dia memberikan 2 kepada teman. Kemudian menang 8 kue. Setelah itu membagi 7 kepada orang lain. Berapa kue Dedi sekarang?
A: Dedi sekarang memiliki 33 - 2 + 8 - 7 = 32 kue.

Verifikasi: Perhitungan: 33 - 2 = 31, 31 + 8 = 39, 39 - 7 = 32. Benar.

Jawaban akhir: 32 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 22 kertas. Dia memberikan 3 kepada teman. Kemudian menang 20 kertas. Setelah itu membagi 10 kepada orang lain. Berapa kertas Nina sekarang?
A: Nina sekarang memiliki 22 - 3 + 20 - 10 = 28 kertas.

Verifikasi: Perhitungan yang benar: 22 - 3 = 19, 19 + 20 = 39, 39 - 10 = 29. Jawaban awal salah.

Jawaban akhir: 29 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Wati memiliki 29 kartu. Dia membagi 5 kepada teman. Kemudian menang 8 kartu. Setelah itu membagi 6 kepada orang lain. Berapa kartu Wati sekarang?
A: Wati sekarang memiliki 29 - 5 + 8 - 6 = 26 kartu.

Verifikasi: Perhitungan: 29 - 5 = 24, 24 + 8 = 32, 32 - 6 = 26. Benar.

Jawaban akhir: 26 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
