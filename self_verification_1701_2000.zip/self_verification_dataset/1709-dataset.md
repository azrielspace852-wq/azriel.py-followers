# Dataset Verifikasi Diri 1709

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 30 buku. Dia meminjamkan 3 kepada teman. Kemudian membeli 14 buku. Setelah itu meminjamkan 3 kepada orang lain. Berapa buku Dedi sekarang?
A: Dedi sekarang memiliki 30 - 3 + 14 - 3 = 38 buku.

Verifikasi: Perhitungan: 30 - 3 = 27, 27 + 14 = 41, 41 - 3 = 38. Benar.

Jawaban akhir: 38 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Dedi memiliki 28 kelereng. Dia meminjamkan 3 kepada teman. Kemudian membeli 6 kelereng. Setelah itu memberikan 3 kepada orang lain. Berapa kelereng Dedi sekarang?
A: Dedi sekarang memiliki 28 - 3 + 6 - 3 = 30 kelereng.

Verifikasi: Perhitungan yang benar: 28 - 3 = 25, 25 + 6 = 31, 31 - 3 = 28. Jawaban awal salah.

Jawaban akhir: 28 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Yudi memiliki 45 kelereng. Dia membagi 3 kepada teman. Kemudian menerima 20 kelereng. Setelah itu meminjamkan 3 kepada orang lain. Berapa kelereng Yudi sekarang?
A: Yudi sekarang memiliki 45 - 3 + 20 - 3 = 59 kelereng.

Verifikasi: Perhitungan: 45 - 3 = 42, 42 + 20 = 62, 62 - 3 = 59. Benar.

Jawaban akhir: 59 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
