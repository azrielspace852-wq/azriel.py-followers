# Dataset Verifikasi Diri 1738

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 95 pensil. Dia membagi 13 kepada teman. Kemudian mendapat 11 pensil. Setelah itu membagi 4 kepada orang lain. Berapa pensil Oscar sekarang?
A: Oscar sekarang memiliki 95 - 13 + 11 - 4 = 88 pensil.

Verifikasi: Perhitungan yang benar: 95 - 13 = 82, 82 + 11 = 93, 93 - 4 = 89. Jawaban awal salah.

Jawaban akhir: 89 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Yudi memiliki 43 buku tulis. Dia meminjamkan 11 kepada teman. Kemudian membeli 1 buku tulis. Setelah itu meminjamkan 15 kepada orang lain. Berapa buku tulis Yudi sekarang?
A: Yudi sekarang memiliki 43 - 11 + 1 - 15 = 18 buku tulis.

Verifikasi: Perhitungan: 43 - 11 = 32, 32 + 1 = 33, 33 - 15 = 18. Benar.

Jawaban akhir: 18 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 81 stiker. Dia meminjamkan 6 kepada teman. Kemudian membeli 15 stiker. Setelah itu meminjamkan 6 kepada orang lain. Berapa stiker Vina sekarang?
A: Vina sekarang memiliki 81 - 6 + 15 - 6 = 84 stiker.

Verifikasi: Perhitungan: 81 - 6 = 75, 75 + 15 = 90, 90 - 6 = 84. Benar.

Jawaban akhir: 84 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
