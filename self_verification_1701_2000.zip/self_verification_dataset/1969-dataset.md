# Dataset Verifikasi Diri 1969

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 23 kelereng. Dia memberikan 4 kepada teman. Kemudian menang 11 kelereng. Setelah itu membagi 15 kepada orang lain. Berapa kelereng Kiki sekarang?
A: Kiki sekarang memiliki 23 - 4 + 11 - 15 = 15 kelereng.

Verifikasi: Perhitungan: 23 - 4 = 19, 19 + 11 = 30, 30 - 15 = 15. Benar.

Jawaban akhir: 15 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Fajar memiliki 91 penghapus. Dia membagi 17 kepada teman. Kemudian menerima 8 penghapus. Setelah itu membagi 3 kepada orang lain. Berapa penghapus Fajar sekarang?
A: Fajar sekarang memiliki 91 - 17 + 8 - 3 = 79 penghapus.

Verifikasi: Perhitungan: 91 - 17 = 74, 74 + 8 = 82, 82 - 3 = 79. Benar.

Jawaban akhir: 79 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 28 penggaris. Dia membagi 3 kepada teman. Kemudian mendapat 19 penggaris. Setelah itu meminjamkan 8 kepada orang lain. Berapa penggaris Fajar sekarang?
A: Fajar sekarang memiliki 28 - 3 + 19 - 8 = 36 penggaris.

Verifikasi: Perhitungan: 28 - 3 = 25, 25 + 19 = 44, 44 - 8 = 36. Benar.

Jawaban akhir: 36 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
