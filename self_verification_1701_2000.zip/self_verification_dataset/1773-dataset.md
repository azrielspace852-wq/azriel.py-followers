# Dataset Verifikasi Diri 1773

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 25 buku tulis. Dia meminjamkan 7 kepada teman. Kemudian menerima 4 buku tulis. Setelah itu memberikan 1 kepada orang lain. Berapa buku tulis Nina sekarang?
A: Nina sekarang memiliki 25 - 7 + 4 - 1 = 21 buku tulis.

Verifikasi: Perhitungan: 25 - 7 = 18, 18 + 4 = 22, 22 - 1 = 21. Benar.

Jawaban akhir: 21 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 90 penghapus. Dia memberikan 27 kepada teman. Kemudian mendapat 13 penghapus. Setelah itu meminjamkan 12 kepada orang lain. Berapa penghapus Gita sekarang?
A: Gita sekarang memiliki 90 - 27 + 13 - 12 = 64 penghapus.

Verifikasi: Perhitungan: 90 - 27 = 63, 63 + 13 = 76, 76 - 12 = 64. Benar.

Jawaban akhir: 64 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Putri memiliki 95 apel. Dia memberikan 18 kepada teman. Kemudian menang 7 apel. Setelah itu meminjamkan 3 kepada orang lain. Berapa apel Putri sekarang?
A: Putri sekarang memiliki 95 - 18 + 7 - 3 = 81 apel.

Verifikasi: Perhitungan: 95 - 18 = 77, 77 + 7 = 84, 84 - 3 = 81. Benar.

Jawaban akhir: 81 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
