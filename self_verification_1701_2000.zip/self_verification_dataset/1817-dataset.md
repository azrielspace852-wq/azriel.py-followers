# Dataset Verifikasi Diri 1817

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 29 bola. Dia membagi 5 kepada teman. Kemudian mendapat 15 bola. Setelah itu membagi 10 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 29 - 5 + 15 - 10 = 29 bola.

Verifikasi: Perhitungan: 29 - 5 = 24, 24 + 15 = 39, 39 - 10 = 29. Benar.

Jawaban akhir: 29 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 86 rupiah. Dia meminjamkan 10 kepada teman. Kemudian menerima 8 rupiah. Setelah itu memberikan 12 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 86 - 10 + 8 - 12 = 71 rupiah.

Verifikasi: Perhitungan yang benar: 86 - 10 = 76, 76 + 8 = 84, 84 - 12 = 72. Jawaban awal salah.

Jawaban akhir: 72 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 83 spidol. Dia memberikan 11 kepada teman. Kemudian menang 12 spidol. Setelah itu meminjamkan 13 kepada orang lain. Berapa spidol Putri sekarang?
A: Putri sekarang memiliki 83 - 11 + 12 - 13 = 73 spidol.

Verifikasi: Perhitungan yang benar: 83 - 11 = 72, 72 + 12 = 84, 84 - 13 = 71. Jawaban awal salah.

Jawaban akhir: 71 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup
