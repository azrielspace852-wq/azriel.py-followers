# Dataset Verifikasi Diri 1874

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 12 bola. Dia meminjamkan 3 kepada teman. Kemudian menerima 10 bola. Setelah itu meminjamkan 5 kepada orang lain. Berapa bola Tono sekarang?
A: Tono sekarang memiliki 12 - 3 + 10 - 5 = 14 bola.

Verifikasi: Perhitungan: 12 - 3 = 9, 9 + 10 = 19, 19 - 5 = 14. Benar.

Jawaban akhir: 14 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Putri memiliki 27 pensil. Dia memberikan 4 kepada teman. Kemudian menang 12 pensil. Setelah itu memberikan 10 kepada orang lain. Berapa pensil Putri sekarang?
A: Putri sekarang memiliki 27 - 4 + 12 - 10 = 25 pensil.

Verifikasi: Perhitungan: 27 - 4 = 23, 23 + 12 = 35, 35 - 10 = 25. Benar.

Jawaban akhir: 25 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Andi memiliki 39 rupiah. Dia meminjamkan 10 kepada teman. Kemudian menang 13 rupiah. Setelah itu membagi 15 kepada orang lain. Berapa rupiah Andi sekarang?
A: Andi sekarang memiliki 39 - 10 + 13 - 15 = 27 rupiah.

Verifikasi: Perhitungan: 39 - 10 = 29, 29 + 13 = 42, 42 - 15 = 27. Benar.

Jawaban akhir: 27 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
