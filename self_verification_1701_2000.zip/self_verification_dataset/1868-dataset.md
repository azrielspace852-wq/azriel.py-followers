# Dataset Verifikasi Diri 1868

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 22 rupiah. Dia membagi 1 kepada teman. Kemudian membeli 2 rupiah. Setelah itu membagi 14 kepada orang lain. Berapa rupiah Hani sekarang?
A: Hani sekarang memiliki 22 - 1 + 2 - 14 = 9 rupiah.

Verifikasi: Perhitungan: 22 - 1 = 21, 21 + 2 = 23, 23 - 14 = 9. Benar.

Jawaban akhir: 9 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Putri memiliki 94 penghapus. Dia memberikan 21 kepada teman. Kemudian menang 3 penghapus. Setelah itu membagi 5 kepada orang lain. Berapa penghapus Putri sekarang?
A: Putri sekarang memiliki 94 - 21 + 3 - 5 = 73 penghapus.

Verifikasi: Perhitungan yang benar: 94 - 21 = 73, 73 + 3 = 76, 76 - 5 = 71. Jawaban awal salah.

Jawaban akhir: 71 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Maya memiliki 81 apel. Dia meminjamkan 5 kepada teman. Kemudian mendapat 2 apel. Setelah itu meminjamkan 5 kepada orang lain. Berapa apel Maya sekarang?
A: Maya sekarang memiliki 81 - 5 + 2 - 5 = 73 apel.

Verifikasi: Perhitungan: 81 - 5 = 76, 76 + 2 = 78, 78 - 5 = 73. Benar.

Jawaban akhir: 73 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
