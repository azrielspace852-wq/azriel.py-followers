# Dataset Verifikasi Diri 1921

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 62 kelereng. Dia meminjamkan 8 kepada teman. Kemudian membeli 19 kelereng. Setelah itu memberikan 14 kepada orang lain. Berapa kelereng Eko sekarang?
A: Eko sekarang memiliki 62 - 8 + 19 - 14 = 60 kelereng.

Verifikasi: Perhitungan yang benar: 62 - 8 = 54, 54 + 19 = 73, 73 - 14 = 59. Jawaban awal salah.

Jawaban akhir: 59 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Andi memiliki 62 apel. Dia memberikan 2 kepada teman. Kemudian mendapat 16 apel. Setelah itu membagi 9 kepada orang lain. Berapa apel Andi sekarang?
A: Andi sekarang memiliki 62 - 2 + 16 - 9 = 67 apel.

Verifikasi: Perhitungan: 62 - 2 = 60, 60 + 16 = 76, 76 - 9 = 67. Benar.

Jawaban akhir: 67 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Indra memiliki 45 pensil. Dia membagi 1 kepada teman. Kemudian mendapat 1 pensil. Setelah itu membagi 2 kepada orang lain. Berapa pensil Indra sekarang?
A: Indra sekarang memiliki 45 - 1 + 1 - 2 = 43 pensil.

Verifikasi: Perhitungan: 45 - 1 = 44, 44 + 1 = 45, 45 - 2 = 43. Benar.

Jawaban akhir: 43 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
