# Dataset Verifikasi Diri 1867

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 66 buku tulis. Dia meminjamkan 9 kepada teman. Kemudian menerima 6 buku tulis. Setelah itu membagi 8 kepada orang lain. Berapa buku tulis Andi sekarang?
A: Andi sekarang memiliki 66 - 9 + 6 - 8 = 53 buku tulis.

Verifikasi: Perhitungan yang benar: 66 - 9 = 57, 57 + 6 = 63, 63 - 8 = 55. Jawaban awal salah.

Jawaban akhir: 55 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Siti memiliki 24 kertas. Dia meminjamkan 5 kepada teman. Kemudian menang 1 kertas. Setelah itu meminjamkan 10 kepada orang lain. Berapa kertas Siti sekarang?
A: Siti sekarang memiliki 24 - 5 + 1 - 10 = 10 kertas.

Verifikasi: Perhitungan: 24 - 5 = 19, 19 + 1 = 20, 20 - 10 = 10. Benar.

Jawaban akhir: 10 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Joko memiliki 86 penggaris. Dia memberikan 9 kepada teman. Kemudian membeli 1 penggaris. Setelah itu memberikan 4 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 86 - 9 + 1 - 4 = 74 penggaris.

Verifikasi: Perhitungan: 86 - 9 = 77, 77 + 1 = 78, 78 - 4 = 74. Benar.

Jawaban akhir: 74 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
