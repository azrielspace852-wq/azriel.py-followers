# Dataset Verifikasi Diri 1772

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 83 kertas. Dia meminjamkan 2 kepada teman. Kemudian mendapat 15 kertas. Setelah itu membagi 1 kepada orang lain. Berapa kertas Indra sekarang?
A: Indra sekarang memiliki 83 - 2 + 15 - 1 = 95 kertas.

Verifikasi: Perhitungan: 83 - 2 = 81, 81 + 15 = 96, 96 - 1 = 95. Benar.

Jawaban akhir: 95 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Maya memiliki 91 buku tulis. Dia membagi 10 kepada teman. Kemudian membeli 18 buku tulis. Setelah itu memberikan 3 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 91 - 10 + 18 - 3 = 96 buku tulis.

Verifikasi: Perhitungan: 91 - 10 = 81, 81 + 18 = 99, 99 - 3 = 96. Benar.

Jawaban akhir: 96 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Maya memiliki 50 kue. Dia meminjamkan 2 kepada teman. Kemudian membeli 4 kue. Setelah itu memberikan 10 kepada orang lain. Berapa kue Maya sekarang?
A: Maya sekarang memiliki 50 - 2 + 4 - 10 = 40 kue.

Verifikasi: Perhitungan yang benar: 50 - 2 = 48, 48 + 4 = 52, 52 - 10 = 42. Jawaban awal salah.

Jawaban akhir: 42 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
