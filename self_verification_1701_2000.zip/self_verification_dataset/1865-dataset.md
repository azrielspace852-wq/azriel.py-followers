# Dataset Verifikasi Diri 1865

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 78 buku. Dia memberikan 26 kepada teman. Kemudian menerima 12 buku. Setelah itu meminjamkan 13 kepada orang lain. Berapa buku Candra sekarang?
A: Candra sekarang memiliki 78 - 26 + 12 - 13 = 51 buku.

Verifikasi: Perhitungan: 78 - 26 = 52, 52 + 12 = 64, 64 - 13 = 51. Benar.

Jawaban akhir: 51 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Udin memiliki 18 rupiah. Dia membagi 5 kepada teman. Kemudian membeli 8 rupiah. Setelah itu meminjamkan 4 kepada orang lain. Berapa rupiah Udin sekarang?
A: Udin sekarang memiliki 18 - 5 + 8 - 4 = 18 rupiah.

Verifikasi: Perhitungan yang benar: 18 - 5 = 13, 13 + 8 = 21, 21 - 4 = 17. Jawaban awal salah.

Jawaban akhir: 17 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Rina memiliki 17 buku tulis. Dia memberikan 5 kepada teman. Kemudian membeli 6 buku tulis. Setelah itu membagi 1 kepada orang lain. Berapa buku tulis Rina sekarang?
A: Rina sekarang memiliki 17 - 5 + 6 - 1 = 17 buku tulis.

Verifikasi: Perhitungan: 17 - 5 = 12, 12 + 6 = 18, 18 - 1 = 17. Benar.

Jawaban akhir: 17 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
