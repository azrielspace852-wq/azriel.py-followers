# Dataset Verifikasi Diri 1802

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 100 pensil. Dia membagi 26 kepada teman. Kemudian menerima 14 pensil. Setelah itu memberikan 9 kepada orang lain. Berapa pensil Nina sekarang?
A: Nina sekarang memiliki 100 - 26 + 14 - 9 = 79 pensil.

Verifikasi: Perhitungan: 100 - 26 = 74, 74 + 14 = 88, 88 - 9 = 79. Benar.

Jawaban akhir: 79 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Putri memiliki 49 kertas. Dia memberikan 3 kepada teman. Kemudian menerima 2 kertas. Setelah itu memberikan 4 kepada orang lain. Berapa kertas Putri sekarang?
A: Putri sekarang memiliki 49 - 3 + 2 - 4 = 47 kertas.

Verifikasi: Perhitungan yang benar: 49 - 3 = 46, 46 + 2 = 48, 48 - 4 = 44. Jawaban awal salah.

Jawaban akhir: 44 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Dedi memiliki 99 apel. Dia meminjamkan 19 kepada teman. Kemudian mendapat 4 apel. Setelah itu membagi 3 kepada orang lain. Berapa apel Dedi sekarang?
A: Dedi sekarang memiliki 99 - 19 + 4 - 3 = 81 apel.

Verifikasi: Perhitungan: 99 - 19 = 80, 80 + 4 = 84, 84 - 3 = 81. Benar.

Jawaban akhir: 81 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
