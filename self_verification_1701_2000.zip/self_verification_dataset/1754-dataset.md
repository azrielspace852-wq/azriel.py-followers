# Dataset Verifikasi Diri 1754

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 24 kertas. Dia membagi 7 kepada teman. Kemudian menerima 1 kertas. Setelah itu membagi 2 kepada orang lain. Berapa kertas Kiki sekarang?
A: Kiki sekarang memiliki 24 - 7 + 1 - 2 = 16 kertas.

Verifikasi: Perhitungan: 24 - 7 = 17, 17 + 1 = 18, 18 - 2 = 16. Benar.

Jawaban akhir: 16 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Fajar memiliki 57 kelereng. Dia membagi 2 kepada teman. Kemudian menang 5 kelereng. Setelah itu meminjamkan 3 kepada orang lain. Berapa kelereng Fajar sekarang?
A: Fajar sekarang memiliki 57 - 2 + 5 - 3 = 57 kelereng.

Verifikasi: Perhitungan: 57 - 2 = 55, 55 + 5 = 60, 60 - 3 = 57. Benar.

Jawaban akhir: 57 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Nina memiliki 25 kue. Dia membagi 2 kepada teman. Kemudian mendapat 20 kue. Setelah itu membagi 7 kepada orang lain. Berapa kue Nina sekarang?
A: Nina sekarang memiliki 25 - 2 + 20 - 7 = 36 kue.

Verifikasi: Perhitungan: 25 - 2 = 23, 23 + 20 = 43, 43 - 7 = 36. Benar.

Jawaban akhir: 36 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
