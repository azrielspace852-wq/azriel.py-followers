# Dataset Verifikasi Diri 1888

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 44 stiker. Dia membagi 10 kepada teman. Kemudian menerima 17 stiker. Setelah itu meminjamkan 2 kepada orang lain. Berapa stiker Maya sekarang?
A: Maya sekarang memiliki 44 - 10 + 17 - 2 = 49 stiker.

Verifikasi: Perhitungan: 44 - 10 = 34, 34 + 17 = 51, 51 - 2 = 49. Benar.

Jawaban akhir: 49 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 33 kertas. Dia memberikan 3 kepada teman. Kemudian menang 1 kertas. Setelah itu membagi 3 kepada orang lain. Berapa kertas Indra sekarang?
A: Indra sekarang memiliki 33 - 3 + 1 - 3 = 29 kertas.

Verifikasi: Perhitungan yang benar: 33 - 3 = 30, 30 + 1 = 31, 31 - 3 = 28. Jawaban awal salah.

Jawaban akhir: 28 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Gita memiliki 22 rupiah. Dia membagi 4 kepada teman. Kemudian membeli 17 rupiah. Setelah itu membagi 15 kepada orang lain. Berapa rupiah Gita sekarang?
A: Gita sekarang memiliki 22 - 4 + 17 - 15 = 22 rupiah.

Verifikasi: Perhitungan yang benar: 22 - 4 = 18, 18 + 17 = 35, 35 - 15 = 20. Jawaban awal salah.

Jawaban akhir: 20 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
