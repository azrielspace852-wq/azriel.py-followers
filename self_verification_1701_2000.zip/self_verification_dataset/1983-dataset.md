# Dataset Verifikasi Diri 1983

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 18 bola. Dia membagi 5 kepada teman. Kemudian membeli 15 bola. Setelah itu membagi 5 kepada orang lain. Berapa bola Joko sekarang?
A: Joko sekarang memiliki 18 - 5 + 15 - 5 = 23 bola.

Verifikasi: Perhitungan: 18 - 5 = 13, 13 + 15 = 28, 28 - 5 = 23. Benar.

Jawaban akhir: 23 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Yudi memiliki 30 buku tulis. Dia meminjamkan 2 kepada teman. Kemudian mendapat 1 buku tulis. Setelah itu meminjamkan 12 kepada orang lain. Berapa buku tulis Yudi sekarang?
A: Yudi sekarang memiliki 30 - 2 + 1 - 12 = 19 buku tulis.

Verifikasi: Perhitungan yang benar: 30 - 2 = 28, 28 + 1 = 29, 29 - 12 = 17. Jawaban awal salah.

Jawaban akhir: 17 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Candra memiliki 26 penggaris. Dia membagi 1 kepada teman. Kemudian mendapat 9 penggaris. Setelah itu meminjamkan 3 kepada orang lain. Berapa penggaris Candra sekarang?
A: Candra sekarang memiliki 26 - 1 + 9 - 3 = 29 penggaris.

Verifikasi: Perhitungan yang benar: 26 - 1 = 25, 25 + 9 = 34, 34 - 3 = 31. Jawaban awal salah.

Jawaban akhir: 31 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
