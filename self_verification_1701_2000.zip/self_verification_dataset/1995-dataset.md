# Dataset Verifikasi Diri 1995

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 40 rupiah. Dia meminjamkan 8 kepada teman. Kemudian membeli 18 rupiah. Setelah itu meminjamkan 3 kepada orang lain. Berapa rupiah Candra sekarang?
A: Candra sekarang memiliki 40 - 8 + 18 - 3 = 47 rupiah.

Verifikasi: Perhitungan: 40 - 8 = 32, 32 + 18 = 50, 50 - 3 = 47. Benar.

Jawaban akhir: 47 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Vina memiliki 75 penggaris. Dia memberikan 14 kepada teman. Kemudian menerima 2 penggaris. Setelah itu memberikan 1 kepada orang lain. Berapa penggaris Vina sekarang?
A: Vina sekarang memiliki 75 - 14 + 2 - 1 = 62 penggaris.

Verifikasi: Perhitungan: 75 - 14 = 61, 61 + 2 = 63, 63 - 1 = 62. Benar.

Jawaban akhir: 62 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 46 rupiah. Dia memberikan 10 kepada teman. Kemudian menerima 10 rupiah. Setelah itu membagi 10 kepada orang lain. Berapa rupiah Gita sekarang?
A: Gita sekarang memiliki 46 - 10 + 10 - 10 = 35 rupiah.

Verifikasi: Perhitungan yang benar: 46 - 10 = 36, 36 + 10 = 46, 46 - 10 = 36. Jawaban awal salah.

Jawaban akhir: 36 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
