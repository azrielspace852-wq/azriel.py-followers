# Dataset Verifikasi Diri 1922

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 88 rupiah. Dia meminjamkan 15 kepada teman. Kemudian menang 12 rupiah. Setelah itu meminjamkan 10 kepada orang lain. Berapa rupiah Dedi sekarang?
A: Dedi sekarang memiliki 88 - 15 + 12 - 10 = 74 rupiah.

Verifikasi: Perhitungan yang benar: 88 - 15 = 73, 73 + 12 = 85, 85 - 10 = 75. Jawaban awal salah.

Jawaban akhir: 75 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 24 kertas. Dia memberikan 2 kepada teman. Kemudian membeli 19 kertas. Setelah itu memberikan 12 kepada orang lain. Berapa kertas Vina sekarang?
A: Vina sekarang memiliki 24 - 2 + 19 - 12 = 29 kertas.

Verifikasi: Perhitungan: 24 - 2 = 22, 22 + 19 = 41, 41 - 12 = 29. Benar.

Jawaban akhir: 29 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Kiki memiliki 100 buku tulis. Dia membagi 26 kepada teman. Kemudian menang 2 buku tulis. Setelah itu meminjamkan 14 kepada orang lain. Berapa buku tulis Kiki sekarang?
A: Kiki sekarang memiliki 100 - 26 + 2 - 14 = 62 buku tulis.

Verifikasi: Perhitungan: 100 - 26 = 74, 74 + 2 = 76, 76 - 14 = 62. Benar.

Jawaban akhir: 62 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
