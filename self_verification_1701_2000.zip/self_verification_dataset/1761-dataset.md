# Dataset Verifikasi Diri 1761

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 31 penggaris. Dia meminjamkan 8 kepada teman. Kemudian membeli 20 penggaris. Setelah itu membagi 4 kepada orang lain. Berapa penggaris Maya sekarang?
A: Maya sekarang memiliki 31 - 8 + 20 - 4 = 41 penggaris.

Verifikasi: Perhitungan yang benar: 31 - 8 = 23, 23 + 20 = 43, 43 - 4 = 39. Jawaban awal salah.

Jawaban akhir: 39 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 97 rupiah. Dia membagi 27 kepada teman. Kemudian mendapat 17 rupiah. Setelah itu meminjamkan 15 kepada orang lain. Berapa rupiah Eko sekarang?
A: Eko sekarang memiliki 97 - 27 + 17 - 15 = 72 rupiah.

Verifikasi: Perhitungan: 97 - 27 = 70, 70 + 17 = 87, 87 - 15 = 72. Benar.

Jawaban akhir: 72 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 97 buku. Dia membagi 18 kepada teman. Kemudian menang 18 buku. Setelah itu meminjamkan 4 kepada orang lain. Berapa buku Zaki sekarang?
A: Zaki sekarang memiliki 97 - 18 + 18 - 4 = 93 buku.

Verifikasi: Perhitungan: 97 - 18 = 79, 79 + 18 = 97, 97 - 4 = 93. Benar.

Jawaban akhir: 93 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
