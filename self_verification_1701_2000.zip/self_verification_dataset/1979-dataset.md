# Dataset Verifikasi Diri 1979

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 19 kartu. Dia meminjamkan 1 kepada teman. Kemudian membeli 9 kartu. Setelah itu meminjamkan 3 kepada orang lain. Berapa kartu Andi sekarang?
A: Andi sekarang memiliki 19 - 1 + 9 - 3 = 24 kartu.

Verifikasi: Perhitungan: 19 - 1 = 18, 18 + 9 = 27, 27 - 3 = 24. Benar.

Jawaban akhir: 24 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Yudi memiliki 28 kartu. Dia memberikan 4 kepada teman. Kemudian menerima 18 kartu. Setelah itu memberikan 2 kepada orang lain. Berapa kartu Yudi sekarang?
A: Yudi sekarang memiliki 28 - 4 + 18 - 2 = 38 kartu.

Verifikasi: Perhitungan yang benar: 28 - 4 = 24, 24 + 18 = 42, 42 - 2 = 40. Jawaban awal salah.

Jawaban akhir: 40 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Maya memiliki 87 penggaris. Dia meminjamkan 12 kepada teman. Kemudian menerima 11 penggaris. Setelah itu meminjamkan 9 kepada orang lain. Berapa penggaris Maya sekarang?
A: Maya sekarang memiliki 87 - 12 + 11 - 9 = 77 penggaris.

Verifikasi: Perhitungan: 87 - 12 = 75, 75 + 11 = 86, 86 - 9 = 77. Benar.

Jawaban akhir: 77 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
