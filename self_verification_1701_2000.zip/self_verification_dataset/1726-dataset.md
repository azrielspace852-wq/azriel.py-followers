# Dataset Verifikasi Diri 1726

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 82 apel. Dia meminjamkan 4 kepada teman. Kemudian menerima 17 apel. Setelah itu meminjamkan 10 kepada orang lain. Berapa apel Gita sekarang?
A: Gita sekarang memiliki 82 - 4 + 17 - 10 = 83 apel.

Verifikasi: Perhitungan yang benar: 82 - 4 = 78, 78 + 17 = 95, 95 - 10 = 85. Jawaban awal salah.

Jawaban akhir: 85 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 88 rupiah. Dia memberikan 11 kepada teman. Kemudian menerima 7 rupiah. Setelah itu membagi 8 kepada orang lain. Berapa rupiah Eko sekarang?
A: Eko sekarang memiliki 88 - 11 + 7 - 8 = 77 rupiah.

Verifikasi: Perhitungan yang benar: 88 - 11 = 77, 77 + 7 = 84, 84 - 8 = 76. Jawaban awal salah.

Jawaban akhir: 76 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Oscar memiliki 80 kartu. Dia membagi 26 kepada teman. Kemudian mendapat 8 kartu. Setelah itu meminjamkan 6 kepada orang lain. Berapa kartu Oscar sekarang?
A: Oscar sekarang memiliki 80 - 26 + 8 - 6 = 56 kartu.

Verifikasi: Perhitungan: 80 - 26 = 54, 54 + 8 = 62, 62 - 6 = 56. Benar.

Jawaban akhir: 56 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
