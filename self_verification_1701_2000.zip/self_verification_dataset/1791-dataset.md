# Dataset Verifikasi Diri 1791

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 61 rupiah. Dia membagi 4 kepada teman. Kemudian menang 9 rupiah. Setelah itu meminjamkan 3 kepada orang lain. Berapa rupiah Tono sekarang?
A: Tono sekarang memiliki 61 - 4 + 9 - 3 = 63 rupiah.

Verifikasi: Perhitungan: 61 - 4 = 57, 57 + 9 = 66, 66 - 3 = 63. Benar.

Jawaban akhir: 63 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Udin memiliki 68 penghapus. Dia membagi 7 kepada teman. Kemudian membeli 8 penghapus. Setelah itu meminjamkan 7 kepada orang lain. Berapa penghapus Udin sekarang?
A: Udin sekarang memiliki 68 - 7 + 8 - 7 = 62 penghapus.

Verifikasi: Perhitungan: 68 - 7 = 61, 61 + 8 = 69, 69 - 7 = 62. Benar.

Jawaban akhir: 62 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Joko memiliki 42 penggaris. Dia memberikan 9 kepada teman. Kemudian mendapat 20 penggaris. Setelah itu memberikan 1 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 42 - 9 + 20 - 1 = 52 penggaris.

Verifikasi: Perhitungan: 42 - 9 = 33, 33 + 20 = 53, 53 - 1 = 52. Benar.

Jawaban akhir: 52 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
