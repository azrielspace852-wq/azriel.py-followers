# Dataset Verifikasi Diri 1960

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 69 kue. Dia meminjamkan 18 kepada teman. Kemudian menang 18 kue. Setelah itu membagi 8 kepada orang lain. Berapa kue Udin sekarang?
A: Udin sekarang memiliki 69 - 18 + 18 - 8 = 59 kue.

Verifikasi: Perhitungan yang benar: 69 - 18 = 51, 51 + 18 = 69, 69 - 8 = 61. Jawaban awal salah.

Jawaban akhir: 61 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Joko memiliki 16 kelereng. Dia memberikan 2 kepada teman. Kemudian menerima 13 kelereng. Setelah itu membagi 6 kepada orang lain. Berapa kelereng Joko sekarang?
A: Joko sekarang memiliki 16 - 2 + 13 - 6 = 21 kelereng.

Verifikasi: Perhitungan: 16 - 2 = 14, 14 + 13 = 27, 27 - 6 = 21. Benar.

Jawaban akhir: 21 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Kiki memiliki 39 pensil. Dia memberikan 11 kepada teman. Kemudian menang 3 pensil. Setelah itu meminjamkan 8 kepada orang lain. Berapa pensil Kiki sekarang?
A: Kiki sekarang memiliki 39 - 11 + 3 - 8 = 23 pensil.

Verifikasi: Perhitungan: 39 - 11 = 28, 28 + 3 = 31, 31 - 8 = 23. Benar.

Jawaban akhir: 23 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
