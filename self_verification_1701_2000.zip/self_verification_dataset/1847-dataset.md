# Dataset Verifikasi Diri 1847

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 39 rupiah. Dia meminjamkan 1 kepada teman. Kemudian mendapat 19 rupiah. Setelah itu memberikan 13 kepada orang lain. Berapa rupiah Rina sekarang?
A: Rina sekarang memiliki 39 - 1 + 19 - 13 = 44 rupiah.

Verifikasi: Perhitungan: 39 - 1 = 38, 38 + 19 = 57, 57 - 13 = 44. Benar.

Jawaban akhir: 44 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Zaki memiliki 40 kartu. Dia memberikan 12 kepada teman. Kemudian mendapat 18 kartu. Setelah itu membagi 12 kepada orang lain. Berapa kartu Zaki sekarang?
A: Zaki sekarang memiliki 40 - 12 + 18 - 12 = 34 kartu.

Verifikasi: Perhitungan: 40 - 12 = 28, 28 + 18 = 46, 46 - 12 = 34. Benar.

Jawaban akhir: 34 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 37 pulpen. Dia meminjamkan 7 kepada teman. Kemudian menang 19 pulpen. Setelah itu meminjamkan 13 kepada orang lain. Berapa pulpen Indra sekarang?
A: Indra sekarang memiliki 37 - 7 + 19 - 13 = 36 pulpen.

Verifikasi: Perhitungan: 37 - 7 = 30, 30 + 19 = 49, 49 - 13 = 36. Benar.

Jawaban akhir: 36 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
