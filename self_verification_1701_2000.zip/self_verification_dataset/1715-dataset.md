# Dataset Verifikasi Diri 1715

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 42 pulpen. Dia memberikan 14 kepada teman. Kemudian menerima 10 pulpen. Setelah itu membagi 1 kepada orang lain. Berapa pulpen Oscar sekarang?
A: Oscar sekarang memiliki 42 - 14 + 10 - 1 = 37 pulpen.

Verifikasi: Perhitungan: 42 - 14 = 28, 28 + 10 = 38, 38 - 1 = 37. Benar.

Jawaban akhir: 37 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Candra memiliki 53 spidol. Dia memberikan 16 kepada teman. Kemudian mendapat 19 spidol. Setelah itu memberikan 8 kepada orang lain. Berapa spidol Candra sekarang?
A: Candra sekarang memiliki 53 - 16 + 19 - 8 = 48 spidol.

Verifikasi: Perhitungan: 53 - 16 = 37, 37 + 19 = 56, 56 - 8 = 48. Benar.

Jawaban akhir: 48 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Putri memiliki 99 kartu. Dia memberikan 28 kepada teman. Kemudian menerima 5 kartu. Setelah itu meminjamkan 1 kepada orang lain. Berapa kartu Putri sekarang?
A: Putri sekarang memiliki 99 - 28 + 5 - 1 = 74 kartu.

Verifikasi: Perhitungan yang benar: 99 - 28 = 71, 71 + 5 = 76, 76 - 1 = 75. Jawaban awal salah.

Jawaban akhir: 75 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
