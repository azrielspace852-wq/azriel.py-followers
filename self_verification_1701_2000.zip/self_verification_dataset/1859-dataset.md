# Dataset Verifikasi Diri 1859

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 64 pensil. Dia memberikan 16 kepada teman. Kemudian menerima 12 pensil. Setelah itu membagi 6 kepada orang lain. Berapa pensil Zaki sekarang?
A: Zaki sekarang memiliki 64 - 16 + 12 - 6 = 52 pensil.

Verifikasi: Perhitungan yang benar: 64 - 16 = 48, 48 + 12 = 60, 60 - 6 = 54. Jawaban awal salah.

Jawaban akhir: 54 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Joko memiliki 30 buku. Dia memberikan 2 kepada teman. Kemudian mendapat 14 buku. Setelah itu memberikan 14 kepada orang lain. Berapa buku Joko sekarang?
A: Joko sekarang memiliki 30 - 2 + 14 - 14 = 31 buku.

Verifikasi: Perhitungan yang benar: 30 - 2 = 28, 28 + 14 = 42, 42 - 14 = 28. Jawaban awal salah.

Jawaban akhir: 28 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 40 buku tulis. Dia membagi 13 kepada teman. Kemudian mendapat 18 buku tulis. Setelah itu meminjamkan 2 kepada orang lain. Berapa buku tulis Hani sekarang?
A: Hani sekarang memiliki 40 - 13 + 18 - 2 = 43 buku tulis.

Verifikasi: Perhitungan: 40 - 13 = 27, 27 + 18 = 45, 45 - 2 = 43. Benar.

Jawaban akhir: 43 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
