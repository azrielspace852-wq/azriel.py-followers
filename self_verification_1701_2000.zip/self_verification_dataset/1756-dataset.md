# Dataset Verifikasi Diri 1756

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 78 kue. Dia membagi 19 kepada teman. Kemudian menerima 14 kue. Setelah itu memberikan 15 kepada orang lain. Berapa kue Budi sekarang?
A: Budi sekarang memiliki 78 - 19 + 14 - 15 = 60 kue.

Verifikasi: Perhitungan yang benar: 78 - 19 = 59, 59 + 14 = 73, 73 - 15 = 58. Jawaban awal salah.

Jawaban akhir: 58 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Hani memiliki 45 apel. Dia membagi 15 kepada teman. Kemudian mendapat 5 apel. Setelah itu memberikan 15 kepada orang lain. Berapa apel Hani sekarang?
A: Hani sekarang memiliki 45 - 15 + 5 - 15 = 19 apel.

Verifikasi: Perhitungan yang benar: 45 - 15 = 30, 30 + 5 = 35, 35 - 15 = 20. Jawaban awal salah.

Jawaban akhir: 20 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Wati memiliki 50 kertas. Dia meminjamkan 15 kepada teman. Kemudian mendapat 11 kertas. Setelah itu membagi 4 kepada orang lain. Berapa kertas Wati sekarang?
A: Wati sekarang memiliki 50 - 15 + 11 - 4 = 40 kertas.

Verifikasi: Perhitungan yang benar: 50 - 15 = 35, 35 + 11 = 46, 46 - 4 = 42. Jawaban awal salah.

Jawaban akhir: 42 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
