# Dataset Verifikasi Diri 1734

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 87 apel. Dia meminjamkan 21 kepada teman. Kemudian mendapat 12 apel. Setelah itu meminjamkan 1 kepada orang lain. Berapa apel Lina sekarang?
A: Lina sekarang memiliki 87 - 21 + 12 - 1 = 79 apel.

Verifikasi: Perhitungan yang benar: 87 - 21 = 66, 66 + 12 = 78, 78 - 1 = 77. Jawaban awal salah.

Jawaban akhir: 77 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 22 kartu. Dia membagi 4 kepada teman. Kemudian membeli 18 kartu. Setelah itu meminjamkan 4 kepada orang lain. Berapa kartu Udin sekarang?
A: Udin sekarang memiliki 22 - 4 + 18 - 4 = 31 kartu.

Verifikasi: Perhitungan yang benar: 22 - 4 = 18, 18 + 18 = 36, 36 - 4 = 32. Jawaban awal salah.

Jawaban akhir: 32 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 90 kartu. Dia membagi 1 kepada teman. Kemudian membeli 10 kartu. Setelah itu membagi 5 kepada orang lain. Berapa kartu Gita sekarang?
A: Gita sekarang memiliki 90 - 1 + 10 - 5 = 94 kartu.

Verifikasi: Perhitungan: 90 - 1 = 89, 89 + 10 = 99, 99 - 5 = 94. Benar.

Jawaban akhir: 94 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
