# Dataset Verifikasi Diri 1852

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 55 kartu. Dia meminjamkan 9 kepada teman. Kemudian menerima 12 kartu. Setelah itu meminjamkan 8 kepada orang lain. Berapa kartu Fajar sekarang?
A: Fajar sekarang memiliki 55 - 9 + 12 - 8 = 49 kartu.

Verifikasi: Perhitungan yang benar: 55 - 9 = 46, 46 + 12 = 58, 58 - 8 = 50. Jawaban awal salah.

Jawaban akhir: 50 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Joko memiliki 85 apel. Dia meminjamkan 17 kepada teman. Kemudian menerima 15 apel. Setelah itu memberikan 4 kepada orang lain. Berapa apel Joko sekarang?
A: Joko sekarang memiliki 85 - 17 + 15 - 4 = 79 apel.

Verifikasi: Perhitungan: 85 - 17 = 68, 68 + 15 = 83, 83 - 4 = 79. Benar.

Jawaban akhir: 79 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Vina memiliki 74 rupiah. Dia membagi 17 kepada teman. Kemudian menerima 19 rupiah. Setelah itu memberikan 10 kepada orang lain. Berapa rupiah Vina sekarang?
A: Vina sekarang memiliki 74 - 17 + 19 - 10 = 66 rupiah.

Verifikasi: Perhitungan: 74 - 17 = 57, 57 + 19 = 76, 76 - 10 = 66. Benar.

Jawaban akhir: 66 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
