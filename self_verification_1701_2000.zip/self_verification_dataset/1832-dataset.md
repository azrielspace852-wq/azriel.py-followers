# Dataset Verifikasi Diri 1832

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 50 penghapus. Dia meminjamkan 9 kepada teman. Kemudian mendapat 10 penghapus. Setelah itu meminjamkan 7 kepada orang lain. Berapa penghapus Udin sekarang?
A: Udin sekarang memiliki 50 - 9 + 10 - 7 = 44 penghapus.

Verifikasi: Perhitungan: 50 - 9 = 41, 41 + 10 = 51, 51 - 7 = 44. Benar.

Jawaban akhir: 44 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Indra memiliki 23 buku. Dia membagi 3 kepada teman. Kemudian mendapat 5 buku. Setelah itu meminjamkan 9 kepada orang lain. Berapa buku Indra sekarang?
A: Indra sekarang memiliki 23 - 3 + 5 - 9 = 16 buku.

Verifikasi: Perhitungan: 23 - 3 = 20, 20 + 5 = 25, 25 - 9 = 16. Benar.

Jawaban akhir: 16 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Yudi memiliki 78 kertas. Dia meminjamkan 3 kepada teman. Kemudian mendapat 14 kertas. Setelah itu membagi 14 kepada orang lain. Berapa kertas Yudi sekarang?
A: Yudi sekarang memiliki 78 - 3 + 14 - 14 = 75 kertas.

Verifikasi: Perhitungan: 78 - 3 = 75, 75 + 14 = 89, 89 - 14 = 75. Benar.

Jawaban akhir: 75 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
