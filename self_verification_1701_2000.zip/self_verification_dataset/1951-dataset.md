# Dataset Verifikasi Diri 1951

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 32 pulpen. Dia memberikan 3 kepada teman. Kemudian membeli 12 pulpen. Setelah itu memberikan 5 kepada orang lain. Berapa pulpen Joko sekarang?
A: Joko sekarang memiliki 32 - 3 + 12 - 5 = 39 pulpen.

Verifikasi: Perhitungan yang benar: 32 - 3 = 29, 29 + 12 = 41, 41 - 5 = 36. Jawaban awal salah.

Jawaban akhir: 36 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Maya memiliki 92 kartu. Dia membagi 22 kepada teman. Kemudian menang 9 kartu. Setelah itu meminjamkan 14 kepada orang lain. Berapa kartu Maya sekarang?
A: Maya sekarang memiliki 92 - 22 + 9 - 14 = 65 kartu.

Verifikasi: Perhitungan: 92 - 22 = 70, 70 + 9 = 79, 79 - 14 = 65. Benar.

Jawaban akhir: 65 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Zaki memiliki 88 pulpen. Dia meminjamkan 11 kepada teman. Kemudian membeli 12 pulpen. Setelah itu memberikan 2 kepada orang lain. Berapa pulpen Zaki sekarang?
A: Zaki sekarang memiliki 88 - 11 + 12 - 2 = 87 pulpen.

Verifikasi: Perhitungan: 88 - 11 = 77, 77 + 12 = 89, 89 - 2 = 87. Benar.

Jawaban akhir: 87 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
