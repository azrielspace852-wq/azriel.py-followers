# Dataset Verifikasi Diri 1905

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 27 rupiah. Dia meminjamkan 8 kepada teman. Kemudian menang 15 rupiah. Setelah itu memberikan 6 kepada orang lain. Berapa rupiah Oscar sekarang?
A: Oscar sekarang memiliki 27 - 8 + 15 - 6 = 28 rupiah.

Verifikasi: Perhitungan: 27 - 8 = 19, 19 + 15 = 34, 34 - 6 = 28. Benar.

Jawaban akhir: 28 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Vina memiliki 82 apel. Dia memberikan 24 kepada teman. Kemudian menang 18 apel. Setelah itu membagi 14 kepada orang lain. Berapa apel Vina sekarang?
A: Vina sekarang memiliki 82 - 24 + 18 - 14 = 65 apel.

Verifikasi: Perhitungan yang benar: 82 - 24 = 58, 58 + 18 = 76, 76 - 14 = 62. Jawaban awal salah.

Jawaban akhir: 62 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Indra memiliki 75 bola. Dia membagi 3 kepada teman. Kemudian mendapat 17 bola. Setelah itu memberikan 14 kepada orang lain. Berapa bola Indra sekarang?
A: Indra sekarang memiliki 75 - 3 + 17 - 14 = 75 bola.

Verifikasi: Perhitungan: 75 - 3 = 72, 72 + 17 = 89, 89 - 14 = 75. Benar.

Jawaban akhir: 75 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
