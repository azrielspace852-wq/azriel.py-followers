# Dataset Verifikasi Diri 1768

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 92 buku tulis. Dia memberikan 2 kepada teman. Kemudian mendapat 12 buku tulis. Setelah itu meminjamkan 1 kepada orang lain. Berapa buku tulis Zaki sekarang?
A: Zaki sekarang memiliki 92 - 2 + 12 - 1 = 101 buku tulis.

Verifikasi: Perhitungan: 92 - 2 = 90, 90 + 12 = 102, 102 - 1 = 101. Benar.

Jawaban akhir: 101 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Gita memiliki 85 pensil. Dia meminjamkan 2 kepada teman. Kemudian mendapat 5 pensil. Setelah itu meminjamkan 2 kepada orang lain. Berapa pensil Gita sekarang?
A: Gita sekarang memiliki 85 - 2 + 5 - 2 = 85 pensil.

Verifikasi: Perhitungan yang benar: 85 - 2 = 83, 83 + 5 = 88, 88 - 2 = 86. Jawaban awal salah.

Jawaban akhir: 86 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Vina memiliki 70 apel. Dia memberikan 8 kepada teman. Kemudian mendapat 9 apel. Setelah itu membagi 2 kepada orang lain. Berapa apel Vina sekarang?
A: Vina sekarang memiliki 70 - 8 + 9 - 2 = 69 apel.

Verifikasi: Perhitungan: 70 - 8 = 62, 62 + 9 = 71, 71 - 2 = 69. Benar.

Jawaban akhir: 69 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
