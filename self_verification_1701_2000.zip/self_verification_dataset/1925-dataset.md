# Dataset Verifikasi Diri 1925

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 77 rupiah. Dia meminjamkan 9 kepada teman. Kemudian mendapat 13 rupiah. Setelah itu meminjamkan 14 kepada orang lain. Berapa rupiah Yudi sekarang?
A: Yudi sekarang memiliki 77 - 9 + 13 - 14 = 68 rupiah.

Verifikasi: Perhitungan yang benar: 77 - 9 = 68, 68 + 13 = 81, 81 - 14 = 67. Jawaban awal salah.

Jawaban akhir: 67 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 99 kue. Dia memberikan 33 kepada teman. Kemudian mendapat 20 kue. Setelah itu membagi 6 kepada orang lain. Berapa kue Hani sekarang?
A: Hani sekarang memiliki 99 - 33 + 20 - 6 = 80 kue.

Verifikasi: Perhitungan: 99 - 33 = 66, 66 + 20 = 86, 86 - 6 = 80. Benar.

Jawaban akhir: 80 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Dedi memiliki 41 kelereng. Dia memberikan 4 kepada teman. Kemudian membeli 9 kelereng. Setelah itu membagi 8 kepada orang lain. Berapa kelereng Dedi sekarang?
A: Dedi sekarang memiliki 41 - 4 + 9 - 8 = 38 kelereng.

Verifikasi: Perhitungan: 41 - 4 = 37, 37 + 9 = 46, 46 - 8 = 38. Benar.

Jawaban akhir: 38 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
