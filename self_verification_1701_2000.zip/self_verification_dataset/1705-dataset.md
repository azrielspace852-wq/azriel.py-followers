# Dataset Verifikasi Diri 1705

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 99 pensil. Dia membagi 31 kepada teman. Kemudian menerima 3 pensil. Setelah itu memberikan 10 kepada orang lain. Berapa pensil Putri sekarang?
A: Putri sekarang memiliki 99 - 31 + 3 - 10 = 60 pensil.

Verifikasi: Perhitungan yang benar: 99 - 31 = 68, 68 + 3 = 71, 71 - 10 = 61. Jawaban awal salah.

Jawaban akhir: 61 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Fajar memiliki 83 bola. Dia memberikan 2 kepada teman. Kemudian membeli 20 bola. Setelah itu memberikan 3 kepada orang lain. Berapa bola Fajar sekarang?
A: Fajar sekarang memiliki 83 - 2 + 20 - 3 = 98 bola.

Verifikasi: Perhitungan: 83 - 2 = 81, 81 + 20 = 101, 101 - 3 = 98. Benar.

Jawaban akhir: 98 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Dedi memiliki 57 penggaris. Dia memberikan 17 kepada teman. Kemudian menang 17 penggaris. Setelah itu memberikan 14 kepada orang lain. Berapa penggaris Dedi sekarang?
A: Dedi sekarang memiliki 57 - 17 + 17 - 14 = 42 penggaris.

Verifikasi: Perhitungan yang benar: 57 - 17 = 40, 40 + 17 = 57, 57 - 14 = 43. Jawaban awal salah.

Jawaban akhir: 43 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar
