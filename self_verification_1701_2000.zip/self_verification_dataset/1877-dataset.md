# Dataset Verifikasi Diri 1877

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 11 pulpen. Dia meminjamkan 2 kepada teman. Kemudian menang 17 pulpen. Setelah itu membagi 2 kepada orang lain. Berapa pulpen Yudi sekarang?
A: Yudi sekarang memiliki 11 - 2 + 17 - 2 = 24 pulpen.

Verifikasi: Perhitungan: 11 - 2 = 9, 9 + 17 = 26, 26 - 2 = 24. Benar.

Jawaban akhir: 24 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Fajar memiliki 15 spidol. Dia memberikan 1 kepada teman. Kemudian menang 5 spidol. Setelah itu meminjamkan 13 kepada orang lain. Berapa spidol Fajar sekarang?
A: Fajar sekarang memiliki 15 - 1 + 5 - 13 = 4 spidol.

Verifikasi: Perhitungan yang benar: 15 - 1 = 14, 14 + 5 = 19, 19 - 13 = 6. Jawaban awal salah.

Jawaban akhir: 6 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Udin memiliki 33 stiker. Dia memberikan 9 kepada teman. Kemudian menerima 3 stiker. Setelah itu membagi 8 kepada orang lain. Berapa stiker Udin sekarang?
A: Udin sekarang memiliki 33 - 9 + 3 - 8 = 17 stiker.

Verifikasi: Perhitungan yang benar: 33 - 9 = 24, 24 + 3 = 27, 27 - 8 = 19. Jawaban awal salah.

Jawaban akhir: 19 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
