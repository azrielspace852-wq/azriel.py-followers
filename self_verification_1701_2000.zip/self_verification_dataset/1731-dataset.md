# Dataset Verifikasi Diri 1731

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 12 buku tulis. Dia meminjamkan 2 kepada teman. Kemudian menerima 7 buku tulis. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku tulis Wati sekarang?
A: Wati sekarang memiliki 12 - 2 + 7 - 11 = 6 buku tulis.

Verifikasi: Perhitungan: 12 - 2 = 10, 10 + 7 = 17, 17 - 11 = 6. Benar.

Jawaban akhir: 6 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Joko memiliki 14 kartu. Dia memberikan 1 kepada teman. Kemudian mendapat 17 kartu. Setelah itu memberikan 11 kepada orang lain. Berapa kartu Joko sekarang?
A: Joko sekarang memiliki 14 - 1 + 17 - 11 = 18 kartu.

Verifikasi: Perhitungan yang benar: 14 - 1 = 13, 13 + 17 = 30, 30 - 11 = 19. Jawaban awal salah.

Jawaban akhir: 19 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 57 rupiah. Dia membagi 1 kepada teman. Kemudian menang 15 rupiah. Setelah itu meminjamkan 4 kepada orang lain. Berapa rupiah Oscar sekarang?
A: Oscar sekarang memiliki 57 - 1 + 15 - 4 = 67 rupiah.

Verifikasi: Perhitungan: 57 - 1 = 56, 56 + 15 = 71, 71 - 4 = 67. Benar.

Jawaban akhir: 67 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
