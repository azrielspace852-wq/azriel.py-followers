# Dataset Verifikasi Diri 1944

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 11 apel. Dia memberikan 3 kepada teman. Kemudian mendapat 4 apel. Setelah itu membagi 3 kepada orang lain. Berapa apel Udin sekarang?
A: Udin sekarang memiliki 11 - 3 + 4 - 3 = 9 apel.

Verifikasi: Perhitungan: 11 - 3 = 8, 8 + 4 = 12, 12 - 3 = 9. Benar.

Jawaban akhir: 9 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Fajar memiliki 91 kelereng. Dia meminjamkan 30 kepada teman. Kemudian menang 3 kelereng. Setelah itu memberikan 2 kepada orang lain. Berapa kelereng Fajar sekarang?
A: Fajar sekarang memiliki 91 - 30 + 3 - 2 = 62 kelereng.

Verifikasi: Perhitungan: 91 - 30 = 61, 61 + 3 = 64, 64 - 2 = 62. Benar.

Jawaban akhir: 62 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Putri memiliki 39 spidol. Dia memberikan 1 kepada teman. Kemudian menang 11 spidol. Setelah itu meminjamkan 2 kepada orang lain. Berapa spidol Putri sekarang?
A: Putri sekarang memiliki 39 - 1 + 11 - 2 = 48 spidol.

Verifikasi: Perhitungan yang benar: 39 - 1 = 38, 38 + 11 = 49, 49 - 2 = 47. Jawaban awal salah.

Jawaban akhir: 47 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
