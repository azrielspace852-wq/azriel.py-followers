# Dataset Verifikasi Diri 1976

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 81 pensil. Dia meminjamkan 21 kepada teman. Kemudian menerima 14 pensil. Setelah itu memberikan 5 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 81 - 21 + 14 - 5 = 69 pensil.

Verifikasi: Perhitungan: 81 - 21 = 60, 60 + 14 = 74, 74 - 5 = 69. Benar.

Jawaban akhir: 69 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Oscar memiliki 56 kartu. Dia meminjamkan 8 kepada teman. Kemudian membeli 20 kartu. Setelah itu memberikan 13 kepada orang lain. Berapa kartu Oscar sekarang?
A: Oscar sekarang memiliki 56 - 8 + 20 - 13 = 56 kartu.

Verifikasi: Perhitungan yang benar: 56 - 8 = 48, 48 + 20 = 68, 68 - 13 = 55. Jawaban awal salah.

Jawaban akhir: 55 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Lina memiliki 67 bola. Dia membagi 11 kepada teman. Kemudian membeli 18 bola. Setelah itu memberikan 4 kepada orang lain. Berapa bola Lina sekarang?
A: Lina sekarang memiliki 67 - 11 + 18 - 4 = 70 bola.

Verifikasi: Perhitungan: 67 - 11 = 56, 56 + 18 = 74, 74 - 4 = 70. Benar.

Jawaban akhir: 70 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
