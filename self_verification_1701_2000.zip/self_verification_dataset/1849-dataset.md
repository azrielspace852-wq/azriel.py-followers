# Dataset Verifikasi Diri 1849

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 36 pulpen. Dia membagi 12 kepada teman. Kemudian mendapat 19 pulpen. Setelah itu meminjamkan 8 kepada orang lain. Berapa pulpen Eko sekarang?
A: Eko sekarang memiliki 36 - 12 + 19 - 8 = 35 pulpen.

Verifikasi: Perhitungan: 36 - 12 = 24, 24 + 19 = 43, 43 - 8 = 35. Benar.

Jawaban akhir: 35 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Eko memiliki 47 kue. Dia membagi 2 kepada teman. Kemudian menerima 9 kue. Setelah itu meminjamkan 1 kepada orang lain. Berapa kue Eko sekarang?
A: Eko sekarang memiliki 47 - 2 + 9 - 1 = 53 kue.

Verifikasi: Perhitungan: 47 - 2 = 45, 45 + 9 = 54, 54 - 1 = 53. Benar.

Jawaban akhir: 53 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Wati memiliki 73 kue. Dia memberikan 14 kepada teman. Kemudian menang 13 kue. Setelah itu meminjamkan 9 kepada orang lain. Berapa kue Wati sekarang?
A: Wati sekarang memiliki 73 - 14 + 13 - 9 = 62 kue.

Verifikasi: Perhitungan yang benar: 73 - 14 = 59, 59 + 13 = 72, 72 - 9 = 63. Jawaban awal salah.

Jawaban akhir: 63 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
