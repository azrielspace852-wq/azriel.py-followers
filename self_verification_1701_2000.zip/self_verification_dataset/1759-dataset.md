# Dataset Verifikasi Diri 1759

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 99 pulpen. Dia meminjamkan 4 kepada teman. Kemudian membeli 20 pulpen. Setelah itu memberikan 1 kepada orang lain. Berapa pulpen Udin sekarang?
A: Udin sekarang memiliki 99 - 4 + 20 - 1 = 116 pulpen.

Verifikasi: Perhitungan yang benar: 99 - 4 = 95, 95 + 20 = 115, 115 - 1 = 114. Jawaban awal salah.

Jawaban akhir: 114 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Eko memiliki 97 pensil. Dia membagi 8 kepada teman. Kemudian mendapat 3 pensil. Setelah itu membagi 14 kepada orang lain. Berapa pensil Eko sekarang?
A: Eko sekarang memiliki 97 - 8 + 3 - 14 = 79 pensil.

Verifikasi: Perhitungan yang benar: 97 - 8 = 89, 89 + 3 = 92, 92 - 14 = 78. Jawaban awal salah.

Jawaban akhir: 78 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Rina memiliki 62 bola. Dia membagi 2 kepada teman. Kemudian menerima 8 bola. Setelah itu meminjamkan 4 kepada orang lain. Berapa bola Rina sekarang?
A: Rina sekarang memiliki 62 - 2 + 8 - 4 = 64 bola.

Verifikasi: Perhitungan: 62 - 2 = 60, 60 + 8 = 68, 68 - 4 = 64. Benar.

Jawaban akhir: 64 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
