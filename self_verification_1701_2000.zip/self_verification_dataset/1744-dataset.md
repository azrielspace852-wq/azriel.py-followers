# Dataset Verifikasi Diri 1744

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 66 kartu. Dia memberikan 20 kepada teman. Kemudian mendapat 5 kartu. Setelah itu membagi 13 kepada orang lain. Berapa kartu Joko sekarang?
A: Joko sekarang memiliki 66 - 20 + 5 - 13 = 39 kartu.

Verifikasi: Perhitungan yang benar: 66 - 20 = 46, 46 + 5 = 51, 51 - 13 = 38. Jawaban awal salah.

Jawaban akhir: 38 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Dedi memiliki 66 buku. Dia meminjamkan 18 kepada teman. Kemudian menang 12 buku. Setelah itu memberikan 14 kepada orang lain. Berapa buku Dedi sekarang?
A: Dedi sekarang memiliki 66 - 18 + 12 - 14 = 44 buku.

Verifikasi: Perhitungan yang benar: 66 - 18 = 48, 48 + 12 = 60, 60 - 14 = 46. Jawaban awal salah.

Jawaban akhir: 46 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Budi memiliki 56 pensil. Dia memberikan 15 kepada teman. Kemudian membeli 18 pensil. Setelah itu membagi 3 kepada orang lain. Berapa pensil Budi sekarang?
A: Budi sekarang memiliki 56 - 15 + 18 - 3 = 57 pensil.

Verifikasi: Perhitungan yang benar: 56 - 15 = 41, 41 + 18 = 59, 59 - 3 = 56. Jawaban awal salah.

Jawaban akhir: 56 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
