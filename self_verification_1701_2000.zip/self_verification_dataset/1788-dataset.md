# Dataset Verifikasi Diri 1788

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 15 pulpen. Dia memberikan 4 kepada teman. Kemudian menang 13 pulpen. Setelah itu meminjamkan 5 kepada orang lain. Berapa pulpen Oscar sekarang?
A: Oscar sekarang memiliki 15 - 4 + 13 - 5 = 19 pulpen.

Verifikasi: Perhitungan: 15 - 4 = 11, 11 + 13 = 24, 24 - 5 = 19. Benar.

Jawaban akhir: 19 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Kiki memiliki 78 rupiah. Dia membagi 4 kepada teman. Kemudian mendapat 20 rupiah. Setelah itu membagi 3 kepada orang lain. Berapa rupiah Kiki sekarang?
A: Kiki sekarang memiliki 78 - 4 + 20 - 3 = 92 rupiah.

Verifikasi: Perhitungan yang benar: 78 - 4 = 74, 74 + 20 = 94, 94 - 3 = 91. Jawaban awal salah.

Jawaban akhir: 91 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Siti memiliki 15 penggaris. Dia membagi 3 kepada teman. Kemudian menang 18 penggaris. Setelah itu meminjamkan 2 kepada orang lain. Berapa penggaris Siti sekarang?
A: Siti sekarang memiliki 15 - 3 + 18 - 2 = 28 penggaris.

Verifikasi: Perhitungan: 15 - 3 = 12, 12 + 18 = 30, 30 - 2 = 28. Benar.

Jawaban akhir: 28 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar
