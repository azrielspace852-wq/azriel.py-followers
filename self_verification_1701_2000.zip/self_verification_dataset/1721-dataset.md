# Dataset Verifikasi Diri 1721

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 11 kertas. Dia meminjamkan 3 kepada teman. Kemudian membeli 12 kertas. Setelah itu meminjamkan 5 kepada orang lain. Berapa kertas Kiki sekarang?
A: Kiki sekarang memiliki 11 - 3 + 12 - 5 = 15 kertas.

Verifikasi: Perhitungan: 11 - 3 = 8, 8 + 12 = 20, 20 - 5 = 15. Benar.

Jawaban akhir: 15 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 35 apel. Dia membagi 8 kepada teman. Kemudian mendapat 12 apel. Setelah itu meminjamkan 1 kepada orang lain. Berapa apel Eko sekarang?
A: Eko sekarang memiliki 35 - 8 + 12 - 1 = 38 apel.

Verifikasi: Perhitungan: 35 - 8 = 27, 27 + 12 = 39, 39 - 1 = 38. Benar.

Jawaban akhir: 38 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 61 stiker. Dia memberikan 3 kepada teman. Kemudian menerima 1 stiker. Setelah itu membagi 14 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 61 - 3 + 1 - 14 = 45 stiker.

Verifikasi: Perhitungan: 61 - 3 = 58, 58 + 1 = 59, 59 - 14 = 45. Benar.

Jawaban akhir: 45 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
