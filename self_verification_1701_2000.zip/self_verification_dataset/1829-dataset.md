# Dataset Verifikasi Diri 1829

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 44 apel. Dia meminjamkan 6 kepada teman. Kemudian menerima 2 apel. Setelah itu meminjamkan 8 kepada orang lain. Berapa apel Fajar sekarang?
A: Fajar sekarang memiliki 44 - 6 + 2 - 8 = 31 apel.

Verifikasi: Perhitungan yang benar: 44 - 6 = 38, 38 + 2 = 40, 40 - 8 = 32. Jawaban awal salah.

Jawaban akhir: 32 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Joko memiliki 55 penggaris. Dia memberikan 6 kepada teman. Kemudian menerima 20 penggaris. Setelah itu meminjamkan 11 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 55 - 6 + 20 - 11 = 58 penggaris.

Verifikasi: Perhitungan: 55 - 6 = 49, 49 + 20 = 69, 69 - 11 = 58. Benar.

Jawaban akhir: 58 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Andi memiliki 50 pulpen. Dia memberikan 10 kepada teman. Kemudian mendapat 11 pulpen. Setelah itu meminjamkan 12 kepada orang lain. Berapa pulpen Andi sekarang?
A: Andi sekarang memiliki 50 - 10 + 11 - 12 = 40 pulpen.

Verifikasi: Perhitungan yang benar: 50 - 10 = 40, 40 + 11 = 51, 51 - 12 = 39. Jawaban awal salah.

Jawaban akhir: 39 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
