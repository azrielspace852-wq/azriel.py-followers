# Dataset Verifikasi Diri 1719

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 45 penggaris. Dia membagi 14 kepada teman. Kemudian mendapat 16 penggaris. Setelah itu membagi 6 kepada orang lain. Berapa penggaris Siti sekarang?
A: Siti sekarang memiliki 45 - 14 + 16 - 6 = 41 penggaris.

Verifikasi: Perhitungan: 45 - 14 = 31, 31 + 16 = 47, 47 - 6 = 41. Benar.

Jawaban akhir: 41 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 59 buku. Dia memberikan 19 kepada teman. Kemudian mendapat 16 buku. Setelah itu memberikan 7 kepada orang lain. Berapa buku Udin sekarang?
A: Udin sekarang memiliki 59 - 19 + 16 - 7 = 48 buku.

Verifikasi: Perhitungan yang benar: 59 - 19 = 40, 40 + 16 = 56, 56 - 7 = 49. Jawaban awal salah.

Jawaban akhir: 49 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 22 buku. Dia memberikan 1 kepada teman. Kemudian membeli 9 buku. Setelah itu meminjamkan 9 kepada orang lain. Berapa buku Indra sekarang?
A: Indra sekarang memiliki 22 - 1 + 9 - 9 = 21 buku.

Verifikasi: Perhitungan: 22 - 1 = 21, 21 + 9 = 30, 30 - 9 = 21. Benar.

Jawaban akhir: 21 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
