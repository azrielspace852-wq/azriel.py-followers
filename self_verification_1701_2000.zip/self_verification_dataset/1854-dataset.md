# Dataset Verifikasi Diri 1854

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 75 kertas. Dia membagi 17 kepada teman. Kemudian membeli 1 kertas. Setelah itu membagi 9 kepada orang lain. Berapa kertas Budi sekarang?
A: Budi sekarang memiliki 75 - 17 + 1 - 9 = 50 kertas.

Verifikasi: Perhitungan: 75 - 17 = 58, 58 + 1 = 59, 59 - 9 = 50. Benar.

Jawaban akhir: 50 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Nina memiliki 38 kelereng. Dia membagi 11 kepada teman. Kemudian menerima 16 kelereng. Setelah itu meminjamkan 3 kepada orang lain. Berapa kelereng Nina sekarang?
A: Nina sekarang memiliki 38 - 11 + 16 - 3 = 40 kelereng.

Verifikasi: Perhitungan: 38 - 11 = 27, 27 + 16 = 43, 43 - 3 = 40. Benar.

Jawaban akhir: 40 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 97 kartu. Dia memberikan 29 kepada teman. Kemudian mendapat 11 kartu. Setelah itu meminjamkan 1 kepada orang lain. Berapa kartu Indra sekarang?
A: Indra sekarang memiliki 97 - 29 + 11 - 1 = 78 kartu.

Verifikasi: Perhitungan: 97 - 29 = 68, 68 + 11 = 79, 79 - 1 = 78. Benar.

Jawaban akhir: 78 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
