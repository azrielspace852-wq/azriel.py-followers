# Dataset Verifikasi Diri 1939

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 96 kelereng. Dia membagi 24 kepada teman. Kemudian menang 7 kelereng. Setelah itu memberikan 11 kepada orang lain. Berapa kelereng Hani sekarang?
A: Hani sekarang memiliki 96 - 24 + 7 - 11 = 68 kelereng.

Verifikasi: Perhitungan: 96 - 24 = 72, 72 + 7 = 79, 79 - 11 = 68. Benar.

Jawaban akhir: 68 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 99 kelereng. Dia memberikan 18 kepada teman. Kemudian mendapat 4 kelereng. Setelah itu membagi 7 kepada orang lain. Berapa kelereng Indra sekarang?
A: Indra sekarang memiliki 99 - 18 + 4 - 7 = 78 kelereng.

Verifikasi: Perhitungan: 99 - 18 = 81, 81 + 4 = 85, 85 - 7 = 78. Benar.

Jawaban akhir: 78 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Budi memiliki 19 kue. Dia memberikan 2 kepada teman. Kemudian mendapat 7 kue. Setelah itu membagi 8 kepada orang lain. Berapa kue Budi sekarang?
A: Budi sekarang memiliki 19 - 2 + 7 - 8 = 16 kue.

Verifikasi: Perhitungan: 19 - 2 = 17, 17 + 7 = 24, 24 - 8 = 16. Benar.

Jawaban akhir: 16 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
