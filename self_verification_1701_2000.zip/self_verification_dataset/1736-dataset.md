# Dataset Verifikasi Diri 1736

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 46 rupiah. Dia membagi 1 kepada teman. Kemudian menerima 20 rupiah. Setelah itu meminjamkan 12 kepada orang lain. Berapa rupiah Candra sekarang?
A: Candra sekarang memiliki 46 - 1 + 20 - 12 = 54 rupiah.

Verifikasi: Perhitungan yang benar: 46 - 1 = 45, 45 + 20 = 65, 65 - 12 = 53. Jawaban awal salah.

Jawaban akhir: 53 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Oscar memiliki 12 pensil. Dia meminjamkan 1 kepada teman. Kemudian membeli 8 pensil. Setelah itu membagi 9 kepada orang lain. Berapa pensil Oscar sekarang?
A: Oscar sekarang memiliki 12 - 1 + 8 - 9 = 12 pensil.

Verifikasi: Perhitungan yang benar: 12 - 1 = 11, 11 + 8 = 19, 19 - 9 = 10. Jawaban awal salah.

Jawaban akhir: 10 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Yudi memiliki 14 bola. Dia membagi 4 kepada teman. Kemudian menerima 20 bola. Setelah itu membagi 13 kepada orang lain. Berapa bola Yudi sekarang?
A: Yudi sekarang memiliki 14 - 4 + 20 - 13 = 17 bola.

Verifikasi: Perhitungan: 14 - 4 = 10, 10 + 20 = 30, 30 - 13 = 17. Benar.

Jawaban akhir: 17 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A dan B. Apakah A?
A: Ya, A.

Verifikasi: Ya, konjungsi eliminasi.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
