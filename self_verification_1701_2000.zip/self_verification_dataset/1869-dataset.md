# Dataset Verifikasi Diri 1869

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 14 kertas. Dia meminjamkan 3 kepada teman. Kemudian mendapat 10 kertas. Setelah itu memberikan 15 kepada orang lain. Berapa kertas Wati sekarang?
A: Wati sekarang memiliki 14 - 3 + 10 - 15 = 4 kertas.

Verifikasi: Perhitungan yang benar: 14 - 3 = 11, 11 + 10 = 21, 21 - 15 = 6. Jawaban awal salah.

Jawaban akhir: 6 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Maya memiliki 58 kelereng. Dia meminjamkan 7 kepada teman. Kemudian membeli 6 kelereng. Setelah itu meminjamkan 4 kepada orang lain. Berapa kelereng Maya sekarang?
A: Maya sekarang memiliki 58 - 7 + 6 - 4 = 53 kelereng.

Verifikasi: Perhitungan: 58 - 7 = 51, 51 + 6 = 57, 57 - 4 = 53. Benar.

Jawaban akhir: 53 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Andi memiliki 64 apel. Dia memberikan 1 kepada teman. Kemudian mendapat 1 apel. Setelah itu membagi 13 kepada orang lain. Berapa apel Andi sekarang?
A: Andi sekarang memiliki 64 - 1 + 1 - 13 = 51 apel.

Verifikasi: Perhitungan: 64 - 1 = 63, 63 + 1 = 64, 64 - 13 = 51. Benar.

Jawaban akhir: 51 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
