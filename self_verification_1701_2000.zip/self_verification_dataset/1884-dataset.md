# Dataset Verifikasi Diri 1884

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 89 buku tulis. Dia memberikan 9 kepada teman. Kemudian menang 8 buku tulis. Setelah itu memberikan 4 kepada orang lain. Berapa buku tulis Udin sekarang?
A: Udin sekarang memiliki 89 - 9 + 8 - 4 = 84 buku tulis.

Verifikasi: Perhitungan: 89 - 9 = 80, 80 + 8 = 88, 88 - 4 = 84. Benar.

Jawaban akhir: 84 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Lina memiliki 97 spidol. Dia meminjamkan 20 kepada teman. Kemudian mendapat 11 spidol. Setelah itu meminjamkan 9 kepada orang lain. Berapa spidol Lina sekarang?
A: Lina sekarang memiliki 97 - 20 + 11 - 9 = 80 spidol.

Verifikasi: Perhitungan yang benar: 97 - 20 = 77, 77 + 11 = 88, 88 - 9 = 79. Jawaban awal salah.

Jawaban akhir: 79 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Candra memiliki 61 stiker. Dia memberikan 14 kepada teman. Kemudian menang 16 stiker. Setelah itu meminjamkan 14 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 61 - 14 + 16 - 14 = 48 stiker.

Verifikasi: Perhitungan yang benar: 61 - 14 = 47, 47 + 16 = 63, 63 - 14 = 49. Jawaban awal salah.

Jawaban akhir: 49 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
