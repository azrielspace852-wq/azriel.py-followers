# Dataset Verifikasi Diri 1800

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 82 buku. Dia meminjamkan 13 kepada teman. Kemudian menang 10 buku. Setelah itu memberikan 10 kepada orang lain. Berapa buku Eko sekarang?
A: Eko sekarang memiliki 82 - 13 + 10 - 10 = 69 buku.

Verifikasi: Perhitungan: 82 - 13 = 69, 69 + 10 = 79, 79 - 10 = 69. Benar.

Jawaban akhir: 69 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Fajar memiliki 53 buku. Dia meminjamkan 6 kepada teman. Kemudian menang 17 buku. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 53 - 6 + 17 - 11 = 54 buku.

Verifikasi: Perhitungan yang benar: 53 - 6 = 47, 47 + 17 = 64, 64 - 11 = 53. Jawaban awal salah.

Jawaban akhir: 53 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 72 stiker. Dia meminjamkan 16 kepada teman. Kemudian menang 12 stiker. Setelah itu meminjamkan 15 kepada orang lain. Berapa stiker Indra sekarang?
A: Indra sekarang memiliki 72 - 16 + 12 - 15 = 53 stiker.

Verifikasi: Perhitungan: 72 - 16 = 56, 56 + 12 = 68, 68 - 15 = 53. Benar.

Jawaban akhir: 53 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
