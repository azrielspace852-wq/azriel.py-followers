# Dataset Verifikasi Diri 1881

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Hani memiliki 51 buku tulis. Dia meminjamkan 1 kepada teman. Kemudian mendapat 5 buku tulis. Setelah itu meminjamkan 15 kepada orang lain. Berapa buku tulis Hani sekarang?
A: Hani sekarang memiliki 51 - 1 + 5 - 15 = 40 buku tulis.

Verifikasi: Perhitungan: 51 - 1 = 50, 50 + 5 = 55, 55 - 15 = 40. Benar.

Jawaban akhir: 40 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Siti memiliki 40 kertas. Dia memberikan 3 kepada teman. Kemudian membeli 10 kertas. Setelah itu memberikan 6 kepada orang lain. Berapa kertas Siti sekarang?
A: Siti sekarang memiliki 40 - 3 + 10 - 6 = 41 kertas.

Verifikasi: Perhitungan: 40 - 3 = 37, 37 + 10 = 47, 47 - 6 = 41. Benar.

Jawaban akhir: 41 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Candra memiliki 84 kelereng. Dia membagi 4 kepada teman. Kemudian menang 15 kelereng. Setelah itu memberikan 12 kepada orang lain. Berapa kelereng Candra sekarang?
A: Candra sekarang memiliki 84 - 4 + 15 - 12 = 86 kelereng.

Verifikasi: Perhitungan yang benar: 84 - 4 = 80, 80 + 15 = 95, 95 - 12 = 83. Jawaban awal salah.

Jawaban akhir: 83 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
