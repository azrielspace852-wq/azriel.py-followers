# Dataset Verifikasi Diri 1914

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 69 buku tulis. Dia meminjamkan 13 kepada teman. Kemudian mendapat 4 buku tulis. Setelah itu meminjamkan 12 kepada orang lain. Berapa buku tulis Dedi sekarang?
A: Dedi sekarang memiliki 69 - 13 + 4 - 12 = 48 buku tulis.

Verifikasi: Perhitungan: 69 - 13 = 56, 56 + 4 = 60, 60 - 12 = 48. Benar.

Jawaban akhir: 48 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Lina memiliki 26 stiker. Dia memberikan 5 kepada teman. Kemudian menerima 9 stiker. Setelah itu memberikan 10 kepada orang lain. Berapa stiker Lina sekarang?
A: Lina sekarang memiliki 26 - 5 + 9 - 10 = 20 stiker.

Verifikasi: Perhitungan: 26 - 5 = 21, 21 + 9 = 30, 30 - 10 = 20. Benar.

Jawaban akhir: 20 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Kiki memiliki 78 apel. Dia memberikan 19 kepada teman. Kemudian menerima 3 apel. Setelah itu memberikan 3 kepada orang lain. Berapa apel Kiki sekarang?
A: Kiki sekarang memiliki 78 - 19 + 3 - 3 = 59 apel.

Verifikasi: Perhitungan: 78 - 19 = 59, 59 + 3 = 62, 62 - 3 = 59. Benar.

Jawaban akhir: 59 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
