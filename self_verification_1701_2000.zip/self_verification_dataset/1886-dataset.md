# Dataset Verifikasi Diri 1886

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 59 penggaris. Dia membagi 11 kepada teman. Kemudian mendapat 4 penggaris. Setelah itu memberikan 3 kepada orang lain. Berapa penggaris Tono sekarang?
A: Tono sekarang memiliki 59 - 11 + 4 - 3 = 52 penggaris.

Verifikasi: Perhitungan yang benar: 59 - 11 = 48, 48 + 4 = 52, 52 - 3 = 49. Jawaban awal salah.

Jawaban akhir: 49 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Candra memiliki 86 stiker. Dia meminjamkan 19 kepada teman. Kemudian mendapat 20 stiker. Setelah itu membagi 14 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 86 - 19 + 20 - 14 = 73 stiker.

Verifikasi: Perhitungan: 86 - 19 = 67, 67 + 20 = 87, 87 - 14 = 73. Benar.

Jawaban akhir: 73 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 79 penggaris. Dia membagi 18 kepada teman. Kemudian menang 16 penggaris. Setelah itu membagi 3 kepada orang lain. Berapa penggaris Candra sekarang?
A: Candra sekarang memiliki 79 - 18 + 16 - 3 = 74 penggaris.

Verifikasi: Perhitungan: 79 - 18 = 61, 61 + 16 = 77, 77 - 3 = 74. Benar.

Jawaban akhir: 74 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
