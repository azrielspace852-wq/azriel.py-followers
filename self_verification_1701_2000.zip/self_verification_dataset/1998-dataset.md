# Dataset Verifikasi Diri 1998

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 59 kue. Dia meminjamkan 9 kepada teman. Kemudian mendapat 9 kue. Setelah itu memberikan 15 kepada orang lain. Berapa kue Rina sekarang?
A: Rina sekarang memiliki 59 - 9 + 9 - 15 = 44 kue.

Verifikasi: Perhitungan: 59 - 9 = 50, 50 + 9 = 59, 59 - 15 = 44. Benar.

Jawaban akhir: 44 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Yudi memiliki 90 buku. Dia memberikan 26 kepada teman. Kemudian menang 7 buku. Setelah itu memberikan 13 kepada orang lain. Berapa buku Yudi sekarang?
A: Yudi sekarang memiliki 90 - 26 + 7 - 13 = 59 buku.

Verifikasi: Perhitungan yang benar: 90 - 26 = 64, 64 + 7 = 71, 71 - 13 = 58. Jawaban awal salah.

Jawaban akhir: 58 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Candra memiliki 41 bola. Dia meminjamkan 11 kepada teman. Kemudian mendapat 12 bola. Setelah itu membagi 10 kepada orang lain. Berapa bola Candra sekarang?
A: Candra sekarang memiliki 41 - 11 + 12 - 10 = 33 bola.

Verifikasi: Perhitungan yang benar: 41 - 11 = 30, 30 + 12 = 42, 42 - 10 = 32. Jawaban awal salah.

Jawaban akhir: 32 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
