# Dataset Verifikasi Diri 1745

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 54 kartu. Dia memberikan 10 kepada teman. Kemudian membeli 2 kartu. Setelah itu membagi 13 kepada orang lain. Berapa kartu Oscar sekarang?
A: Oscar sekarang memiliki 54 - 10 + 2 - 13 = 35 kartu.

Verifikasi: Perhitungan yang benar: 54 - 10 = 44, 44 + 2 = 46, 46 - 13 = 33. Jawaban awal salah.

Jawaban akhir: 33 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Udin memiliki 57 kelereng. Dia membagi 9 kepada teman. Kemudian membeli 20 kelereng. Setelah itu memberikan 4 kepada orang lain. Berapa kelereng Udin sekarang?
A: Udin sekarang memiliki 57 - 9 + 20 - 4 = 64 kelereng.

Verifikasi: Perhitungan: 57 - 9 = 48, 48 + 20 = 68, 68 - 4 = 64. Benar.

Jawaban akhir: 64 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Fajar memiliki 42 pulpen. Dia meminjamkan 5 kepada teman. Kemudian mendapat 16 pulpen. Setelah itu meminjamkan 5 kepada orang lain. Berapa pulpen Fajar sekarang?
A: Fajar sekarang memiliki 42 - 5 + 16 - 5 = 50 pulpen.

Verifikasi: Perhitungan yang benar: 42 - 5 = 37, 37 + 16 = 53, 53 - 5 = 48. Jawaban awal salah.

Jawaban akhir: 48 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
