# Dataset Verifikasi Diri 1894

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 85 kue. Dia membagi 26 kepada teman. Kemudian menerima 8 kue. Setelah itu membagi 14 kepada orang lain. Berapa kue Budi sekarang?
A: Budi sekarang memiliki 85 - 26 + 8 - 14 = 53 kue.

Verifikasi: Perhitungan: 85 - 26 = 59, 59 + 8 = 67, 67 - 14 = 53. Benar.

Jawaban akhir: 53 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Indra memiliki 83 pensil. Dia memberikan 25 kepada teman. Kemudian mendapat 16 pensil. Setelah itu membagi 8 kepada orang lain. Berapa pensil Indra sekarang?
A: Indra sekarang memiliki 83 - 25 + 16 - 8 = 66 pensil.

Verifikasi: Perhitungan: 83 - 25 = 58, 58 + 16 = 74, 74 - 8 = 66. Benar.

Jawaban akhir: 66 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 64 kue. Dia membagi 5 kepada teman. Kemudian menang 14 kue. Setelah itu membagi 15 kepada orang lain. Berapa kue Hani sekarang?
A: Hani sekarang memiliki 64 - 5 + 14 - 15 = 58 kue.

Verifikasi: Perhitungan: 64 - 5 = 59, 59 + 14 = 73, 73 - 15 = 58. Benar.

Jawaban akhir: 58 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
