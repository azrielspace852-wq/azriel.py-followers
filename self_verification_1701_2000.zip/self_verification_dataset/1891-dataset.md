# Dataset Verifikasi Diri 1891

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 88 spidol. Dia membagi 1 kepada teman. Kemudian menang 19 spidol. Setelah itu memberikan 13 kepada orang lain. Berapa spidol Yudi sekarang?
A: Yudi sekarang memiliki 88 - 1 + 19 - 13 = 93 spidol.

Verifikasi: Perhitungan: 88 - 1 = 87, 87 + 19 = 106, 106 - 13 = 93. Benar.

Jawaban akhir: 93 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Nina memiliki 86 kartu. Dia memberikan 25 kepada teman. Kemudian menerima 4 kartu. Setelah itu meminjamkan 12 kepada orang lain. Berapa kartu Nina sekarang?
A: Nina sekarang memiliki 86 - 25 + 4 - 12 = 55 kartu.

Verifikasi: Perhitungan yang benar: 86 - 25 = 61, 61 + 4 = 65, 65 - 12 = 53. Jawaban awal salah.

Jawaban akhir: 53 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Udin memiliki 73 penggaris. Dia memberikan 4 kepada teman. Kemudian menerima 8 penggaris. Setelah itu meminjamkan 2 kepada orang lain. Berapa penggaris Udin sekarang?
A: Udin sekarang memiliki 73 - 4 + 8 - 2 = 75 penggaris.

Verifikasi: Perhitungan: 73 - 4 = 69, 69 + 8 = 77, 77 - 2 = 75. Benar.

Jawaban akhir: 75 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar
