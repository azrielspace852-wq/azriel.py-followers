# Dataset Verifikasi Diri 1980

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 57 kelereng. Dia memberikan 13 kepada teman. Kemudian membeli 7 kelereng. Setelah itu membagi 1 kepada orang lain. Berapa kelereng Dedi sekarang?
A: Dedi sekarang memiliki 57 - 13 + 7 - 1 = 51 kelereng.

Verifikasi: Perhitungan yang benar: 57 - 13 = 44, 44 + 7 = 51, 51 - 1 = 50. Jawaban awal salah.

Jawaban akhir: 50 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 27 rupiah. Dia membagi 3 kepada teman. Kemudian mendapat 16 rupiah. Setelah itu memberikan 15 kepada orang lain. Berapa rupiah Vina sekarang?
A: Vina sekarang memiliki 27 - 3 + 16 - 15 = 25 rupiah.

Verifikasi: Perhitungan: 27 - 3 = 24, 24 + 16 = 40, 40 - 15 = 25. Benar.

Jawaban akhir: 25 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 95 bola. Dia memberikan 27 kepada teman. Kemudian mendapat 13 bola. Setelah itu meminjamkan 7 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 95 - 27 + 13 - 7 = 74 bola.

Verifikasi: Perhitungan: 95 - 27 = 68, 68 + 13 = 81, 81 - 7 = 74. Benar.

Jawaban akhir: 74 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
