# Dataset Verifikasi Diri 1892

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Budi memiliki 41 pensil. Dia membagi 6 kepada teman. Kemudian menang 18 pensil. Setelah itu membagi 8 kepada orang lain. Berapa pensil Budi sekarang?
A: Budi sekarang memiliki 41 - 6 + 18 - 8 = 45 pensil.

Verifikasi: Perhitungan: 41 - 6 = 35, 35 + 18 = 53, 53 - 8 = 45. Benar.

Jawaban akhir: 45 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Budi memiliki 51 buku tulis. Dia memberikan 5 kepada teman. Kemudian membeli 16 buku tulis. Setelah itu meminjamkan 12 kepada orang lain. Berapa buku tulis Budi sekarang?
A: Budi sekarang memiliki 51 - 5 + 16 - 12 = 50 buku tulis.

Verifikasi: Perhitungan: 51 - 5 = 46, 46 + 16 = 62, 62 - 12 = 50. Benar.

Jawaban akhir: 50 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Udin memiliki 44 apel. Dia memberikan 3 kepada teman. Kemudian menerima 7 apel. Setelah itu memberikan 12 kepada orang lain. Berapa apel Udin sekarang?
A: Udin sekarang memiliki 44 - 3 + 7 - 12 = 36 apel.

Verifikasi: Perhitungan: 44 - 3 = 41, 41 + 7 = 48, 48 - 12 = 36. Benar.

Jawaban akhir: 36 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
