# Dataset Verifikasi Diri 1740

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 81 rupiah. Dia membagi 10 kepada teman. Kemudian menerima 11 rupiah. Setelah itu memberikan 13 kepada orang lain. Berapa rupiah Siti sekarang?
A: Siti sekarang memiliki 81 - 10 + 11 - 13 = 69 rupiah.

Verifikasi: Perhitungan: 81 - 10 = 71, 71 + 11 = 82, 82 - 13 = 69. Benar.

Jawaban akhir: 69 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Budi memiliki 29 kelereng. Dia meminjamkan 6 kepada teman. Kemudian mendapat 1 kelereng. Setelah itu meminjamkan 7 kepada orang lain. Berapa kelereng Budi sekarang?
A: Budi sekarang memiliki 29 - 6 + 1 - 7 = 17 kelereng.

Verifikasi: Perhitungan: 29 - 6 = 23, 23 + 1 = 24, 24 - 7 = 17. Benar.

Jawaban akhir: 17 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Lina memiliki 42 spidol. Dia membagi 3 kepada teman. Kemudian mendapat 19 spidol. Setelah itu membagi 6 kepada orang lain. Berapa spidol Lina sekarang?
A: Lina sekarang memiliki 42 - 3 + 19 - 6 = 52 spidol.

Verifikasi: Perhitungan: 42 - 3 = 39, 39 + 19 = 58, 58 - 6 = 52. Benar.

Jawaban akhir: 52 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
