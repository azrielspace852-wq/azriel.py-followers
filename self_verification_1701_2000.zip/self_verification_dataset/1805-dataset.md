# Dataset Verifikasi Diri 1805

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 10 kartu. Dia meminjamkan 1 kepada teman. Kemudian menang 7 kartu. Setelah itu meminjamkan 6 kepada orang lain. Berapa kartu Yudi sekarang?
A: Yudi sekarang memiliki 10 - 1 + 7 - 6 = 10 kartu.

Verifikasi: Perhitungan: 10 - 1 = 9, 9 + 7 = 16, 16 - 6 = 10. Benar.

Jawaban akhir: 10 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Tono memiliki 48 kartu. Dia membagi 10 kepada teman. Kemudian menerima 17 kartu. Setelah itu meminjamkan 5 kepada orang lain. Berapa kartu Tono sekarang?
A: Tono sekarang memiliki 48 - 10 + 17 - 5 = 50 kartu.

Verifikasi: Perhitungan: 48 - 10 = 38, 38 + 17 = 55, 55 - 5 = 50. Benar.

Jawaban akhir: 50 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Vina memiliki 84 buku. Dia memberikan 3 kepada teman. Kemudian menang 12 buku. Setelah itu meminjamkan 4 kepada orang lain. Berapa buku Vina sekarang?
A: Vina sekarang memiliki 84 - 3 + 12 - 4 = 89 buku.

Verifikasi: Perhitungan: 84 - 3 = 81, 81 + 12 = 93, 93 - 4 = 89. Benar.

Jawaban akhir: 89 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
