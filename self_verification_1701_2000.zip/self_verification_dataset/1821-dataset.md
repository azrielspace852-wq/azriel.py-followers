# Dataset Verifikasi Diri 1821

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 11 bola. Dia memberikan 3 kepada teman. Kemudian mendapat 8 bola. Setelah itu membagi 13 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 11 - 3 + 8 - 13 = 3 bola.

Verifikasi: Perhitungan: 11 - 3 = 8, 8 + 8 = 16, 16 - 13 = 3. Benar.

Jawaban akhir: 3 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Siti memiliki 82 pulpen. Dia meminjamkan 17 kepada teman. Kemudian menerima 10 pulpen. Setelah itu memberikan 7 kepada orang lain. Berapa pulpen Siti sekarang?
A: Siti sekarang memiliki 82 - 17 + 10 - 7 = 68 pulpen.

Verifikasi: Perhitungan: 82 - 17 = 65, 65 + 10 = 75, 75 - 7 = 68. Benar.

Jawaban akhir: 68 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 5

Q: Eko memiliki 83 pensil. Dia memberikan 18 kepada teman. Kemudian mendapat 7 pensil. Setelah itu memberikan 9 kepada orang lain. Berapa pensil Eko sekarang?
A: Eko sekarang memiliki 83 - 18 + 7 - 9 = 62 pensil.

Verifikasi: Perhitungan yang benar: 83 - 18 = 65, 65 + 7 = 72, 72 - 9 = 63. Jawaban awal salah.

Jawaban akhir: 63 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
