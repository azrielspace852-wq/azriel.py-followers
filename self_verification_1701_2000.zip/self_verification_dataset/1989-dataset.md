# Dataset Verifikasi Diri 1989

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 79 kertas. Dia membagi 22 kepada teman. Kemudian membeli 20 kertas. Setelah itu meminjamkan 15 kepada orang lain. Berapa kertas Candra sekarang?
A: Candra sekarang memiliki 79 - 22 + 20 - 15 = 60 kertas.

Verifikasi: Perhitungan yang benar: 79 - 22 = 57, 57 + 20 = 77, 77 - 15 = 62. Jawaban awal salah.

Jawaban akhir: 62 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 36 buku. Dia meminjamkan 11 kepada teman. Kemudian menang 19 buku. Setelah itu memberikan 11 kepada orang lain. Berapa buku Dedi sekarang?
A: Dedi sekarang memiliki 36 - 11 + 19 - 11 = 34 buku.

Verifikasi: Perhitungan yang benar: 36 - 11 = 25, 25 + 19 = 44, 44 - 11 = 33. Jawaban awal salah.

Jawaban akhir: 33 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 86 spidol. Dia meminjamkan 6 kepada teman. Kemudian mendapat 6 spidol. Setelah itu membagi 7 kepada orang lain. Berapa spidol Rina sekarang?
A: Rina sekarang memiliki 86 - 6 + 6 - 7 = 79 spidol.

Verifikasi: Perhitungan: 86 - 6 = 80, 80 + 6 = 86, 86 - 7 = 79. Benar.

Jawaban akhir: 79 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
