# Dataset Verifikasi Diri 1714

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 73 bola. Dia memberikan 2 kepada teman. Kemudian membeli 16 bola. Setelah itu membagi 1 kepada orang lain. Berapa bola Putri sekarang?
A: Putri sekarang memiliki 73 - 2 + 16 - 1 = 86 bola.

Verifikasi: Perhitungan: 73 - 2 = 71, 71 + 16 = 87, 87 - 1 = 86. Benar.

Jawaban akhir: 86 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Oscar memiliki 58 spidol. Dia membagi 12 kepada teman. Kemudian membeli 9 spidol. Setelah itu meminjamkan 5 kepada orang lain. Berapa spidol Oscar sekarang?
A: Oscar sekarang memiliki 58 - 12 + 9 - 5 = 53 spidol.

Verifikasi: Perhitungan yang benar: 58 - 12 = 46, 46 + 9 = 55, 55 - 5 = 50. Jawaban awal salah.

Jawaban akhir: 50 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Siti memiliki 22 bola. Dia membagi 6 kepada teman. Kemudian membeli 4 bola. Setelah itu membagi 12 kepada orang lain. Berapa bola Siti sekarang?
A: Siti sekarang memiliki 22 - 6 + 4 - 12 = 8 bola.

Verifikasi: Perhitungan: 22 - 6 = 16, 16 + 4 = 20, 20 - 12 = 8. Benar.

Jawaban akhir: 8 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
