# Dataset Verifikasi Diri 1858

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 83 penghapus. Dia memberikan 9 kepada teman. Kemudian menang 10 penghapus. Setelah itu meminjamkan 15 kepada orang lain. Berapa penghapus Lina sekarang?
A: Lina sekarang memiliki 83 - 9 + 10 - 15 = 69 penghapus.

Verifikasi: Perhitungan: 83 - 9 = 74, 74 + 10 = 84, 84 - 15 = 69. Benar.

Jawaban akhir: 69 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Dedi memiliki 100 kelereng. Dia memberikan 6 kepada teman. Kemudian membeli 7 kelereng. Setelah itu meminjamkan 12 kepada orang lain. Berapa kelereng Dedi sekarang?
A: Dedi sekarang memiliki 100 - 6 + 7 - 12 = 89 kelereng.

Verifikasi: Perhitungan: 100 - 6 = 94, 94 + 7 = 101, 101 - 12 = 89. Benar.

Jawaban akhir: 89 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Hani memiliki 29 rupiah. Dia memberikan 5 kepada teman. Kemudian mendapat 14 rupiah. Setelah itu meminjamkan 1 kepada orang lain. Berapa rupiah Hani sekarang?
A: Hani sekarang memiliki 29 - 5 + 14 - 1 = 37 rupiah.

Verifikasi: Perhitungan: 29 - 5 = 24, 24 + 14 = 38, 38 - 1 = 37. Benar.

Jawaban akhir: 37 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
