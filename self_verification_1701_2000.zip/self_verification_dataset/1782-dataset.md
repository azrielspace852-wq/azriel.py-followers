# Dataset Verifikasi Diri 1782

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 20 spidol. Dia memberikan 2 kepada teman. Kemudian mendapat 1 spidol. Setelah itu memberikan 15 kepada orang lain. Berapa spidol Zaki sekarang?
A: Zaki sekarang memiliki 20 - 2 + 1 - 15 = 4 spidol.

Verifikasi: Perhitungan: 20 - 2 = 18, 18 + 1 = 19, 19 - 15 = 4. Benar.

Jawaban akhir: 4 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Hani memiliki 93 rupiah. Dia membagi 10 kepada teman. Kemudian menerima 12 rupiah. Setelah itu membagi 8 kepada orang lain. Berapa rupiah Hani sekarang?
A: Hani sekarang memiliki 93 - 10 + 12 - 8 = 90 rupiah.

Verifikasi: Perhitungan yang benar: 93 - 10 = 83, 83 + 12 = 95, 95 - 8 = 87. Jawaban awal salah.

Jawaban akhir: 87 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Oscar memiliki 39 bola. Dia meminjamkan 2 kepada teman. Kemudian membeli 16 bola. Setelah itu memberikan 4 kepada orang lain. Berapa bola Oscar sekarang?
A: Oscar sekarang memiliki 39 - 2 + 16 - 4 = 50 bola.

Verifikasi: Perhitungan yang benar: 39 - 2 = 37, 37 + 16 = 53, 53 - 4 = 49. Jawaban awal salah.

Jawaban akhir: 49 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
