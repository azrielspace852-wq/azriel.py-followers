# Dataset Verifikasi Diri 1746

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 96 penghapus. Dia membagi 19 kepada teman. Kemudian mendapat 1 penghapus. Setelah itu memberikan 10 kepada orang lain. Berapa penghapus Eko sekarang?
A: Eko sekarang memiliki 96 - 19 + 1 - 10 = 68 penghapus.

Verifikasi: Perhitungan: 96 - 19 = 77, 77 + 1 = 78, 78 - 10 = 68. Benar.

Jawaban akhir: 68 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 46 buku. Dia memberikan 3 kepada teman. Kemudian menang 15 buku. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku Fajar sekarang?
A: Fajar sekarang memiliki 46 - 3 + 15 - 11 = 46 buku.

Verifikasi: Perhitungan yang benar: 46 - 3 = 43, 43 + 15 = 58, 58 - 11 = 47. Jawaban awal salah.

Jawaban akhir: 47 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Eko memiliki 10 buku tulis. Dia membagi 3 kepada teman. Kemudian mendapat 10 buku tulis. Setelah itu meminjamkan 4 kepada orang lain. Berapa buku tulis Eko sekarang?
A: Eko sekarang memiliki 10 - 3 + 10 - 4 = 13 buku tulis.

Verifikasi: Perhitungan: 10 - 3 = 7, 7 + 10 = 17, 17 - 4 = 13. Benar.

Jawaban akhir: 13 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup
