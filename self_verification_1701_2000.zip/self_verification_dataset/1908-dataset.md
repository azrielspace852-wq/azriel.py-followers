# Dataset Verifikasi Diri 1908

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Lina memiliki 30 buku. Dia membagi 2 kepada teman. Kemudian mendapat 16 buku. Setelah itu membagi 5 kepada orang lain. Berapa buku Lina sekarang?
A: Lina sekarang memiliki 30 - 2 + 16 - 5 = 39 buku.

Verifikasi: Perhitungan: 30 - 2 = 28, 28 + 16 = 44, 44 - 5 = 39. Benar.

Jawaban akhir: 39 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Yudi memiliki 75 apel. Dia memberikan 2 kepada teman. Kemudian menang 5 apel. Setelah itu meminjamkan 2 kepada orang lain. Berapa apel Yudi sekarang?
A: Yudi sekarang memiliki 75 - 2 + 5 - 2 = 76 apel.

Verifikasi: Perhitungan: 75 - 2 = 73, 73 + 5 = 78, 78 - 2 = 76. Benar.

Jawaban akhir: 76 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 27 pensil. Dia memberikan 6 kepada teman. Kemudian menang 13 pensil. Setelah itu membagi 7 kepada orang lain. Berapa pensil Maya sekarang?
A: Maya sekarang memiliki 27 - 6 + 13 - 7 = 27 pensil.

Verifikasi: Perhitungan: 27 - 6 = 21, 21 + 13 = 34, 34 - 7 = 27. Benar.

Jawaban akhir: 27 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua A adalah B. Tidak ada A yang adalah B. Apa kesimpulannya?
A: Semua A adalah B.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak ada kesimpulan yang valid.

Jenis kesalahan: kontradiksi
