# Dataset Verifikasi Diri 1988

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 95 pensil. Dia memberikan 10 kepada teman. Kemudian membeli 12 pensil. Setelah itu membagi 9 kepada orang lain. Berapa pensil Candra sekarang?
A: Candra sekarang memiliki 95 - 10 + 12 - 9 = 89 pensil.

Verifikasi: Perhitungan yang benar: 95 - 10 = 85, 85 + 12 = 97, 97 - 9 = 88. Jawaban awal salah.

Jawaban akhir: 88 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Dedi memiliki 47 penggaris. Dia memberikan 14 kepada teman. Kemudian menerima 5 penggaris. Setelah itu meminjamkan 12 kepada orang lain. Berapa penggaris Dedi sekarang?
A: Dedi sekarang memiliki 47 - 14 + 5 - 12 = 26 penggaris.

Verifikasi: Perhitungan: 47 - 14 = 33, 33 + 5 = 38, 38 - 12 = 26. Benar.

Jawaban akhir: 26 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 83 stiker. Dia membagi 19 kepada teman. Kemudian membeli 14 stiker. Setelah itu membagi 6 kepada orang lain. Berapa stiker Zaki sekarang?
A: Zaki sekarang memiliki 83 - 19 + 14 - 6 = 71 stiker.

Verifikasi: Perhitungan yang benar: 83 - 19 = 64, 64 + 14 = 78, 78 - 6 = 72. Jawaban awal salah.

Jawaban akhir: 72 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
