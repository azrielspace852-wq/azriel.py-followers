# Dataset Verifikasi Diri 1928

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 89 stiker. Dia membagi 26 kepada teman. Kemudian menang 5 stiker. Setelah itu memberikan 4 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 89 - 26 + 5 - 4 = 64 stiker.

Verifikasi: Perhitungan: 89 - 26 = 63, 63 + 5 = 68, 68 - 4 = 64. Benar.

Jawaban akhir: 64 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Fajar memiliki 22 penggaris. Dia memberikan 6 kepada teman. Kemudian mendapat 8 penggaris. Setelah itu memberikan 4 kepada orang lain. Berapa penggaris Fajar sekarang?
A: Fajar sekarang memiliki 22 - 6 + 8 - 4 = 20 penggaris.

Verifikasi: Perhitungan: 22 - 6 = 16, 16 + 8 = 24, 24 - 4 = 20. Benar.

Jawaban akhir: 20 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Oscar memiliki 17 pensil. Dia membagi 5 kepada teman. Kemudian mendapat 11 pensil. Setelah itu meminjamkan 2 kepada orang lain. Berapa pensil Oscar sekarang?
A: Oscar sekarang memiliki 17 - 5 + 11 - 2 = 24 pensil.

Verifikasi: Perhitungan yang benar: 17 - 5 = 12, 12 + 11 = 23, 23 - 2 = 21. Jawaban awal salah.

Jawaban akhir: 21 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
