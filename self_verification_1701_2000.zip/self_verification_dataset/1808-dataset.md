# Dataset Verifikasi Diri 1808

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Nina memiliki 35 rupiah. Dia membagi 11 kepada teman. Kemudian menang 7 rupiah. Setelah itu membagi 10 kepada orang lain. Berapa rupiah Nina sekarang?
A: Nina sekarang memiliki 35 - 11 + 7 - 10 = 21 rupiah.

Verifikasi: Perhitungan: 35 - 11 = 24, 24 + 7 = 31, 31 - 10 = 21. Benar.

Jawaban akhir: 21 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 89 buku tulis. Dia memberikan 12 kepada teman. Kemudian mendapat 11 buku tulis. Setelah itu memberikan 7 kepada orang lain. Berapa buku tulis Dedi sekarang?
A: Dedi sekarang memiliki 89 - 12 + 11 - 7 = 84 buku tulis.

Verifikasi: Perhitungan yang benar: 89 - 12 = 77, 77 + 11 = 88, 88 - 7 = 81. Jawaban awal salah.

Jawaban akhir: 81 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Budi memiliki 66 kartu. Dia membagi 19 kepada teman. Kemudian membeli 4 kartu. Setelah itu membagi 4 kepada orang lain. Berapa kartu Budi sekarang?
A: Budi sekarang memiliki 66 - 19 + 4 - 4 = 47 kartu.

Verifikasi: Perhitungan: 66 - 19 = 47, 47 + 4 = 51, 51 - 4 = 47. Benar.

Jawaban akhir: 47 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
