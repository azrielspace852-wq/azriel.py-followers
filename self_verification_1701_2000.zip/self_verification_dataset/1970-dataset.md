# Dataset Verifikasi Diri 1970

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 51 bola. Dia membagi 14 kepada teman. Kemudian menerima 10 bola. Setelah itu meminjamkan 4 kepada orang lain. Berapa bola Yudi sekarang?
A: Yudi sekarang memiliki 51 - 14 + 10 - 4 = 43 bola.

Verifikasi: Perhitungan: 51 - 14 = 37, 37 + 10 = 47, 47 - 4 = 43. Benar.

Jawaban akhir: 43 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Budi memiliki 63 kue. Dia meminjamkan 17 kepada teman. Kemudian menang 7 kue. Setelah itu membagi 8 kepada orang lain. Berapa kue Budi sekarang?
A: Budi sekarang memiliki 63 - 17 + 7 - 8 = 45 kue.

Verifikasi: Perhitungan: 63 - 17 = 46, 46 + 7 = 53, 53 - 8 = 45. Benar.

Jawaban akhir: 45 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Putri memiliki 59 kelereng. Dia membagi 4 kepada teman. Kemudian menerima 20 kelereng. Setelah itu membagi 15 kepada orang lain. Berapa kelereng Putri sekarang?
A: Putri sekarang memiliki 59 - 4 + 20 - 15 = 63 kelereng.

Verifikasi: Perhitungan yang benar: 59 - 4 = 55, 55 + 20 = 75, 75 - 15 = 60. Jawaban awal salah.

Jawaban akhir: 60 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar
