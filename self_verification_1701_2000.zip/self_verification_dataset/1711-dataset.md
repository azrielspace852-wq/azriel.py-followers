# Dataset Verifikasi Diri 1711

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 61 kue. Dia memberikan 3 kepada teman. Kemudian menerima 6 kue. Setelah itu meminjamkan 3 kepada orang lain. Berapa kue Rina sekarang?
A: Rina sekarang memiliki 61 - 3 + 6 - 3 = 59 kue.

Verifikasi: Perhitungan yang benar: 61 - 3 = 58, 58 + 6 = 64, 64 - 3 = 61. Jawaban awal salah.

Jawaban akhir: 61 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Putri memiliki 38 kertas. Dia memberikan 4 kepada teman. Kemudian membeli 6 kertas. Setelah itu meminjamkan 4 kepada orang lain. Berapa kertas Putri sekarang?
A: Putri sekarang memiliki 38 - 4 + 6 - 4 = 35 kertas.

Verifikasi: Perhitungan yang benar: 38 - 4 = 34, 34 + 6 = 40, 40 - 4 = 36. Jawaban awal salah.

Jawaban akhir: 36 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Indra memiliki 12 kartu. Dia memberikan 3 kepada teman. Kemudian menerima 13 kartu. Setelah itu meminjamkan 10 kepada orang lain. Berapa kartu Indra sekarang?
A: Indra sekarang memiliki 12 - 3 + 13 - 10 = 15 kartu.

Verifikasi: Perhitungan yang benar: 12 - 3 = 9, 9 + 13 = 22, 22 - 10 = 12. Jawaban awal salah.

Jawaban akhir: 12 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
