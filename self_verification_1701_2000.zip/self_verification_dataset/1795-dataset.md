# Dataset Verifikasi Diri 1795

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 82 penggaris. Dia memberikan 24 kepada teman. Kemudian menang 2 penggaris. Setelah itu meminjamkan 9 kepada orang lain. Berapa penggaris Udin sekarang?
A: Udin sekarang memiliki 82 - 24 + 2 - 9 = 49 penggaris.

Verifikasi: Perhitungan yang benar: 82 - 24 = 58, 58 + 2 = 60, 60 - 9 = 51. Jawaban awal salah.

Jawaban akhir: 51 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 18 bola. Dia meminjamkan 6 kepada teman. Kemudian menang 7 bola. Setelah itu meminjamkan 5 kepada orang lain. Berapa bola Vina sekarang?
A: Vina sekarang memiliki 18 - 6 + 7 - 5 = 14 bola.

Verifikasi: Perhitungan: 18 - 6 = 12, 12 + 7 = 19, 19 - 5 = 14. Benar.

Jawaban akhir: 14 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Lina memiliki 60 pensil. Dia membagi 5 kepada teman. Kemudian menerima 4 pensil. Setelah itu memberikan 6 kepada orang lain. Berapa pensil Lina sekarang?
A: Lina sekarang memiliki 60 - 5 + 4 - 6 = 53 pensil.

Verifikasi: Perhitungan: 60 - 5 = 55, 55 + 4 = 59, 59 - 6 = 53. Benar.

Jawaban akhir: 53 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
