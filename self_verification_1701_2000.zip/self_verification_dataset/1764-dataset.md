# Dataset Verifikasi Diri 1764

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 79 kue. Dia membagi 6 kepada teman. Kemudian menang 14 kue. Setelah itu membagi 9 kepada orang lain. Berapa kue Dedi sekarang?
A: Dedi sekarang memiliki 79 - 6 + 14 - 9 = 81 kue.

Verifikasi: Perhitungan yang benar: 79 - 6 = 73, 73 + 14 = 87, 87 - 9 = 78. Jawaban awal salah.

Jawaban akhir: 78 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Siti memiliki 35 pensil. Dia membagi 11 kepada teman. Kemudian mendapat 4 pensil. Setelah itu memberikan 10 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 35 - 11 + 4 - 10 = 20 pensil.

Verifikasi: Perhitungan yang benar: 35 - 11 = 24, 24 + 4 = 28, 28 - 10 = 18. Jawaban awal salah.

Jawaban akhir: 18 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Joko memiliki 86 rupiah. Dia membagi 11 kepada teman. Kemudian membeli 6 rupiah. Setelah itu meminjamkan 5 kepada orang lain. Berapa rupiah Joko sekarang?
A: Joko sekarang memiliki 86 - 11 + 6 - 5 = 76 rupiah.

Verifikasi: Perhitungan: 86 - 11 = 75, 75 + 6 = 81, 81 - 5 = 76. Benar.

Jawaban akhir: 76 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
