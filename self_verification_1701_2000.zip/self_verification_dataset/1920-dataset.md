# Dataset Verifikasi Diri 1920

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Fajar memiliki 18 apel. Dia memberikan 1 kepada teman. Kemudian mendapat 4 apel. Setelah itu meminjamkan 15 kepada orang lain. Berapa apel Fajar sekarang?
A: Fajar sekarang memiliki 18 - 1 + 4 - 15 = 6 apel.

Verifikasi: Perhitungan: 18 - 1 = 17, 17 + 4 = 21, 21 - 15 = 6. Benar.

Jawaban akhir: 6 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Andi memiliki 77 kue. Dia membagi 1 kepada teman. Kemudian menang 19 kue. Setelah itu meminjamkan 2 kepada orang lain. Berapa kue Andi sekarang?
A: Andi sekarang memiliki 77 - 1 + 19 - 2 = 93 kue.

Verifikasi: Perhitungan: 77 - 1 = 76, 76 + 19 = 95, 95 - 2 = 93. Benar.

Jawaban akhir: 93 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 54 kelereng. Dia membagi 4 kepada teman. Kemudian menerima 11 kelereng. Setelah itu memberikan 6 kepada orang lain. Berapa kelereng Maya sekarang?
A: Maya sekarang memiliki 54 - 4 + 11 - 6 = 55 kelereng.

Verifikasi: Perhitungan: 54 - 4 = 50, 50 + 11 = 61, 61 - 6 = 55. Benar.

Jawaban akhir: 55 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
