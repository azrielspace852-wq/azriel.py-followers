# Dataset Verifikasi Diri 1883

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 46 spidol. Dia memberikan 8 kepada teman. Kemudian mendapat 9 spidol. Setelah itu meminjamkan 10 kepada orang lain. Berapa spidol Oscar sekarang?
A: Oscar sekarang memiliki 46 - 8 + 9 - 10 = 36 spidol.

Verifikasi: Perhitungan yang benar: 46 - 8 = 38, 38 + 9 = 47, 47 - 10 = 37. Jawaban awal salah.

Jawaban akhir: 37 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Dedi memiliki 85 apel. Dia memberikan 16 kepada teman. Kemudian mendapat 9 apel. Setelah itu meminjamkan 3 kepada orang lain. Berapa apel Dedi sekarang?
A: Dedi sekarang memiliki 85 - 16 + 9 - 3 = 73 apel.

Verifikasi: Perhitungan yang benar: 85 - 16 = 69, 69 + 9 = 78, 78 - 3 = 75. Jawaban awal salah.

Jawaban akhir: 75 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Joko memiliki 11 penggaris. Dia memberikan 3 kepada teman. Kemudian menerima 17 penggaris. Setelah itu memberikan 5 kepada orang lain. Berapa penggaris Joko sekarang?
A: Joko sekarang memiliki 11 - 3 + 17 - 5 = 21 penggaris.

Verifikasi: Perhitungan yang benar: 11 - 3 = 8, 8 + 17 = 25, 25 - 5 = 20. Jawaban awal salah.

Jawaban akhir: 20 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
