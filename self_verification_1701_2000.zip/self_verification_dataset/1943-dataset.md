# Dataset Verifikasi Diri 1943

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Maya memiliki 69 buku tulis. Dia memberikan 19 kepada teman. Kemudian mendapat 11 buku tulis. Setelah itu memberikan 14 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 69 - 19 + 11 - 14 = 47 buku tulis.

Verifikasi: Perhitungan: 69 - 19 = 50, 50 + 11 = 61, 61 - 14 = 47. Benar.

Jawaban akhir: 47 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Candra memiliki 65 kue. Dia membagi 18 kepada teman. Kemudian menang 6 kue. Setelah itu membagi 6 kepada orang lain. Berapa kue Candra sekarang?
A: Candra sekarang memiliki 65 - 18 + 6 - 6 = 46 kue.

Verifikasi: Perhitungan yang benar: 65 - 18 = 47, 47 + 6 = 53, 53 - 6 = 47. Jawaban awal salah.

Jawaban akhir: 47 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Eko memiliki 74 kelereng. Dia meminjamkan 12 kepada teman. Kemudian menerima 7 kelereng. Setelah itu membagi 2 kepada orang lain. Berapa kelereng Eko sekarang?
A: Eko sekarang memiliki 74 - 12 + 7 - 2 = 67 kelereng.

Verifikasi: Perhitungan: 74 - 12 = 62, 62 + 7 = 69, 69 - 2 = 67. Benar.

Jawaban akhir: 67 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan, maka jalan basah. Tidak hujan. Apakah jalan basah?
A: Tidak, jalan tidak basah.

Verifikasi: Ini menyangkal anteseden. Tidak hujan tidak berarti jalan tidak basah.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
