# Dataset Verifikasi Diri 1801

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 52 pensil. Dia memberikan 6 kepada teman. Kemudian menerima 7 pensil. Setelah itu memberikan 8 kepada orang lain. Berapa pensil Oscar sekarang?
A: Oscar sekarang memiliki 52 - 6 + 7 - 8 = 44 pensil.

Verifikasi: Perhitungan yang benar: 52 - 6 = 46, 46 + 7 = 53, 53 - 8 = 45. Jawaban awal salah.

Jawaban akhir: 45 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Maya memiliki 77 rupiah. Dia meminjamkan 14 kepada teman. Kemudian menerima 20 rupiah. Setelah itu membagi 12 kepada orang lain. Berapa rupiah Maya sekarang?
A: Maya sekarang memiliki 77 - 14 + 20 - 12 = 74 rupiah.

Verifikasi: Perhitungan yang benar: 77 - 14 = 63, 63 + 20 = 83, 83 - 12 = 71. Jawaban awal salah.

Jawaban akhir: 71 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tua dari B. Siapa yang lebih muda antara A dan B?
A: B lebih muda.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Gita memiliki 75 buku. Dia membagi 12 kepada teman. Kemudian menerima 20 buku. Setelah itu meminjamkan 3 kepada orang lain. Berapa buku Gita sekarang?
A: Gita sekarang memiliki 75 - 12 + 20 - 3 = 80 buku.

Verifikasi: Perhitungan: 75 - 12 = 63, 63 + 20 = 83, 83 - 3 = 80. Benar.

Jawaban akhir: 80 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar
