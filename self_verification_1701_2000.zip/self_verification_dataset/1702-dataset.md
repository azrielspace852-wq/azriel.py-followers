# Dataset Verifikasi Diri 1702

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 34 stiker. Dia meminjamkan 7 kepada teman. Kemudian menang 18 stiker. Setelah itu memberikan 3 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 34 - 7 + 18 - 3 = 42 stiker.

Verifikasi: Perhitungan: 34 - 7 = 27, 27 + 18 = 45, 45 - 3 = 42. Benar.

Jawaban akhir: 42 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Budi memiliki 67 spidol. Dia memberikan 21 kepada teman. Kemudian mendapat 13 spidol. Setelah itu membagi 5 kepada orang lain. Berapa spidol Budi sekarang?
A: Budi sekarang memiliki 67 - 21 + 13 - 5 = 53 spidol.

Verifikasi: Perhitungan yang benar: 67 - 21 = 46, 46 + 13 = 59, 59 - 5 = 54. Jawaban awal salah.

Jawaban akhir: 54 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Dedi memiliki 71 kertas. Dia memberikan 5 kepada teman. Kemudian menerima 13 kertas. Setelah itu memberikan 7 kepada orang lain. Berapa kertas Dedi sekarang?
A: Dedi sekarang memiliki 71 - 5 + 13 - 7 = 70 kertas.

Verifikasi: Perhitungan yang benar: 71 - 5 = 66, 66 + 13 = 79, 79 - 7 = 72. Jawaban awal salah.

Jawaban akhir: 72 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar
