# Dataset Verifikasi Diri 1836

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Andi memiliki 75 penggaris. Dia meminjamkan 5 kepada teman. Kemudian mendapat 16 penggaris. Setelah itu memberikan 9 kepada orang lain. Berapa penggaris Andi sekarang?
A: Andi sekarang memiliki 75 - 5 + 16 - 9 = 77 penggaris.

Verifikasi: Perhitungan: 75 - 5 = 70, 70 + 16 = 86, 86 - 9 = 77. Benar.

Jawaban akhir: 77 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Wati memiliki 40 kertas. Dia meminjamkan 11 kepada teman. Kemudian mendapat 9 kertas. Setelah itu meminjamkan 10 kepada orang lain. Berapa kertas Wati sekarang?
A: Wati sekarang memiliki 40 - 11 + 9 - 10 = 28 kertas.

Verifikasi: Perhitungan: 40 - 11 = 29, 29 + 9 = 38, 38 - 10 = 28. Benar.

Jawaban akhir: 28 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Yudi memiliki 100 kue. Dia meminjamkan 14 kepada teman. Kemudian membeli 7 kue. Setelah itu meminjamkan 2 kepada orang lain. Berapa kue Yudi sekarang?
A: Yudi sekarang memiliki 100 - 14 + 7 - 2 = 91 kue.

Verifikasi: Perhitungan: 100 - 14 = 86, 86 + 7 = 93, 93 - 2 = 91. Benar.

Jawaban akhir: 91 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
