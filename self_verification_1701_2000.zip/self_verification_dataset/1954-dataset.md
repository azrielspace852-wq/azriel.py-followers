# Dataset Verifikasi Diri 1954

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 35 rupiah. Dia meminjamkan 5 kepada teman. Kemudian menerima 19 rupiah. Setelah itu membagi 3 kepada orang lain. Berapa rupiah Indra sekarang?
A: Indra sekarang memiliki 35 - 5 + 19 - 3 = 46 rupiah.

Verifikasi: Perhitungan: 35 - 5 = 30, 30 + 19 = 49, 49 - 3 = 46. Benar.

Jawaban akhir: 46 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 80 spidol. Dia meminjamkan 3 kepada teman. Kemudian membeli 13 spidol. Setelah itu meminjamkan 10 kepada orang lain. Berapa spidol Vina sekarang?
A: Vina sekarang memiliki 80 - 3 + 13 - 10 = 80 spidol.

Verifikasi: Perhitungan: 80 - 3 = 77, 77 + 13 = 90, 90 - 10 = 80. Benar.

Jawaban akhir: 80 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Indra memiliki 61 spidol. Dia meminjamkan 17 kepada teman. Kemudian menang 10 spidol. Setelah itu memberikan 2 kepada orang lain. Berapa spidol Indra sekarang?
A: Indra sekarang memiliki 61 - 17 + 10 - 2 = 52 spidol.

Verifikasi: Perhitungan: 61 - 17 = 44, 44 + 10 = 54, 54 - 2 = 52. Benar.

Jawaban akhir: 52 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
