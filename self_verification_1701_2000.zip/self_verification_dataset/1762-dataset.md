# Dataset Verifikasi Diri 1762

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 35 penggaris. Dia memberikan 9 kepada teman. Kemudian mendapat 18 penggaris. Setelah itu membagi 13 kepada orang lain. Berapa penggaris Rina sekarang?
A: Rina sekarang memiliki 35 - 9 + 18 - 13 = 33 penggaris.

Verifikasi: Perhitungan yang benar: 35 - 9 = 26, 26 + 18 = 44, 44 - 13 = 31. Jawaban awal salah.

Jawaban akhir: 31 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Tono memiliki 60 apel. Dia memberikan 19 kepada teman. Kemudian membeli 11 apel. Setelah itu memberikan 1 kepada orang lain. Berapa apel Tono sekarang?
A: Tono sekarang memiliki 60 - 19 + 11 - 1 = 51 apel.

Verifikasi: Perhitungan: 60 - 19 = 41, 41 + 11 = 52, 52 - 1 = 51. Benar.

Jawaban akhir: 51 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Dedi memiliki 79 rupiah. Dia meminjamkan 21 kepada teman. Kemudian membeli 15 rupiah. Setelah itu meminjamkan 9 kepada orang lain. Berapa rupiah Dedi sekarang?
A: Dedi sekarang memiliki 79 - 21 + 15 - 9 = 64 rupiah.

Verifikasi: Perhitungan: 79 - 21 = 58, 58 + 15 = 73, 73 - 9 = 64. Benar.

Jawaban akhir: 64 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
