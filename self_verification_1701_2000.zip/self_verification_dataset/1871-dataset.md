# Dataset Verifikasi Diri 1871

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 61 apel. Dia memberikan 2 kepada teman. Kemudian membeli 14 apel. Setelah itu meminjamkan 1 kepada orang lain. Berapa apel Oscar sekarang?
A: Oscar sekarang memiliki 61 - 2 + 14 - 1 = 72 apel.

Verifikasi: Perhitungan: 61 - 2 = 59, 59 + 14 = 73, 73 - 1 = 72. Benar.

Jawaban akhir: 72 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 61 kertas. Dia meminjamkan 12 kepada teman. Kemudian menerima 7 kertas. Setelah itu memberikan 2 kepada orang lain. Berapa kertas Putri sekarang?
A: Putri sekarang memiliki 61 - 12 + 7 - 2 = 54 kertas.

Verifikasi: Perhitungan: 61 - 12 = 49, 49 + 7 = 56, 56 - 2 = 54. Benar.

Jawaban akhir: 54 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Fajar memiliki 90 apel. Dia membagi 26 kepada teman. Kemudian membeli 20 apel. Setelah itu membagi 14 kepada orang lain. Berapa apel Fajar sekarang?
A: Fajar sekarang memiliki 90 - 26 + 20 - 14 = 73 apel.

Verifikasi: Perhitungan yang benar: 90 - 26 = 64, 64 + 20 = 84, 84 - 14 = 70. Jawaban awal salah.

Jawaban akhir: 70 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar
