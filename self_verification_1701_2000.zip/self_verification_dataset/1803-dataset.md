# Dataset Verifikasi Diri 1803

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 53 stiker. Dia memberikan 16 kepada teman. Kemudian mendapat 17 stiker. Setelah itu memberikan 7 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 53 - 16 + 17 - 7 = 47 stiker.

Verifikasi: Perhitungan: 53 - 16 = 37, 37 + 17 = 54, 54 - 7 = 47. Benar.

Jawaban akhir: 47 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Indra memiliki 40 spidol. Dia memberikan 2 kepada teman. Kemudian membeli 18 spidol. Setelah itu membagi 9 kepada orang lain. Berapa spidol Indra sekarang?
A: Indra sekarang memiliki 40 - 2 + 18 - 9 = 50 spidol.

Verifikasi: Perhitungan yang benar: 40 - 2 = 38, 38 + 18 = 56, 56 - 9 = 47. Jawaban awal salah.

Jawaban akhir: 47 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Nina memiliki 60 stiker. Dia membagi 6 kepada teman. Kemudian mendapat 17 stiker. Setelah itu membagi 2 kepada orang lain. Berapa stiker Nina sekarang?
A: Nina sekarang memiliki 60 - 6 + 17 - 2 = 68 stiker.

Verifikasi: Perhitungan yang benar: 60 - 6 = 54, 54 + 17 = 71, 71 - 2 = 69. Jawaban awal salah.

Jawaban akhir: 69 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
