# Dataset Verifikasi Diri 1776

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 58 kertas. Dia meminjamkan 11 kepada teman. Kemudian menerima 9 kertas. Setelah itu meminjamkan 9 kepada orang lain. Berapa kertas Udin sekarang?
A: Udin sekarang memiliki 58 - 11 + 9 - 9 = 47 kertas.

Verifikasi: Perhitungan: 58 - 11 = 47, 47 + 9 = 56, 56 - 9 = 47. Benar.

Jawaban akhir: 47 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 98 kartu. Dia membagi 13 kepada teman. Kemudian mendapat 8 kartu. Setelah itu meminjamkan 7 kepada orang lain. Berapa kartu Rina sekarang?
A: Rina sekarang memiliki 98 - 13 + 8 - 7 = 86 kartu.

Verifikasi: Perhitungan: 98 - 13 = 85, 85 + 8 = 93, 93 - 7 = 86. Benar.

Jawaban akhir: 86 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 14 kertas. Dia memberikan 3 kepada teman. Kemudian membeli 11 kertas. Setelah itu membagi 3 kepada orang lain. Berapa kertas Rina sekarang?
A: Rina sekarang memiliki 14 - 3 + 11 - 3 = 21 kertas.

Verifikasi: Perhitungan yang benar: 14 - 3 = 11, 11 + 11 = 22, 22 - 3 = 19. Jawaban awal salah.

Jawaban akhir: 19 kertas.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
