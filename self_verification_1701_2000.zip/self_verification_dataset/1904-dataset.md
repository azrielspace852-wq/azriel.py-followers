# Dataset Verifikasi Diri 1904

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 55 pulpen. Dia memberikan 11 kepada teman. Kemudian mendapat 9 pulpen. Setelah itu meminjamkan 7 kepada orang lain. Berapa pulpen Indra sekarang?
A: Indra sekarang memiliki 55 - 11 + 9 - 7 = 48 pulpen.

Verifikasi: Perhitungan yang benar: 55 - 11 = 44, 44 + 9 = 53, 53 - 7 = 46. Jawaban awal salah.

Jawaban akhir: 46 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 3

Q: Eko memiliki 14 pensil. Dia membagi 4 kepada teman. Kemudian membeli 7 pensil. Setelah itu membagi 15 kepada orang lain. Berapa pensil Eko sekarang?
A: Eko sekarang memiliki 14 - 4 + 7 - 15 = 2 pensil.

Verifikasi: Perhitungan: 14 - 4 = 10, 10 + 7 = 17, 17 - 15 = 2. Benar.

Jawaban akhir: 2 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Kiki memiliki 29 bola. Dia meminjamkan 2 kepada teman. Kemudian menerima 8 bola. Setelah itu memberikan 5 kepada orang lain. Berapa bola Kiki sekarang?
A: Kiki sekarang memiliki 29 - 2 + 8 - 5 = 30 bola.

Verifikasi: Perhitungan: 29 - 2 = 27, 27 + 8 = 35, 35 - 5 = 30. Benar.

Jawaban akhir: 30 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
