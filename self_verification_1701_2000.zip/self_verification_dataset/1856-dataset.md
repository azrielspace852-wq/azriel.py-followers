# Dataset Verifikasi Diri 1856

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 53 penghapus. Dia meminjamkan 9 kepada teman. Kemudian membeli 13 penghapus. Setelah itu memberikan 6 kepada orang lain. Berapa penghapus Rina sekarang?
A: Rina sekarang memiliki 53 - 9 + 13 - 6 = 51 penghapus.

Verifikasi: Perhitungan: 53 - 9 = 44, 44 + 13 = 57, 57 - 6 = 51. Benar.

Jawaban akhir: 51 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 83 stiker. Dia meminjamkan 18 kepada teman. Kemudian menang 20 stiker. Setelah itu membagi 14 kepada orang lain. Berapa stiker Rina sekarang?
A: Rina sekarang memiliki 83 - 18 + 20 - 14 = 69 stiker.

Verifikasi: Perhitungan yang benar: 83 - 18 = 65, 65 + 20 = 85, 85 - 14 = 71. Jawaban awal salah.

Jawaban akhir: 71 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Joko memiliki 39 penghapus. Dia memberikan 3 kepada teman. Kemudian menang 4 penghapus. Setelah itu memberikan 6 kepada orang lain. Berapa penghapus Joko sekarang?
A: Joko sekarang memiliki 39 - 3 + 4 - 6 = 34 penghapus.

Verifikasi: Perhitungan: 39 - 3 = 36, 36 + 4 = 40, 40 - 6 = 34. Benar.

Jawaban akhir: 34 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
