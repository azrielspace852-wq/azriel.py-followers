# Dataset Verifikasi Diri 1866

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 16 bola. Dia memberikan 1 kepada teman. Kemudian mendapat 20 bola. Setelah itu meminjamkan 3 kepada orang lain. Berapa bola Gita sekarang?
A: Gita sekarang memiliki 16 - 1 + 20 - 3 = 32 bola.

Verifikasi: Perhitungan: 16 - 1 = 15, 15 + 20 = 35, 35 - 3 = 32. Benar.

Jawaban akhir: 32 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 3

Q: Gita memiliki 44 penghapus. Dia meminjamkan 6 kepada teman. Kemudian mendapat 15 penghapus. Setelah itu memberikan 13 kepada orang lain. Berapa penghapus Gita sekarang?
A: Gita sekarang memiliki 44 - 6 + 15 - 13 = 39 penghapus.

Verifikasi: Perhitungan yang benar: 44 - 6 = 38, 38 + 15 = 53, 53 - 13 = 40. Jawaban awal salah.

Jawaban akhir: 40 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Eko memiliki 61 bola. Dia meminjamkan 11 kepada teman. Kemudian membeli 20 bola. Setelah itu memberikan 5 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 61 - 11 + 20 - 5 = 65 bola.

Verifikasi: Perhitungan: 61 - 11 = 50, 50 + 20 = 70, 70 - 5 = 65. Benar.

Jawaban akhir: 65 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar
