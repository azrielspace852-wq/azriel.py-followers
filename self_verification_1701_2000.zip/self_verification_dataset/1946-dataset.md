# Dataset Verifikasi Diri 1946

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 46 apel. Dia memberikan 8 kepada teman. Kemudian menerima 5 apel. Setelah itu meminjamkan 4 kepada orang lain. Berapa apel Putri sekarang?
A: Putri sekarang memiliki 46 - 8 + 5 - 4 = 39 apel.

Verifikasi: Perhitungan: 46 - 8 = 38, 38 + 5 = 43, 43 - 4 = 39. Benar.

Jawaban akhir: 39 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Maya memiliki 27 kartu. Dia meminjamkan 3 kepada teman. Kemudian menang 6 kartu. Setelah itu meminjamkan 10 kepada orang lain. Berapa kartu Maya sekarang?
A: Maya sekarang memiliki 27 - 3 + 6 - 10 = 22 kartu.

Verifikasi: Perhitungan yang benar: 27 - 3 = 24, 24 + 6 = 30, 30 - 10 = 20. Jawaban awal salah.

Jawaban akhir: 20 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Beberapa burung bisa terbang. Apakah semua burung bisa terbang?
A: Tidak, tidak semua burung bisa terbang.

Verifikasi: 'Beberapa bisa terbang' tidak menolak kemungkinan semua bisa terbang.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Yudi memiliki 88 stiker. Dia membagi 21 kepada teman. Kemudian menang 19 stiker. Setelah itu memberikan 8 kepada orang lain. Berapa stiker Yudi sekarang?
A: Yudi sekarang memiliki 88 - 21 + 19 - 8 = 78 stiker.

Verifikasi: Perhitungan: 88 - 21 = 67, 67 + 19 = 86, 86 - 8 = 78. Benar.

Jawaban akhir: 78 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah
