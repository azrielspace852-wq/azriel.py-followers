# Dataset Verifikasi Diri 1875

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Gita memiliki 99 penggaris. Dia membagi 14 kepada teman. Kemudian membeli 17 penggaris. Setelah itu meminjamkan 7 kepada orang lain. Berapa penggaris Gita sekarang?
A: Gita sekarang memiliki 99 - 14 + 17 - 7 = 96 penggaris.

Verifikasi: Perhitungan yang benar: 99 - 14 = 85, 85 + 17 = 102, 102 - 7 = 95. Jawaban awal salah.

Jawaban akhir: 95 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 92 bola. Dia memberikan 17 kepada teman. Kemudian membeli 4 bola. Setelah itu membagi 1 kepada orang lain. Berapa bola Eko sekarang?
A: Eko sekarang memiliki 92 - 17 + 4 - 1 = 78 bola.

Verifikasi: Perhitungan: 92 - 17 = 75, 75 + 4 = 79, 79 - 1 = 78. Benar.

Jawaban akhir: 78 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Dedi memiliki 28 rupiah. Dia membagi 6 kepada teman. Kemudian menerima 5 rupiah. Setelah itu memberikan 13 kepada orang lain. Berapa rupiah Dedi sekarang?
A: Dedi sekarang memiliki 28 - 6 + 5 - 13 = 14 rupiah.

Verifikasi: Perhitungan: 28 - 6 = 22, 22 + 5 = 27, 27 - 13 = 14. Benar.

Jawaban akhir: 14 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
