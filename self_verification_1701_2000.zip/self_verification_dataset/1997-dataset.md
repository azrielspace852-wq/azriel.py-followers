# Dataset Verifikasi Diri 1997

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 62 pulpen. Dia meminjamkan 10 kepada teman. Kemudian menang 20 pulpen. Setelah itu memberikan 13 kepada orang lain. Berapa pulpen Wati sekarang?
A: Wati sekarang memiliki 62 - 10 + 20 - 13 = 59 pulpen.

Verifikasi: Perhitungan: 62 - 10 = 52, 52 + 20 = 72, 72 - 13 = 59. Benar.

Jawaban akhir: 59 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Zaki memiliki 40 stiker. Dia membagi 8 kepada teman. Kemudian mendapat 2 stiker. Setelah itu membagi 14 kepada orang lain. Berapa stiker Zaki sekarang?
A: Zaki sekarang memiliki 40 - 8 + 2 - 14 = 19 stiker.

Verifikasi: Perhitungan yang benar: 40 - 8 = 32, 32 + 2 = 34, 34 - 14 = 20. Jawaban awal salah.

Jawaban akhir: 20 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Gita memiliki 61 kartu. Dia memberikan 17 kepada teman. Kemudian menang 16 kartu. Setelah itu memberikan 11 kepada orang lain. Berapa kartu Gita sekarang?
A: Gita sekarang memiliki 61 - 17 + 16 - 11 = 49 kartu.

Verifikasi: Perhitungan: 61 - 17 = 44, 44 + 16 = 60, 60 - 11 = 49. Benar.

Jawaban akhir: 49 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
