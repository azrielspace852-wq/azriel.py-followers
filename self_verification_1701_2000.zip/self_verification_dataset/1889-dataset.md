# Dataset Verifikasi Diri 1889

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 30 buku. Dia membagi 5 kepada teman. Kemudian membeli 4 buku. Setelah itu meminjamkan 1 kepada orang lain. Berapa buku Kiki sekarang?
A: Kiki sekarang memiliki 30 - 5 + 4 - 1 = 26 buku.

Verifikasi: Perhitungan yang benar: 30 - 5 = 25, 25 + 4 = 29, 29 - 1 = 28. Jawaban awal salah.

Jawaban akhir: 28 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: A lebih tinggi dari B. B lebih tinggi dari C. Siapa yang paling pendek?
A: C adalah yang paling pendek.

Verifikasi: Karena A > B > C, maka C paling pendek. Benar.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Siti memiliki 14 bola. Dia memberikan 1 kepada teman. Kemudian menerima 11 bola. Setelah itu membagi 5 kepada orang lain. Berapa bola Siti sekarang?
A: Siti sekarang memiliki 14 - 1 + 11 - 5 = 17 bola.

Verifikasi: Perhitungan yang benar: 14 - 1 = 13, 13 + 11 = 24, 24 - 5 = 19. Jawaban awal salah.

Jawaban akhir: 19 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Udin memiliki 24 pensil. Dia membagi 6 kepada teman. Kemudian menang 6 pensil. Setelah itu memberikan 7 kepada orang lain. Berapa pensil Udin sekarang?
A: Udin sekarang memiliki 24 - 6 + 6 - 7 = 15 pensil.

Verifikasi: Perhitungan yang benar: 24 - 6 = 18, 18 + 6 = 24, 24 - 7 = 17. Jawaban awal salah.

Jawaban akhir: 17 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh
