# Dataset Verifikasi Diri 1743

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 36 buku tulis. Dia meminjamkan 7 kepada teman. Kemudian membeli 5 buku tulis. Setelah itu memberikan 8 kepada orang lain. Berapa buku tulis Siti sekarang?
A: Siti sekarang memiliki 36 - 7 + 5 - 8 = 26 buku tulis.

Verifikasi: Perhitungan: 36 - 7 = 29, 29 + 5 = 34, 34 - 8 = 26. Benar.

Jawaban akhir: 26 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Semua burung bisa terbang. Penguin adalah burung. Apakah penguin bisa terbang?
A: Ya, penguin bisa terbang.

Verifikasi: Berdasarkan premis yang diberikan, ya. Namun premis tersebut tidak sesuai kenyataan.

Jawaban akhir: Berdasarkan premis, ya. Namun premis tidak sesuai kenyataan.

Jenis kesalahan: premis_salah

## Contoh 3

Q: Siti memiliki 54 penggaris. Dia membagi 7 kepada teman. Kemudian membeli 8 penggaris. Setelah itu meminjamkan 14 kepada orang lain. Berapa penggaris Siti sekarang?
A: Siti sekarang memiliki 54 - 7 + 8 - 14 = 41 penggaris.

Verifikasi: Perhitungan: 54 - 7 = 47, 47 + 8 = 55, 55 - 14 = 41. Benar.

Jawaban akhir: 41 penggaris.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua anggota tim adalah atlet. Budi adalah atlet. Apakah Budi anggota tim?
A: Ya, Budi anggota tim.

Verifikasi: Semua anggota adalah atlet, tapi tidak semua atlet adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Hani memiliki 12 spidol. Dia membagi 2 kepada teman. Kemudian menerima 18 spidol. Setelah itu memberikan 2 kepada orang lain. Berapa spidol Hani sekarang?
A: Hani sekarang memiliki 12 - 2 + 18 - 2 = 26 spidol.

Verifikasi: Perhitungan: 12 - 2 = 10, 10 + 18 = 28, 28 - 2 = 26. Benar.

Jawaban akhir: 26 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
