# Dataset Verifikasi Diri 1961

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 10 bola. Dia memberikan 3 kepada teman. Kemudian menang 16 bola. Setelah itu memberikan 9 kepada orang lain. Berapa bola Siti sekarang?
A: Siti sekarang memiliki 10 - 3 + 16 - 9 = 14 bola.

Verifikasi: Perhitungan: 10 - 3 = 7, 7 + 16 = 23, 23 - 9 = 14. Benar.

Jawaban akhir: 14 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Tono memiliki 16 kelereng. Dia memberikan 1 kepada teman. Kemudian menerima 13 kelereng. Setelah itu memberikan 11 kepada orang lain. Berapa kelereng Tono sekarang?
A: Tono sekarang memiliki 16 - 1 + 13 - 11 = 17 kelereng.

Verifikasi: Perhitungan: 16 - 1 = 15, 15 + 13 = 28, 28 - 11 = 17. Benar.

Jawaban akhir: 17 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Gita memiliki 86 kue. Dia memberikan 21 kepada teman. Kemudian menerima 10 kue. Setelah itu memberikan 14 kepada orang lain. Berapa kue Gita sekarang?
A: Gita sekarang memiliki 86 - 21 + 10 - 14 = 63 kue.

Verifikasi: Perhitungan yang benar: 86 - 21 = 65, 65 + 10 = 75, 75 - 14 = 61. Jawaban awal salah.

Jawaban akhir: 61 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika A maka B. Jika C maka B. Apakah jika A maka C?
A: Ya.

Verifikasi: Tidak. Premis tidak menghubungkan A dan C secara langsung.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
