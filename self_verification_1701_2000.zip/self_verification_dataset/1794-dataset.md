# Dataset Verifikasi Diri 1794

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 74 pensil. Dia memberikan 19 kepada teman. Kemudian menerima 10 pensil. Setelah itu meminjamkan 3 kepada orang lain. Berapa pensil Siti sekarang?
A: Siti sekarang memiliki 74 - 19 + 10 - 3 = 62 pensil.

Verifikasi: Perhitungan: 74 - 19 = 55, 55 + 10 = 65, 65 - 3 = 62. Benar.

Jawaban akhir: 62 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Eko memiliki 57 penghapus. Dia membagi 10 kepada teman. Kemudian menang 1 penghapus. Setelah itu meminjamkan 15 kepada orang lain. Berapa penghapus Eko sekarang?
A: Eko sekarang memiliki 57 - 10 + 1 - 15 = 33 penghapus.

Verifikasi: Perhitungan: 57 - 10 = 47, 47 + 1 = 48, 48 - 15 = 33. Benar.

Jawaban akhir: 33 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Budi tidak datang ke kantor. Berarti dia sakit?
A: Ya, Budi pasti sakit.

Verifikasi: Tidak datang ke kantor bisa karena banyak alasan selain sakit.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah

## Contoh 5

Q: Hani memiliki 16 spidol. Dia meminjamkan 1 kepada teman. Kemudian menang 12 spidol. Setelah itu meminjamkan 8 kepada orang lain. Berapa spidol Hani sekarang?
A: Hani sekarang memiliki 16 - 1 + 12 - 8 = 22 spidol.

Verifikasi: Perhitungan yang benar: 16 - 1 = 15, 15 + 12 = 27, 27 - 8 = 19. Jawaban awal salah.

Jawaban akhir: 19 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika hujan, maka jalan basah. Jalan basah. Apakah hujan?
A: Ya, pasti hujan.

Verifikasi: Ini afirmasi konsekuen. Jalan basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
