# Dataset Verifikasi Diri 1952

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Joko memiliki 22 spidol. Dia meminjamkan 3 kepada teman. Kemudian mendapat 16 spidol. Setelah itu memberikan 4 kepada orang lain. Berapa spidol Joko sekarang?
A: Joko sekarang memiliki 22 - 3 + 16 - 4 = 29 spidol.

Verifikasi: Perhitungan yang benar: 22 - 3 = 19, 19 + 16 = 35, 35 - 4 = 31. Jawaban awal salah.

Jawaban akhir: 31 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua anggota klub adalah siswa. Andi adalah siswa. Apakah Andi anggota klub?
A: Ya, Andi anggota klub.

Verifikasi: Semua anggota adalah siswa, tapi tidak semua siswa adalah anggota.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Gita memiliki 29 kelereng. Dia memberikan 3 kepada teman. Kemudian menerima 17 kelereng. Setelah itu meminjamkan 6 kepada orang lain. Berapa kelereng Gita sekarang?
A: Gita sekarang memiliki 29 - 3 + 17 - 6 = 37 kelereng.

Verifikasi: Perhitungan: 29 - 3 = 26, 26 + 17 = 43, 43 - 6 = 37. Benar.

Jawaban akhir: 37 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Yudi memiliki 28 rupiah. Dia meminjamkan 8 kepada teman. Kemudian membeli 6 rupiah. Setelah itu memberikan 9 kepada orang lain. Berapa rupiah Yudi sekarang?
A: Yudi sekarang memiliki 28 - 8 + 6 - 9 = 18 rupiah.

Verifikasi: Perhitungan yang benar: 28 - 8 = 20, 20 + 6 = 26, 26 - 9 = 17. Jawaban awal salah.

Jawaban akhir: 17 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah
