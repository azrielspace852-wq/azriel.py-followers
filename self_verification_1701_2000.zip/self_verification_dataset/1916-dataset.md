# Dataset Verifikasi Diri 1916

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 88 kartu. Dia meminjamkan 4 kepada teman. Kemudian menerima 20 kartu. Setelah itu meminjamkan 3 kepada orang lain. Berapa kartu Tono sekarang?
A: Tono sekarang memiliki 88 - 4 + 20 - 3 = 101 kartu.

Verifikasi: Perhitungan: 88 - 4 = 84, 84 + 20 = 104, 104 - 3 = 101. Benar.

Jawaban akhir: 101 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Candra memiliki 43 buku. Dia memberikan 11 kepada teman. Kemudian membeli 14 buku. Setelah itu meminjamkan 11 kepada orang lain. Berapa buku Candra sekarang?
A: Candra sekarang memiliki 43 - 11 + 14 - 11 = 33 buku.

Verifikasi: Perhitungan yang benar: 43 - 11 = 32, 32 + 14 = 46, 46 - 11 = 35. Jawaban awal salah.

Jawaban akhir: 35 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Zaki memiliki 59 kelereng. Dia meminjamkan 16 kepada teman. Kemudian mendapat 20 kelereng. Setelah itu meminjamkan 4 kepada orang lain. Berapa kelereng Zaki sekarang?
A: Zaki sekarang memiliki 59 - 16 + 20 - 4 = 59 kelereng.

Verifikasi: Perhitungan: 59 - 16 = 43, 43 + 20 = 63, 63 - 4 = 59. Benar.

Jawaban akhir: 59 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
