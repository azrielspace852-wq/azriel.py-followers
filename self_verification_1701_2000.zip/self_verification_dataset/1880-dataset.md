# Dataset Verifikasi Diri 1880

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Siti memiliki 90 kue. Dia membagi 9 kepada teman. Kemudian mendapat 6 kue. Setelah itu membagi 11 kepada orang lain. Berapa kue Siti sekarang?
A: Siti sekarang memiliki 90 - 9 + 6 - 11 = 76 kue.

Verifikasi: Perhitungan: 90 - 9 = 81, 81 + 6 = 87, 87 - 11 = 76. Benar.

Jawaban akhir: 76 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 33 pensil. Dia membagi 7 kepada teman. Kemudian menerima 4 pensil. Setelah itu membagi 14 kepada orang lain. Berapa pensil Rina sekarang?
A: Rina sekarang memiliki 33 - 7 + 4 - 14 = 19 pensil.

Verifikasi: Perhitungan yang benar: 33 - 7 = 26, 26 + 4 = 30, 30 - 14 = 16. Jawaban awal salah.

Jawaban akhir: 16 pensil.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Maya memiliki 36 buku tulis. Dia meminjamkan 9 kepada teman. Kemudian menerima 13 buku tulis. Setelah itu membagi 11 kepada orang lain. Berapa buku tulis Maya sekarang?
A: Maya sekarang memiliki 36 - 9 + 13 - 11 = 30 buku tulis.

Verifikasi: Perhitungan yang benar: 36 - 9 = 27, 27 + 13 = 40, 40 - 11 = 29. Jawaban awal salah.

Jawaban akhir: 29 buku tulis.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
