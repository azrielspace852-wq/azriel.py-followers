# Dataset Verifikasi Diri 1812

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 25 penggaris. Dia memberikan 2 kepada teman. Kemudian menerima 19 penggaris. Setelah itu membagi 13 kepada orang lain. Berapa penggaris Udin sekarang?
A: Udin sekarang memiliki 25 - 2 + 19 - 13 = 27 penggaris.

Verifikasi: Perhitungan yang benar: 25 - 2 = 23, 23 + 19 = 42, 42 - 13 = 29. Jawaban awal salah.

Jawaban akhir: 29 penggaris.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Zaki memiliki 17 rupiah. Dia memberikan 1 kepada teman. Kemudian mendapat 17 rupiah. Setelah itu membagi 14 kepada orang lain. Berapa rupiah Zaki sekarang?
A: Zaki sekarang memiliki 17 - 1 + 17 - 14 = 18 rupiah.

Verifikasi: Perhitungan yang benar: 17 - 1 = 16, 16 + 17 = 33, 33 - 14 = 19. Jawaban awal salah.

Jawaban akhir: 19 rupiah.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Rina memiliki 49 pensil. Dia membagi 7 kepada teman. Kemudian mendapat 6 pensil. Setelah itu meminjamkan 9 kepada orang lain. Berapa pensil Rina sekarang?
A: Rina sekarang memiliki 49 - 7 + 6 - 9 = 39 pensil.

Verifikasi: Perhitungan: 49 - 7 = 42, 42 + 6 = 48, 48 - 9 = 39. Benar.

Jawaban akhir: 39 pensil.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
