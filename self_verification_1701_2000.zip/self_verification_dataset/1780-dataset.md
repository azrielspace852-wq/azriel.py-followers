# Dataset Verifikasi Diri 1780

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Indra memiliki 22 kelereng. Dia meminjamkan 7 kepada teman. Kemudian menang 14 kelereng. Setelah itu memberikan 3 kepada orang lain. Berapa kelereng Indra sekarang?
A: Indra sekarang memiliki 22 - 7 + 14 - 3 = 24 kelereng.

Verifikasi: Perhitungan yang benar: 22 - 7 = 15, 15 + 14 = 29, 29 - 3 = 26. Jawaban awal salah.

Jawaban akhir: 26 kelereng.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Andi belajar selama dua minggu. Apakah Andi akan lulus ujian?
A: Ya, Andi akan lulus karena sudah belajar lama.

Verifikasi: Lama belajar saja tidak cukup untuk memastikan kelulusan.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 3

Q: Joko memiliki 47 kertas. Dia memberikan 3 kepada teman. Kemudian mendapat 18 kertas. Setelah itu membagi 13 kepada orang lain. Berapa kertas Joko sekarang?
A: Joko sekarang memiliki 47 - 3 + 18 - 13 = 49 kertas.

Verifikasi: Perhitungan: 47 - 3 = 44, 44 + 18 = 62, 62 - 13 = 49. Benar.

Jawaban akhir: 49 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua siswa yang rajin lulus. Andi lulus. Apakah Andi rajin?
A: Ya, Andi rajin.

Verifikasi: Ini afirmasi konsekuen. Lulus bisa karena sebab lain.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Oscar memiliki 13 kertas. Dia memberikan 3 kepada teman. Kemudian membeli 1 kertas. Setelah itu meminjamkan 15 kepada orang lain. Berapa kertas Oscar sekarang?
A: Oscar sekarang memiliki 13 - 3 + 1 - 15 = -4 kertas.

Verifikasi: Perhitungan: 13 - 3 = 10, 10 + 1 = 11, 11 - 15 = -4. Benar.

Jawaban akhir: -4 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
