# Dataset Verifikasi Diri 1765

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 66 bola. Dia meminjamkan 11 kepada teman. Kemudian menerima 6 bola. Setelah itu membagi 3 kepada orang lain. Berapa bola Wati sekarang?
A: Wati sekarang memiliki 66 - 11 + 6 - 3 = 57 bola.

Verifikasi: Perhitungan yang benar: 66 - 11 = 55, 55 + 6 = 61, 61 - 3 = 58. Jawaban awal salah.

Jawaban akhir: 58 bola.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Jika hujan maka basah. Basah. Apakah hujan?
A: Ya, hujan.

Verifikasi: Afirmasi konsekuen. Basah bisa karena sebab lain.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 3

Q: Candra memiliki 49 stiker. Dia membagi 12 kepada teman. Kemudian membeli 12 stiker. Setelah itu membagi 11 kepada orang lain. Berapa stiker Candra sekarang?
A: Candra sekarang memiliki 49 - 12 + 12 - 11 = 38 stiker.

Verifikasi: Perhitungan: 49 - 12 = 37, 37 + 12 = 49, 49 - 11 = 38. Benar.

Jawaban akhir: 38 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Zaki memiliki 70 spidol. Dia meminjamkan 11 kepada teman. Kemudian menang 1 spidol. Setelah itu memberikan 10 kepada orang lain. Berapa spidol Zaki sekarang?
A: Zaki sekarang memiliki 70 - 11 + 1 - 10 = 50 spidol.

Verifikasi: Perhitungan: 70 - 11 = 59, 59 + 1 = 60, 60 - 10 = 50. Benar.

Jawaban akhir: 50 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
