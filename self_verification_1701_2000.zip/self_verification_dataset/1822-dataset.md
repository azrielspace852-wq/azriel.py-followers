# Dataset Verifikasi Diri 1822

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 74 penghapus. Dia memberikan 24 kepada teman. Kemudian mendapat 10 penghapus. Setelah itu memberikan 14 kepada orang lain. Berapa penghapus Wati sekarang?
A: Wati sekarang memiliki 74 - 24 + 10 - 14 = 46 penghapus.

Verifikasi: Perhitungan: 74 - 24 = 50, 50 + 10 = 60, 60 - 14 = 46. Benar.

Jawaban akhir: 46 penghapus.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Beberapa kucing hitam. Apakah semua kucing hitam?
A: Tidak, tidak semua kucing hitam.

Verifikasi: 'Beberapa hitam' tidak menolak semua hitam.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Yudi memiliki 44 kue. Dia meminjamkan 7 kepada teman. Kemudian menerima 5 kue. Setelah itu memberikan 10 kepada orang lain. Berapa kue Yudi sekarang?
A: Yudi sekarang memiliki 44 - 7 + 5 - 10 = 30 kue.

Verifikasi: Perhitungan yang benar: 44 - 7 = 37, 37 + 5 = 42, 42 - 10 = 32. Jawaban awal salah.

Jawaban akhir: 32 kue.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Cuaca cerah hari ini. Apakah akan turun hujan besok?
A: Tidak, tidak akan hujan besok karena hari ini cerah.

Verifikasi: Cuaca hari ini tidak menentukan cuaca besok secara pasti.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: kesimpulan_terlalu_jauh

## Contoh 5

Q: Lina memiliki 47 bola. Dia membagi 13 kepada teman. Kemudian menang 4 bola. Setelah itu meminjamkan 7 kepada orang lain. Berapa bola Lina sekarang?
A: Lina sekarang memiliki 47 - 13 + 4 - 7 = 31 bola.

Verifikasi: Perhitungan: 47 - 13 = 34, 34 + 4 = 38, 38 - 7 = 31. Benar.

Jawaban akhir: 31 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Budi selalu jujur. Budi berbohong hari ini. Apakah Budi jujur?
A: Budi jujur.

Verifikasi: Premis saling bertentangan.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi
