# Dataset Verifikasi Diri 1903

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Yudi memiliki 33 kartu. Dia memberikan 11 kepada teman. Kemudian membeli 15 kartu. Setelah itu meminjamkan 12 kepada orang lain. Berapa kartu Yudi sekarang?
A: Yudi sekarang memiliki 33 - 11 + 15 - 12 = 25 kartu.

Verifikasi: Perhitungan: 33 - 11 = 22, 22 + 15 = 37, 37 - 12 = 25. Benar.

Jawaban akhir: 25 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih tinggi dari B. Siapa yang paling pendek antara A dan B?
A: B adalah yang paling pendek.

Verifikasi: Ya, karena A lebih tinggi.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Wati memiliki 31 apel. Dia membagi 1 kepada teman. Kemudian membeli 15 apel. Setelah itu meminjamkan 12 kepada orang lain. Berapa apel Wati sekarang?
A: Wati sekarang memiliki 31 - 1 + 15 - 12 = 33 apel.

Verifikasi: Perhitungan: 31 - 1 = 30, 30 + 15 = 45, 45 - 12 = 33. Benar.

Jawaban akhir: 33 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: A adalah yang paling tinggi.

Verifikasi: Informasi hanya mengatakan A lebih tinggi dari B. Tidak ada informasi tentang orang lain. Jadi tidak dapat dipastikan bahwa A adalah yang paling tinggi.

Jawaban akhir: Tidak dapat dipastikan. Kita hanya tahu A lebih tinggi dari B.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Tono memiliki 99 stiker. Dia meminjamkan 17 kepada teman. Kemudian membeli 11 stiker. Setelah itu meminjamkan 15 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 99 - 17 + 11 - 15 = 77 stiker.

Verifikasi: Perhitungan yang benar: 99 - 17 = 82, 82 + 11 = 93, 93 - 15 = 78. Jawaban awal salah.

Jawaban akhir: 78 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih cepat dari B. C lebih cepat dari A. Siapa yang paling cepat antara B dan C?
A: C lebih cepat dari B.

Verifikasi: Karena C lebih cepat dari A dan A lebih cepat dari B, maka C lebih cepat dari B.

Jawaban akhir: C lebih cepat dari B.

Jenis kesalahan: logika_benar
