# Dataset Verifikasi Diri 1851

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 18 pulpen. Dia memberikan 1 kepada teman. Kemudian mendapat 5 pulpen. Setelah itu membagi 14 kepada orang lain. Berapa pulpen Wati sekarang?
A: Wati sekarang memiliki 18 - 1 + 5 - 14 = 9 pulpen.

Verifikasi: Perhitungan yang benar: 18 - 1 = 17, 17 + 5 = 22, 22 - 14 = 8. Jawaban awal salah.

Jawaban akhir: 8 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Semua siswa yang rajin lulus. Andi tidak lulus. Apakah Andi rajin?
A: Tidak, Andi tidak rajin.

Verifikasi: Ya, modus tollens. Jika rajin maka lulus. Karena tidak lulus, maka tidak rajin.

Jawaban akhir: Tidak, Andi tidak rajin.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Maya memiliki 53 buku. Dia membagi 5 kepada teman. Kemudian membeli 19 buku. Setelah itu membagi 1 kepada orang lain. Berapa buku Maya sekarang?
A: Maya sekarang memiliki 53 - 5 + 19 - 1 = 66 buku.

Verifikasi: Perhitungan: 53 - 5 = 48, 48 + 19 = 67, 67 - 1 = 66. Benar.

Jawaban akhir: 66 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika hujan maka basah. Tidak basah. Apakah hujan?
A: Tidak hujan.

Verifikasi: Ya, modus tollens.

Jawaban akhir: Tidak hujan.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Udin memiliki 78 stiker. Dia membagi 16 kepada teman. Kemudian mendapat 15 stiker. Setelah itu membagi 2 kepada orang lain. Berapa stiker Udin sekarang?
A: Udin sekarang memiliki 78 - 16 + 15 - 2 = 76 stiker.

Verifikasi: Perhitungan yang benar: 78 - 16 = 62, 62 + 15 = 77, 77 - 2 = 75. Jawaban awal salah.

Jawaban akhir: 75 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A atau B. A. Apakah B?
A: Tidak, bukan B.

Verifikasi: Tidak dapat disimpulkan. A atau B bisa keduanya benar.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup
