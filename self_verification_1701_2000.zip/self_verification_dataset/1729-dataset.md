# Dataset Verifikasi Diri 1729

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Udin memiliki 94 stiker. Dia meminjamkan 25 kepada teman. Kemudian membeli 11 stiker. Setelah itu memberikan 2 kepada orang lain. Berapa stiker Udin sekarang?
A: Udin sekarang memiliki 94 - 25 + 11 - 2 = 78 stiker.

Verifikasi: Perhitungan: 94 - 25 = 69, 69 + 11 = 80, 80 - 2 = 78. Benar.

Jawaban akhir: 78 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A dan B. Apakah bukan A?
A: Tidak.

Verifikasi: Ya, jika A dan B maka A benar.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Vina memiliki 93 apel. Dia membagi 22 kepada teman. Kemudian membeli 18 apel. Setelah itu memberikan 3 kepada orang lain. Berapa apel Vina sekarang?
A: Vina sekarang memiliki 93 - 22 + 18 - 3 = 86 apel.

Verifikasi: Perhitungan: 93 - 22 = 71, 71 + 18 = 89, 89 - 3 = 86. Benar.

Jawaban akhir: 86 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Semua mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Tidak ada.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Candra memiliki 33 apel. Dia meminjamkan 5 kepada teman. Kemudian menerima 10 apel. Setelah itu memberikan 9 kepada orang lain. Berapa apel Candra sekarang?
A: Candra sekarang memiliki 33 - 5 + 10 - 9 = 27 apel.

Verifikasi: Perhitungan yang benar: 33 - 5 = 28, 28 + 10 = 38, 38 - 9 = 29. Jawaban awal salah.

Jawaban akhir: 29 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
