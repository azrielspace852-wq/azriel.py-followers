# Dataset Verifikasi Diri 1816

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Dedi memiliki 21 kue. Dia meminjamkan 3 kepada teman. Kemudian mendapat 12 kue. Setelah itu membagi 4 kepada orang lain. Berapa kue Dedi sekarang?
A: Dedi sekarang memiliki 21 - 3 + 12 - 4 = 26 kue.

Verifikasi: Perhitungan: 21 - 3 = 18, 18 + 12 = 30, 30 - 4 = 26. Benar.

Jawaban akhir: 26 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Dedi memiliki 49 apel. Dia memberikan 3 kepada teman. Kemudian menang 16 apel. Setelah itu meminjamkan 12 kepada orang lain. Berapa apel Dedi sekarang?
A: Dedi sekarang memiliki 49 - 3 + 16 - 12 = 50 apel.

Verifikasi: Perhitungan: 49 - 3 = 46, 46 + 16 = 62, 62 - 12 = 50. Benar.

Jawaban akhir: 50 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Kiki memiliki 94 buku. Dia membagi 7 kepada teman. Kemudian mendapat 12 buku. Setelah itu memberikan 15 kepada orang lain. Berapa buku Kiki sekarang?
A: Kiki sekarang memiliki 94 - 7 + 12 - 15 = 84 buku.

Verifikasi: Perhitungan: 94 - 7 = 87, 87 + 12 = 99, 99 - 15 = 84. Benar.

Jawaban akhir: 84 buku.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
