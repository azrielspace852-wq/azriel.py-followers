# Dataset Verifikasi Diri 1878

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Wati memiliki 20 stiker. Dia meminjamkan 6 kepada teman. Kemudian mendapat 3 stiker. Setelah itu membagi 1 kepada orang lain. Berapa stiker Wati sekarang?
A: Wati sekarang memiliki 20 - 6 + 3 - 1 = 16 stiker.

Verifikasi: Perhitungan: 20 - 6 = 14, 14 + 3 = 17, 17 - 1 = 16. Benar.

Jawaban akhir: 16 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Putri memiliki 18 buku tulis. Dia membagi 4 kepada teman. Kemudian menerima 15 buku tulis. Setelah itu membagi 13 kepada orang lain. Berapa buku tulis Putri sekarang?
A: Putri sekarang memiliki 18 - 4 + 15 - 13 = 16 buku tulis.

Verifikasi: Perhitungan: 18 - 4 = 14, 14 + 15 = 29, 29 - 13 = 16. Benar.

Jawaban akhir: 16 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Oscar memiliki 60 spidol. Dia memberikan 7 kepada teman. Kemudian mendapat 7 spidol. Setelah itu meminjamkan 15 kepada orang lain. Berapa spidol Oscar sekarang?
A: Oscar sekarang memiliki 60 - 7 + 7 - 15 = 46 spidol.

Verifikasi: Perhitungan yang benar: 60 - 7 = 53, 53 + 7 = 60, 60 - 15 = 45. Jawaban awal salah.

Jawaban akhir: 45 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
