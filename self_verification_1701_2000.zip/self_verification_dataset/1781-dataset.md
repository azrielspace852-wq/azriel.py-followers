# Dataset Verifikasi Diri 1781

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Candra memiliki 30 kue. Dia meminjamkan 2 kepada teman. Kemudian membeli 6 kue. Setelah itu membagi 14 kepada orang lain. Berapa kue Candra sekarang?
A: Candra sekarang memiliki 30 - 2 + 6 - 14 = 20 kue.

Verifikasi: Perhitungan: 30 - 2 = 28, 28 + 6 = 34, 34 - 14 = 20. Benar.

Jawaban akhir: 20 kue.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A atau B. Bukan A. Apakah B?
A: Ya, B.

Verifikasi: Ya, disjungsi eliminasi.

Jawaban akhir: Ya, B.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 22 penghapus. Dia memberikan 2 kepada teman. Kemudian menerima 10 penghapus. Setelah itu meminjamkan 6 kepada orang lain. Berapa penghapus Indra sekarang?
A: Indra sekarang memiliki 22 - 2 + 10 - 6 = 26 penghapus.

Verifikasi: Perhitungan yang benar: 22 - 2 = 20, 20 + 10 = 30, 30 - 6 = 24. Jawaban awal salah.

Jawaban akhir: 24 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: Jika A maka B. Jika B maka C. Apakah jika A maka C?
A: Ya.

Verifikasi: Ya, silogisme hipotetis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Lina memiliki 23 apel. Dia meminjamkan 4 kepada teman. Kemudian menang 6 apel. Setelah itu meminjamkan 6 kepada orang lain. Berapa apel Lina sekarang?
A: Lina sekarang memiliki 23 - 4 + 6 - 6 = 19 apel.

Verifikasi: Perhitungan: 23 - 4 = 19, 19 + 6 = 25, 25 - 6 = 19. Benar.

Jawaban akhir: 19 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
