# Dataset Verifikasi Diri 1751

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Rina memiliki 65 kelereng. Dia membagi 18 kepada teman. Kemudian mendapat 16 kelereng. Setelah itu membagi 3 kepada orang lain. Berapa kelereng Rina sekarang?
A: Rina sekarang memiliki 65 - 18 + 16 - 3 = 60 kelereng.

Verifikasi: Perhitungan: 65 - 18 = 47, 47 + 16 = 63, 63 - 3 = 60. Benar.

Jawaban akhir: 60 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 78 bola. Dia meminjamkan 9 kepada teman. Kemudian mendapat 4 bola. Setelah itu memberikan 2 kepada orang lain. Berapa bola Rina sekarang?
A: Rina sekarang memiliki 78 - 9 + 4 - 2 = 71 bola.

Verifikasi: Perhitungan: 78 - 9 = 69, 69 + 4 = 73, 73 - 2 = 71. Benar.

Jawaban akhir: 71 bola.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Tidak ada kucing yang bisa terbang. Apakah ada kucing yang bisa terbang?
A: Tidak ada.

Verifikasi: Ya, premis langsung mengatakan tidak ada.

Jawaban akhir: Tidak ada.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 11 kartu. Dia membagi 3 kepada teman. Kemudian membeli 19 kartu. Setelah itu meminjamkan 14 kepada orang lain. Berapa kartu Maya sekarang?
A: Maya sekarang memiliki 11 - 3 + 19 - 14 = 13 kartu.

Verifikasi: Perhitungan: 11 - 3 = 8, 8 + 19 = 27, 27 - 14 = 13. Benar.

Jawaban akhir: 13 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih tua dari B. B lebih tua dari C. Siapa yang paling muda?
A: C adalah yang paling muda.

Verifikasi: Ya, A lebih tua dari B lebih tua dari C, C paling muda.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
