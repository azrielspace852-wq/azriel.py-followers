# Dataset Verifikasi Diri 1786

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Zaki memiliki 34 kertas. Dia memberikan 8 kepada teman. Kemudian membeli 6 kertas. Setelah itu memberikan 1 kepada orang lain. Berapa kertas Zaki sekarang?
A: Zaki sekarang memiliki 34 - 8 + 6 - 1 = 31 kertas.

Verifikasi: Perhitungan: 34 - 8 = 26, 26 + 6 = 32, 32 - 1 = 31. Benar.

Jawaban akhir: 31 kertas.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih cepat dari B. B lebih cepat dari C. Siapa yang paling cepat?
A: A adalah yang paling cepat.

Verifikasi: Karena A lebih cepat dari B dan B lebih cepat dari C, maka A lebih cepat dari C. Jadi A paling cepat.

Jawaban akhir: A.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Zaki memiliki 24 spidol. Dia meminjamkan 5 kepada teman. Kemudian menang 15 spidol. Setelah itu meminjamkan 15 kepada orang lain. Berapa spidol Zaki sekarang?
A: Zaki sekarang memiliki 24 - 5 + 15 - 15 = 19 spidol.

Verifikasi: Perhitungan: 24 - 5 = 19, 19 + 15 = 34, 34 - 15 = 19. Benar.

Jawaban akhir: 19 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Ya, A menyukai C.

Verifikasi: Hubungan menyukai tidak bersifat transitif. Tidak ada informasi yang mendukung A menyukai C.

Jawaban akhir: Tidak dapat disimpulkan dari informasi tersebut.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Hani memiliki 44 kartu. Dia meminjamkan 3 kepada teman. Kemudian membeli 2 kartu. Setelah itu memberikan 15 kepada orang lain. Berapa kartu Hani sekarang?
A: Hani sekarang memiliki 44 - 3 + 2 - 15 = 27 kartu.

Verifikasi: Perhitungan yang benar: 44 - 3 = 41, 41 + 2 = 43, 43 - 15 = 28. Jawaban awal salah.

Jawaban akhir: 28 kartu.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Semua A adalah B. Sebagian B adalah C. Apakah semua A adalah C?
A: Ya, semua A adalah C.

Verifikasi: Premis tidak mendukung kesimpulan tersebut. Hanya sebagian B adalah C.

Jawaban akhir: Tidak dapat disimpulkan bahwa semua A adalah C.

Jenis kesalahan: logika_salah
