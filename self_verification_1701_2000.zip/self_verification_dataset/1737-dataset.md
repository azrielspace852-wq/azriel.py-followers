# Dataset Verifikasi Diri 1737

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 72 rupiah. Dia meminjamkan 24 kepada teman. Kemudian menang 3 rupiah. Setelah itu membagi 11 kepada orang lain. Berapa rupiah Tono sekarang?
A: Tono sekarang memiliki 72 - 24 + 3 - 11 = 40 rupiah.

Verifikasi: Perhitungan: 72 - 24 = 48, 48 + 3 = 51, 51 - 11 = 40. Benar.

Jawaban akhir: 40 rupiah.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak ada yang datang ke rapat. Apakah Budi datang?
A: Tidak, Budi tidak datang.

Verifikasi: Ya, karena tidak ada yang datang.

Jawaban akhir: Tidak, Budi tidak datang.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Andi memiliki 78 kartu. Dia memberikan 2 kepada teman. Kemudian mendapat 4 kartu. Setelah itu membagi 8 kepada orang lain. Berapa kartu Andi sekarang?
A: Andi sekarang memiliki 78 - 2 + 4 - 8 = 72 kartu.

Verifikasi: Perhitungan: 78 - 2 = 76, 76 + 4 = 80, 80 - 8 = 72. Benar.

Jawaban akhir: 72 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 5

Q: Zaki memiliki 44 apel. Dia meminjamkan 13 kepada teman. Kemudian menang 9 apel. Setelah itu memberikan 11 kepada orang lain. Berapa apel Zaki sekarang?
A: Zaki sekarang memiliki 44 - 13 + 9 - 11 = 27 apel.

Verifikasi: Perhitungan yang benar: 44 - 13 = 31, 31 + 9 = 40, 40 - 11 = 29. Jawaban awal salah.

Jawaban akhir: 29 apel.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar
