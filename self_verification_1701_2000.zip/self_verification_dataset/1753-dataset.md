# Dataset Verifikasi Diri 1753

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Kiki memiliki 66 pulpen. Dia meminjamkan 12 kepada teman. Kemudian menerima 14 pulpen. Setelah itu memberikan 4 kepada orang lain. Berapa pulpen Kiki sekarang?
A: Kiki sekarang memiliki 66 - 12 + 14 - 4 = 63 pulpen.

Verifikasi: Perhitungan yang benar: 66 - 12 = 54, 54 + 14 = 68, 68 - 4 = 64. Jawaban awal salah.

Jawaban akhir: 64 pulpen.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa mobil berwarna merah. Apakah ada mobil yang tidak merah?
A: Ya, ada yang tidak merah.

Verifikasi: Informasi tidak cukup untuk menyimpulkan.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Zaki memiliki 60 buku. Dia memberikan 1 kepada teman. Kemudian menang 7 buku. Setelah itu membagi 12 kepada orang lain. Berapa buku Zaki sekarang?
A: Zaki sekarang memiliki 60 - 1 + 7 - 12 = 52 buku.

Verifikasi: Perhitungan yang benar: 60 - 1 = 59, 59 + 7 = 66, 66 - 12 = 54. Jawaban awal salah.

Jawaban akhir: 54 buku.

Jenis kesalahan: aritmetika_salah

## Contoh 4

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Maya memiliki 68 stiker. Dia memberikan 18 kepada teman. Kemudian mendapat 5 stiker. Setelah itu meminjamkan 9 kepada orang lain. Berapa stiker Maya sekarang?
A: Maya sekarang memiliki 68 - 18 + 5 - 9 = 47 stiker.

Verifikasi: Perhitungan yang benar: 68 - 18 = 50, 50 + 5 = 55, 55 - 9 = 46. Jawaban awal salah.

Jawaban akhir: 46 stiker.

Jenis kesalahan: aritmetika_salah

## Contoh 6

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
