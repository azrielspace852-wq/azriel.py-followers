# Dataset Verifikasi Diri 1902

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Tono memiliki 69 spidol. Dia membagi 2 kepada teman. Kemudian mendapat 9 spidol. Setelah itu membagi 1 kepada orang lain. Berapa spidol Tono sekarang?
A: Tono sekarang memiliki 69 - 2 + 9 - 1 = 76 spidol.

Verifikasi: Perhitungan yang benar: 69 - 2 = 67, 67 + 9 = 76, 76 - 1 = 75. Jawaban awal salah.

Jawaban akhir: 75 spidol.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Tidak ada mobil yang berwarna hijau. Apakah semua mobil tidak hijau?
A: Ya.

Verifikasi: Ya.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Indra memiliki 11 kelereng. Dia meminjamkan 1 kepada teman. Kemudian mendapat 7 kelereng. Setelah itu memberikan 3 kepada orang lain. Berapa kelereng Indra sekarang?
A: Indra sekarang memiliki 11 - 1 + 7 - 3 = 14 kelereng.

Verifikasi: Perhitungan: 11 - 1 = 10, 10 + 7 = 17, 17 - 3 = 14. Benar.

Jawaban akhir: 14 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih kuat dari B. Siapa yang lebih lemah antara A dan B?
A: B lebih lemah.

Verifikasi: Ya.

Jawaban akhir: B.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Hani memiliki 88 kelereng. Dia membagi 24 kepada teman. Kemudian mendapat 18 kelereng. Setelah itu meminjamkan 1 kepada orang lain. Berapa kelereng Hani sekarang?
A: Hani sekarang memiliki 88 - 24 + 18 - 1 = 81 kelereng.

Verifikasi: Perhitungan: 88 - 24 = 64, 64 + 18 = 82, 82 - 1 = 81. Benar.

Jawaban akhir: 81 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Jika ada listrik, maka lampu bisa menyala. Ada listrik. Apakah lampu menyala?
A: Ya, lampu menyala.

Verifikasi: Premis mengatakan 'bisa menyala', bukan pasti menyala.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah
