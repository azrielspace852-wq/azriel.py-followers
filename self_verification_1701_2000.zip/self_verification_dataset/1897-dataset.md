# Dataset Verifikasi Diri 1897

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Putri memiliki 11 penghapus. Dia membagi 1 kepada teman. Kemudian mendapat 9 penghapus. Setelah itu memberikan 14 kepada orang lain. Berapa penghapus Putri sekarang?
A: Putri sekarang memiliki 11 - 1 + 9 - 14 = 7 penghapus.

Verifikasi: Perhitungan yang benar: 11 - 1 = 10, 10 + 9 = 19, 19 - 14 = 5. Jawaban awal salah.

Jawaban akhir: 5 penghapus.

Jenis kesalahan: aritmetika_salah

## Contoh 2

Q: Beberapa siswa lulus ujian. Apakah semua siswa lulus?
A: Tidak, tidak semua siswa lulus.

Verifikasi: 'Beberapa lulus' tidak menolak kemungkinan semua lulus.

Jawaban akhir: Tidak dapat disimpulkan.

Jenis kesalahan: informasi_tidak_cukup

## Contoh 3

Q: Putri memiliki 84 kartu. Dia membagi 16 kepada teman. Kemudian menang 20 kartu. Setelah itu meminjamkan 2 kepada orang lain. Berapa kartu Putri sekarang?
A: Putri sekarang memiliki 84 - 16 + 20 - 2 = 86 kartu.

Verifikasi: Perhitungan: 84 - 16 = 68, 68 + 20 = 88, 88 - 2 = 86. Benar.

Jawaban akhir: 86 kartu.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: A lebih tinggi dari B. B lebih tinggi dari A. Siapa yang lebih tinggi?
A: A lebih tinggi dari B.

Verifikasi: Premis saling bertentangan. Tidak mungkin A > B dan B > A.

Jawaban akhir: Premis saling bertentangan. Tidak dapat disimpulkan.

Jenis kesalahan: kontradiksi

## Contoh 5

Q: Candra memiliki 13 spidol. Dia memberikan 4 kepada teman. Kemudian mendapat 12 spidol. Setelah itu meminjamkan 3 kepada orang lain. Berapa spidol Candra sekarang?
A: Candra sekarang memiliki 13 - 4 + 12 - 3 = 18 spidol.

Verifikasi: Perhitungan: 13 - 4 = 9, 9 + 12 = 21, 21 - 3 = 18. Benar.

Jawaban akhir: 18 spidol.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Dia tidak membalas pesan saya. Berarti dia marah?
A: Ya, dia pasti marah.

Verifikasi: Tidak membalas pesan bisa karena banyak alasan.

Jawaban akhir: Tidak dapat disimpulkan. Ada banyak kemungkinan lain.

Jenis kesalahan: asumsi_salah
