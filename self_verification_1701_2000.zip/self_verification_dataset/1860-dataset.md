# Dataset Verifikasi Diri 1860

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Oscar memiliki 85 apel. Dia membagi 19 kepada teman. Kemudian menerima 2 apel. Setelah itu membagi 7 kepada orang lain. Berapa apel Oscar sekarang?
A: Oscar sekarang memiliki 85 - 19 + 2 - 7 = 61 apel.

Verifikasi: Perhitungan: 85 - 19 = 66, 66 + 2 = 68, 68 - 7 = 61. Benar.

Jawaban akhir: 61 apel.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: Tidak semua siswa lulus. Apakah ada siswa yang tidak lulus?
A: Ya, ada siswa yang tidak lulus.

Verifikasi: Ya, 'tidak semua lulus' berarti ada yang tidak lulus.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 17 buku tulis. Dia membagi 1 kepada teman. Kemudian mendapat 11 buku tulis. Setelah itu meminjamkan 8 kepada orang lain. Berapa buku tulis Rina sekarang?
A: Rina sekarang memiliki 17 - 1 + 11 - 8 = 19 buku tulis.

Verifikasi: Perhitungan: 17 - 1 = 16, 16 + 11 = 27, 27 - 8 = 19. Benar.

Jawaban akhir: 19 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Hanya beberapa siswa yang hadir. Apakah semua siswa hadir?
A: Tidak, tidak semua siswa hadir.

Verifikasi: Ya, 'hanya beberapa' berarti tidak semua.

Jawaban akhir: Tidak.

Jenis kesalahan: logika_benar

## Contoh 5

Q: Tono memiliki 86 stiker. Dia meminjamkan 21 kepada teman. Kemudian membeli 18 stiker. Setelah itu meminjamkan 4 kepada orang lain. Berapa stiker Tono sekarang?
A: Tono sekarang memiliki 86 - 21 + 18 - 4 = 79 stiker.

Verifikasi: Perhitungan: 86 - 21 = 65, 65 + 18 = 83, 83 - 4 = 79. Benar.

Jawaban akhir: 79 stiker.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: A lebih besar dari B. B lebih besar dari C. C lebih besar dari D. Siapa yang paling kecil?
A: D adalah yang paling kecil.

Verifikasi: Ya, A > B > C > D, D paling kecil.

Jawaban akhir: D.

Jenis kesalahan: logika_benar
