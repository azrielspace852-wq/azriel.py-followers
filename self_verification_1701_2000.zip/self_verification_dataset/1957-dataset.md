# Dataset Verifikasi Diri 1957

Kategori: verifikasi_diri
Tujuan: Melatih model untuk memeriksa dan mengoreksi jawaban sendiri.

## Contoh 1

Q: Eko memiliki 29 kelereng. Dia memberikan 1 kepada teman. Kemudian mendapat 10 kelereng. Setelah itu memberikan 2 kepada orang lain. Berapa kelereng Eko sekarang?
A: Eko sekarang memiliki 29 - 1 + 10 - 2 = 36 kelereng.

Verifikasi: Perhitungan: 29 - 1 = 28, 28 + 10 = 38, 38 - 2 = 36. Benar.

Jawaban akhir: 36 kelereng.

Jenis kesalahan: aritmetika_benar

## Contoh 2

Q: A lebih kuat dari B. B lebih kuat dari C. Siapa yang paling lemah?
A: C adalah yang paling lemah.

Verifikasi: Ya.

Jawaban akhir: C.

Jenis kesalahan: logika_benar

## Contoh 3

Q: Rina memiliki 33 buku tulis. Dia memberikan 4 kepada teman. Kemudian mendapat 5 buku tulis. Setelah itu membagi 9 kepada orang lain. Berapa buku tulis Rina sekarang?
A: Rina sekarang memiliki 33 - 4 + 5 - 9 = 25 buku tulis.

Verifikasi: Perhitungan: 33 - 4 = 29, 29 + 5 = 34, 34 - 9 = 25. Benar.

Jawaban akhir: 25 buku tulis.

Jenis kesalahan: aritmetika_benar

## Contoh 4

Q: Jika lampu menyala, maka ada listrik. Lampu tidak menyala. Apakah ada listrik?
A: Tidak ada listrik.

Verifikasi: Kesalahan menyangkal konsekuen. Lampu tidak menyala bisa karena rusak.

Jawaban akhir: Tidak dapat dipastikan.

Jenis kesalahan: logika_salah

## Contoh 5

Q: Candra memiliki 79 pulpen. Dia meminjamkan 20 kepada teman. Kemudian membeli 14 pulpen. Setelah itu meminjamkan 9 kepada orang lain. Berapa pulpen Candra sekarang?
A: Candra sekarang memiliki 79 - 20 + 14 - 9 = 64 pulpen.

Verifikasi: Perhitungan: 79 - 20 = 59, 59 + 14 = 73, 73 - 9 = 64. Benar.

Jawaban akhir: 64 pulpen.

Jenis kesalahan: aritmetika_benar

## Contoh 6

Q: Semua siswa di kelas ini pandai. Andi adalah siswa di kelas ini. Apakah Andi pandai?
A: Ya, Andi pandai.

Verifikasi: Ya, berdasarkan premis.

Jawaban akhir: Ya.

Jenis kesalahan: logika_benar
