# Dataset Koreksi Kesalahan — 2563

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Kamu bilang Garuda Pancasila memiliki 6 sila. Itu tidak benar. Yang benar Garuda Pancasila memiliki 5 sila.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Garuda Pancasila memiliki 5 sila.

Q: Kamu bilang A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi. Itu tidak benar. Yang benar Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Jawaban sebelumnya: Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.
User: Itu salah. Satu ton = 100 kg ya?
A: Saya keliru sebelumnya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Jawaban sebelumnya: Bahasa Inggris adalah bahasa resmi Indonesia.
User: Itu salah. Bahasa resmi kita bahasa Inggris kan?
A: Saya mengakui kesalahan saya. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Gunung tertinggi di Indonesia adalah Merapi.'?
A: Ya, saya salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Jawaban sebelumnya: Soekarno lahir di Bandung.
User: Itu salah. Soekarno lahir di Bandung ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Soekarno lahir di Blitar, Jawa Timur.

Q: Apakah kamu salah waktu bilang 'Satu jam sama dengan 100 menit.'?
A: Ya, saya salah. Satu jam sama dengan 60 menit.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Saya keliru sebelumnya. Hasil 14 + 6 adalah 20.

Q: Kamu bilang Hasil 12 ÷ 3 adalah 5. Itu tidak benar. Yang benar Hasil 12 ÷ 3 adalah 4.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 12 ÷ 3 adalah 4.

Q: Kamu bilang Soekarno lahir di Bandung. Itu tidak benar. Yang benar Soekarno lahir di Blitar, Jawa Timur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Soekarno lahir di Blitar, Jawa Timur.

Q: Apakah kamu salah waktu bilang 'Air mendidih pada suhu 90 derajat Celsius.'?
A: Ya, saya salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: 6 kali 9 hasilnya 52?
A: Benar, saya salah. Hasil 6 × 9 adalah 54.

Q: Kamu bilang Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. Itu tidak benar. Yang benar Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Kamu bilang Manusia memiliki 5 indera. Itu tidak benar. Yang benar Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: 81 dibagi 9 = 10 kan?
A: Saya tadi salah. Hasil 81 ÷ 9 adalah 9.

Q: Tetap saja, Pulau terbesar di Indonesia adalah Jawa. benar kan?
A: Tidak, itu tetap salah. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Kamu bilang Hasil 8 × 7 adalah 54. Itu tidak benar. Yang benar Hasil 8 × 7 adalah 56.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 8 × 7 adalah 56.

Q: Jawaban sebelumnya: Garuda Pancasila memiliki 6 sila.
User: Itu salah. Pancasila ada 6 sila kan?
A: Saya telah membuat kesalahan. Garuda Pancasila memiliki 5 sila.

Q: Tetap saja, Hasil 6 × 9 adalah 52. benar kan?
A: Tidak, itu tetap salah. Hasil 6 × 9 adalah 54.

Q: Apakah kamu salah waktu bilang 'Ibu kota Indonesia adalah Kuala Lumpur.'?
A: Ya, saya salah. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Kamu bilang Proklamasi kemerdekaan dibacakan oleh Hatta. Itu tidak benar. Yang benar Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Air mendidih di 90 derajat ya?
A: Benar, saya salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Seminggu ada 8 hari kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Terdapat 7 hari dalam seminggu.

Q: Air itu unsur kimia kan?
A: Saya minta maaf, saya salah. Air adalah senyawa (H2O), bukan unsur.

Q: Apakah kamu salah waktu bilang 'Kata 'meja' adalah kata kerja.'?
A: Ya, saya salah. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Jawaban sebelumnya: Matahari adalah planet.
User: Itu salah. Matahari itu planet ya?
A: Saya keliru sebelumnya. Matahari adalah bintang, bukan planet.

Q: Kamu bilang Ibu kota Indonesia adalah Kuala Lumpur. Itu tidak benar. Yang benar Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Es lebih berat dari air ya?
A: Saya tadi salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Apakah kamu salah waktu bilang 'Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.'?
A: Ya, saya salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Jawaban sebelumnya: Planet terbesar di tata surya adalah Bumi.
User: Itu salah. Planet terbesar Bumi kan?
A: Saya keliru sebelumnya. Planet terbesar di tata surya adalah Jupiter.

Q: Apakah kamu salah waktu bilang 'Hasil 45 - 17 adalah 27.'?
A: Ya, saya salah. Hasil 45 - 17 adalah 28.

Q: Tetap saja, Sungai terpanjang di dunia adalah Amazon. benar kan?
A: Tidak, itu tetap salah. Sungai terpanjang di dunia biasanya disebut Nil, meskipun ada perdebatan dengan Amazon tergantung metode pengukuran.

Q: Manusia pakai insang ya?
A: Saya minta maaf, saya salah. Manusia bernafas dengan paru-paru.

Q: Tetap saja, Satu jam sama dengan 100 menit. benar kan?
A: Tidak, itu tetap salah. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Hasil 81 ÷ 9 adalah 10.'?
A: Ya, saya salah. Hasil 81 ÷ 9 adalah 9.

Q: Tetap saja, Soekarno lahir di Bandung. benar kan?
A: Tidak, itu tetap salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Apakah kamu salah waktu bilang 'Komputer pertama dibuat tahun 2000.'?
A: Ya, saya salah. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Jawaban sebelumnya: A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.
User: Itu salah. A lebih tinggi B, B lebih tinggi C, berarti C paling tinggi kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Apakah kamu salah waktu bilang 'Manusia memiliki 5 indera.'?
A: Ya, saya salah. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Kamu bilang Bumi mengelilingi Matahari dalam 365 hari tepat. Itu tidak benar. Yang benar Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Apakah kamu salah waktu bilang 'A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.'?
A: Ya, saya salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Manusia cuma punya 5 indera ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Jawaban sebelumnya: Hiu adalah mamalia.
User: Itu salah. Hiu itu mamalia kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Hiu adalah ikan, bukan mamalia.

Q: Apakah kamu salah waktu bilang 'Indonesia merdeka pada tahun 1944.'?
A: Ya, saya salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Tetap saja, Matahari adalah planet. benar kan?
A: Tidak, itu tetap salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Ibukota Australia adalah Sydney. benar kan?
A: Tidak, itu tetap salah. Ibukota Australia adalah Canberra.

Q: Kamu bilang Komputer pertama dibuat tahun 2000. Itu tidak benar. Yang benar Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.
