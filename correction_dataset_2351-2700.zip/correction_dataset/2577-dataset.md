# Dataset Koreksi Kesalahan — 2577

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Kamu bilang Gunung tertinggi di Indonesia adalah Merapi. Itu tidak benar. Yang benar Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Kamu bilang Hasil 23 + 18 adalah 40. Itu tidak benar. Yang benar Hasil 23 + 18 adalah 41.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 23 + 18 adalah 41.

Q: Manusia pakai insang ya?
A: Saya telah membuat kesalahan. Manusia bernafas dengan paru-paru.

Q: Tetap saja, Hasil 81 ÷ 9 adalah 10. benar kan?
A: Tidak, itu tetap salah. Hasil 81 ÷ 9 adalah 9.

Q: Apakah kamu salah waktu bilang 'Listrik ditemukan oleh Einstein.'?
A: Ya, saya salah. Listrik sebagai fenomena sudah lama dikenal; Benjamin Franklin melakukan eksperimen terkenal, dan banyak ilmuwan berkontribusi.

Q: Apakah kamu salah waktu bilang 'Gunung Everest berada di Indonesia.'?
A: Ya, saya salah. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Jawaban sebelumnya: Hasil 6 × 9 adalah 52.
User: Itu salah. 6 kali 9 hasilnya 52?
A: Saya keliru sebelumnya. Hasil 6 × 9 adalah 54.

Q: Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Saya koreksi: jawaban sebelumnya tidak benar. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Everest di Indonesia ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Kamu bilang Pulau terbesar di Indonesia adalah Jawa. Itu tidak benar. Yang benar Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Apakah kamu salah waktu bilang 'Air mendidih pada suhu 90 derajat Celsius.'?
A: Ya, saya salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Perang Dunia II berakhir tahun 1944. Itu tidak benar. Yang benar Perang Dunia II berakhir tahun 1945.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Perang Dunia II berakhir tahun 1945.

Q: Kamu bilang Ibukota Australia adalah Sydney. Itu tidak benar. Yang benar Ibukota Australia adalah Canberra.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibukota Australia adalah Canberra.

Q: Seminggu ada 8 hari kan?
A: Saya keliru sebelumnya. Terdapat 7 hari dalam seminggu.

Q: Jawaban sebelumnya: Hasil 81 ÷ 9 adalah 10.
User: Itu salah. 81 dibagi 9 = 10 kan?
A: Saya tadi salah. Hasil 81 ÷ 9 adalah 9.

Q: Tetap saja, Hasil 14 + 6 adalah 20. benar kan?
A: Tidak, itu tetap salah. Hasil 14 + 6 adalah 20.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Apakah kamu salah waktu bilang 'Hasil 9² adalah 81, jadi 9³ adalah 243.'?
A: Ya, saya salah. 9² = 81, tetapi 9³ = 729, bukan 243.

Q: Kamu bilang Soekarno lahir di Bandung. Itu tidak benar. Yang benar Soekarno lahir di Blitar, Jawa Timur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Soekarno lahir di Blitar, Jawa Timur.

Q: Tetap saja, Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. benar kan?
A: Tidak, itu tetap salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Kamu bilang Es lebih berat dari air. Itu tidak benar. Yang benar Es lebih ringan dari air dalam bentuk cair (karena mengapung).
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Tetap saja, Manusia memiliki 5 indera. benar kan?
A: Tidak, itu tetap salah. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Apakah kamu salah waktu bilang 'Hasil 45 - 17 adalah 27.'?
A: Ya, saya salah. Hasil 45 - 17 adalah 28.

Q: Tetap saja, Bulan memancarkan cahayanya sendiri. benar kan?
A: Tidak, itu tetap salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Tetap saja, Komputer pertama dibuat tahun 2000. benar kan?
A: Tidak, itu tetap salah. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Tetap saja, Bahasa Inggris adalah bahasa resmi Indonesia. benar kan?
A: Tidak, itu tetap salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Jawaban sebelumnya: Bumi mengelilingi Matahari dalam 365 hari tepat.
User: Itu salah. Satu tahun pasti 365 hari kan?
A: Benar, saya salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Kamu bilang Ibu kota Indonesia adalah Kuala Lumpur. Itu tidak benar. Yang benar Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: 8 kali 7 hasilnya 54 ya?
A: Saya tadi salah. Hasil 8 × 7 adalah 56.

Q: Kamu bilang Hasil 45 - 17 adalah 27. Itu tidak benar. Yang benar Hasil 45 - 17 adalah 28.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 45 - 17 adalah 28.

Q: Tetap saja, Manusia bernafas dengan insang. benar kan?
A: Tidak, itu tetap salah. Manusia bernafas dengan paru-paru.

Q: Jawaban sebelumnya: Bahasa resmi Indonesia adalah bahasa Jawa.
User: Itu salah. Bahasa resmi kita bahasa Jawa kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Kamu bilang Proklamasi kemerdekaan dibacakan oleh Hatta. Itu tidak benar. Yang benar Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: 15 + 27 = 41 kan?
A: Benar, saya salah. Hasil 15 + 27 adalah 42.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Hasil 14 + 6 adalah 20.

Q: Apakah kamu salah waktu bilang 'A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.'?
A: Ya, saya salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Tetap saja, Air adalah unsur. benar kan?
A: Tidak, itu tetap salah. Air adalah senyawa (H2O), bukan unsur.

Q: Kamu bilang Kelelawar adalah burung. Itu tidak benar. Yang benar Kelelawar adalah mamalia yang bisa terbang, bukan burung.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Tetap saja, Es lebih berat dari air. benar kan?
A: Tidak, itu tetap salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Matahari itu planet ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Hasil 30 - 12 adalah 17. benar kan?
A: Tidak, itu tetap salah. Hasil 30 - 12 adalah 18.

Q: Jawaban sebelumnya: Jika semua A adalah B, maka semua B adalah A.
User: Itu salah. Kalau semua A adalah B, berarti semua B adalah A ya?
A: Jawaban saya tadi keliru. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Tetap saja, Matahari adalah planet. benar kan?
A: Tidak, itu tetap salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Bahasa resmi Indonesia adalah bahasa Jawa. benar kan?
A: Tidak, itu tetap salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya tadi salah. Satu jam sama dengan 60 menit.

Q: Indonesia merdeka tahun 1944 ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Jawaban sebelumnya: Perang Dunia II berakhir tahun 1944.
User: Itu salah. Perang Dunia II selesai 1944 ya?
A: Saya telah membuat kesalahan. Perang Dunia II berakhir tahun 1945.

Q: Jawaban sebelumnya: Hasil 12 ÷ 3 adalah 5.
User: Itu salah. 12 dibagi 3 hasilnya 5 ya?
A: Benar, saya salah. Hasil 12 ÷ 3 adalah 4.
