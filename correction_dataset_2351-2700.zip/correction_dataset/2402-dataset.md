# Dataset Koreksi Kesalahan — 2402

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Tetap saja, Hasil 23 + 18 adalah 40. benar kan?
A: Tidak, itu tetap salah. Hasil 23 + 18 adalah 41.

Q: Jawaban sebelumnya: Hasil 30 - 12 adalah 17.
User: Itu salah. 30 kurang 12 = 17 ya?
A: Saya keliru sebelumnya. Hasil 30 - 12 adalah 18.

Q: Apakah kamu salah waktu bilang 'Matahari adalah planet.'?
A: Ya, saya salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Bulan memancarkan cahayanya sendiri. benar kan?
A: Tidak, itu tetap salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Tetap saja, Internet ditemukan tahun 2010. benar kan?
A: Tidak, itu tetap salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Jawaban sebelumnya: Hasil 23 + 18 adalah 40.
User: Itu salah. 23 + 18 = 40 kan?
A: Jawaban saya tadi keliru. Hasil 23 + 18 adalah 41.

Q: 81 dibagi 9 = 10 kan?
A: Saya telah membuat kesalahan. Hasil 81 ÷ 9 adalah 9.

Q: Apakah kamu salah waktu bilang 'Hasil 14 + 6 adalah 20.'?
A: Ya, saya salah. Hasil 14 + 6 adalah 20.

Q: Jawaban sebelumnya: Es lebih berat dari air.
User: Itu salah. Es lebih berat dari air ya?
A: Saya mengakui kesalahan saya. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Kamu bilang Satu jam sama dengan 100 menit. Itu tidak benar. Yang benar Satu jam sama dengan 60 menit.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Besi lebih ringan dari kayu.'?
A: Ya, saya salah. Besi lebih berat dari kayu pada volume yang sama.

Q: Jawaban sebelumnya: Terdapat 8 hari dalam seminggu.
User: Itu salah. Seminggu ada 8 hari kan?
A: Saya telah membuat kesalahan. Terdapat 7 hari dalam seminggu.

Q: Tetap saja, Jika semua A adalah B, maka semua B adalah A. benar kan?
A: Tidak, itu tetap salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Kamu bilang Hasil 8 × 7 adalah 54. Itu tidak benar. Yang benar Hasil 8 × 7 adalah 56.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 8 × 7 adalah 56.

Q: Hiu itu mamalia kan?
A: Saya tadi salah. Hiu adalah ikan, bukan mamalia.

Q: Tetap saja, Hasil 7 × 8 adalah 54. benar kan?
A: Tidak, itu tetap salah. Hasil 7 × 8 adalah 56.

Q: Apakah kamu salah waktu bilang 'Hasil 23 + 18 adalah 40.'?
A: Ya, saya salah. Hasil 23 + 18 adalah 41.

Q: Kamu bilang Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. Itu tidak benar. Yang benar Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Kamu bilang Listrik ditemukan oleh Einstein. Itu tidak benar. Yang benar Listrik sebagai fenomena sudah lama dikenal. Banyak ilmuwan berkontribusi, termasuk Benjamin Franklin yang melakukan eksperimen terkenal.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Listrik sebagai fenomena sudah lama dikenal. Banyak ilmuwan berkontribusi, termasuk Benjamin Franklin yang melakukan eksperimen terkenal.

Q: Apakah kamu salah waktu bilang 'Bahasa Inggris adalah bahasa resmi Indonesia.'?
A: Ya, saya salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Terdapat 8 hari dalam seminggu.'?
A: Ya, saya salah. Terdapat 7 hari dalam seminggu.

Q: Kamu bilang A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi. Itu tidak benar. Yang benar Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Apakah kamu salah waktu bilang 'Jika semua A adalah B, maka semua B adalah A.'?
A: Ya, saya salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Kalau semua A adalah B, berarti semua B adalah A ya?
A: Jawaban saya tadi keliru. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Kamu bilang Presiden pertama Indonesia adalah Hatta. Itu tidak benar. Yang benar Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Jawaban sebelumnya: Air mendidih pada suhu 90 derajat Celsius.
User: Itu salah. Air mendidih di 90 derajat ya?
A: Saya keliru sebelumnya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Tetap saja, Hasil 56 ÷ 7 adalah 9. benar kan?
A: Tidak, itu tetap salah. Hasil 56 ÷ 7 adalah 8.

Q: Kamu bilang Bahasa resmi Indonesia adalah bahasa Jawa. Itu tidak benar. Yang benar Bahasa resmi Indonesia adalah bahasa Indonesia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Indonesia merdeka tahun 1944 ya?
A: Saya minta maaf, saya salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Perang Dunia II selesai 1944 ya?
A: Saya mengakui kesalahan saya. Perang Dunia II berakhir tahun 1945.

Q: Tetap saja, Manusia bernafas dengan insang. benar kan?
A: Tidak, itu tetap salah. Manusia bernafas dengan paru-paru.

Q: Meja itu kata kerja kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Kamu bilang Air mendidih pada suhu 90 derajat Celsius. Itu tidak benar. Yang benar Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Gunung Everest berada di Indonesia. Itu tidak benar. Yang benar Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Saya mengakui kesalahan saya. Hasil 14 + 6 adalah 20.

Q: Bahasa resmi kita bahasa Jawa kan?
A: Saya tadi salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Tetap saja, Gunung Everest berada di Indonesia. benar kan?
A: Tidak, itu tetap salah. Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.

Q: Jawaban sebelumnya: Jika semua A adalah B, maka semua B adalah A.
User: Itu salah. Kalau semua A adalah B, berarti semua B adalah A ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Komputer pertama tahun 2000 kan?
A: Saya minta maaf, saya salah. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Jawaban sebelumnya: Komputer pertama dibuat tahun 2000.
User: Itu salah. Komputer pertama tahun 2000 kan?
A: Saya tadi salah. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Jawaban sebelumnya: Hasil 81 ÷ 9 adalah 10.
User: Itu salah. 81 dibagi 9 = 10 kan?
A: Jawaban saya tadi keliru. Hasil 81 ÷ 9 adalah 9.

Q: Kamu bilang Hasil 6 × 9 adalah 52. Itu tidak benar. Yang benar Hasil 6 × 9 adalah 54.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 6 × 9 adalah 54.

Q: Apakah kamu salah waktu bilang bahwa 2 + 2 = 5?
A: Ya, saya salah. Hasil 2 + 2 adalah 4.

Q: Tetap saja, ibu kota Indonesia adalah Bandung kan?
A: Tidak, itu tetap salah. Ibu kota Indonesia adalah Jakarta.

Q: Kamu bilang hasil 10 × 10 adalah 1000. Itu tidak benar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan. Hasil 10 × 10 adalah 100.

Q: Apakah kamu keliru soal warna langit?
A: Jika saya mengatakan langit berwarna hijau, itu salah. Langit terlihat biru karena cahaya biru lebih banyak dihamburkan oleh atmosfer.

Q: Kamu sebelumnya bilang ada delapan planet termasuk Pluto.
A: Saya koreksi. Pluto tidak lagi digolongkan sebagai planet utama sejak tahun 2006. Saat ini ada delapan planet.
