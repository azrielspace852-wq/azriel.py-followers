# Dataset Koreksi Kesalahan — 2507

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Jawaban sebelumnya: Manusia bernafas dengan insang.
User: Itu salah. Manusia pakai insang ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Manusia bernafas dengan paru-paru.

Q: Presiden pertama Indonesia Hatta ya?
A: Benar, saya salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Apakah kamu salah waktu bilang 'Presiden pertama Indonesia adalah Hatta.'?
A: Ya, saya salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Pancasila ada 6 sila kan?
A: Saya tadi salah. Garuda Pancasila memiliki 5 sila.

Q: Kalau semua A adalah B, berarti semua B adalah A ya?
A: Saya telah membuat kesalahan. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Apakah kamu salah waktu bilang 'Hasil 12 ÷ 3 adalah 5.'?
A: Ya, saya salah. Hasil 12 ÷ 3 adalah 4.

Q: Tetap saja, Hasil 23 + 18 adalah 40. benar kan?
A: Tidak, itu tetap salah. Hasil 23 + 18 adalah 41.

Q: Apakah kamu salah waktu bilang 'Hasil 7 × 8 adalah 54.'?
A: Ya, saya salah. Hasil 7 × 8 adalah 56.

Q: 30 kurang 12 = 17 ya?
A: Saya tadi salah. Hasil 30 - 12 adalah 18.

Q: Tetap saja, Bahasa Inggris adalah bahasa resmi Indonesia. benar kan?
A: Tidak, itu tetap salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Matahari adalah planet.'?
A: Ya, saya salah. Matahari adalah bintang, bukan planet.

Q: Jawaban sebelumnya: Presiden pertama Indonesia adalah Hatta.
User: Itu salah. Presiden pertama Indonesia Hatta ya?
A: Benar, saya salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Pelangi cuma 5 warna kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Apakah kamu salah waktu bilang 'Bahasa resmi Indonesia adalah bahasa Jawa.'?
A: Ya, saya salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Apakah kamu salah waktu bilang 'Es lebih berat dari air.'?
A: Ya, saya salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: 12 dibagi 3 hasilnya 5 ya?
A: Benar, saya salah. Hasil 12 ÷ 3 adalah 4.

Q: Kamu bilang Bumi mengelilingi Matahari dalam 365 hari tepat. Itu tidak benar. Yang benar Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Tetap saja, Terdapat 8 hari dalam seminggu. benar kan?
A: Tidak, itu tetap salah. Terdapat 7 hari dalam seminggu.

Q: Tetap saja, Internet ditemukan tahun 2010. benar kan?
A: Tidak, itu tetap salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Tetap saja, Satu jam sama dengan 100 menit. benar kan?
A: Tidak, itu tetap salah. Satu jam sama dengan 60 menit.

Q: Jawaban sebelumnya: Air mendidih pada suhu 90 derajat Celsius.
User: Itu salah. Air mendidih di 90 derajat ya?
A: Saya tadi salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Tetap saja, Uang kertas 100.000 rupiah berwarna merah. benar kan?
A: Tidak, itu tetap salah. Uang kertas 100.000 rupiah berwarna merah muda / pink.

Q: Kamu bilang Kata 'meja' adalah kata kerja. Itu tidak benar. Yang benar Kata 'meja' adalah kata benda, bukan kata kerja.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Tetap saja, Proklamasi kemerdekaan dibacakan oleh Hatta. benar kan?
A: Tidak, itu tetap salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Kamu bilang Sinonim dari 'besar' adalah 'kecil'. Itu tidak benar. Yang benar Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Tetap saja, Perang Dunia II berakhir tahun 1944. benar kan?
A: Tidak, itu tetap salah. Perang Dunia II berakhir tahun 1945.

Q: Kamu bilang Manusia bernafas dengan insang. Itu tidak benar. Yang benar Manusia bernafas dengan paru-paru.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Manusia bernafas dengan paru-paru.

Q: Soekarno lahir di Bandung ya?
A: Saya minta maaf, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Kamu bilang Tomat adalah sayuran. Itu tidak benar. Yang benar Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Kamu bilang Air adalah unsur. Itu tidak benar. Yang benar Air adalah senyawa (H2O), bukan unsur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air adalah senyawa (H2O), bukan unsur.

Q: Tetap saja, Hasil 6 × 9 adalah 52. benar kan?
A: Tidak, itu tetap salah. Hasil 6 × 9 adalah 54.

Q: Kamu bilang Ibukota Australia adalah Sydney. Itu tidak benar. Yang benar Ibukota Australia adalah Canberra.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibukota Australia adalah Canberra.

Q: Kamu bilang Manusia memiliki 5 indera. Itu tidak benar. Yang benar Secara tradisional disebut lima indera, tetapi sebenarnya manusia memiliki lebih banyak indera, termasuk indera keseimbangan dan indera posisi tubuh.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Secara tradisional disebut lima indera, tetapi sebenarnya manusia memiliki lebih banyak indera, termasuk indera keseimbangan dan indera posisi tubuh.

Q: Apakah kamu salah waktu bilang 'Uang kertas 100.000 rupiah berwarna merah.'?
A: Ya, saya salah. Uang kertas 100.000 rupiah berwarna merah muda / pink.

Q: Tetap saja, Ibukota Australia adalah Sydney. benar kan?
A: Tidak, itu tetap salah. Ibukota Australia adalah Canberra.

Q: Kamu bilang Planet terbesar di tata surya adalah Bumi. Itu tidak benar. Yang benar Planet terbesar di tata surya adalah Yupiter.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Planet terbesar di tata surya adalah Yupiter.

Q: Tetap saja, Manusia memiliki 5 indera. benar kan?
A: Tidak, itu tetap salah. Secara tradisional disebut lima indera, tetapi sebenarnya manusia memiliki lebih banyak indera, termasuk indera keseimbangan dan indera posisi tubuh.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Saya telah membuat kesalahan. Hasil 14 + 6 adalah 20.

Q: Apakah kamu salah waktu bilang 'Jika semua A adalah B, maka semua B adalah A.'?
A: Ya, saya salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Kamu bilang Air mendidih pada suhu 90 derajat Celsius. Itu tidak benar. Yang benar Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Air mendidih di 90 derajat ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Jawaban sebelumnya: Perang Dunia II berakhir tahun 1944.
User: Itu salah. Perang Dunia II selesai 1944 ya?
A: Saya tadi salah. Perang Dunia II berakhir tahun 1945.

Q: Apakah kamu salah waktu bilang 'Ibukota Australia adalah Sydney.'?
A: Ya, saya salah. Ibukota Australia adalah Canberra.

Q: Tetap saja, Hasil 100 - 37 adalah 62. benar kan?
A: Tidak, itu tetap salah. Hasil 100 - 37 adalah 63.

Q: Tetap saja, Bulan memancarkan cahayanya sendiri. benar kan?
A: Tidak, itu tetap salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Kamu bilang Bahasa resmi Indonesia adalah bahasa Jawa. Itu tidak benar. Yang benar Bahasa resmi Indonesia adalah bahasa Indonesia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Komputer pertama tahun 2000 kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Tetap saja, A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi. benar kan?
A: Tidak, itu tetap salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.
