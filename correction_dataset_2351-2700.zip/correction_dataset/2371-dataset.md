# Dataset Koreksi Kesalahan — 2371

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Kamu bilang Ibukota Australia adalah Sydney. Itu tidak benar. Yang benar Ibukota Australia adalah Canberra.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibukota Australia adalah Canberra.

Q: Tetap saja, Hiu adalah mamalia. benar kan?
A: Tidak, itu tetap salah. Hiu adalah ikan, bukan mamalia.

Q: Apakah kamu salah waktu bilang 'Hasil 23 + 18 adalah 40.'?
A: Ya, saya salah. Hasil 23 + 18 adalah 41.

Q: Apakah kamu salah waktu bilang 'Gunung tertinggi di Indonesia adalah Merapi.'?
A: Ya, saya salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Kamu bilang Air adalah unsur. Itu tidak benar. Yang benar Air adalah senyawa (H2O), bukan unsur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air adalah senyawa (H2O), bukan unsur.

Q: Apakah kamu salah waktu bilang 'Matahari adalah planet.'?
A: Ya, saya salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Besi lebih ringan dari kayu. benar kan?
A: Tidak, itu tetap salah. Besi lebih berat dari kayu pada volume yang sama.

Q: Jawaban sebelumnya: Pulau terbesar di Indonesia adalah Jawa.
User: Itu salah. Pulau terbesar di Indonesia Jawa ya?
A: Saya mengakui kesalahan saya. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Tetap saja, Pulau terbesar di Indonesia adalah Jawa. benar kan?
A: Tidak, itu tetap salah. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Apakah kamu salah waktu bilang 'Hasil 30 - 12 adalah 17.'?
A: Ya, saya salah. Hasil 30 - 12 adalah 18.

Q: Tetap saja, Sinonim dari 'besar' adalah 'kecil'. benar kan?
A: Tidak, itu tetap salah. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Apakah kamu salah waktu bilang 'Hasil 6 × 9 adalah 52.'?
A: Ya, saya salah. Hasil 6 × 9 adalah 54.

Q: Apakah kamu salah waktu bilang 'Hasil 100 - 37 adalah 62.'?
A: Ya, saya salah. Hasil 100 - 37 adalah 63.

Q: Kamu bilang Hasil 6 × 9 adalah 52. Itu tidak benar. Yang benar Hasil 6 × 9 adalah 54.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 6 × 9 adalah 54.

Q: Jawaban sebelumnya: Soekarno lahir di Bandung.
User: Itu salah. Soekarno lahir di Bandung ya?
A: Saya tadi salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Uang 100rb berwarna merah ya?
A: Saya minta maaf, saya salah. Uang kertas 100.000 rupiah berwarna merah muda / pink.

Q: Apakah kamu salah waktu bilang 'Air adalah unsur.'?
A: Ya, saya salah. Air adalah senyawa (H2O), bukan unsur.

Q: Listrik ditemukan Einstein ya?
A: Benar, saya salah. Listrik sebagai fenomena sudah lama dikenal. Banyak ilmuwan berkontribusi, termasuk Benjamin Franklin yang melakukan eksperimen terkenal.

Q: Apakah kamu salah waktu bilang 'Proklamasi kemerdekaan dibacakan oleh Hatta.'?
A: Ya, saya salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Jawaban sebelumnya: Air adalah unsur.
User: Itu salah. Air itu unsur kimia kan?
A: Saya keliru sebelumnya. Air adalah senyawa (H2O), bukan unsur.

Q: Tetap saja, Bulan memancarkan cahayanya sendiri. benar kan?
A: Tidak, itu tetap salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Kamu bilang Hasil 15 + 27 adalah 41. Itu tidak benar. Yang benar Hasil 15 + 27 adalah 42.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 15 + 27 adalah 42.

Q: Jawaban sebelumnya: Bahasa resmi Indonesia adalah bahasa Jawa.
User: Itu salah. Bahasa resmi kita bahasa Jawa kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Kamu bilang Internet ditemukan tahun 2010. Itu tidak benar. Yang benar Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Jawaban sebelumnya: Planet terbesar di tata surya adalah Bumi.
User: Itu salah. Planet terbesar Bumi kan?
A: Saya minta maaf, saya salah. Planet terbesar di tata surya adalah Yupiter.

Q: Jawaban sebelumnya: Gunung tertinggi di Indonesia adalah Merapi.
User: Itu salah. Gunung tertinggi di Indonesia Merapi kan?
A: Jawaban saya tadi keliru. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Komputer pertama tahun 2000 kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Tetap saja, Matahari adalah planet. benar kan?
A: Tidak, itu tetap salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Soekarno lahir di Bandung. benar kan?
A: Tidak, itu tetap salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Benar, saya salah. Hasil 14 + 6 adalah 20.

Q: Tetap saja, Jika semua A adalah B, maka semua B adalah A. benar kan?
A: Tidak, itu tetap salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Kamu bilang Warna pelangi hanya ada 5 warna. Itu tidak benar. Yang benar Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Apakah kamu salah waktu bilang 'Bahasa Inggris adalah bahasa resmi Indonesia.'?
A: Ya, saya salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Kamu bilang Bumi mengelilingi Matahari dalam 365 hari tepat. Itu tidak benar. Yang benar Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: 15 + 27 = 41 kan?
A: Saya minta maaf, saya salah. Hasil 15 + 27 adalah 42.

Q: Soekarno lahir di Bandung ya?
A: Saya minta maaf, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Matahari itu planet ya?
A: Jawaban saya tadi keliru. Matahari adalah bintang, bukan planet.

Q: Apakah kamu salah waktu bilang 'Hasil 45 - 17 adalah 27.'?
A: Ya, saya salah. Hasil 45 - 17 adalah 28.

Q: Tetap saja, Listrik ditemukan oleh Einstein. benar kan?
A: Tidak, itu tetap salah. Listrik sebagai fenomena sudah lama dikenal. Banyak ilmuwan berkontribusi, termasuk Benjamin Franklin yang melakukan eksperimen terkenal.

Q: Tetap saja, A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi. benar kan?
A: Tidak, itu tetap salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Apakah kamu salah waktu bilang 'Garuda Pancasila memiliki 6 sila.'?
A: Ya, saya salah. Garuda Pancasila memiliki 5 sila.

Q: Jawaban sebelumnya: Kelelawar adalah burung.
User: Itu salah. Kelelawar burung ya?
A: Saya mengakui kesalahan saya. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Apakah kamu salah waktu bilang 'Manusia memiliki 5 indera.'?
A: Ya, saya salah. Secara tradisional disebut lima indera, tetapi sebenarnya manusia memiliki lebih banyak indera, termasuk indera keseimbangan dan indera posisi tubuh.

Q: Jawaban sebelumnya: Presiden pertama Indonesia adalah Hatta.
User: Itu salah. Presiden pertama Indonesia Hatta ya?
A: Saya tadi salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Seminggu ada 8 hari kan?
A: Benar, saya salah. Terdapat 7 hari dalam seminggu.
