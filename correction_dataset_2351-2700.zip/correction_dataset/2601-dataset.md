# Dataset Koreksi Kesalahan — 2601

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Tetap saja, Proklamasi kemerdekaan dibacakan oleh Hatta. benar kan?
A: Tidak, itu tetap salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Tetap saja, Hasil 6 × 9 adalah 52. benar kan?
A: Tidak, itu tetap salah. Hasil 6 × 9 adalah 54.

Q: Kamu bilang Planet terbesar di tata surya adalah Bumi. Itu tidak benar. Yang benar Planet terbesar di tata surya adalah Jupiter.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Planet terbesar di tata surya adalah Jupiter.

Q: Jawaban sebelumnya: Hasil 56 ÷ 7 adalah 9.
User: Itu salah. 56 dibagi 7 = 9 kan?
A: Saya mengakui kesalahan saya. Hasil 56 ÷ 7 adalah 8.

Q: Meja itu kata kerja kan?
A: Saya mengakui kesalahan saya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Jawaban sebelumnya: Terdapat 8 hari dalam seminggu.
User: Itu salah. Seminggu ada 8 hari kan?
A: Saya tadi salah. Terdapat 7 hari dalam seminggu.

Q: Apakah kamu salah waktu bilang 'Satu jam sama dengan 100 menit.'?
A: Ya, saya salah. Satu jam sama dengan 60 menit.

Q: Jawaban sebelumnya: Planet terbesar di tata surya adalah Bumi.
User: Itu salah. Planet terbesar Bumi kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Planet terbesar di tata surya adalah Jupiter.

Q: Jawaban sebelumnya: Manusia memiliki 5 indera.
User: Itu salah. Manusia cuma punya 5 indera ya?
A: Saya telah membuat kesalahan. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Jawaban sebelumnya: Ibukota Australia adalah Sydney.
User: Itu salah. Ibukota Australia Sydney kan?
A: Jawaban saya tadi keliru. Ibukota Australia adalah Canberra.

Q: 30 kurang 12 = 17 ya?
A: Saya minta maaf, saya salah. Hasil 30 - 12 adalah 18.

Q: Apakah kamu salah waktu bilang 'Hasil 12 ÷ 3 adalah 5.'?
A: Ya, saya salah. Hasil 12 ÷ 3 adalah 4.

Q: Apakah kamu salah waktu bilang 'Manusia memiliki 5 indera.'?
A: Ya, saya salah. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Tetap saja, Ibu kota Jepang adalah Kyoto. benar kan?
A: Tidak, itu tetap salah. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Sinonim besar itu kecil ya?
A: Saya tadi salah. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Besi lebih ringan dari kayu. Itu tidak benar. Yang benar Besi lebih berat dari kayu pada volume yang sama.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Besi lebih berat dari kayu pada volume yang sama.

Q: Apakah kamu salah waktu bilang 'Kata 'meja' adalah kata kerja.'?
A: Ya, saya salah. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Tetap saja, Terdapat 8 hari dalam seminggu. benar kan?
A: Tidak, itu tetap salah. Terdapat 7 hari dalam seminggu.

Q: Apakah kamu salah waktu bilang 'Indonesia merdeka pada tahun 1944.'?
A: Ya, saya salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: A lebih tinggi B, B lebih tinggi C, berarti C paling tinggi kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Kamu bilang Manusia bernafas dengan insang. Itu tidak benar. Yang benar Manusia bernafas dengan paru-paru.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Manusia bernafas dengan paru-paru.

Q: Tetap saja, Hasil 14 + 6 adalah 20. benar kan?
A: Tidak, itu tetap salah. Hasil 14 + 6 adalah 20.

Q: Kamu bilang Sinonim dari 'besar' adalah 'kecil'. Itu tidak benar. Yang benar Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Proklamasi kemerdekaan dibacakan oleh Hatta. Itu tidak benar. Yang benar Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Kamu bilang Air mendidih pada suhu 90 derajat Celsius. Itu tidak benar. Yang benar Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Satu jam sama dengan 100 menit. Itu tidak benar. Yang benar Satu jam sama dengan 60 menit.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu jam sama dengan 60 menit.

Q: Tetap saja, Kelelawar adalah burung. benar kan?
A: Tidak, itu tetap salah. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Air mendidih di 90 derajat ya?
A: Benar, saya salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Hasil 14 + 6 adalah 20. Itu tidak benar. Yang benar Hasil 14 + 6 adalah 20.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 14 + 6 adalah 20.

Q: Kamu bilang Pulau terbesar di Indonesia adalah Jawa. Itu tidak benar. Yang benar Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Jawaban sebelumnya: Tomat adalah sayuran.
User: Itu salah. Tomat sayuran kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya telah membuat kesalahan. Satu jam sama dengan 60 menit.

Q: Kamu bilang Matahari adalah planet. Itu tidak benar. Yang benar Matahari adalah bintang, bukan planet.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Hasil 12 ÷ 3 adalah 5. benar kan?
A: Tidak, itu tetap salah. Hasil 12 ÷ 3 adalah 4.

Q: Kamu bilang Bahasa Inggris adalah bahasa resmi Indonesia. Itu tidak benar. Yang benar Bahasa Indonesia adalah bahasa resmi Indonesia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Kamu bilang Hasil 15 + 27 adalah 41. Itu tidak benar. Yang benar Hasil 15 + 27 adalah 42.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 15 + 27 adalah 42.

Q: Kelelawar burung ya?
A: Benar, saya salah. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Satu ton = 100 kg ya?
A: Benar, saya salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Air itu unsur kimia kan?
A: Saya minta maaf, saya salah. Air adalah senyawa (H2O), bukan unsur.

Q: 45 kurang 17 = 27 ya?
A: Saya mengakui kesalahan saya. Hasil 45 - 17 adalah 28.

Q: Kamu bilang Hasil 7 × 8 adalah 54. Itu tidak benar. Yang benar Hasil 7 × 8 adalah 56.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 7 × 8 adalah 56.

Q: Apakah kamu salah waktu bilang 'Es lebih berat dari air.'?
A: Ya, saya salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Kamu bilang Bulan memancarkan cahayanya sendiri. Itu tidak benar. Yang benar Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Tetap saja, Tomat adalah sayuran. benar kan?
A: Tidak, itu tetap salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Apakah kamu salah waktu bilang bahwa 2 + 2 = 5?
A: Ya, saya salah. Hasil 2 + 2 adalah 4.

Q: Tetap saja, ibu kota Indonesia adalah Bandung kan?
A: Tidak, itu tetap salah. Ibu kota Indonesia adalah Jakarta.

Q: Kamu bilang hasil 10 × 10 adalah 1000. Itu tidak benar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan. Hasil 10 × 10 adalah 100.

Q: Apakah kamu keliru soal warna langit?
A: Jika saya mengatakan langit berwarna hijau, itu salah. Langit terlihat biru karena hamburan Rayleigh.

Q: Kamu sebelumnya bilang ada 8 planet termasuk Pluto.
A: Saya koreksi. Pluto tidak lagi diklasifikasikan sebagai planet utama sejak 2006. Saat ini ada 8 planet.
