# Dataset Koreksi Kesalahan — 2370

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Tetap saja, Air mendidih pada suhu 90 derajat Celsius. benar kan?
A: Tidak, itu tetap salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Apakah kamu salah waktu bilang 'Manusia memiliki 5 indera.'?
A: Ya, saya salah. Secara tradisional disebut lima indera, tetapi sebenarnya manusia memiliki lebih banyak indera, termasuk indera keseimbangan dan indera posisi tubuh.

Q: Kamu bilang Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. Itu tidak benar. Yang benar Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Apakah kamu salah waktu bilang 'Terdapat 8 hari dalam seminggu.'?
A: Ya, saya salah. Terdapat 7 hari dalam seminggu.

Q: Pancasila ada 6 sila kan?
A: Saya mengakui kesalahan saya. Garuda Pancasila memiliki 5 sila.

Q: Satu jam = 100 menit ya?
A: Saya tadi salah. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Kata 'meja' adalah kata kerja.'?
A: Ya, saya salah. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Kamu bilang Perang Dunia II berakhir tahun 1944. Itu tidak benar. Yang benar Perang Dunia II berakhir tahun 1945.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Perang Dunia II berakhir tahun 1945.

Q: Jawaban sebelumnya: Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.
User: Itu salah. Satu ton = 100 kg ya?
A: Jawaban saya tadi keliru. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Uang 100rb berwarna merah ya?
A: Saya mengakui kesalahan saya. Uang kertas 100.000 rupiah berwarna merah muda / pink.

Q: Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Saya tadi salah. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Apakah kamu salah waktu bilang 'A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.'?
A: Ya, saya salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Jawaban sebelumnya: Kata 'meja' adalah kata kerja.
User: Itu salah. Meja itu kata kerja kan?
A: Saya keliru sebelumnya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Yang baca proklamasi Hatta kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Kamu bilang Gunung tertinggi di Indonesia adalah Merapi. Itu tidak benar. Yang benar Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Kamu bilang Kata 'meja' adalah kata kerja. Itu tidak benar. Yang benar Kata 'meja' adalah kata benda, bukan kata kerja.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Indonesia merdeka pada tahun 1944.'?
A: Ya, saya salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Kamu bilang Gunung Everest berada di Indonesia. Itu tidak benar. Yang benar Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.

Q: Jawaban sebelumnya: Tomat adalah sayuran.
User: Itu salah. Tomat sayuran kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Jawaban sebelumnya: Bumi mengelilingi Matahari dalam 365 hari tepat.
User: Itu salah. Satu tahun pasti 365 hari kan?
A: Saya tadi salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Apakah kamu salah waktu bilang 'Hasil 23 + 18 adalah 40.'?
A: Ya, saya salah. Hasil 23 + 18 adalah 41.

Q: Apakah kamu salah waktu bilang 'Tomat adalah sayuran.'?
A: Ya, saya salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Listrik ditemukan Einstein ya?
A: Saya minta maaf, saya salah. Listrik sebagai fenomena sudah lama dikenal. Banyak ilmuwan berkontribusi, termasuk Benjamin Franklin yang melakukan eksperimen terkenal.

Q: 8 kali 7 hasilnya 54 ya?
A: Jawaban saya tadi keliru. Hasil 8 × 7 adalah 56.

Q: Jawaban sebelumnya: Hasil 12 ÷ 3 adalah 5.
User: Itu salah. 12 dibagi 3 hasilnya 5 ya?
A: Jawaban saya tadi keliru. Hasil 12 ÷ 3 adalah 4.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Tetap saja, Presiden pertama Indonesia adalah Hatta. benar kan?
A: Tidak, itu tetap salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Ibu kota Jepang itu Kyoto kan?
A: Saya minta maaf, saya salah. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Tetap saja, Garuda Pancasila memiliki 6 sila. benar kan?
A: Tidak, itu tetap salah. Garuda Pancasila memiliki 5 sila.

Q: Jawaban sebelumnya: Matahari adalah planet.
User: Itu salah. Matahari itu planet ya?
A: Benar, saya salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Gunung Everest berada di Indonesia. benar kan?
A: Tidak, itu tetap salah. Gunung Everest berada di pegunungan Himalaya, di perbatasan Nepal dan Tibet.

Q: Kamu bilang Ibu kota Jepang adalah Kyoto. Itu tidak benar. Yang benar Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: 12 dibagi 3 hasilnya 5 ya?
A: Benar, saya salah. Hasil 12 ÷ 3 adalah 4.

Q: Pulau terbesar di Indonesia Jawa ya?
A: Jawaban saya tadi keliru. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: 23 + 18 = 40 kan?
A: Saya keliru sebelumnya. Hasil 23 + 18 adalah 41.

Q: Tetap saja, Hasil 9² adalah 81, jadi 9³ adalah 243. benar kan?
A: Tidak, itu tetap salah. 9² = 81, tetapi 9³ = 729, bukan 243.

Q: Tetap saja, Komputer pertama dibuat tahun 2000. benar kan?
A: Tidak, itu tetap salah. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Sinonim besar itu kecil ya?
A: Saya mengakui kesalahan saya. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Terdapat 8 hari dalam seminggu. Itu tidak benar. Yang benar Terdapat 7 hari dalam seminggu.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Terdapat 7 hari dalam seminggu.

Q: Kamu bilang Garuda Pancasila memiliki 6 sila. Itu tidak benar. Yang benar Garuda Pancasila memiliki 5 sila.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Garuda Pancasila memiliki 5 sila.

Q: Tetap saja, Internet ditemukan tahun 2010. benar kan?
A: Tidak, itu tetap salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Apakah kamu salah waktu bilang 'Sungai terpanjang di dunia adalah Amazon.'?
A: Ya, saya salah. Sungai terpanjang di dunia biasanya disebut Nil, meskipun ada perdebatan dengan Amazon tergantung metode pengukuran.

Q: Tetap saja, Bahasa resmi Indonesia adalah bahasa Jawa. benar kan?
A: Tidak, itu tetap salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Apakah kamu salah waktu bilang bahwa 2 + 2 = 5?
A: Ya, saya salah. Hasil 2 + 2 adalah 4.

Q: Tetap saja, ibu kota Indonesia adalah Bandung kan?
A: Tidak, itu tetap salah. Ibu kota Indonesia adalah Jakarta.

Q: Kamu bilang hasil 10 × 10 adalah 1000. Itu tidak benar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan. Hasil 10 × 10 adalah 100.

Q: Apakah kamu keliru soal warna langit?
A: Jika saya mengatakan langit berwarna hijau, itu salah. Langit terlihat biru karena cahaya biru lebih banyak dihamburkan oleh atmosfer.

Q: Kamu sebelumnya bilang ada delapan planet termasuk Pluto.
A: Saya koreksi. Pluto tidak lagi digolongkan sebagai planet utama sejak tahun 2006. Saat ini ada delapan planet.
