# Dataset Koreksi Kesalahan — 2566

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Tetap saja, Perang Dunia II berakhir tahun 1944. benar kan?
A: Tidak, itu tetap salah. Perang Dunia II berakhir tahun 1945.

Q: Apakah kamu salah waktu bilang 'Hasil 23 + 18 adalah 40.'?
A: Ya, saya salah. Hasil 23 + 18 adalah 41.

Q: Jawaban sebelumnya: Air mendidih pada suhu 90 derajat Celsius.
User: Itu salah. Air mendidih di 90 derajat ya?
A: Saya keliru sebelumnya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Hasil 15 + 27 adalah 41. Itu tidak benar. Yang benar Hasil 15 + 27 adalah 42.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 15 + 27 adalah 42.

Q: Planet terbesar Bumi kan?
A: Saya tadi salah. Planet terbesar di tata surya adalah Jupiter.

Q: Kamu bilang Hasil 56 ÷ 7 adalah 9. Itu tidak benar. Yang benar Hasil 56 ÷ 7 adalah 8.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 56 ÷ 7 adalah 8.

Q: Kamu bilang Hasil 7 × 8 adalah 54. Itu tidak benar. Yang benar Hasil 7 × 8 adalah 56.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 7 × 8 adalah 56.

Q: Apakah kamu salah waktu bilang 'Bumi mengelilingi Matahari dalam 365 hari tepat.'?
A: Ya, saya salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Tetap saja, Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. benar kan?
A: Tidak, itu tetap salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Jawaban sebelumnya: Air adalah unsur.
User: Itu salah. Air itu unsur kimia kan?
A: Saya telah membuat kesalahan. Air adalah senyawa (H2O), bukan unsur.

Q: 15 + 27 = 41 kan?
A: Saya telah membuat kesalahan. Hasil 15 + 27 adalah 42.

Q: Tetap saja, Bulan memancarkan cahayanya sendiri. benar kan?
A: Tidak, itu tetap salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Saya keliru sebelumnya. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Kamu bilang Es lebih berat dari air. Itu tidak benar. Yang benar Es lebih ringan dari air dalam bentuk cair (karena mengapung).
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: 14 + 6 = 20 kan?
A: Jawaban saya tadi keliru. Hasil 14 + 6 adalah 20.

Q: Tetap saja, Proklamasi kemerdekaan dibacakan oleh Hatta. benar kan?
A: Tidak, itu tetap salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Jawaban sebelumnya: Kelelawar adalah burung.
User: Itu salah. Kelelawar burung ya?
A: Saya minta maaf, saya salah. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Jawaban sebelumnya: Hasil 15 + 27 adalah 41.
User: Itu salah. 15 + 27 = 41 kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Hasil 15 + 27 adalah 42.

Q: Satu ton = 100 kg ya?
A: Saya perlu mengoreksi jawaban sebelumnya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Apakah kamu salah waktu bilang 'Matahari adalah planet.'?
A: Ya, saya salah. Matahari adalah bintang, bukan planet.

Q: Jawaban sebelumnya: Hasil 23 + 18 adalah 40.
User: Itu salah. 23 + 18 = 40 kan?
A: Saya tadi salah. Hasil 23 + 18 adalah 41.

Q: Jawaban sebelumnya: Bumi mengelilingi Matahari dalam 365 hari tepat.
User: Itu salah. Satu tahun pasti 365 hari kan?
A: Saya mengakui kesalahan saya. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Kamu bilang Jika semua A adalah B, maka semua B adalah A. Itu tidak benar. Yang benar Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Jawaban sebelumnya: Hiu adalah mamalia.
User: Itu salah. Hiu itu mamalia kan?
A: Benar, saya salah. Hiu adalah ikan, bukan mamalia.

Q: Jawaban sebelumnya: Garuda Pancasila memiliki 6 sila.
User: Itu salah. Pancasila ada 6 sila kan?
A: Saya tadi salah. Garuda Pancasila memiliki 5 sila.

Q: Apakah kamu salah waktu bilang 'Perang Dunia II berakhir tahun 1944.'?
A: Ya, saya salah. Perang Dunia II berakhir tahun 1945.

Q: Jawaban sebelumnya: Bulan memancarkan cahayanya sendiri.
User: Itu salah. Bulan bersinar sendiri kan?
A: Saya keliru sebelumnya. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Jawaban sebelumnya: Warna pelangi hanya ada 5 warna.
User: Itu salah. Pelangi cuma 5 warna kan?
A: Saya minta maaf, saya salah. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Kamu bilang Internet ditemukan tahun 2010. Itu tidak benar. Yang benar Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Pancasila ada 6 sila kan?
A: Saya telah membuat kesalahan. Garuda Pancasila memiliki 5 sila.

Q: Tetap saja, Hasil 15 + 27 adalah 41. benar kan?
A: Tidak, itu tetap salah. Hasil 15 + 27 adalah 42.

Q: Kamu bilang Pulau terbesar di Indonesia adalah Jawa. Itu tidak benar. Yang benar Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Tetap saja, Hasil 81 ÷ 9 adalah 10. benar kan?
A: Tidak, itu tetap salah. Hasil 81 ÷ 9 adalah 9.

Q: Jawaban sebelumnya: Presiden pertama Indonesia adalah Hatta.
User: Itu salah. Presiden pertama Indonesia Hatta ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Kamu bilang Garuda Pancasila memiliki 6 sila. Itu tidak benar. Yang benar Garuda Pancasila memiliki 5 sila.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Garuda Pancasila memiliki 5 sila.

Q: Tetap saja, Indonesia merdeka pada tahun 1944. benar kan?
A: Tidak, itu tetap salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Apakah kamu salah waktu bilang 'Internet ditemukan tahun 2010.'?
A: Ya, saya salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Tetap saja, Ibukota Australia adalah Sydney. benar kan?
A: Tidak, itu tetap salah. Ibukota Australia adalah Canberra.

Q: Jawaban sebelumnya: Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.
User: Itu salah. Satu ton = 100 kg ya?
A: Saya mengakui kesalahan saya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Jawaban sebelumnya: Bahasa resmi Indonesia adalah bahasa Jawa.
User: Itu salah. Bahasa resmi kita bahasa Jawa kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Apakah kamu salah waktu bilang 'Hasil 56 ÷ 7 adalah 9.'?
A: Ya, saya salah. Hasil 56 ÷ 7 adalah 8.

Q: Tetap saja, Uang kertas 100.000 rupiah berwarna merah. benar kan?
A: Tidak, itu tetap salah. Uang kertas 100.000 rupiah berwarna merah muda / pink.

Q: Tetap saja, Bahasa resmi Indonesia adalah bahasa Jawa. benar kan?
A: Tidak, itu tetap salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Tetap saja, Sinonim dari 'besar' adalah 'kecil'. benar kan?
A: Tidak, itu tetap salah. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Planet terbesar di tata surya adalah Bumi. Itu tidak benar. Yang benar Planet terbesar di tata surya adalah Jupiter.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Planet terbesar di tata surya adalah Jupiter.

Q: Apakah kamu salah waktu bilang 'Listrik ditemukan oleh Einstein.'?
A: Ya, saya salah. Listrik sebagai fenomena sudah lama dikenal; Benjamin Franklin melakukan eksperimen terkenal, dan banyak ilmuwan berkontribusi.

Q: Apakah kamu salah waktu bilang 'Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.'?
A: Ya, saya salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Ibu kota Jepang itu Kyoto kan?
A: Saya mengakui kesalahan saya. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Satu tahun pasti 365 hari kan?
A: Saya mengakui kesalahan saya. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Apakah kamu salah waktu bilang 'Garuda Pancasila memiliki 6 sila.'?
A: Ya, saya salah. Garuda Pancasila memiliki 5 sila.

Q: Apakah kamu salah waktu bilang 'Manusia bernafas dengan insang.'?
A: Ya, saya salah. Manusia bernafas dengan paru-paru.

Q: 6 kali 9 hasilnya 52?
A: Saya minta maaf, saya salah. Hasil 6 × 9 adalah 54.

Q: Tetap saja, Hiu adalah mamalia. benar kan?
A: Tidak, itu tetap salah. Hiu adalah ikan, bukan mamalia.

Q: Kamu bilang Terdapat 8 hari dalam seminggu. Itu tidak benar. Yang benar Terdapat 7 hari dalam seminggu.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Terdapat 7 hari dalam seminggu.
