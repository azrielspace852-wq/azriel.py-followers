# Dataset Koreksi Kesalahan — 2561

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Bahasa resmi kita bahasa Jawa kan?
A: Saya keliru sebelumnya. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Jawaban sebelumnya: Planet terbesar di tata surya adalah Bumi.
User: Itu salah. Planet terbesar Bumi kan?
A: Saya telah membuat kesalahan. Planet terbesar di tata surya adalah Jupiter.

Q: Apakah kamu salah waktu bilang 'Hasil 30 - 12 adalah 17.'?
A: Ya, saya salah. Hasil 30 - 12 adalah 18.

Q: Bahasa resmi kita bahasa Inggris kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Satu ton = 100 kg ya?
A: Saya keliru sebelumnya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Tetap saja, Internet ditemukan tahun 2010. benar kan?
A: Tidak, itu tetap salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Soekarno lahir di Bandung ya?
A: Saya mengakui kesalahan saya. Soekarno lahir di Blitar, Jawa Timur.

Q: Jawaban sebelumnya: Air mendidih pada suhu 90 derajat Celsius.
User: Itu salah. Air mendidih di 90 derajat ya?
A: Benar, saya salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Tetap saja, Manusia memiliki 5 indera. benar kan?
A: Tidak, itu tetap salah. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Jawaban sebelumnya: Listrik ditemukan oleh Einstein.
User: Itu salah. Listrik ditemukan Einstein ya?
A: Jawaban saya tadi keliru. Listrik sebagai fenomena sudah lama dikenal; Benjamin Franklin melakukan eksperimen terkenal, dan banyak ilmuwan berkontribusi.

Q: Tetap saja, Sinonim dari 'besar' adalah 'kecil'. benar kan?
A: Tidak, itu tetap salah. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Tetap saja, Hasil 8 × 7 adalah 54. benar kan?
A: Tidak, itu tetap salah. Hasil 8 × 7 adalah 56.

Q: Tetap saja, Bumi mengelilingi Matahari dalam 365 hari tepat. benar kan?
A: Tidak, itu tetap salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Apakah kamu salah waktu bilang 'Hasil 8 × 7 adalah 54.'?
A: Ya, saya salah. Hasil 8 × 7 adalah 56.

Q: Apakah kamu salah waktu bilang 'Perang Dunia II berakhir tahun 1944.'?
A: Ya, saya salah. Perang Dunia II berakhir tahun 1945.

Q: Sinonim besar itu kecil ya?
A: Saya keliru sebelumnya. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Jawaban sebelumnya: Bahasa Inggris adalah bahasa resmi Indonesia.
User: Itu salah. Bahasa resmi kita bahasa Inggris kan?
A: Saya mengakui kesalahan saya. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Ibukota Australia adalah Sydney.'?
A: Ya, saya salah. Ibukota Australia adalah Canberra.

Q: Jawaban sebelumnya: Hasil 23 + 18 adalah 40.
User: Itu salah. 23 + 18 = 40 kan?
A: Jawaban saya tadi keliru. Hasil 23 + 18 adalah 41.

Q: Tetap saja, Satu jam sama dengan 100 menit. benar kan?
A: Tidak, itu tetap salah. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Hasil 45 - 17 adalah 27.'?
A: Ya, saya salah. Hasil 45 - 17 adalah 28.

Q: Kamu bilang Terdapat 8 hari dalam seminggu. Itu tidak benar. Yang benar Terdapat 7 hari dalam seminggu.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Terdapat 7 hari dalam seminggu.

Q: Apakah kamu salah waktu bilang 'Gunung tertinggi di Indonesia adalah Merapi.'?
A: Ya, saya salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: 100 kurang 37 = 62 kan?
A: Saya keliru sebelumnya. Hasil 100 - 37 adalah 63.

Q: Apakah kamu salah waktu bilang 'Air adalah unsur.'?
A: Ya, saya salah. Air adalah senyawa (H2O), bukan unsur.

Q: Tetap saja, Ibu kota Jepang adalah Kyoto. benar kan?
A: Tidak, itu tetap salah. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Everest di Indonesia ya?
A: Saya telah membuat kesalahan. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Presiden pertama Indonesia Hatta ya?
A: Benar, saya salah. Presiden pertama Indonesia adalah Soekarno. Hatta adalah wakil presiden pertama.

Q: Pelangi cuma 5 warna kan?
A: Saya minta maaf, saya salah. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Es lebih berat dari air ya?
A: Saya keliru sebelumnya. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Air mendidih di 90 derajat ya?
A: Saya mengakui kesalahan saya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Satu jam sama dengan 100 menit. Itu tidak benar. Yang benar Satu jam sama dengan 60 menit.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Satu jam sama dengan 60 menit.

Q: Tetap saja, Hasil 14 + 6 adalah 20. benar kan?
A: Tidak, itu tetap salah. Hasil 14 + 6 adalah 20.

Q: Apakah kamu salah waktu bilang 'Warna pelangi hanya ada 5 warna.'?
A: Ya, saya salah. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Kamu bilang Ibu kota Jepang adalah Kyoto. Itu tidak benar. Yang benar Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Satu jam = 100 menit ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Satu jam sama dengan 60 menit.

Q: Jawaban sebelumnya: Ibu kota Indonesia adalah Kuala Lumpur.
User: Itu salah. Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Jawaban saya tadi keliru. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Jawaban sebelumnya: Garuda Pancasila memiliki 6 sila.
User: Itu salah. Pancasila ada 6 sila kan?
A: Benar, saya salah. Garuda Pancasila memiliki 5 sila.

Q: Kamu bilang Kata 'meja' adalah kata kerja. Itu tidak benar. Yang benar Kata 'meja' adalah kata benda, bukan kata kerja.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Tetap saja, Bahasa resmi Indonesia adalah bahasa Jawa. benar kan?
A: Tidak, itu tetap salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Jawaban sebelumnya: Kelelawar adalah burung.
User: Itu salah. Kelelawar burung ya?
A: Saya telah membuat kesalahan. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Jawaban sebelumnya: Terdapat 8 hari dalam seminggu.
User: Itu salah. Seminggu ada 8 hari kan?
A: Saya mengakui kesalahan saya. Terdapat 7 hari dalam seminggu.

Q: Jawaban sebelumnya: Hasil 8 × 7 adalah 54.
User: Itu salah. 8 kali 7 hasilnya 54 ya?
A: Saya keliru sebelumnya. Hasil 8 × 7 adalah 56.

Q: Apakah kamu salah waktu bilang 'Indonesia merdeka pada tahun 1944.'?
A: Ya, saya salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Jawaban sebelumnya: Komputer pertama dibuat tahun 2000.
User: Itu salah. Komputer pertama tahun 2000 kan?
A: Jawaban saya tadi keliru. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Indonesia merdeka tahun 1944 ya?
A: Saya mengakui kesalahan saya. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Tetap saja, Soekarno lahir di Bandung. benar kan?
A: Tidak, itu tetap salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Kamu bilang Komputer pertama dibuat tahun 2000. Itu tidak benar. Yang benar Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Kamu bilang Manusia bernafas dengan insang. Itu tidak benar. Yang benar Manusia bernafas dengan paru-paru.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Manusia bernafas dengan paru-paru.

Q: Satu tahun pasti 365 hari kan?
A: Saya minta maaf, saya salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Tetap saja, Gunung Everest berada di Indonesia. benar kan?
A: Tidak, itu tetap salah. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Apakah kamu salah waktu bilang 'Bahasa Inggris adalah bahasa resmi Indonesia.'?
A: Ya, saya salah. Bahasa Indonesia adalah bahasa resmi Indonesia.
