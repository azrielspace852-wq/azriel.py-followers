# Dataset Koreksi Kesalahan — 2690

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Tetap saja, Proklamasi kemerdekaan dibacakan oleh Hatta. benar kan?
A: Tidak, itu tetap salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Tetap saja, Hiu adalah mamalia. benar kan?
A: Tidak, itu tetap salah. Hiu adalah ikan, bukan mamalia.

Q: Apakah kamu salah waktu bilang 'Hasil 100 - 37 adalah 62.'?
A: Ya, saya salah. Hasil 100 - 37 adalah 63.

Q: Apakah kamu salah waktu bilang 'Bulan memancarkan cahayanya sendiri.'?
A: Ya, saya salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Apakah kamu salah waktu bilang 'Es lebih berat dari air.'?
A: Ya, saya salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Everest di Indonesia ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Kelelawar burung ya?
A: Jawaban saya tadi keliru. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Soekarno lahir di Bandung ya?
A: Saya telah membuat kesalahan. Soekarno lahir di Blitar, Jawa Timur.

Q: Kamu bilang Kelelawar adalah burung. Itu tidak benar. Yang benar Kelelawar adalah mamalia yang bisa terbang, bukan burung.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Jawaban sebelumnya: Hasil 8 × 7 adalah 54.
User: Itu salah. 8 kali 7 hasilnya 54 ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Hasil 8 × 7 adalah 56.

Q: Jawaban sebelumnya: Hasil 12 ÷ 3 adalah 5.
User: Itu salah. 12 dibagi 3 hasilnya 5 ya?
A: Saya perlu mengoreksi jawaban sebelumnya. Hasil 12 ÷ 3 adalah 4.

Q: Kamu bilang Gunung tertinggi di Indonesia adalah Merapi. Itu tidak benar. Yang benar Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Jawaban sebelumnya: Kata 'meja' adalah kata kerja.
User: Itu salah. Meja itu kata kerja kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Jawaban sebelumnya: Sinonim dari 'besar' adalah 'kecil'.
User: Itu salah. Sinonim besar itu kecil ya?
A: Saya telah membuat kesalahan. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Manusia pakai insang ya?
A: Saya koreksi: jawaban sebelumnya tidak benar. Manusia bernafas dengan paru-paru.

Q: 56 dibagi 7 = 9 kan?
A: Saya mengakui kesalahan saya. Hasil 56 ÷ 7 adalah 8.

Q: Tetap saja, Gunung Everest berada di Indonesia. benar kan?
A: Tidak, itu tetap salah. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Tetap saja, Bahasa Inggris adalah bahasa resmi Indonesia. benar kan?
A: Tidak, itu tetap salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Internet ditemukan tahun 2010.'?
A: Ya, saya salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: 14 + 6 = 20 kan?
A: Saya keliru sebelumnya. Hasil 14 + 6 adalah 20.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya keliru sebelumnya. Satu jam sama dengan 60 menit.

Q: Kamu bilang Ibu kota Indonesia adalah Kuala Lumpur. Itu tidak benar. Yang benar Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Jawaban sebelumnya: Hasil 23 + 18 adalah 40.
User: Itu salah. 23 + 18 = 40 kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Hasil 23 + 18 adalah 41.

Q: Satu ton = 100 kg ya?
A: Saya mengakui kesalahan saya. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Tetap saja, Tomat adalah sayuran. benar kan?
A: Tidak, itu tetap salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Kamu bilang Hasil 9² adalah 81, jadi 9³ adalah 243. Itu tidak benar. Yang benar 9² = 81, tetapi 9³ = 729, bukan 243.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. 9² = 81, tetapi 9³ = 729, bukan 243.

Q: Jawaban sebelumnya: Bahasa Inggris adalah bahasa resmi Indonesia.
User: Itu salah. Bahasa resmi kita bahasa Inggris kan?
A: Saya tadi salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Jawaban sebelumnya: Bumi mengelilingi Matahari dalam 365 hari tepat.
User: Itu salah. Satu tahun pasti 365 hari kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Jawaban sebelumnya: Warna pelangi hanya ada 5 warna.
User: Itu salah. Pelangi cuma 5 warna kan?
A: Saya tadi salah. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Jawaban sebelumnya: Manusia bernafas dengan insang.
User: Itu salah. Manusia pakai insang ya?
A: Benar, saya salah. Manusia bernafas dengan paru-paru.

Q: Kamu bilang Air adalah unsur. Itu tidak benar. Yang benar Air adalah senyawa (H2O), bukan unsur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air adalah senyawa (H2O), bukan unsur.

Q: Jawaban sebelumnya: Bahasa resmi Indonesia adalah bahasa Jawa.
User: Itu salah. Bahasa resmi kita bahasa Jawa kan?
A: Saya mengakui kesalahan saya. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Apakah kamu salah waktu bilang 'Bumi mengelilingi Matahari dalam 365 hari tepat.'?
A: Ya, saya salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Kamu bilang Gunung Everest berada di Indonesia. Itu tidak benar. Yang benar Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Gunung Everest berada di Himalaya, perbatasan Nepal dan Tibet.

Q: Jawaban sebelumnya: Ibukota Australia adalah Sydney.
User: Itu salah. Ibukota Australia Sydney kan?
A: Jawaban saya tadi keliru. Ibukota Australia adalah Canberra.

Q: Jawaban sebelumnya: Garuda Pancasila memiliki 6 sila.
User: Itu salah. Pancasila ada 6 sila kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Garuda Pancasila memiliki 5 sila.

Q: Jawaban sebelumnya: Hasil 56 ÷ 7 adalah 9.
User: Itu salah. 56 dibagi 7 = 9 kan?
A: Saya keliru sebelumnya. Hasil 56 ÷ 7 adalah 8.

Q: Apakah kamu salah waktu bilang 'Gunung tertinggi di Indonesia adalah Merapi.'?
A: Ya, saya salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Tetap saja, Hasil 15 + 27 adalah 41. benar kan?
A: Tidak, itu tetap salah. Hasil 15 + 27 adalah 42.

Q: Kamu bilang Hasil 14 + 6 adalah 20. Itu tidak benar. Yang benar Hasil 14 + 6 adalah 20.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 14 + 6 adalah 20.

Q: Tetap saja, Es lebih berat dari air. benar kan?
A: Tidak, itu tetap salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Bahasa resmi kita bahasa Inggris kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Manusia cuma punya 5 indera ya?
A: Jawaban saya tadi keliru. Secara tradisional disebut 5 indera, tetapi sebenarnya manusia memiliki lebih banyak indera termasuk keseimbangan dan proprioception.

Q: Satu jam = 100 menit ya?
A: Jawaban saya tadi keliru. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang bahwa 2 + 2 = 5?
A: Ya, saya salah. Hasil 2 + 2 adalah 4.

Q: Tetap saja, ibu kota Indonesia adalah Bandung kan?
A: Tidak, itu tetap salah. Ibu kota Indonesia adalah Jakarta.

Q: Kamu bilang hasil 10 × 10 adalah 1000. Itu tidak benar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan. Hasil 10 × 10 adalah 100.

Q: Apakah kamu keliru soal warna langit?
A: Jika saya mengatakan langit berwarna hijau, itu salah. Langit terlihat biru karena hamburan Rayleigh.

Q: Kamu sebelumnya bilang ada 8 planet termasuk Pluto.
A: Saya koreksi. Pluto tidak lagi diklasifikasikan sebagai planet utama sejak 2006. Saat ini ada 8 planet.
