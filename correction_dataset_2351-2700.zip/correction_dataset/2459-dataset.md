# Dataset Koreksi Kesalahan — 2459

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Apakah kamu salah waktu bilang 'Bahasa resmi Indonesia adalah bahasa Jawa.'?
A: Ya, saya salah. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Tetap saja, Garuda Pancasila memiliki 6 sila. benar kan?
A: Tidak, itu tetap salah. Garuda Pancasila memiliki 5 sila.

Q: Jawaban sebelumnya: Kata 'meja' adalah kata kerja.
User: Itu salah. Meja itu kata kerja kan?
A: Saya tadi salah. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Kamu bilang Hasil 15 + 27 adalah 41. Itu tidak benar. Yang benar Hasil 15 + 27 adalah 42.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 15 + 27 adalah 42.

Q: Jawaban sebelumnya: Bahasa resmi Indonesia adalah bahasa Jawa.
User: Itu salah. Bahasa resmi kita bahasa Jawa kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Bahasa resmi Indonesia adalah bahasa Indonesia.

Q: Sinonim besar itu kecil ya?
A: Saya telah membuat kesalahan. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Perang Dunia II berakhir tahun 1944. Itu tidak benar. Yang benar Perang Dunia II berakhir tahun 1945.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Perang Dunia II berakhir tahun 1945.

Q: Ibu kota Jepang itu Kyoto kan?
A: Saya tadi salah. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Kamu bilang Soekarno lahir di Bandung. Itu tidak benar. Yang benar Soekarno lahir di Blitar, Jawa Timur.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Soekarno lahir di Blitar, Jawa Timur.

Q: Seminggu ada 8 hari kan?
A: Saya telah membuat kesalahan. Terdapat 7 hari dalam seminggu.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Tomat sayuran kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Kamu bilang Hasil 100 - 37 adalah 62. Itu tidak benar. Yang benar Hasil 100 - 37 adalah 63.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 100 - 37 adalah 63.

Q: Jawaban sebelumnya: Manusia bernafas dengan insang.
User: Itu salah. Manusia pakai insang ya?
A: Saya mengakui kesalahan saya. Manusia bernafas dengan paru-paru.

Q: Tetap saja, Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. benar kan?
A: Tidak, itu tetap salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Jawaban sebelumnya: Bulan memancarkan cahayanya sendiri.
User: Itu salah. Bulan bersinar sendiri kan?
A: Benar, saya salah. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Kamu bilang Bahasa Inggris adalah bahasa resmi Indonesia. Itu tidak benar. Yang benar Bahasa Indonesia adalah bahasa resmi Indonesia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Apakah kamu salah waktu bilang 'Terdapat 8 hari dalam seminggu.'?
A: Ya, saya salah. Terdapat 7 hari dalam seminggu.

Q: Ibukota Australia Sydney kan?
A: Benar, saya salah. Ibukota Australia adalah Canberra.

Q: Apakah kamu salah waktu bilang 'Satu jam sama dengan 100 menit.'?
A: Ya, saya salah. Satu jam sama dengan 60 menit.

Q: Komputer pertama tahun 2000 kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Komputer elektronik awal dibuat jauh sebelumnya, sekitar tahun 1940-an.

Q: Jawaban sebelumnya: Besi lebih ringan dari kayu.
User: Itu salah. Besi lebih ringan dari kayu kan?
A: Maaf, jawaban saya sebelumnya tidak tepat. Besi lebih berat dari kayu pada volume yang sama.

Q: Tetap saja, Tomat adalah sayuran. benar kan?
A: Tidak, itu tetap salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Jawaban sebelumnya: Ibu kota Indonesia adalah Kuala Lumpur.
User: Itu salah. Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Jawaban saya tadi keliru. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Jawaban sebelumnya: Sinonim dari 'besar' adalah 'kecil'.
User: Itu salah. Sinonim besar itu kecil ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Sinonim dari 'besar' adalah 'luas' atau 'agung'. 'Kecil' adalah antonimnya.

Q: Kamu bilang Hasil 56 ÷ 7 adalah 9. Itu tidak benar. Yang benar Hasil 56 ÷ 7 adalah 8.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 56 ÷ 7 adalah 8.

Q: Apakah kamu salah waktu bilang 'Ibu kota Indonesia adalah Kuala Lumpur.'?
A: Ya, saya salah. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Tetap saja, Internet ditemukan tahun 2010. benar kan?
A: Tidak, itu tetap salah. Internet mulai dikembangkan jauh sebelum 2010, sekitar akhir 1960-an hingga 1980-an.

Q: Hiu itu mamalia kan?
A: Saya perlu mengoreksi jawaban sebelumnya. Hiu adalah ikan, bukan mamalia.

Q: Tetap saja, Gunung tertinggi di Indonesia adalah Merapi. benar kan?
A: Tidak, itu tetap salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Tetap saja, Hasil 56 ÷ 7 adalah 9. benar kan?
A: Tidak, itu tetap salah. Hasil 56 ÷ 7 adalah 8.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya keliru sebelumnya. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Ibu kota Jepang adalah Kyoto.'?
A: Ya, saya salah. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Satu jam = 100 menit ya?
A: Saya keliru sebelumnya. Satu jam sama dengan 60 menit.

Q: Tetap saja, Hasil 45 - 17 adalah 27. benar kan?
A: Tidak, itu tetap salah. Hasil 45 - 17 adalah 28.

Q: Kamu bilang Hasil 14 + 6 adalah 20. Itu tidak benar. Yang benar Hasil 14 + 6 adalah 20.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 14 + 6 adalah 20.

Q: Jawaban sebelumnya: A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.
User: Itu salah. A lebih tinggi B, B lebih tinggi C, berarti C paling tinggi kan?
A: Saya keliru sebelumnya. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Tetap saja, Bahasa Inggris adalah bahasa resmi Indonesia. benar kan?
A: Tidak, itu tetap salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Kamu bilang Hasil 45 - 17 adalah 27. Itu tidak benar. Yang benar Hasil 45 - 17 adalah 28.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 45 - 17 adalah 28.

Q: Jawaban sebelumnya: Tomat adalah sayuran.
User: Itu salah. Tomat sayuran kan?
A: Jawaban saya tadi keliru. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: 12 dibagi 3 hasilnya 5 ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Hasil 12 ÷ 3 adalah 4.

Q: Tetap saja, Kelelawar adalah burung. benar kan?
A: Tidak, itu tetap salah. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Apakah kamu salah waktu bilang 'Proklamasi kemerdekaan dibacakan oleh Hatta.'?
A: Ya, saya salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Tetap saja, Satu jam sama dengan 100 menit. benar kan?
A: Tidak, itu tetap salah. Satu jam sama dengan 60 menit.

Q: Apakah kamu salah waktu bilang 'Hasil 15 + 27 adalah 41.'?
A: Ya, saya salah. Hasil 15 + 27 adalah 42.

Q: Apakah kamu salah waktu bilang 'Hasil 8 × 7 adalah 54.'?
A: Ya, saya salah. Hasil 8 × 7 adalah 56.
