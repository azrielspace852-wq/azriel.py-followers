# Dataset Koreksi Kesalahan — 2360

Kategori: correction
Tujuan: Melatih model mengakui kesalahan dan memperbaiki jawaban.

Q: Kamu bilang Hiu adalah mamalia. Itu tidak benar. Yang benar Hiu adalah ikan, bukan mamalia.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hiu adalah ikan, bukan mamalia.

Q: Kamu bilang Hasil 56 ÷ 7 adalah 9. Itu tidak benar. Yang benar Hasil 56 ÷ 7 adalah 8.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 56 ÷ 7 adalah 8.

Q: Jawaban sebelumnya: Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.
User: Itu salah. Satu ton = 100 kg ya?
A: Saya tadi salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Apakah kamu salah waktu bilang 'A lebih tinggi dari B, B lebih tinggi dari C, maka C paling tinggi.'?
A: Ya, saya salah. Salah. Jika A > B dan B > C, maka A paling tinggi dan C paling pendek.

Q: Tetap saja, Hasil 81 ÷ 9 adalah 10. benar kan?
A: Tidak, itu tetap salah. Hasil 81 ÷ 9 adalah 9.

Q: Yang baca proklamasi Hatta kan?
A: Saya minta maaf, saya salah. Proklamasi kemerdekaan dibacakan oleh Soekarno, didampingi Hatta.

Q: Jawaban sebelumnya: Air mendidih pada suhu 90 derajat Celsius.
User: Itu salah. Air mendidih di 90 derajat ya?
A: Saya tadi salah. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Kamu bilang Ibu kota Jepang adalah Kyoto. Itu tidak benar. Yang benar Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: Tetap saja, Perang Dunia II berakhir tahun 1944. benar kan?
A: Tidak, itu tetap salah. Perang Dunia II berakhir tahun 1945.

Q: Jawaban sebelumnya: Garuda Pancasila memiliki 6 sila.
User: Itu salah. Pancasila ada 6 sila kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Garuda Pancasila memiliki 5 sila.

Q: Bahasa resmi kita bahasa Inggris kan?
A: Benar, saya salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Air itu unsur kimia kan?
A: Saya mengakui kesalahan saya. Air adalah senyawa (H2O), bukan unsur.

Q: Apakah kamu salah waktu bilang 'Jika semua A adalah B, maka semua B adalah A.'?
A: Ya, saya salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Tetap saja, Es lebih berat dari air. benar kan?
A: Tidak, itu tetap salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Kamu bilang Air mendidih pada suhu 90 derajat Celsius. Itu tidak benar. Yang benar Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Air mendidih pada suhu 100 derajat Celsius pada tekanan standar.

Q: Apakah kamu salah waktu bilang 'Perang Dunia II berakhir tahun 1944.'?
A: Ya, saya salah. Perang Dunia II berakhir tahun 1945.

Q: Apakah kamu salah waktu bilang 'Matahari adalah planet.'?
A: Ya, saya salah. Matahari adalah bintang, bukan planet.

Q: Tetap saja, Hasil 15 + 27 adalah 41. benar kan?
A: Tidak, itu tetap salah. Hasil 15 + 27 adalah 42.

Q: Satu jam = 100 menit ya?
A: Saya perlu mengoreksi jawaban sebelumnya. Satu jam sama dengan 60 menit.

Q: Es lebih berat dari air ya?
A: Benar, saya salah. Es lebih ringan dari air dalam bentuk cair (karena mengapung).

Q: Tomat sayuran kan?
A: Saya minta maaf, saya salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Jawaban sebelumnya: Hasil 100 - 37 adalah 62.
User: Itu salah. 100 kurang 37 = 62 kan?
A: Saya mengakui kesalahan saya. Hasil 100 - 37 adalah 63.

Q: Tetap saja, Tomat adalah sayuran. benar kan?
A: Tidak, itu tetap salah. Secara botanis tomat adalah buah, meskipun sering dikategorikan sebagai sayuran dalam kuliner.

Q: Jawaban sebelumnya: Pulau terbesar di Indonesia adalah Jawa.
User: Itu salah. Pulau terbesar di Indonesia Jawa ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Pulau terbesar di Indonesia adalah Papua (bagian Indonesia).

Q: Jawaban sebelumnya: Perang Dunia II berakhir tahun 1944.
User: Itu salah. Perang Dunia II selesai 1944 ya?
A: Saya telah membuat kesalahan. Perang Dunia II berakhir tahun 1945.

Q: Tetap saja, Soekarno lahir di Bandung. benar kan?
A: Tidak, itu tetap salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Tetap saja, Hasil 56 ÷ 7 adalah 9. benar kan?
A: Tidak, itu tetap salah. Hasil 56 ÷ 7 adalah 8.

Q: Kamu bilang Kelelawar adalah burung. Itu tidak benar. Yang benar Kelelawar adalah mamalia yang bisa terbang, bukan burung.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Kelelawar adalah mamalia yang bisa terbang, bukan burung.

Q: Tetap saja, Hasil 14 + 6 adalah 20. benar kan?
A: Tidak, itu tetap salah. Hasil 14 + 6 adalah 20.

Q: Tetap saja, Jika semua A adalah B, maka semua B adalah A. benar kan?
A: Tidak, itu tetap salah. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.

Q: Apakah kamu salah waktu bilang 'Soekarno lahir di Bandung.'?
A: Ya, saya salah. Soekarno lahir di Blitar, Jawa Timur.

Q: Apakah kamu salah waktu bilang 'Ibukota Australia adalah Sydney.'?
A: Ya, saya salah. Ibukota Australia adalah Canberra.

Q: Jawaban sebelumnya: Hasil 81 ÷ 9 adalah 10.
User: Itu salah. 81 dibagi 9 = 10 kan?
A: Saya minta maaf, saya salah. Hasil 81 ÷ 9 adalah 9.

Q: Apakah kamu salah waktu bilang 'Bahasa Inggris adalah bahasa resmi Indonesia.'?
A: Ya, saya salah. Bahasa Indonesia adalah bahasa resmi Indonesia.

Q: Tetap saja, Hasil 7 × 8 adalah 54. benar kan?
A: Tidak, itu tetap salah. Hasil 7 × 8 adalah 56.

Q: Apakah kamu salah waktu bilang 'Warna pelangi hanya ada 5 warna.'?
A: Ya, saya salah. Warna pelangi secara umum disebut 7 warna: merah, jingga, kuning, hijau, biru, nila, ungu.

Q: Jawaban sebelumnya: Satu jam sama dengan 100 menit.
User: Itu salah. Satu jam = 100 menit ya?
A: Saya telah membuat kesalahan. Satu jam sama dengan 60 menit.

Q: Tetap saja, Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram. benar kan?
A: Tidak, itu tetap salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Apakah kamu salah waktu bilang 'Besi lebih ringan dari kayu.'?
A: Ya, saya salah. Besi lebih berat dari kayu pada volume yang sama.

Q: Ibu kota Jepang itu Kyoto kan?
A: Saya telah membuat kesalahan. Ibu kota Jepang adalah Tokyo. Kyoto adalah kota bersejarah, bukan ibu kota saat ini.

Q: 12 dibagi 3 hasilnya 5 ya?
A: Jawaban saya tadi keliru. Hasil 12 ÷ 3 adalah 4.

Q: Jawaban sebelumnya: Ibu kota Indonesia adalah Kuala Lumpur.
User: Itu salah. Bukannya ibu kota Indonesia adalah Kuala Lumpur?
A: Saya koreksi: jawaban sebelumnya tidak benar. Ibu kota Indonesia adalah Jakarta. Kuala Lumpur adalah ibu kota Malaysia.

Q: Jawaban sebelumnya: Hasil 15 + 27 adalah 41.
User: Itu salah. 15 + 27 = 41 kan?
A: Saya tadi salah. Hasil 15 + 27 adalah 42.

Q: Apakah kamu salah waktu bilang 'Satu kilogram sama dengan 1000 gram, jadi satu ton sama dengan 100 kilogram.'?
A: Ya, saya salah. Satu ton sama dengan 1000 kilogram, bukan 100 kilogram.

Q: Kamu bilang Bulan memancarkan cahayanya sendiri. Itu tidak benar. Yang benar Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Bulan tidak memancarkan cahaya sendiri; ia memantulkan cahaya Matahari.

Q: Tetap saja, Indonesia merdeka pada tahun 1944. benar kan?
A: Tidak, itu tetap salah. Indonesia merdeka pada tanggal 17 Agustus 1945.

Q: Jawaban sebelumnya: Hasil 23 + 18 adalah 40.
User: Itu salah. 23 + 18 = 40 kan?
A: Benar, saya salah. Hasil 23 + 18 adalah 41.

Q: Kamu bilang Hasil 15 + 27 adalah 41. Itu tidak benar. Yang benar Hasil 15 + 27 adalah 42.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 15 + 27 adalah 42.

Q: Tetap saja, Gunung tertinggi di Indonesia adalah Merapi. benar kan?
A: Tidak, itu tetap salah. Gunung tertinggi di Indonesia adalah Puncak Jaya di Papua.

Q: Kamu bilang Hasil 7 × 8 adalah 54. Itu tidak benar. Yang benar Hasil 7 × 8 adalah 56.
A: Terima kasih atas koreksinya. Saya mengakui kesalahan saya. Hasil 7 × 8 adalah 56.

Q: Jawaban sebelumnya: Hasil 14 + 6 adalah 20.
User: Itu salah. 14 + 6 = 20 kan?
A: Saya koreksi: jawaban sebelumnya tidak benar. Hasil 14 + 6 adalah 20.

Q: Apakah kamu salah waktu bilang 'Hasil 56 ÷ 7 adalah 9.'?
A: Ya, saya salah. Hasil 56 ÷ 7 adalah 8.

Q: Jawaban sebelumnya: Kata 'meja' adalah kata kerja.
User: Itu salah. Meja itu kata kerja kan?
A: Benar, saya salah. Kata 'meja' adalah kata benda, bukan kata kerja.

Q: Apakah kamu salah waktu bilang 'Bumi mengelilingi Matahari dalam 365 hari tepat.'?
A: Ya, saya salah. Bumi mengelilingi Matahari dalam sekitar 365,25 hari, itulah sebabnya ada tahun kabisat.

Q: Kalau semua A adalah B, berarti semua B adalah A ya?
A: Maaf, jawaban saya sebelumnya tidak tepat. Tidak. Jika semua A adalah B, belum tentu semua B adalah A. Itu konversi yang tidak valid.
