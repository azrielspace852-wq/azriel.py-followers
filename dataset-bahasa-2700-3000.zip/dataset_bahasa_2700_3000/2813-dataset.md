Q: Apa arti kata 'kehormatan'?
A: Martabat atau harga diri yang dijaga dengan baik.
Q: Jelaskan makna 'kehormatan'.
A: Martabat atau harga diri yang dijaga dengan baik.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'dekat'?
A: Sinonim dari 'dekat' antara lain: akrab, mesra.
Q: Apa antonim dari kata 'sehat'?
A: Antonim dari 'sehat' adalah 'sakit'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'kecil hati'?
A: Ungkapan 'kecil hati' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kewibawaan'?
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Jelaskan makna 'kewibawaan'.
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'baru'?
A: Sinonim dari 'baru' antara lain: segar, mutakhir.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'keteladanan'?
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Jelaskan makna 'keteladanan'.
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Apa perbedaan antara 'dekat' dan 'akrab'?
A: Dekat bisa jarak fisik. Akrab berarti hubungan intim.
Q: Apa sinonim dari kata 'lama'?
A: Sinonim dari 'lama' antara lain: usang, kuno.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'kebersamaan'?
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Jelaskan makna 'kebersamaan'.
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'baik'?
A: Sinonim dari 'baik' antara lain: bagus, unggul.
Q: Apa antonim dari kata 'rajin'?
A: Antonim dari 'rajin' adalah 'malas'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'kesetiakawanan'?
A: Rasa setia kawan dan saling mendukung.
Q: Jelaskan makna 'kesetiakawanan'.
A: Rasa setia kawan dan saling mendukung.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'buruk'?
A: Sinonim dari 'buruk' antara lain: jelek, rusak.
Q: Apa antonim dari kata 'jujur'?
A: Antonim dari 'jujur' adalah 'bohong'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'kepedulian'?
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Jelaskan makna 'kepedulian'.
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'benar'?
A: Sinonim dari 'benar' antara lain: tepat, akurat.
Q: Apa antonim dari kata 'baik'?
A: Antonim dari 'baik' adalah 'buruk'.
