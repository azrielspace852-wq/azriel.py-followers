Q: Apa arti kata 'kesopanan'?
A: Perilaku yang sesuai dengan norma sopan santun.
Q: Jelaskan makna 'kesopanan'.
A: Perilaku yang sesuai dengan norma sopan santun.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'besar'?
A: Antonim dari 'besar' adalah 'kecil'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kehormatan'?
A: Martabat atau harga diri yang dijaga dengan baik.
Q: Jelaskan makna 'kehormatan'.
A: Martabat atau harga diri yang dijaga dengan baik.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kewibawaan'?
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Jelaskan makna 'kewibawaan'.
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'keteladanan'?
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Jelaskan makna 'keteladanan'.
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Apa perbedaan antara 'dekat' dan 'akrab'?
A: Dekat bisa jarak fisik. Akrab berarti hubungan intim.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'kebersamaan'?
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Jelaskan makna 'kebersamaan'.
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'kesetiakawanan'?
A: Rasa setia kawan dan saling mendukung.
Q: Jelaskan makna 'kesetiakawanan'.
A: Rasa setia kawan dan saling mendukung.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
