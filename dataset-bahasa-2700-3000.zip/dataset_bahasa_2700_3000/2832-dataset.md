Q: Apa arti kata 'misi'?
A: Langkah-langkah konkret untuk mencapai visi.
Q: Jelaskan makna 'misi'.
A: Langkah-langkah konkret untuk mencapai visi.
Q: Apa perbedaan antara 'sering' dan 'kerap'?
A: Sering dan kerap sama-sama banyak kali, kerap lebih formal.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
Q: Bagaimana cara menggunakan kata 'tetapi'?
A: Tetapi untuk kontras. Contoh: Saya ingin pergi, tetapi hujan.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'strategi'?
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Jelaskan makna 'strategi'.
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'taktik'?
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Jelaskan makna 'taktik'.
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Apa perbedaan antara 'banyak' dan 'berlimpah'?
A: Banyak jumlah besar. Berlimpah sangat banyak hingga berlebih.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'rajin'?
A: Antonim dari 'rajin' adalah 'malas'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'prioritas'?
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Jelaskan makna 'prioritas'.
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Apa perbedaan antara 'sedikit' dan 'minim'?
A: Sedikit jumlah kecil. Minim sangat sedikit dari yang diharapkan.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'jujur'?
A: Antonim dari 'jujur' adalah 'bohong'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'penuh' dan 'padat'?
A: Penuh tidak ada ruang kosong. Padat tersusun rapat.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'baik'?
A: Antonim dari 'baik' adalah 'buruk'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'disiplin'?
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Jelaskan makna 'disiplin'.
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'benar'?
A: Antonim dari 'benar' adalah 'salah'.
