Q: Apa arti kata 'kohesi'?
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Jelaskan makna 'kohesi'.
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'sehat'?
A: Sinonim dari 'sehat' antara lain: bugar, waras.
Q: Apa antonim dari kata 'besar'?
A: Antonim dari 'besar' adalah 'kecil'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'ambiguitas'?
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Jelaskan makna 'ambiguitas'.
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Apa perbedaan antara 'tinggi' dan 'luhur'?
A: Tinggi bisa fisik atau posisi. Luhur lebih ke nilai moral yang mulia.
Q: Apa sinonim dari kata 'sakit'?
A: Sinonim dari 'sakit' antara lain: nyeri, pedih.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'polisemi'?
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Jelaskan makna 'polisemi'.
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Apa perbedaan antara 'rendah' dan 'rendah hati'?
A: Rendah bisa posisi atau ukuran. Rendah hati berarti tidak sombong.
Q: Apa sinonim dari kata 'cantik'?
A: Sinonim dari 'cantik' antara lain: indah, elok, molek.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'homonim'?
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Jelaskan makna 'homonim'.
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'tampan'?
A: Sinonim dari 'tampan' antara lain: ganteng, rupawan.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'akronim'?
A: Singkatan yang dilafalkan sebagai kata.
Q: Jelaskan makna 'akronim'.
A: Singkatan yang dilafalkan sebagai kata.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'pintar'?
A: Sinonim dari 'pintar' antara lain: cerdas, pandai.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'lapang dada'?
A: Ungkapan 'lapang dada' berarti Sabar dan tidak mudah marah.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'register'?
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Jelaskan makna 'register'.
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'kaya'?
A: Sinonim dari 'kaya' antara lain: makmur, berlimpah.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
