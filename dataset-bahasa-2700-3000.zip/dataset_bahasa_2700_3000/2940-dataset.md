Q: Apa arti kata 'misi'?
A: Langkah-langkah konkret untuk mencapai visi.
Q: Jelaskan makna 'misi'.
A: Langkah-langkah konkret untuk mencapai visi.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'kaya'?
A: Antonim dari 'kaya' adalah 'miskin'.
Q: Bagaimana cara menggunakan kata 'tetapi'?
A: Tetapi untuk kontras. Contoh: Saya ingin pergi, tetapi hujan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'strategi'?
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Jelaskan makna 'strategi'.
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'kuat'?
A: Antonim dari 'kuat' adalah 'lemah'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'taktik'?
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Jelaskan makna 'taktik'.
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'sehat'?
A: Antonim dari 'sehat' adalah 'sakit'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'prioritas'?
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Jelaskan makna 'prioritas'.
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'tangan terbuka'?
A: Ungkapan 'tangan terbuka' berarti Dermawan.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'disiplin'?
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Jelaskan makna 'disiplin'.
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'rajin'?
A: Antonim dari 'rajin' adalah 'malas'.
