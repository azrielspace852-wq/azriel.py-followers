Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'sejak'?
A: Sejak menunjukkan awal waktu. Contoh: Sejak pagi sudah bekerja.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'ketelitian'?
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Jelaskan makna 'ketelitian'.
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'meskipun'?
A: Meskipun digunakan untuk kontras. Contoh: Meskipun hujan, dia tetap berangkat.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'ketekunan'?
A: Sikap terus berusaha dengan sabar meskipun menghadapi kesulitan.
Q: Jelaskan makna 'ketekunan'.
A: Sikap terus berusaha dengan sabar meskipun menghadapi kesulitan.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'sehingga'?
A: Sehingga menunjukkan akibat. Contoh: Dia belajar keras sehingga berhasil.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kearifan'?
A: Kebijaksanaan yang didasarkan pada pengalaman dan pemahaman mendalam.
Q: Jelaskan makna 'kearifan'.
A: Kebijaksanaan yang didasarkan pada pengalaman dan pemahaman mendalam.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'karena'?
A: Karena menunjukkan alasan. Contoh: Dia terlambat karena macet.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'kepekaan'?
A: Kemampuan merasakan atau memahami sesuatu dengan cepat dan tajam.
Q: Jelaskan makna 'kepekaan'.
A: Kemampuan merasakan atau memahami sesuatu dengan cepat dan tajam.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
Q: Bagaimana cara menggunakan kata 'jika'?
A: Jika digunakan untuk syarat. Contoh: Jika hujan, kita tetap di rumah.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'ketulusan'?
A: Kejujuran hati tanpa pamrih atau niat tersembunyi.
Q: Jelaskan makna 'ketulusan'.
A: Kejujuran hati tanpa pamrih atau niat tersembunyi.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'awal'?
A: Antonim dari 'awal' adalah 'akhir'.
