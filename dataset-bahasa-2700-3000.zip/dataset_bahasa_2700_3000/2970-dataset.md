Q: Apa arti kata 'potensi'?
A: Kemampuan yang masih tersembunyi dan bisa dikembangkan.
Q: Jelaskan makna 'potensi'.
A: Kemampuan yang masih tersembunyi dan bisa dikembangkan.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'tinggi'?
A: Antonim dari 'tinggi' adalah 'rendah'.
Q: Bagaimana cara menggunakan kata 'meskipun'?
A: Meskipun digunakan untuk kontras. Contoh: Meskipun hujan, dia tetap berangkat.
Q: Apa arti ungkapan 'berat hati'?
A: Ungkapan 'berat hati' berarti Enggan atau tidak rela.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'bakat'?
A: Kemampuan bawaan yang menonjol di bidang tertentu.
Q: Jelaskan makna 'bakat'.
A: Kemampuan bawaan yang menonjol di bidang tertentu.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'besar'?
A: Antonim dari 'besar' adalah 'kecil'.
Q: Bagaimana cara menggunakan kata 'sehingga'?
A: Sehingga menunjukkan akibat. Contoh: Dia belajar keras sehingga berhasil.
Q: Apa arti ungkapan 'ringan kaki'?
A: Ungkapan 'ringan kaki' berarti Suka pergi atau tidak betah di rumah.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'minat'?
A: Ketertarikan atau kecenderungan terhadap sesuatu.
Q: Jelaskan makna 'minat'.
A: Ketertarikan atau kecenderungan terhadap sesuatu.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'karena'?
A: Karena menunjukkan alasan. Contoh: Dia terlambat karena macet.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'prestasi'?
A: Hasil yang dicapai dari usaha atau kerja keras.
Q: Jelaskan makna 'prestasi'.
A: Hasil yang dicapai dari usaha atau kerja keras.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'jika'?
A: Jika digunakan untuk syarat. Contoh: Jika hujan, kita tetap di rumah.
Q: Apa arti ungkapan 'rendah hati'?
A: Ungkapan 'rendah hati' berarti Tidak sombong.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'target'?
A: Sasaran atau tujuan yang ingin dicapai.
Q: Jelaskan makna 'target'.
A: Sasaran atau tujuan yang ingin dicapai.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'agar'?
A: Agar menunjukkan tujuan. Contoh: Dia berlatih agar juara.
Q: Apa arti ungkapan 'besar mulut'?
A: Ungkapan 'besar mulut' berarti Suka membual.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'visi'?
A: Gambaran masa depan yang ingin diwujudkan.
Q: Jelaskan makna 'visi'.
A: Gambaran masa depan yang ingin diwujudkan.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
