Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'simpati'?
A: Perasaan turut prihatin atau mendukung orang lain.
Q: Jelaskan makna 'simpati'.
A: Perasaan turut prihatin atau mendukung orang lain.
Q: Apa perbedaan antara 'banyak' dan 'berlimpah'?
A: Banyak jumlah besar. Berlimpah sangat banyak hingga berlebih.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'toleransi'?
A: Sikap menghargai perbedaan pendapat, keyakinan, atau kebiasaan.
Q: Jelaskan makna 'toleransi'.
A: Sikap menghargai perbedaan pendapat, keyakinan, atau kebiasaan.
Q: Apa perbedaan antara 'sedikit' dan 'minim'?
A: Sedikit jumlah kecil. Minim sangat sedikit dari yang diharapkan.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'apresiasi'?
A: Penghargaan atau penilaian positif terhadap sesuatu.
Q: Jelaskan makna 'apresiasi'.
A: Penghargaan atau penilaian positif terhadap sesuatu.
Q: Apa perbedaan antara 'penuh' dan 'padat'?
A: Penuh tidak ada ruang kosong. Padat tersusun rapat.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'ramai'?
A: Antonim dari 'ramai' adalah 'sepi'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'motivasi'?
A: Dorongan dari dalam diri untuk melakukan sesuatu.
Q: Jelaskan makna 'motivasi'.
A: Dorongan dari dalam diri untuk melakukan sesuatu.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'penuh'?
A: Antonim dari 'penuh' adalah 'kosong'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'inspirasi'?
A: Hal yang membangkitkan semangat atau ide baru.
Q: Jelaskan makna 'inspirasi'.
A: Hal yang membangkitkan semangat atau ide baru.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'kaya'?
A: Antonim dari 'kaya' adalah 'miskin'.
