Q: Apa arti kata 'tanggung jawab'?
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Jelaskan makna 'tanggung jawab'.
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'sehat'?
A: Sinonim dari 'sehat' antara lain: bugar, waras.
Q: Apa antonim dari kata 'baik'?
A: Antonim dari 'baik' adalah 'buruk'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'integritas'?
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Jelaskan makna 'integritas'.
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Apa perbedaan antara 'tinggi' dan 'luhur'?
A: Tinggi bisa fisik atau posisi. Luhur lebih ke nilai moral yang mulia.
Q: Apa sinonim dari kata 'sakit'?
A: Sinonim dari 'sakit' antara lain: nyeri, pedih.
Q: Apa antonim dari kata 'benar'?
A: Antonim dari 'benar' adalah 'salah'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'profesionalisme'?
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Jelaskan makna 'profesionalisme'.
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Apa perbedaan antara 'rendah' dan 'rendah hati'?
A: Rendah bisa posisi atau ukuran. Rendah hati berarti tidak sombong.
Q: Apa sinonim dari kata 'cantik'?
A: Sinonim dari 'cantik' antara lain: indah, elok, molek.
Q: Apa antonim dari kata 'mudah'?
A: Antonim dari 'mudah' adalah 'sulit'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'etika'?
A: Nilai-nilai moral yang mengatur perilaku.
Q: Jelaskan makna 'etika'.
A: Nilai-nilai moral yang mengatur perilaku.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'tampan'?
A: Sinonim dari 'tampan' antara lain: ganteng, rupawan.
Q: Apa antonim dari kata 'aman'?
A: Antonim dari 'aman' adalah 'bahaya'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'pintar'?
A: Sinonim dari 'pintar' antara lain: cerdas, pandai.
Q: Apa antonim dari kata 'damai'?
A: Antonim dari 'damai' adalah 'perang'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'nilai'?
A: Hal yang dianggap penting dan berharga.
Q: Jelaskan makna 'nilai'.
A: Hal yang dianggap penting dan berharga.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'kaya'?
A: Sinonim dari 'kaya' antara lain: makmur, berlimpah.
Q: Apa antonim dari kata 'tinggi'?
A: Antonim dari 'tinggi' adalah 'rendah'.
