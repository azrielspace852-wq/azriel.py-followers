Q: Apa arti kata 'komitmen'?
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Jelaskan makna 'komitmen'.
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'anak emas'?
A: Ungkapan 'anak emas' berarti Anak kesayangan.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'tanggung jawab'?
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Jelaskan makna 'tanggung jawab'.
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'integritas'?
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Jelaskan makna 'integritas'.
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'profesionalisme'?
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Jelaskan makna 'profesionalisme'.
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'etika'?
A: Nilai-nilai moral yang mengatur perilaku.
Q: Jelaskan makna 'etika'.
A: Nilai-nilai moral yang mengatur perilaku.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
