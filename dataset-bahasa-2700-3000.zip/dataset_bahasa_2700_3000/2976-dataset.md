Q: Apa arti kata 'koherensi'?
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Jelaskan makna 'koherensi'.
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'sehat'?
A: Sinonim dari 'sehat' antara lain: bugar, waras.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'kohesi'?
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Jelaskan makna 'kohesi'.
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Apa perbedaan antara 'dekat' dan 'akrab'?
A: Dekat bisa jarak fisik. Akrab berarti hubungan intim.
Q: Apa sinonim dari kata 'sakit'?
A: Sinonim dari 'sakit' antara lain: nyeri, pedih.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'ambiguitas'?
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Jelaskan makna 'ambiguitas'.
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'cantik'?
A: Sinonim dari 'cantik' antara lain: indah, elok, molek.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'polisemi'?
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Jelaskan makna 'polisemi'.
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'tampan'?
A: Sinonim dari 'tampan' antara lain: ganteng, rupawan.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'homonim'?
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Jelaskan makna 'homonim'.
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'pintar'?
A: Sinonim dari 'pintar' antara lain: cerdas, pandai.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'akronim'?
A: Singkatan yang dilafalkan sebagai kata.
Q: Jelaskan makna 'akronim'.
A: Singkatan yang dilafalkan sebagai kata.
Q: Apa perbedaan antara 'sulit' dan 'rumit'?
A: Sulit berarti susah dikerjakan. Rumit memiliki banyak bagian terkait.
Q: Apa sinonim dari kata 'kaya'?
A: Sinonim dari 'kaya' antara lain: makmur, berlimpah.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
