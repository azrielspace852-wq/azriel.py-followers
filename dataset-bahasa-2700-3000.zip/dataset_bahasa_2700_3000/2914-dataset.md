Q: Apa arti kata 'semantik'?
A: Cabang ilmu bahasa yang mempelajari makna kata dan kalimat.
Q: Jelaskan makna 'semantik'.
A: Cabang ilmu bahasa yang mempelajari makna kata dan kalimat.
Q: Apa perbedaan antara 'penuh' dan 'padat'?
A: Penuh tidak ada ruang kosong. Padat tersusun rapat.
Q: Apa sinonim dari kata 'mudah'?
A: Sinonim dari 'mudah' antara lain: gampang, ringan.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'diksi'?
A: Pilihan kata yang tepat untuk menyampaikan makna dan suasana.
Q: Jelaskan makna 'diksi'.
A: Pilihan kata yang tepat untuk menyampaikan makna dan suasana.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'sulit'?
A: Sinonim dari 'sulit' antara lain: susah, rumit.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'koherensi'?
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Jelaskan makna 'koherensi'.
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'penting'?
A: Sinonim dari 'penting' antara lain: krusial, urgen.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kohesi'?
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Jelaskan makna 'kohesi'.
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'perlu'?
A: Sinonim dari 'perlu' antara lain: dibutuhkan.
Q: Apa antonim dari kata 'awal'?
A: Antonim dari 'awal' adalah 'akhir'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'ambiguitas'?
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Jelaskan makna 'ambiguitas'.
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'boleh'?
A: Sinonim dari 'boleh' antara lain: diizinkan.
Q: Apa antonim dari kata 'mulai'?
A: Antonim dari 'mulai' adalah 'selesai'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'polisemi'?
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Jelaskan makna 'polisemi'.
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'harus'?
A: Sinonim dari 'harus' antara lain: wajib, mesti.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
