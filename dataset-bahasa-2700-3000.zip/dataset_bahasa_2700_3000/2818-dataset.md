Q: Apa arti kata 'etika'?
A: Nilai-nilai moral yang mengatur perilaku.
Q: Jelaskan makna 'etika'.
A: Nilai-nilai moral yang mengatur perilaku.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'dekat'?
A: Sinonim dari 'dekat' antara lain: akrab, mesra.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'sulit' dan 'rumit'?
A: Sulit berarti susah dikerjakan. Rumit memiliki banyak bagian terkait.
Q: Apa sinonim dari kata 'baru'?
A: Sinonim dari 'baru' antara lain: segar, mutakhir.
Q: Apa antonim dari kata 'rajin'?
A: Antonim dari 'rajin' adalah 'malas'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'nilai'?
A: Hal yang dianggap penting dan berharga.
Q: Jelaskan makna 'nilai'.
A: Hal yang dianggap penting dan berharga.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'lama'?
A: Sinonim dari 'lama' antara lain: usang, kuno.
Q: Apa antonim dari kata 'jujur'?
A: Antonim dari 'jujur' adalah 'bohong'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'prinsip'?
A: Dasar atau pegangan yang dipegang teguh.
Q: Jelaskan makna 'prinsip'.
A: Dasar atau pegangan yang dipegang teguh.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'baik'?
A: Sinonim dari 'baik' antara lain: bagus, unggul.
Q: Apa antonim dari kata 'baik'?
A: Antonim dari 'baik' adalah 'buruk'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'keyakinan'?
A: Kepercayaan yang kuat terhadap sesuatu.
Q: Jelaskan makna 'keyakinan'.
A: Kepercayaan yang kuat terhadap sesuatu.
Q: Apa perbedaan antara 'bisa' dan 'mampu'?
A: Bisa memiliki kemampuan. Mampu menekankan kapasitas.
Q: Apa sinonim dari kata 'buruk'?
A: Sinonim dari 'buruk' antara lain: jelek, rusak.
Q: Apa antonim dari kata 'benar'?
A: Antonim dari 'benar' adalah 'salah'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'harapan'?
A: Keinginan agar sesuatu terjadi di masa depan.
Q: Jelaskan makna 'harapan'.
A: Keinginan agar sesuatu terjadi di masa depan.
Q: Apa perbedaan antara 'boleh' dan 'dapat'?
A: Boleh berarti diizinkan. Dapat berarti mungkin atau mampu.
Q: Apa sinonim dari kata 'benar'?
A: Sinonim dari 'benar' antara lain: tepat, akurat.
Q: Apa antonim dari kata 'mudah'?
A: Antonim dari 'mudah' adalah 'sulit'.
