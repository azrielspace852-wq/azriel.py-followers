Q: Apa arti kata 'ambiguitas'?
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Jelaskan makna 'ambiguitas'.
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'penuh'?
A: Antonim dari 'penuh' adalah 'kosong'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'polisemi'?
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Jelaskan makna 'polisemi'.
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'kaya'?
A: Antonim dari 'kaya' adalah 'miskin'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'homonim'?
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Jelaskan makna 'homonim'.
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'kuat'?
A: Antonim dari 'kuat' adalah 'lemah'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'akronim'?
A: Singkatan yang dilafalkan sebagai kata.
Q: Jelaskan makna 'akronim'.
A: Singkatan yang dilafalkan sebagai kata.
Q: Apa perbedaan antara 'sulit' dan 'rumit'?
A: Sulit berarti susah dikerjakan. Rumit memiliki banyak bagian terkait.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'sehat'?
A: Antonim dari 'sehat' adalah 'sakit'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'lapang dada'?
A: Ungkapan 'lapang dada' berarti Sabar dan tidak mudah marah.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'register'?
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Jelaskan makna 'register'.
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
Q: Bagaimana cara menggunakan kata 'dari'?
A: Dari menunjukkan asal. Contoh: Berasal dari Jakarta.
Q: Apa arti ungkapan 'berat hati'?
A: Ungkapan 'berat hati' berarti Enggan atau tidak rela.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'implikatur'?
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Jelaskan makna 'implikatur'.
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
