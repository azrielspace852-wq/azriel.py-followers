Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'mulai'?
A: Antonim dari 'mulai' adalah 'selesai'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'kecil hati'?
A: Ungkapan 'kecil hati' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'nilai'?
A: Hal yang dianggap penting dan berharga.
Q: Jelaskan makna 'nilai'.
A: Hal yang dianggap penting dan berharga.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'prinsip'?
A: Dasar atau pegangan yang dipegang teguh.
Q: Jelaskan makna 'prinsip'.
A: Dasar atau pegangan yang dipegang teguh.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'keyakinan'?
A: Kepercayaan yang kuat terhadap sesuatu.
Q: Jelaskan makna 'keyakinan'.
A: Kepercayaan yang kuat terhadap sesuatu.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'harapan'?
A: Keinginan agar sesuatu terjadi di masa depan.
Q: Jelaskan makna 'harapan'.
A: Keinginan agar sesuatu terjadi di masa depan.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'dari'?
A: Dari menunjukkan asal. Contoh: Berasal dari Jakarta.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'cita-cita'?
A: Tujuan hidup yang ingin dicapai.
Q: Jelaskan makna 'cita-cita'.
A: Tujuan hidup yang ingin dicapai.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
