Q: Apa arti kata 'misi'?
A: Langkah-langkah konkret untuk mencapai visi.
Q: Jelaskan makna 'misi'.
A: Langkah-langkah konkret untuk mencapai visi.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'mudah'?
A: Sinonim dari 'mudah' antara lain: gampang, ringan.
Q: Apa antonim dari kata 'jujur'?
A: Antonim dari 'jujur' adalah 'bohong'.
Q: Bagaimana cara menggunakan kata 'tetapi'?
A: Tetapi untuk kontras. Contoh: Saya ingin pergi, tetapi hujan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'strategi'?
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Jelaskan makna 'strategi'.
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'sulit'?
A: Sinonim dari 'sulit' antara lain: susah, rumit.
Q: Apa antonim dari kata 'baik'?
A: Antonim dari 'baik' adalah 'buruk'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'taktik'?
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Jelaskan makna 'taktik'.
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Apa perbedaan antara 'bisa' dan 'mampu'?
A: Bisa memiliki kemampuan. Mampu menekankan kapasitas.
Q: Apa sinonim dari kata 'penting'?
A: Sinonim dari 'penting' antara lain: krusial, urgen.
Q: Apa antonim dari kata 'benar'?
A: Antonim dari 'benar' adalah 'salah'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'prioritas'?
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Jelaskan makna 'prioritas'.
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Apa perbedaan antara 'boleh' dan 'dapat'?
A: Boleh berarti diizinkan. Dapat berarti mungkin atau mampu.
Q: Apa sinonim dari kata 'perlu'?
A: Sinonim dari 'perlu' antara lain: dibutuhkan.
Q: Apa antonim dari kata 'mudah'?
A: Antonim dari 'mudah' adalah 'sulit'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'harus' dan 'wajib'?
A: Harus menekankan keharusan. Wajib lebih formal dan mengikat.
Q: Apa sinonim dari kata 'boleh'?
A: Sinonim dari 'boleh' antara lain: diizinkan.
Q: Apa antonim dari kata 'aman'?
A: Antonim dari 'aman' adalah 'bahaya'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'tangan terbuka'?
A: Ungkapan 'tangan terbuka' berarti Dermawan.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'disiplin'?
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Jelaskan makna 'disiplin'.
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'harus'?
A: Sinonim dari 'harus' antara lain: wajib, mesti.
Q: Apa antonim dari kata 'damai'?
A: Antonim dari 'damai' adalah 'perang'.
