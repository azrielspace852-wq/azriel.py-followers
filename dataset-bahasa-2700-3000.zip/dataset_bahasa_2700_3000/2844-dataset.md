Q: Apa arti kata 'kewibawaan'?
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Jelaskan makna 'kewibawaan'.
A: Pengaruh yang membuat orang lain menghormati dan patuh.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'mudah'?
A: Sinonim dari 'mudah' antara lain: gampang, ringan.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'keteladanan'?
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Jelaskan makna 'keteladanan'.
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'sulit'?
A: Sinonim dari 'sulit' antara lain: susah, rumit.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kebersamaan'?
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Jelaskan makna 'kebersamaan'.
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Apa perbedaan antara 'bisa' dan 'mampu'?
A: Bisa memiliki kemampuan. Mampu menekankan kapasitas.
Q: Apa sinonim dari kata 'penting'?
A: Sinonim dari 'penting' antara lain: krusial, urgen.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kesetiakawanan'?
A: Rasa setia kawan dan saling mendukung.
Q: Jelaskan makna 'kesetiakawanan'.
A: Rasa setia kawan dan saling mendukung.
Q: Apa perbedaan antara 'boleh' dan 'dapat'?
A: Boleh berarti diizinkan. Dapat berarti mungkin atau mampu.
Q: Apa sinonim dari kata 'perlu'?
A: Sinonim dari 'perlu' antara lain: dibutuhkan.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kepedulian'?
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Jelaskan makna 'kepedulian'.
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Apa perbedaan antara 'harus' dan 'wajib'?
A: Harus menekankan keharusan. Wajib lebih formal dan mengikat.
Q: Apa sinonim dari kata 'boleh'?
A: Sinonim dari 'boleh' antara lain: diizinkan.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'tangan terbuka'?
A: Ungkapan 'tangan terbuka' berarti Dermawan.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'kesadaran'?
A: Mengetahui dan memahami keadaan diri atau sekitar.
Q: Jelaskan makna 'kesadaran'.
A: Mengetahui dan memahami keadaan diri atau sekitar.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'harus'?
A: Sinonim dari 'harus' antara lain: wajib, mesti.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
