Q: Apa arti kata 'visi'?
A: Gambaran masa depan yang ingin diwujudkan.
Q: Jelaskan makna 'visi'.
A: Gambaran masa depan yang ingin diwujudkan.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'mudah'?
A: Sinonim dari 'mudah' antara lain: gampang, ringan.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'namun'?
A: Namun digunakan untuk kontras. Contoh: Dia pintar, namun malas.
Q: Apa arti ungkapan 'kecil hati'?
A: Ungkapan 'kecil hati' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'misi'?
A: Langkah-langkah konkret untuk mencapai visi.
Q: Jelaskan makna 'misi'.
A: Langkah-langkah konkret untuk mencapai visi.
Q: Apa perbedaan antara 'sering' dan 'kerap'?
A: Sering dan kerap sama-sama banyak kali, kerap lebih formal.
Q: Apa sinonim dari kata 'sulit'?
A: Sinonim dari 'sulit' antara lain: susah, rumit.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'tetapi'?
A: Tetapi untuk kontras. Contoh: Saya ingin pergi, tetapi hujan.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'strategi'?
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Jelaskan makna 'strategi'.
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'penting'?
A: Sinonim dari 'penting' antara lain: krusial, urgen.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'taktik'?
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Jelaskan makna 'taktik'.
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Apa perbedaan antara 'banyak' dan 'berlimpah'?
A: Banyak jumlah besar. Berlimpah sangat banyak hingga berlebih.
Q: Apa sinonim dari kata 'perlu'?
A: Sinonim dari 'perlu' antara lain: dibutuhkan.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'prioritas'?
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Jelaskan makna 'prioritas'.
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Apa perbedaan antara 'sedikit' dan 'minim'?
A: Sedikit jumlah kecil. Minim sangat sedikit dari yang diharapkan.
Q: Apa sinonim dari kata 'boleh'?
A: Sinonim dari 'boleh' antara lain: diizinkan.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'penuh' dan 'padat'?
A: Penuh tidak ada ruang kosong. Padat tersusun rapat.
Q: Apa sinonim dari kata 'harus'?
A: Sinonim dari 'harus' antara lain: wajib, mesti.
Q: Apa antonim dari kata 'awal'?
A: Antonim dari 'awal' adalah 'akhir'.
