Q: Apa arti kata 'assertif'?
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Jelaskan makna 'assertif'.
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'sampai'?
A: Sampai juga batas. Contoh: Sampai jumpa besok.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'sejak'?
A: Sejak menunjukkan awal waktu. Contoh: Sejak pagi sudah bekerja.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'ketelitian'?
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Jelaskan makna 'ketelitian'.
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Apa perbedaan antara 'cepat' dan 'segera'?
A: Cepat berarti dalam waktu singkat. Segera berarti tanpa ditunda.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'meskipun'?
A: Meskipun digunakan untuk kontras. Contoh: Meskipun hujan, dia tetap berangkat.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'ketekunan'?
A: Sikap terus berusaha dengan sabar meskipun menghadapi kesulitan.
Q: Jelaskan makna 'ketekunan'.
A: Sikap terus berusaha dengan sabar meskipun menghadapi kesulitan.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'sehingga'?
A: Sehingga menunjukkan akibat. Contoh: Dia belajar keras sehingga berhasil.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'kearifan'?
A: Kebijaksanaan yang didasarkan pada pengalaman dan pemahaman mendalam.
Q: Jelaskan makna 'kearifan'.
A: Kebijaksanaan yang didasarkan pada pengalaman dan pemahaman mendalam.
Q: Apa perbedaan antara 'tinggi' dan 'luhur'?
A: Tinggi bisa fisik atau posisi. Luhur lebih ke nilai moral yang mulia.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'karena'?
A: Karena menunjukkan alasan. Contoh: Dia terlambat karena macet.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'kepekaan'?
A: Kemampuan merasakan atau memahami sesuatu dengan cepat dan tajam.
Q: Jelaskan makna 'kepekaan'.
A: Kemampuan merasakan atau memahami sesuatu dengan cepat dan tajam.
Q: Apa perbedaan antara 'rendah' dan 'rendah hati'?
A: Rendah bisa posisi atau ukuran. Rendah hati berarti tidak sombong.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
