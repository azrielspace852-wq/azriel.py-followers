Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'dekat'?
A: Sinonim dari 'dekat' antara lain: akrab, mesra.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'ringan kaki'?
A: Ungkapan 'ringan kaki' berarti Suka pergi atau tidak betah di rumah.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'simpati'?
A: Perasaan turut prihatin atau mendukung orang lain.
Q: Jelaskan makna 'simpati'.
A: Perasaan turut prihatin atau mendukung orang lain.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'baru'?
A: Sinonim dari 'baru' antara lain: segar, mutakhir.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'toleransi'?
A: Sikap menghargai perbedaan pendapat, keyakinan, atau kebiasaan.
Q: Jelaskan makna 'toleransi'.
A: Sikap menghargai perbedaan pendapat, keyakinan, atau kebiasaan.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'lama'?
A: Sinonim dari 'lama' antara lain: usang, kuno.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'rendah hati'?
A: Ungkapan 'rendah hati' berarti Tidak sombong.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'apresiasi'?
A: Penghargaan atau penilaian positif terhadap sesuatu.
Q: Jelaskan makna 'apresiasi'.
A: Penghargaan atau penilaian positif terhadap sesuatu.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'baik'?
A: Sinonim dari 'baik' antara lain: bagus, unggul.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'besar mulut'?
A: Ungkapan 'besar mulut' berarti Suka membual.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'motivasi'?
A: Dorongan dari dalam diri untuk melakukan sesuatu.
Q: Jelaskan makna 'motivasi'.
A: Dorongan dari dalam diri untuk melakukan sesuatu.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'buruk'?
A: Sinonim dari 'buruk' antara lain: jelek, rusak.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'kecil hati'?
A: Ungkapan 'kecil hati' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'inspirasi'?
A: Hal yang membangkitkan semangat atau ide baru.
Q: Jelaskan makna 'inspirasi'.
A: Hal yang membangkitkan semangat atau ide baru.
Q: Apa perbedaan antara 'cepat' dan 'segera'?
A: Cepat berarti dalam waktu singkat. Segera berarti tanpa ditunda.
Q: Apa sinonim dari kata 'benar'?
A: Sinonim dari 'benar' antara lain: tepat, akurat.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
