Q: Apa arti kata 'koherensi'?
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Jelaskan makna 'koherensi'.
A: Keterkaitan makna yang membuat teks mudah dipahami secara keseluruhan.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kohesi'?
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Jelaskan makna 'kohesi'.
A: Hubungan antar bagian teks melalui alat bahasa seperti kata penghubung.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'ambiguitas'?
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Jelaskan makna 'ambiguitas'.
A: Ketidakjelasan makna yang bisa ditafsirkan lebih dari satu cara.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'polisemi'?
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Jelaskan makna 'polisemi'.
A: Satu kata yang memiliki beberapa makna yang saling terkait.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'homonim'?
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Jelaskan makna 'homonim'.
A: Kata yang sama ejaan atau bunyinya tetapi berbeda makna.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'ramai'?
A: Antonim dari 'ramai' adalah 'sepi'.
Q: Bagaimana cara menggunakan kata 'mengenai'?
A: Mengenai sama dengan tentang. Contoh: Berita mengenai cuaca.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'akronim'?
A: Singkatan yang dilafalkan sebagai kata.
Q: Jelaskan makna 'akronim'.
A: Singkatan yang dilafalkan sebagai kata.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'penuh'?
A: Antonim dari 'penuh' adalah 'kosong'.
