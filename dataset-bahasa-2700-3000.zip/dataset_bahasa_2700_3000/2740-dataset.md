Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'awal'?
A: Antonim dari 'awal' adalah 'akhir'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'disiplin'?
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Jelaskan makna 'disiplin'.
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'mulai'?
A: Antonim dari 'mulai' adalah 'selesai'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'lapang dada'?
A: Ungkapan 'lapang dada' berarti Sabar dan tidak mudah marah.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'komitmen'?
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Jelaskan makna 'komitmen'.
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Apa perbedaan antara 'jauh' dan 'jarak'?
A: Jauh adalah sifat. Jarak adalah ukuran antara dua titik.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'masuk'?
A: Antonim dari 'masuk' adalah 'keluar'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'berat hati'?
A: Ungkapan 'berat hati' berarti Enggan atau tidak rela.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'tanggung jawab'?
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Jelaskan makna 'tanggung jawab'.
A: Kesediaan menanggung akibat dari tindakan sendiri.
Q: Apa perbedaan antara 'dekat' dan 'akrab'?
A: Dekat bisa jarak fisik. Akrab berarti hubungan intim.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'ringan kaki'?
A: Ungkapan 'ringan kaki' berarti Suka pergi atau tidak betah di rumah.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'integritas'?
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Jelaskan makna 'integritas'.
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'profesionalisme'?
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Jelaskan makna 'profesionalisme'.
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
