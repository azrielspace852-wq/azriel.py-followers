Q: Apa arti kata 'kerendahan hati'?
A: Sikap tidak sombong dan mau mengakui kekurangan diri.
Q: Jelaskan makna 'kerendahan hati'.
A: Sikap tidak sombong dan mau mengakui kekurangan diri.
Q: Apa perbedaan antara 'bisa' dan 'mampu'?
A: Bisa memiliki kemampuan. Mampu menekankan kapasitas.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kepatuhan'?
A: Kesediaan mengikuti aturan atau perintah dengan sukarela.
Q: Jelaskan makna 'kepatuhan'.
A: Kesediaan mengikuti aturan atau perintah dengan sukarela.
Q: Apa perbedaan antara 'boleh' dan 'dapat'?
A: Boleh berarti diizinkan. Dapat berarti mungkin atau mampu.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'rendah hati'?
A: Ungkapan 'rendah hati' berarti Tidak sombong.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'keterbukaan'?
A: Sikap jujur dan mau menerima masukan atau kritik.
Q: Jelaskan makna 'keterbukaan'.
A: Sikap jujur dan mau menerima masukan atau kritik.
Q: Apa perbedaan antara 'harus' dan 'wajib'?
A: Harus menekankan keharusan. Wajib lebih formal dan mengikat.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'besar mulut'?
A: Ungkapan 'besar mulut' berarti Suka membual.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'kesetiaan'?
A: Sikap tetap setia dan tidak berkhianat terhadap seseorang atau prinsip.
Q: Jelaskan makna 'kesetiaan'.
A: Sikap tetap setia dan tidak berkhianat terhadap seseorang atau prinsip.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'kecil hati'?
A: Ungkapan 'kecil hati' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'keteguhan'?
A: Sikap tetap pada pendirian meski ada tekanan atau godaan.
Q: Jelaskan makna 'keteguhan'.
A: Sikap tetap pada pendirian meski ada tekanan atau godaan.
Q: Apa perbedaan antara 'sering' dan 'kerap'?
A: Sering dan kerap sama-sama banyak kali, kerap lebih formal.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'panas hati'?
A: Ungkapan 'panas hati' berarti Marah atau kesal.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'keikhlasan'?
A: Melakukan sesuatu dengan hati bersih tanpa mengharapkan imbalan.
Q: Jelaskan makna 'keikhlasan'.
A: Melakukan sesuatu dengan hati bersih tanpa mengharapkan imbalan.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'ramai'?
A: Antonim dari 'ramai' adalah 'sepi'.
