Q: Apa arti kata 'cita-cita'?
A: Tujuan hidup yang ingin dicapai.
Q: Jelaskan makna 'cita-cita'.
A: Tujuan hidup yang ingin dicapai.
Q: Apa perbedaan antara 'harus' dan 'wajib'?
A: Harus menekankan keharusan. Wajib lebih formal dan mengikat.
Q: Apa sinonim dari kata 'sehat'?
A: Sinonim dari 'sehat' antara lain: bugar, waras.
Q: Apa antonim dari kata 'naik'?
A: Antonim dari 'naik' adalah 'turun'.
Q: Bagaimana cara menggunakan kata 'ke'?
A: Ke menunjukkan arah. Contoh: Pergi ke pasar.
Q: Apa arti ungkapan 'tangan terbuka'?
A: Ungkapan 'tangan terbuka' berarti Dermawan.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'semangat'?
A: Dorongan kuat untuk melakukan atau mencapai sesuatu.
Q: Jelaskan makna 'semangat'.
A: Dorongan kuat untuk melakukan atau mencapai sesuatu.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'sakit'?
A: Sinonim dari 'sakit' antara lain: nyeri, pedih.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'di'?
A: Di menunjukkan tempat. Contoh: Buku ada di meja.
Q: Apa arti ungkapan 'tangan besi'?
A: Ungkapan 'tangan besi' berarti Tegas dan keras dalam memimpin.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'energi'?
A: Kekuatan untuk melakukan aktivitas.
Q: Jelaskan makna 'energi'.
A: Kekuatan untuk melakukan aktivitas.
Q: Apa perbedaan antara 'sering' dan 'kerap'?
A: Sering dan kerap sama-sama banyak kali, kerap lebih formal.
Q: Apa sinonim dari kata 'cantik'?
A: Sinonim dari 'cantik' antara lain: indah, elok, molek.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'hingga'?
A: Hingga menunjukkan batas. Contoh: Menunggu hingga sore.
Q: Apa arti ungkapan 'anak emas'?
A: Ungkapan 'anak emas' berarti Anak kesayangan.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'stamina'?
A: Daya tahan tubuh atau mental dalam jangka panjang.
Q: Jelaskan makna 'stamina'.
A: Daya tahan tubuh atau mental dalam jangka panjang.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'tampan'?
A: Sinonim dari 'tampan' antara lain: ganteng, rupawan.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'sampai'?
A: Sampai juga batas. Contoh: Sampai jumpa besok.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'ketahanan'?
A: Kemampuan bertahan menghadapi tekanan.
Q: Jelaskan makna 'ketahanan'.
A: Kemampuan bertahan menghadapi tekanan.
Q: Apa perbedaan antara 'banyak' dan 'berlimpah'?
A: Banyak jumlah besar. Berlimpah sangat banyak hingga berlebih.
Q: Apa sinonim dari kata 'pintar'?
A: Sinonim dari 'pintar' antara lain: cerdas, pandai.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'sejak'?
A: Sejak menunjukkan awal waktu. Contoh: Sejak pagi sudah bekerja.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'fleksibilitas'?
A: Kemampuan menyesuaikan diri dengan perubahan.
Q: Jelaskan makna 'fleksibilitas'.
A: Kemampuan menyesuaikan diri dengan perubahan.
Q: Apa perbedaan antara 'sedikit' dan 'minim'?
A: Sedikit jumlah kecil. Minim sangat sedikit dari yang diharapkan.
Q: Apa sinonim dari kata 'kaya'?
A: Sinonim dari 'kaya' antara lain: makmur, berlimpah.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
