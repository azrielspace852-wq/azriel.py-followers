Q: Apa arti kata 'strategi'?
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Jelaskan makna 'strategi'.
A: Rencana jangka panjang untuk mencapai tujuan.
Q: Apa perbedaan antara 'jarang' dan 'langka'?
A: Jarang berarti tidak sering. Langka berarti sulit ditemukan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'lalu'?
A: Lalu menunjukkan urutan. Contoh: Dia makan, lalu tidur.
Q: Apa arti ungkapan 'mata duitan'?
A: Ungkapan 'mata duitan' berarti Hanya memikirkan uang.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'taktik'?
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Jelaskan makna 'taktik'.
A: Cara atau langkah spesifik dalam melaksanakan strategi.
Q: Apa perbedaan antara 'banyak' dan 'berlimpah'?
A: Banyak jumlah besar. Berlimpah sangat banyak hingga berlebih.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'kemudian'?
A: Kemudian juga urutan. Contoh: Dia tiba, kemudian istirahat.
Q: Apa arti ungkapan 'kepala batu'?
A: Ungkapan 'kepala batu' berarti Sulit dinasihati.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'prioritas'?
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Jelaskan makna 'prioritas'.
A: Hal yang didahulukan karena dianggap lebih penting.
Q: Apa perbedaan antara 'sedikit' dan 'minim'?
A: Sedikit jumlah kecil. Minim sangat sedikit dari yang diharapkan.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'sebelum'?
A: Sebelum menunjukkan waktu sebelumnya. Contoh: Cuci tangan sebelum makan.
Q: Apa arti ungkapan 'mulut manis'?
A: Ungkapan 'mulut manis' berarti Pandai merayu.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'fokus'?
A: Pemusatan perhatian pada satu hal.
Q: Jelaskan makna 'fokus'.
A: Pemusatan perhatian pada satu hal.
Q: Apa perbedaan antara 'penuh' dan 'padat'?
A: Penuh tidak ada ruang kosong. Padat tersusun rapat.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'tangan terbuka'?
A: Ungkapan 'tangan terbuka' berarti Dermawan.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'disiplin'?
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Jelaskan makna 'disiplin'.
A: Kepatuhan pada aturan dan kemampuan mengendalikan diri.
Q: Apa perbedaan antara 'kosong' dan 'hampa'?
A: Kosong tidak berisi. Hampa menekankan perasaan kosong.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'tangan besi'?
A: Ungkapan 'tangan besi' berarti Tegas dan keras dalam memimpin.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'komitmen'?
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Jelaskan makna 'komitmen'.
A: Janji atau kesungguhan untuk melakukan sesuatu.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
