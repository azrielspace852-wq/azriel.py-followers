Q: Apa arti kata 'keteladanan'?
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Jelaskan makna 'keteladanan'.
A: Memberikan contoh yang baik untuk diikuti orang lain.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'aman'?
A: Antonim dari 'aman' adalah 'bahaya'.
Q: Bagaimana cara menggunakan kata 'sesudah'?
A: Sesudah menunjukkan waktu setelah. Contoh: Sesudah makan dia mencuci piring.
Q: Apa arti ungkapan 'besar kepala'?
A: Ungkapan 'besar kepala' berarti Sombong atau angkuh.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kebersamaan'?
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Jelaskan makna 'kebersamaan'.
A: Perasaan dan tindakan bersama dalam satu kelompok.
Q: Apa perbedaan antara 'bisa' dan 'mampu'?
A: Bisa memiliki kemampuan. Mampu menekankan kapasitas.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'damai'?
A: Antonim dari 'damai' adalah 'perang'.
Q: Bagaimana cara menggunakan kata 'ketika'?
A: Ketika menunjukkan waktu kejadian. Contoh: Ketika hujan kami berteduh.
Q: Apa arti ungkapan 'ringan tangan'?
A: Ungkapan 'ringan tangan' berarti Suka membantu orang lain.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'kesetiakawanan'?
A: Rasa setia kawan dan saling mendukung.
Q: Jelaskan makna 'kesetiakawanan'.
A: Rasa setia kawan dan saling mendukung.
Q: Apa perbedaan antara 'boleh' dan 'dapat'?
A: Boleh berarti diizinkan. Dapat berarti mungkin atau mampu.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'tinggi'?
A: Antonim dari 'tinggi' adalah 'rendah'.
Q: Bagaimana cara menggunakan kata 'saat'?
A: Saat juga untuk waktu. Contoh: Saat dia datang saya sudah siap.
Q: Apa arti ungkapan 'panjang tangan'?
A: Ungkapan 'panjang tangan' berarti Suka mencuri.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'kepedulian'?
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Jelaskan makna 'kepedulian'.
A: Sikap peduli dan perhatian terhadap orang lain atau lingkungan.
Q: Apa perbedaan antara 'harus' dan 'wajib'?
A: Harus menekankan keharusan. Wajib lebih formal dan mengikat.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'besar'?
A: Antonim dari 'besar' adalah 'kecil'.
Q: Bagaimana cara menggunakan kata 'sambil'?
A: Sambil menunjukkan dua kegiatan bersamaan. Contoh: Belajar sambil mendengarkan musik.
Q: Apa arti ungkapan 'keras kepala'?
A: Ungkapan 'keras kepala' berarti Tidak mau dinasihati.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'kesadaran'?
A: Mengetahui dan memahami keadaan diri atau sekitar.
Q: Jelaskan makna 'kesadaran'.
A: Mengetahui dan memahami keadaan diri atau sekitar.
Q: Apa perbedaan antara 'perlu' dan 'penting'?
A: Perlu berarti dibutuhkan. Penting memiliki urgensi tinggi.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'lapang dada'?
A: Ungkapan 'lapang dada' berarti Sabar dan tidak mudah marah.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'pengertian'?
A: Kemampuan memahami perasaan atau situasi orang lain.
Q: Jelaskan makna 'pengertian'.
A: Kemampuan memahami perasaan atau situasi orang lain.
Q: Apa perbedaan antara 'sering' dan 'kerap'?
A: Sering dan kerap sama-sama banyak kali, kerap lebih formal.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
