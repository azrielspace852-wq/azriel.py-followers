Q: Apa arti kata 'implikatur'?
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Jelaskan makna 'implikatur'.
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Apa perbedaan antara 'dekat' dan 'akrab'?
A: Dekat bisa jarak fisik. Akrab berarti hubungan intim.
Q: Apa sinonim dari kata 'mudah'?
A: Sinonim dari 'mudah' antara lain: gampang, ringan.
Q: Apa antonim dari kata 'ramai'?
A: Antonim dari 'ramai' adalah 'sepi'.
Q: Bagaimana cara menggunakan kata 'ke'?
A: Ke menunjukkan arah. Contoh: Pergi ke pasar.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'presuposisi'?
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Jelaskan makna 'presuposisi'.
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'sulit'?
A: Sinonim dari 'sulit' antara lain: susah, rumit.
Q: Apa antonim dari kata 'penuh'?
A: Antonim dari 'penuh' adalah 'kosong'.
Q: Bagaimana cara menggunakan kata 'di'?
A: Di menunjukkan tempat. Contoh: Buku ada di meja.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'deiksis'?
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Jelaskan makna 'deiksis'.
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'penting'?
A: Sinonim dari 'penting' antara lain: krusial, urgen.
Q: Apa antonim dari kata 'kaya'?
A: Antonim dari 'kaya' adalah 'miskin'.
Q: Bagaimana cara menggunakan kata 'hingga'?
A: Hingga menunjukkan batas. Contoh: Menunggu hingga sore.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'assertif'?
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Jelaskan makna 'assertif'.
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'perlu'?
A: Sinonim dari 'perlu' antara lain: dibutuhkan.
Q: Apa antonim dari kata 'kuat'?
A: Antonim dari 'kuat' adalah 'lemah'.
Q: Bagaimana cara menggunakan kata 'sampai'?
A: Sampai juga batas. Contoh: Sampai jumpa besok.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Apa perbedaan antara 'sulit' dan 'rumit'?
A: Sulit berarti susah dikerjakan. Rumit memiliki banyak bagian terkait.
Q: Apa sinonim dari kata 'boleh'?
A: Sinonim dari 'boleh' antara lain: diizinkan.
Q: Apa antonim dari kata 'sehat'?
A: Antonim dari 'sehat' adalah 'sakit'.
Q: Bagaimana cara menggunakan kata 'sejak'?
A: Sejak menunjukkan awal waktu. Contoh: Sejak pagi sudah bekerja.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'ketelitian'?
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Jelaskan makna 'ketelitian'.
A: Kemampuan mengerjakan sesuatu dengan cermat dan hati-hati agar hasil akurat.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'harus'?
A: Sinonim dari 'harus' antara lain: wajib, mesti.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
