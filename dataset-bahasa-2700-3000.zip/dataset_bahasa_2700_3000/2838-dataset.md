Q: Apa arti kata 'register'?
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Jelaskan makna 'register'.
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Apa perbedaan antara 'cepat' dan 'segera'?
A: Cepat berarti dalam waktu singkat. Segera berarti tanpa ditunda.
Q: Apa sinonim dari kata 'dekat'?
A: Sinonim dari 'dekat' antara lain: akrab, mesra.
Q: Apa antonim dari kata 'tinggi'?
A: Antonim dari 'tinggi' adalah 'rendah'.
Q: Bagaimana cara menggunakan kata 'dari'?
A: Dari menunjukkan asal. Contoh: Berasal dari Jakarta.
Q: Apa arti ungkapan 'anak emas'?
A: Ungkapan 'anak emas' berarti Anak kesayangan.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'implikatur'?
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Jelaskan makna 'implikatur'.
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'baru'?
A: Sinonim dari 'baru' antara lain: segar, mutakhir.
Q: Apa antonim dari kata 'besar'?
A: Antonim dari 'besar' adalah 'kecil'.
Q: Bagaimana cara menggunakan kata 'ke'?
A: Ke menunjukkan arah. Contoh: Pergi ke pasar.
Q: Apa arti ungkapan 'buah hati'?
A: Ungkapan 'buah hati' berarti Kekasih atau anak yang sangat disayangi.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'presuposisi'?
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Jelaskan makna 'presuposisi'.
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Apa perbedaan antara 'tinggi' dan 'luhur'?
A: Tinggi bisa fisik atau posisi. Luhur lebih ke nilai moral yang mulia.
Q: Apa sinonim dari kata 'lama'?
A: Sinonim dari 'lama' antara lain: usang, kuno.
Q: Apa antonim dari kata 'panjang'?
A: Antonim dari 'panjang' adalah 'pendek'.
Q: Bagaimana cara menggunakan kata 'di'?
A: Di menunjukkan tempat. Contoh: Buku ada di meja.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'deiksis'?
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Jelaskan makna 'deiksis'.
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Apa perbedaan antara 'rendah' dan 'rendah hati'?
A: Rendah bisa posisi atau ukuran. Rendah hati berarti tidak sombong.
Q: Apa sinonim dari kata 'baik'?
A: Sinonim dari 'baik' antara lain: bagus, unggul.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'hingga'?
A: Hingga menunjukkan batas. Contoh: Menunggu hingga sore.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'assertif'?
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Jelaskan makna 'assertif'.
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'buruk'?
A: Sinonim dari 'buruk' antara lain: jelek, rusak.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'sampai'?
A: Sampai juga batas. Contoh: Sampai jumpa besok.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Apa perbedaan antara 'lembut' dan 'halus'?
A: Lembut menekankan kelembutan sikap. Halus menekankan kehalusan cara.
Q: Apa sinonim dari kata 'benar'?
A: Sinonim dari 'benar' antara lain: tepat, akurat.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
