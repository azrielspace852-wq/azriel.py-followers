Q: Apa arti kata 'integritas'?
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Jelaskan makna 'integritas'.
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Apa perbedaan antara 'baru' dan 'mutakhir'?
A: Baru berarti belum lama ada. Mutakhir berarti paling terkini.
Q: Apa sinonim dari kata 'besar'?
A: Sinonim dari 'besar' antara lain: agung, raksasa.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'profesionalisme'?
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Jelaskan makna 'profesionalisme'.
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Apa perbedaan antara 'lama' dan 'kuno'?
A: Lama berarti sudah berlalu waktu. Kuno berarti dari zaman dulu.
Q: Apa sinonim dari kata 'kecil'?
A: Sinonim dari 'kecil' antara lain: mungil, mini.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'etika'?
A: Nilai-nilai moral yang mengatur perilaku.
Q: Jelaskan makna 'etika'.
A: Nilai-nilai moral yang mengatur perilaku.
Q: Apa perbedaan antara 'mudah' dan 'sederhana'?
A: Mudah berarti tidak sulit. Sederhana berarti tidak rumit.
Q: Apa sinonim dari kata 'cepat'?
A: Sinonim dari 'cepat' antara lain: kilat, gesit.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'sulit' dan 'rumit'?
A: Sulit berarti susah dikerjakan. Rumit memiliki banyak bagian terkait.
Q: Apa sinonim dari kata 'lambat'?
A: Sinonim dari 'lambat' antara lain: lamban, pelan.
Q: Apa antonim dari kata 'bersih'?
A: Antonim dari 'bersih' adalah 'kotor'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'nilai'?
A: Hal yang dianggap penting dan berharga.
Q: Jelaskan makna 'nilai'.
A: Hal yang dianggap penting dan berharga.
Q: Apa perbedaan antara 'benar' dan 'tepat'?
A: Benar sesuai kebenaran. Tepat sesuai yang diharapkan.
Q: Apa sinonim dari kata 'tinggi'?
A: Sinonim dari 'tinggi' antara lain: menjulang.
Q: Apa antonim dari kata 'terang'?
A: Antonim dari 'terang' adalah 'gelap'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'prinsip'?
A: Dasar atau pegangan yang dipegang teguh.
Q: Jelaskan makna 'prinsip'.
A: Dasar atau pegangan yang dipegang teguh.
Q: Apa perbedaan antara 'salah' dan 'keliru'?
A: Salah berarti tidak benar. Keliru lebih lembut untuk kesalahan tidak sengaja.
Q: Apa sinonim dari kata 'rendah'?
A: Sinonim dari 'rendah' antara lain: pendek.
Q: Apa antonim dari kata 'ramai'?
A: Antonim dari 'ramai' adalah 'sepi'.
