Q: Apa arti kata 'integritas'?
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Jelaskan makna 'integritas'.
A: Keselarasan antara kata, sikap, dan tindakan.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'sehat'?
A: Sinonim dari 'sehat' antara lain: bugar, waras.
Q: Apa antonim dari kata 'penuh'?
A: Antonim dari 'penuh' adalah 'kosong'.
Q: Bagaimana cara menggunakan kata 'dengan'?
A: Dengan menunjukkan cara atau alat. Contoh: Menulis dengan pensil.
Q: Apa arti ungkapan 'air muka'?
A: Ungkapan 'air muka' berarti Raut wajah yang menunjukkan perasaan.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'profesionalisme'?
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Jelaskan makna 'profesionalisme'.
A: Sikap dan kemampuan kerja yang sesuai standar profesional.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'sakit'?
A: Sinonim dari 'sakit' antara lain: nyeri, pedih.
Q: Apa antonim dari kata 'kaya'?
A: Antonim dari 'kaya' adalah 'miskin'.
Q: Bagaimana cara menggunakan kata 'tanpa'?
A: Tanpa berarti tidak memakai. Contoh: Pergi tanpa payung.
Q: Apa arti ungkapan 'muka dua'?
A: Ungkapan 'muka dua' berarti Munafik.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'etika'?
A: Nilai-nilai moral yang mengatur perilaku.
Q: Jelaskan makna 'etika'.
A: Nilai-nilai moral yang mengatur perilaku.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'cantik'?
A: Sinonim dari 'cantik' antara lain: indah, elok, molek.
Q: Apa antonim dari kata 'kuat'?
A: Antonim dari 'kuat' adalah 'lemah'.
Q: Bagaimana cara menggunakan kata 'bagi'?
A: Bagi menunjukkan penerima. Contoh: Buku ini bagi anak-anak.
Q: Apa arti ungkapan 'muka tembok'?
A: Ungkapan 'muka tembok' berarti Tidak tahu malu.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'moral'?
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Jelaskan makna 'moral'.
A: Ajaran tentang baik dan buruk yang diterima masyarakat.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'tampan'?
A: Sinonim dari 'tampan' antara lain: ganteng, rupawan.
Q: Apa antonim dari kata 'sehat'?
A: Antonim dari 'sehat' adalah 'sakit'.
Q: Bagaimana cara menggunakan kata 'untuk'?
A: Untuk menunjukkan tujuan. Contoh: Uang ini untuk membeli buku.
Q: Apa arti ungkapan 'telinga tipis'?
A: Ungkapan 'telinga tipis' berarti Mudah tersinggung.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'nilai'?
A: Hal yang dianggap penting dan berharga.
Q: Jelaskan makna 'nilai'.
A: Hal yang dianggap penting dan berharga.
Q: Apa perbedaan antara 'cepat' dan 'segera'?
A: Cepat berarti dalam waktu singkat. Segera berarti tanpa ditunda.
Q: Apa sinonim dari kata 'pintar'?
A: Sinonim dari 'pintar' antara lain: cerdas, pandai.
Q: Apa antonim dari kata 'senang'?
A: Antonim dari 'senang' adalah 'sedih'.
Q: Bagaimana cara menggunakan kata 'tentang'?
A: Tentang menunjukkan topik. Contoh: Bercerita tentang liburan.
Q: Apa arti ungkapan 'buah bibir'?
A: Ungkapan 'buah bibir' berarti Menjadi bahan pembicaraan banyak orang.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'prinsip'?
A: Dasar atau pegangan yang dipegang teguh.
Q: Jelaskan makna 'prinsip'.
A: Dasar atau pegangan yang dipegang teguh.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'kaya'?
A: Sinonim dari 'kaya' antara lain: makmur, berlimpah.
Q: Apa antonim dari kata 'berani'?
A: Antonim dari 'berani' adalah 'penakut'.
