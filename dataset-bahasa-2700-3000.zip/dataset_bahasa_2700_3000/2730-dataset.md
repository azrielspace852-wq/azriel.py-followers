Q: Apa arti kata 'register'?
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Jelaskan makna 'register'.
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Apa perbedaan antara 'sabar' dan 'tabah'?
A: Sabar berarti menahan diri dari marah. Tabah berarti tetap kuat menghadapi cobaan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'lebar'?
A: Antonim dari 'lebar' adalah 'sempit'.
Q: Bagaimana cara menggunakan kata 'dari'?
A: Dari menunjukkan asal. Contoh: Berasal dari Jakarta.
Q: Apa arti ungkapan 'berat hati'?
A: Ungkapan 'berat hati' berarti Enggan atau tidak rela.
Q: Mana yang lebih formal: 'Bagaimana kabar Anda?' atau 'Bagaimana kabarmu?'?
A: Bagaimana kabar Anda? lebih formal. Yang pertama formal, yang kedua informal.
Q: Apa arti kata 'implikatur'?
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Jelaskan makna 'implikatur'.
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Apa perbedaan antara 'rajin' dan 'tekun'?
A: Rajin berarti sering mengerjakan. Tekun berarti mengerjakan dengan sungguh-sungguh terus-menerus.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'dalam'?
A: Antonim dari 'dalam' adalah 'dangkal'.
Q: Bagaimana cara menggunakan kata 'ke'?
A: Ke menunjukkan arah. Contoh: Pergi ke pasar.
Q: Apa arti ungkapan 'ringan kaki'?
A: Ungkapan 'ringan kaki' berarti Suka pergi atau tidak betah di rumah.
Q: Mana yang lebih formal: 'Terima kasih atas bantuannya.' atau 'Makasih ya bantuannya.'?
A: Terima kasih atas bantuannya. lebih formal. Yang pertama formal.
Q: Apa arti kata 'presuposisi'?
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Jelaskan makna 'presuposisi'.
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Apa perbedaan antara 'pintar' dan 'cerdas'?
A: Pintar merujuk pada pengetahuan. Cerdas menekankan kemampuan berpikir cepat dan logis.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'jauh'?
A: Antonim dari 'jauh' adalah 'dekat'.
Q: Bagaimana cara menggunakan kata 'di'?
A: Di menunjukkan tempat. Contoh: Buku ada di meja.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Saya mohon maaf.' atau 'Aku minta maaf.'?
A: Saya mohon maaf. lebih formal. Saya dan mohon lebih formal.
Q: Apa arti kata 'deiksis'?
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Jelaskan makna 'deiksis'.
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Apa perbedaan antara 'baik' dan 'baik hati'?
A: Baik bisa bermutu atau tidak jahat. Baik hati khusus berarti dermawan dan perhatian.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'cepat'?
A: Antonim dari 'cepat' adalah 'lambat'.
Q: Bagaimana cara menggunakan kata 'hingga'?
A: Hingga menunjukkan batas. Contoh: Menunggu hingga sore.
Q: Apa arti ungkapan 'rendah hati'?
A: Ungkapan 'rendah hati' berarti Tidak sombong.
Q: Mana yang lebih formal: 'Apakah Anda bersedia?' atau 'Mau nggak?'?
A: Apakah Anda bersedia? lebih formal. Yang pertama formal.
Q: Apa arti kata 'assertif'?
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Jelaskan makna 'assertif'.
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Apa perbedaan antara 'cantik' dan 'indah'?
A: Cantik biasanya untuk penampilan orang. Indah lebih luas untuk pemandangan atau seni.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'awal'?
A: Antonim dari 'awal' adalah 'akhir'.
Q: Bagaimana cara menggunakan kata 'sampai'?
A: Sampai juga batas. Contoh: Sampai jumpa besok.
Q: Apa arti ungkapan 'besar mulut'?
A: Ungkapan 'besar mulut' berarti Suka membual.
Q: Mana yang lebih formal: 'Silakan masuk.' atau 'Masuk aja.'?
A: Silakan masuk. lebih formal. Silakan lebih sopan.
Q: Apa arti kata 'empati'?
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Jelaskan makna 'empati'.
A: Kemampuan merasakan apa yang dirasakan orang lain dalam komunikasi.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'mulai'?
A: Antonim dari 'mulai' adalah 'selesai'.
