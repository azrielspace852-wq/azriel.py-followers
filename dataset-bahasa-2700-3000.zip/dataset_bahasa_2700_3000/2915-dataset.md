Q: Apa arti kata 'akronim'?
A: Singkatan yang dilafalkan sebagai kata.
Q: Jelaskan makna 'akronim'.
A: Singkatan yang dilafalkan sebagai kata.
Q: Apa perbedaan antara 'besar' dan 'luas'?
A: Besar menekankan ukuran volume. Luas menekankan dimensi permukaan atau cakupan.
Q: Apa sinonim dari kata 'bahagia'?
A: Sinonim dari 'bahagia' antara lain: senang, gembira, sukacita.
Q: Apa antonim dari kata 'maju'?
A: Antonim dari 'maju' adalah 'mundur'.
Q: Bagaimana cara menggunakan kata 'oleh'?
A: Oleh menunjukkan pelaku. Contoh: Buku ditulis oleh penulis terkenal.
Q: Apa arti ungkapan 'lapang dada'?
A: Ungkapan 'lapang dada' berarti Sabar dan tidak mudah marah.
Q: Mana yang lebih formal: 'Saya ingin bertanya.' atau 'Aku mau nanya.'?
A: Saya ingin bertanya. lebih formal. Ingin dan bertanya lebih formal.
Q: Apa arti kata 'register'?
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Jelaskan makna 'register'.
A: Ragam bahasa yang disesuaikan dengan situasi dan tujuan komunikasi.
Q: Apa perbedaan antara 'cepat' dan 'segera'?
A: Cepat berarti dalam waktu singkat. Segera berarti tanpa ditunda.
Q: Apa sinonim dari kata 'sedih'?
A: Sinonim dari 'sedih' antara lain: pilu, duka, muram.
Q: Apa antonim dari kata 'buka'?
A: Antonim dari 'buka' adalah 'tutup'.
Q: Bagaimana cara menggunakan kata 'dari'?
A: Dari menunjukkan asal. Contoh: Berasal dari Jakarta.
Q: Apa arti ungkapan 'berat hati'?
A: Ungkapan 'berat hati' berarti Enggan atau tidak rela.
Q: Mana yang lebih formal: 'Mohon ditunggu sebentar.' atau 'Tunggu bentar ya.'?
A: Mohon ditunggu sebentar. lebih formal. Mohon lebih formal.
Q: Apa arti kata 'implikatur'?
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Jelaskan makna 'implikatur'.
A: Makna tambahan yang tersirat dari ujaran di luar makna harfiah.
Q: Apa perbedaan antara 'lambat' dan 'lamban'?
A: Lambat memakan waktu lama. Lamban menekankan gerakan kurang gesit.
Q: Apa sinonim dari kata 'marah'?
A: Sinonim dari 'marah' antara lain: geram, jengkel, kesal.
Q: Apa antonim dari kata 'hidup'?
A: Antonim dari 'hidup' adalah 'mati'.
Q: Bagaimana cara menggunakan kata 'ke'?
A: Ke menunjukkan arah. Contoh: Pergi ke pasar.
Q: Apa arti ungkapan 'ringan kaki'?
A: Ungkapan 'ringan kaki' berarti Suka pergi atau tidak betah di rumah.
Q: Mana yang lebih formal: 'Saya setuju dengan pendapat Anda.' atau 'Aku setuju sama pendapatmu.'?
A: Saya setuju dengan pendapat Anda. lebih formal. Dengan dan Anda lebih formal.
Q: Apa arti kata 'presuposisi'?
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Jelaskan makna 'presuposisi'.
A: Anggapan yang dianggap benar sebagai latar belakang ujaran.
Q: Apa perbedaan antara 'tinggi' dan 'luhur'?
A: Tinggi bisa fisik atau posisi. Luhur lebih ke nilai moral yang mulia.
Q: Apa sinonim dari kata 'takut'?
A: Sinonim dari 'takut' antara lain: cemas, khawatir, gentar.
Q: Apa antonim dari kata 'siang'?
A: Antonim dari 'siang' adalah 'malam'.
Q: Bagaimana cara menggunakan kata 'di'?
A: Di menunjukkan tempat. Contoh: Buku ada di meja.
Q: Apa arti ungkapan 'tinggi hati'?
A: Ungkapan 'tinggi hati' berarti Sombong.
Q: Mana yang lebih formal: 'Saya tidak mengerti.' atau 'Aku nggak ngerti.'?
A: Saya tidak mengerti. lebih formal. Tidak dan mengerti lebih formal.
Q: Apa arti kata 'deiksis'?
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Jelaskan makna 'deiksis'.
A: Kata yang maknanya bergantung pada konteks seperti saya, di sini, sekarang.
Q: Apa perbedaan antara 'rendah' dan 'rendah hati'?
A: Rendah bisa posisi atau ukuran. Rendah hati berarti tidak sombong.
Q: Apa sinonim dari kata 'heran'?
A: Sinonim dari 'heran' antara lain: kagum, takjub, tercengang.
Q: Apa antonim dari kata 'panas'?
A: Antonim dari 'panas' adalah 'dingin'.
Q: Bagaimana cara menggunakan kata 'hingga'?
A: Hingga menunjukkan batas. Contoh: Menunggu hingga sore.
Q: Apa arti ungkapan 'rendah hati'?
A: Ungkapan 'rendah hati' berarti Tidak sombong.
Q: Mana yang lebih formal: 'Saya senang bertemu Anda.' atau 'Seneng ketemu kamu.'?
A: Saya senang bertemu Anda. lebih formal. Yang pertama formal.
Q: Apa arti kata 'assertif'?
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Jelaskan makna 'assertif'.
A: Menyampaikan pendapat atau kebutuhan dengan tegas namun tetap menghormati orang lain.
Q: Apa perbedaan antara 'keras' dan 'tegas'?
A: Keras bisa kasar. Tegas berarti jelas dan tidak ragu dalam keputusan.
Q: Apa sinonim dari kata 'bingung'?
A: Sinonim dari 'bingung' antara lain: bimbang, ragu, galau.
Q: Apa antonim dari kata 'basah'?
A: Antonim dari 'basah' adalah 'kering'.
