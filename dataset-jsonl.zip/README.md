# Dataset JSONL — Conversational Reasoning AI

Dataset ini dihasilkan dari `combined-markdown.md` sesuai struktur dan prinsip
pada `AI-Dataset-Specification.md`.

## Isi

| File | Kategori | Jumlah baris |
|---|---|---|
| `clarification/clarification.jsonl` | clarification | 17.550 |
| `conversation/conversation.jsonl` | conversation (multi-turn) | 349 |
| `correction/correction.jsonl` | correction | 17.377 |
| `language/language.jsonl` | language (bahasa) | 15.750 |
| `reasoning/reasoning.jsonl` | reasoning | 13.286 |
| `self_verification/self_verification.jsonl` | self_verification | 1.794 |
| `uncertainty/uncertainty.jsonl` | uncertainty (jujur/faktual/batasan diri) | 2.580 |
| `dataset_combined.jsonl` | gabungan semua di atas | 68.686 |

Total baris asli sumber (`Q:` count di combined-markdown.md) = 69.749, dan hasil
parsing (68.337 pasangan QA + 1.412 giliran user pada percakapan multi-turn)
cocok persis — tidak ada data yang hilang atau terpotong saat parsing.

## Skema field (kategori QA: clarification, correction, language, reasoning, uncertainty)

```json
{
  "id": "reasoning_000001",
  "category": "reasoning",
  "input": "...",
  "context": null,
  "expected_action": "ANSWER | SEARCH | CLARIFY | CORRECT",
  "knowledge_status": "KNOWN | UNKNOWN | INSUFFICIENT | SEARCH_REQUIRED",
  "reasoning_summary": null,
  "response": "... (null jika expected_action = SEARCH, sesuai contoh di spesifikasi bagian 17)",
  "source_required": true/false,
  "source_file": "path file markdown sumber asli (untuk ketertelusuran)"
}
```

`expected_action` dan `knowledge_status` ditentukan otomatis berdasarkan pola
kalimat pada jawaban asli (mis. "tidak dapat dipastikan" → INSUFFICIENT,
"perlu mencari informasi terbaru" → SEARCH_REQUIRED, jawaban berupa
pertanyaan balik → CLARIFY, dsb.), **bukan hasil karangan** — hanya klasifikasi
dari teks yang sudah ada di sumber.

## Skema field kategori `conversation`

```json
{
  "id": "conversation_000001",
  "category": "conversation",
  "turns": [
    {"role": "user", "content": "..."},
    {"role": "assistant", "content": "..."}
  ],
  "source_file": "..."
}
```

## Skema field kategori `self_verification`

```json
{
  "id": "self_verification_000001",
  "category": "self_verification",
  "problem": "...",
  "initial_answer": "...",
  "verification": "...",
  "final_answer": "...",
  "error_type": "...",
  "source_file": "..."
}
```

## Catatan penting

- `difficulty` dan `reasoning_summary` **tidak diisi** (null) karena tidak ada
  dasarnya di sumber data — sesuai larangan spesifikasi bagian 21 poin 2 & 5
  ("jangan mengisi dengan tebakan", "jangan menggunakan fakta yang belum
  diverifikasi").
- Kategori `anti_hallucination`, `deep_reasoning`, `search`,
  `search_grounding`, `source_conflict`, dan `evaluation` yang disebut pada
  spesifikasi bagian 18 **tidak dibuat** karena tidak ada materi sumber untuk
  kategori tersebut di `combined-markdown.md` — dataset ini tidak
  mengarang contoh untuk mengisi kekosongan tersebut.
- `evaluation/` sengaja tidak dibuat dari data yang sama dengan training
  (sesuai bagian 19), karena butuh contoh yang berbeda dari training set —
  belum tersedia di sumber.
