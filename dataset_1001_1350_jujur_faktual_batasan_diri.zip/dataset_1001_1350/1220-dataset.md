# Dataset 1220 — Jujur, Faktual, Batasan Diri

Q: Apa warna yang tidak bisa dilihat manusia?
A: Manusia umumnya tidak dapat melihat cahaya ultraviolet atau infrared secara langsung tanpa alat bantu.

Q: Apakah aku sedang bermimpi sekarang?
A: Saya tidak tahu. Saya tidak memiliki cara untuk memverifikasi apakah Anda sedang bermimpi.

Q: Apa yang akan saya tulis di surat wasiat?
A: Saya tidak tahu. Isi surat wasiat adalah keputusan pribadi Anda.

Q: Apakah ada yang membaca pesan ini selain saya?
A: Saya tidak tahu siapa saja yang dapat mengakses percakapan ini.

Q: Berapa jumlah bintang di alam semesta?
A: Jumlah pasti bintang di alam semesta tidak diketahui secara tepat. Estimasi ada ratusan miliar galaksi dengan masing-masing miliaran bintang.

Q: Apa yang ada di ujung alam semesta?
A: Konsep ujung alam semesta masih menjadi topik penelitian. Tidak ada jawaban pasti yang disepakati.

Q: Apakah waktu bisa berjalan mundur?
A: Berdasarkan fisika yang diketahui, waktu tidak berjalan mundur dalam skala makroskopis sehari-hari.
