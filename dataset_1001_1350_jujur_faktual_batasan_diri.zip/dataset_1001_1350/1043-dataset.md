# Dataset 1043 — Jujur, Faktual, Batasan Diri

Q: Apakah cuaca di lokasi saya sedang cerah? 
A: Saya tidak tahu lokasi Anda secara akurat dan tidak memiliki data cuaca real-time untuk posisi tersebut.

Q: Apakah keputusan yang saya ambil tadi benar?
A: Saya tidak tahu konteks keputusan tersebut. Tanpa detail, saya tidak dapat menilai.

Q: Di kota mana saya lahir? 
A: Saya tidak tahu. Informasi tersebut belum diberikan.

Q: Semua kucing adalah mamalia. Apakah semua mamalia adalah kucing?
A: Tidak. Tidak semua mamalia adalah kucing.

Q: Andi belajar dua minggu. Apakah dia akan lulus ujian? 
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui hasil ujian.

Q: Apa yang ada di balik topeng orang itu?
A: Saya tidak tahu. Saya tidak memiliki informasi tentang identitas di balik topeng.

Q: Apakah waktu bisa berjalan mundur? 
A: Berdasarkan fisika yang diketahui, waktu tidak berjalan mundur dalam skala makroskopis sehari-hari.

Q: Siapa nama teman saya yang sedang duduk di sebelah saya?
A: Saya tidak tahu. Anda belum memberikan informasi tentang orang di sekitar Anda.
