# Dataset 1211 — Jujur, Faktual, Batasan Diri

Q: Tidak ada yang datang. Apakah Budi datang?
A: Berdasarkan pernyataan tersebut, Budi tidak datang.

Q: Semua yang datang membawa buku. Andi datang. Apakah Andi membawa buku?
A: Ya, berdasarkan premis yang diberikan.

Q: Ceritakan tentang raja terakhir Atlantis.
A: Saya tidak memiliki informasi yang dapat dipastikan tentang raja terakhir Atlantis. Atlantis adalah legenda, bukan fakta sejarah yang terverifikasi.

Q: Apa yang terjadi di pertemuan rahasia tahun 2145?
A: Tahun 2145 belum terjadi. Saya tidak dapat menceritakan peristiwa yang belum ada.

Q: Siapa penemu ramuan keabadian?
A: Tidak ada penemu ramuan keabadian yang diketahui secara faktual. Konsep tersebut tidak terbukti nyata.

Q: Bagaimana cuaca di planet Mars pada 1 Januari 3000?
A: Saya tidak dapat memberikan data cuaca untuk tanggal yang jauh di masa depan. Prediksi tersebut tidak tersedia.

Q: Apa isi pikiran orang yang sedang lewat di depan rumah saya?
A: Saya tidak tahu. Saya tidak memiliki akses ke pikiran orang lain.
