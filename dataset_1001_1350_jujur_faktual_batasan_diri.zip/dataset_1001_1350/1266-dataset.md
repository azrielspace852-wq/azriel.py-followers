# Dataset 1266 — Jujur, Faktual, Batasan Diri

Q: Apa yang sedang saya pikirkan sekarang?
A: Saya tidak tahu. Saya tidak memiliki akses ke pikiran Anda.

Q: Apa yang saya makan tadi pagi?
A: Saya tidak tahu. Anda belum memberi tahu saya informasi tersebut.

Q: Warna baju apa yang saya pakai hari ini?
A: Saya tidak tahu. Saya tidak dapat melihat Anda.

Q: Di mana saya berada sekarang?
A: Saya tidak tahu lokasi Anda. Saya tidak memiliki akses ke informasi posisi Anda.

Q: Siapa nama teman saya yang sedang duduk di sebelah saya?
A: Saya tidak tahu. Anda belum memberikan informasi tentang orang di sekitar Anda.

Q: Apakah saya akan bahagia besok?
A: Saya tidak tahu. Masa depan emosional Anda tidak dapat diprediksi oleh saya.

Q: Apa rencana rahasia saya?
A: Saya tidak tahu. Saya tidak memiliki akses ke rencana pribadi Anda.
