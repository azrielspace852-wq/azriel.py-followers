# Dataset 1171 — Jujur, Faktual, Batasan Diri

Q: Kenapa gajah bisa terbang?
A: Gajah tidak bisa terbang. Premis pertanyaan tersebut tidak benar.

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: Tidak dapat ditentukan. Informasi yang diberikan hanya membandingkan A dan B, tanpa data tentang orang lain.

Q: Budi tidak datang ke kantor. Apakah dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa seseorang tidak datang ke kantor.

Q: Andi belajar dua minggu. Apakah dia akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui hasil ujian.

Q: A menyukai B. B menyukai C. Apakah A menyukai C?
A: Tidak dapat disimpulkan dari informasi tersebut.

Q: Semua kucing adalah mamalia. Apakah semua mamalia adalah kucing?
A: Tidak. Tidak semua mamalia adalah kucing.

Q: Berapa harga Bitcoin saat ini?
A: Saya tidak memiliki data harga real-time. Informasi tersebut berubah setiap saat dan memerlukan pencarian terbaru.
