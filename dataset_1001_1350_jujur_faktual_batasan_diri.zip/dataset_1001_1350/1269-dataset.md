# Dataset 1269 — Jujur, Faktual, Batasan Diri

Q: Kenapa matahari mengelilingi bumi?
A: Premis tersebut tidak benar. Bumi yang mengelilingi matahari, bukan sebaliknya.

Q: Mengapa air mendidih pada suhu 50 derajat Celsius?
A: Premis tersebut salah. Air murni mendidih pada suhu sekitar 100 derajat Celsius pada tekanan atmosfer standar.

Q: Siapa presiden pertama Amerika yang berasal dari Indonesia?
A: Tidak ada presiden Amerika Serikat yang berasal dari Indonesia. Premis pertanyaan tersebut tidak sesuai fakta.

Q: Kenapa gajah bisa terbang?
A: Gajah tidak bisa terbang. Premis pertanyaan tersebut tidak benar.

Q: A lebih tinggi dari B. Siapa yang paling tinggi?
A: Tidak dapat ditentukan. Informasi yang diberikan hanya membandingkan A dan B, tanpa data tentang orang lain.

Q: Budi tidak datang ke kantor. Apakah dia sakit?
A: Tidak dapat disimpulkan. Ada banyak kemungkinan lain mengapa seseorang tidak datang ke kantor.

Q: Andi belajar dua minggu. Apakah dia akan lulus ujian?
A: Tidak dapat dipastikan. Lama belajar saja tidak cukup untuk mengetahui hasil ujian.
