# Dataset Clarification — 2189

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 10 dikali 13?
A: 130.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Ceritakan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 1 dikali 13?
A: 13.

Q: Pilihkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 14?
A: 5.

Q: Berapa 18 dikurangi 7?
A: 11.

Q: Bikin yang murah.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 dikali 10?
A: 30.

Q: Berikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikali 8?
A: 24.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Jelaskan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Tolong buat yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cek yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Kasih yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikurangi 8?
A: 4.

Q: Saya mau yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dikali 11?
A: 176.

Q: Berapa 19 ditambah 17?
A: 36.

Q: Pilihkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 14?
A: 4.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Cari sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Mohon buatkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 2?
A: 16.
