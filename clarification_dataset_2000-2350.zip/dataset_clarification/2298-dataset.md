# Dataset Clarification — 2298

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 ditambah 15?
A: 34.

Q: Berapa 5 ditambah 9?
A: 14.

Q: Sesuaikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikurangi 2?
A: 10.

Q: Berapa 1 dikali 19?
A: 19.

Q: Saya mau yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Rapikan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 13 ditambah 15?
A: 28.

Q: Berapa 13 dikurangi 11?
A: 2.

Q: Berikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Ubah yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Saya mau yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 16 dikali 10?
A: 160.

Q: Ubah yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Rapikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 11?
A: 0.

Q: Analisis yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 dikurangi 1?
A: 1.

Q: Berapa 10 dikali 2?
A: 20.

Q: Saya butuh yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Ubah hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 ditambah 10?
A: 15.

Q: Berapa 10 dikali 3?
A: 30.

Q: Cek yang keren.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 8 dikali 6?
A: 48.

Q: Ceritakan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Mohon buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?
