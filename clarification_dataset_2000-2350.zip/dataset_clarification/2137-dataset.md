# Dataset Clarification — 2137

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cek seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Berapa 3 dikali 13?
A: 39.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Buatkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Cari yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Tampilkan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Perbaiki yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Bikin sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dikali 12?
A: 96.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Saya mau yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 ditambah 20?
A: 29.

Q: Berikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 dikali 4?
A: 48.

Q: Berapa 8 dikali 10?
A: 80.

Q: Berapa 10 ditambah 11?
A: 21.

Q: Kasih yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 18 ditambah 7?
A: 25.

Q: Cari yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 ditambah 5?
A: 19.

Q: Berapa 11 ditambah 12?
A: 23.

Q: Analisis yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikurangi 10?
A: 8.

Q: Hitung yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikali 20?
A: 380.

Q: Berapa 15 ditambah 17?
A: 32.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 20 dikali 9?
A: 180.

Q: Berapa 5 dikali 8?
A: 40.

Q: Rapikan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 ditambah 1?
A: 10.

Q: Buatkan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang keren.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang itu.
A: Siap. Maksudnya yang seperti apa?
