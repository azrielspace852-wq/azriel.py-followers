# Dataset Clarification — 2273

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Mohon buatkan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Pilihkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Rapikan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Analisis yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Sesuaikan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Ceritakan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Tampilkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Rapikan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Rapikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Tolong buat yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Mohon buatkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Saya mau hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Cari seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Bikin yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Tampilkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?
