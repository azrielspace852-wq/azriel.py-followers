# Dataset Clarification — 2259

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 17 dikali 18?
A: 306.

Q: Berapa 16 dikali 10?
A: 160.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Hitung yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Sesuaikan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikali 19?
A: 380.

Q: Cari yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Pilihkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 1 ditambah 8?
A: 9.

Q: Analisis yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 ditambah 14?
A: 25.

Q: Berapa 5 dikali 9?
A: 45.

Q: Berapa 18 dikali 1?
A: 18.

Q: Berapa 17 dikali 10?
A: 170.

Q: Ubah yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 ditambah 8?
A: 11.

Q: Ceritakan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 9 dikurangi 8?
A: 1.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 16 ditambah 19?
A: 35.

Q: Rapikan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 1?
A: 13.

Q: Berapa 19 dikurangi 8?
A: 11.

Q: Berapa 5 ditambah 14?
A: 19.

Q: Bikin yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 18?
A: 162.

Q: Saya butuh yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikali 20?
A: 140.

Q: Ceritakan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 ditambah 10?
A: 29.

Q: Perbaiki yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Buatkan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang itu.
A: Bisa. Untuk tujuan apa?
