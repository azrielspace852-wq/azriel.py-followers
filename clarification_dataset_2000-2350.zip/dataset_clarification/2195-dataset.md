# Dataset Clarification — 2195

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 17 dikali 5?
A: 85.

Q: Buatkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 9 dikali 19?
A: 171.

Q: Saya butuh yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 19 dikali 5?
A: 95.

Q: Berapa 10 ditambah 1?
A: 11.

Q: Berapa 20 ditambah 8?
A: 28.

Q: Rapikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 15 dikali 14?
A: 210.

Q: Tolong buat yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikali 7?
A: 49.

Q: Berapa 2 ditambah 15?
A: 17.

Q: Tampilkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Ubah yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 ditambah 10?
A: 24.

Q: Berapa 4 dikali 18?
A: 72.

Q: Rapikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 ditambah 19?
A: 30.

Q: Berapa 17 dikali 2?
A: 34.

Q: Berapa 12 ditambah 5?
A: 17.

Q: Saya mau yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Saya butuh yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikali 3?
A: 45.

Q: Tolong buat yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikali 7?
A: 140.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Ubah yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikurangi 16?
A: 3.
