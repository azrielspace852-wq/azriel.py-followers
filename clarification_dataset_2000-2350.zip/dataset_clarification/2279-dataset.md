# Dataset Clarification — 2279

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikali 8?
A: 144.

Q: Berapa 20 ditambah 17?
A: 37.

Q: Analisis sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 5?
A: 15.

Q: Buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 16?
A: 31.

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 ditambah 3?
A: 13.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Jelaskan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Cari yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 ditambah 16?
A: 27.

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Berapa 17 dikurangi 17?
A: 0.

Q: Berikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 ditambah 15?
A: 29.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Bikin yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dikali 1?
A: 4.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Analisis yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Pilihkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Ceritakan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 ditambah 1?
A: 17.

Q: Perbaiki yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 1 dikali 16?
A: 16.

Q: Ubah yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Cek hal itu.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dikali 7?
A: 105.

Q: Berapa 20 ditambah 2?
A: 22.

Q: Berapa 20 dikali 16?
A: 320.

Q: Saya butuh yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikali 16?
A: 208.

Q: Cari yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Ubah yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dibagi 2?
A: 4.
