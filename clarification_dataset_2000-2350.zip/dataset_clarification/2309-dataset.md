# Dataset Clarification — 2309

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Mohon buatkan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 6?
A: 24.

Q: Saya butuh yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 1 dikali 17?
A: 17.

Q: Berapa 2 ditambah 19?
A: 21.

Q: Tampilkan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikali 8?
A: 56.

Q: Berapa 11 dikali 8?
A: 88.

Q: Berapa 3 dikali 16?
A: 48.

Q: Berapa 13 ditambah 8?
A: 21.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Hitung yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Mohon buatkan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 ditambah 4?
A: 24.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 4 dikali 19?
A: 76.

Q: Berapa 9 ditambah 8?
A: 17.

Q: Pilihkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dikali 15?
A: 120.

Q: Tolong buat yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikali 18?
A: 342.

Q: Mohon buatkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 ditambah 16?
A: 24.

Q: Cari yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 8?
A: 24.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Jelaskan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 8 dikali 17?
A: 136.

Q: Berapa 5 dikurangi 1?
A: 4.

Q: Saya butuh yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 ditambah 6?
A: 14.

Q: Berapa 5 dibagi 5?
A: 1.
