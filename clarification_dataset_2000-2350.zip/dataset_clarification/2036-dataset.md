# Dataset Clarification — 2036

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 8 dikali 6?
A: 48.

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Tampilkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 ditambah 13?
A: 24.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Cek yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Ubah hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Kasih yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Saya butuh yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 ditambah 16?
A: 19.

Q: Berapa 12 dikali 8?
A: 96.

Q: Berikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 ditambah 14?
A: 27.

Q: Analisis seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dikurangi 1?
A: 3.

Q: Ubah yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dikali 15?
A: 150.

Q: Analisis yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 ditambah 7?
A: 13.

Q: Tampilkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dikali 9?
A: 135.

Q: Analisis yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 6 dikali 7?
A: 42.

Q: Berapa 8 dikali 13?
A: 104.

Q: Tampilkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Cari seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 ditambah 13?
A: 22.

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Hitung yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 ditambah 5?
A: 15.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Ubah yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang pas.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 ditambah 17?
A: 26.

Q: Ceritakan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang cepat.
A: Siap. Yang mana yang dimaksud?
