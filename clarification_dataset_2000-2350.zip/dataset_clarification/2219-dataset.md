# Dataset Clarification — 2219

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Cari hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 3 dikali 15?
A: 45.

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Rapikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dikali 6?
A: 24.

Q: Ceritakan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Ubah yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Pilihkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Saya mau yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Berapa 5 dikali 16?
A: 80.

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 17?
A: 23.

Q: Berapa 14 ditambah 15?
A: 29.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 18 dikali 3?
A: 54.

Q: Saya mau yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang detail.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Ceritakan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Cek yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Buatkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berikan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Jelaskan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Analisis yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Rapikan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dikurangi 1?
A: 7.
