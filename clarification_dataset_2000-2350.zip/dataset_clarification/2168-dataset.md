# Dataset Clarification — 2168

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Kasih sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Tampilkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 ditambah 19?
A: 35.

Q: Jelaskan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Kasih sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 4?
A: 11.

Q: Bikin yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 15?
A: 3.

Q: Rapikan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 5 dikali 10?
A: 50.

Q: Mohon buatkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Berapa 6 dikali 6?
A: 36.

Q: Saya mau yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Cari yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 ditambah 4?
A: 11.

Q: Berapa 7 ditambah 17?
A: 24.

Q: Bikin yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 13 ditambah 6?
A: 19.

Q: Berapa 10 dikali 8?
A: 80.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 dikali 5?
A: 25.

Q: Tolong buat yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Pilihkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Pilihkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 14?
A: 210.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 7 ditambah 2?
A: 9.
