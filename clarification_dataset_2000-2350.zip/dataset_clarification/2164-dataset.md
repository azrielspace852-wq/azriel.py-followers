# Dataset Clarification — 2164

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Sesuaikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikali 18?
A: 324.

Q: Tolong buat yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Ubah yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Saya mau yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berikan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Ubah hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Pilihkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Cek yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Cek sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Mohon buatkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Cek yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Apa nama satuan energi?
A: Joule.

Q: Cek sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Bikin yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Berapa 12 dikali 15?
A: 180.

Q: Ubah yang terbaik.
A: Bisa. Untuk keperluan apa?
