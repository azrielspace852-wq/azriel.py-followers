# Dataset Clarification — 2094

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 ditambah 3?
A: 22.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 5 ditambah 20?
A: 25.

Q: Ubah yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Saya mau yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Mohon buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Berapa 5 ditambah 6?
A: 11.

Q: Pilihkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Sesuaikan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Ceritakan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Ubah yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Cari yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Sesuaikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Hitung yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Ubah yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Buatkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Analisis sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 5 ditambah 1?
A: 6.

Q: Analisis yang ini.
A: Baik. Bisa dijelaskan lebih detail?
