# Dataset Clarification — 2304

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Tolong buat sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama indera perasa?
A: Lidah.

Q: Berapa 7 ditambah 11?
A: 18.

Q: Saya butuh yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 2?
A: 32.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Cek sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Kasih yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Ceritakan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Analisis yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Tolong buat yang pas.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang sana.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Buatkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Rapikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 1 ditambah 6?
A: 7.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Saya butuh yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Cari yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Cek yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Saya mau yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?
