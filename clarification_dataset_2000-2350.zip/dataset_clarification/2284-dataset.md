# Dataset Clarification — 2284

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Analisis yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Saya mau yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Berapa 1 dikali 16?
A: 16.

Q: Hitung yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Ubah yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama satuan energi?
A: Joule.

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Pilihkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Bikin yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 ditambah 8?
A: 15.

Q: Hitung yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Analisis yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera perasa?
A: Lidah.

Q: Perbaiki yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Ubah yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Saya mau sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikali 3?
A: 54.
