# Dataset Clarification — 2088

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 ditambah 4?
A: 19.

Q: Berapa 11 dikali 3?
A: 33.

Q: Rapikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 dikali 13?
A: 39.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Berapa 9 dikurangi 4?
A: 5.

Q: Berapa 10 ditambah 10?
A: 20.

Q: Pilihkan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 6 dikali 20?
A: 120.

Q: Berikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Sesuaikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Bikin hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 15?
A: 5.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 2 dikali 17?
A: 34.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 4 dikali 15?
A: 60.

Q: Berapa 4 ditambah 12?
A: 16.

Q: Kasih yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Perbaiki yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 dikali 19?
A: 57.

Q: Buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 14?
A: 224.

Q: Mohon buatkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Bikin sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Hitung hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikurangi 8?
A: 1.

Q: Perbaiki yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 12 dikali 18?
A: 216.

Q: Berapa 17 dikurangi 1?
A: 16.

Q: Berapa 17 ditambah 16?
A: 33.
