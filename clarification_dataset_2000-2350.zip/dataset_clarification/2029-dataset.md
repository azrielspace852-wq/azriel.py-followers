# Dataset Clarification — 2029

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikali 12?
A: 180.

Q: Cari yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikali 9?
A: 180.

Q: Berapa 5 ditambah 15?
A: 20.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Cari yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 2 ditambah 4?
A: 6.

Q: Berapa 8 dikali 4?
A: 32.

Q: Berapa 18 dikali 8?
A: 144.

Q: Mohon buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 ditambah 14?
A: 18.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Ceritakan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 8?
A: 96.

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Ceritakan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 ditambah 4?
A: 23.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berapa 19 ditambah 10?
A: 29.

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Berapa 20 ditambah 3?
A: 23.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Jelaskan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Jelaskan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 ditambah 3?
A: 4.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Kasih yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikali 10?
A: 70.

Q: Berikan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang sana.
A: Siap. Tentang apa tepatnya?

Q: Rapikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 9?
A: 9.
