# Dataset Clarification — 2173

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Perbaiki yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Cari seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Cari yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Cari yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Buatkan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Cari yang itu.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Saya mau yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Jelaskan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Saya butuh yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Cari yang keren.
A: Bisa. Untuk tujuan apa?

Q: Rapikan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Tolong buat yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.
