# Dataset Clarification — 2183

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Jelaskan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Ceritakan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Cari yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Saya butuh yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya butuh yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Cek yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berikan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Analisis yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Rapikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Ceritakan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Cari yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Cek seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.
