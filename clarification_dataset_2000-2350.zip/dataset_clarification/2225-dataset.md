# Dataset Clarification — 2225

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Berikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dikali 14?
A: 56.

Q: Cek yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 ditambah 11?
A: 19.

Q: Berapa 19 dikurangi 3?
A: 16.

Q: Berapa 7 ditambah 13?
A: 20.

Q: Berapa 18 dikurangi 4?
A: 14.

Q: Tolong buat yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 1 ditambah 9?
A: 10.

Q: Cek yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 19?
A: 209.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Sesuaikan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Bikin yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 ditambah 4?
A: 11.

Q: Jelaskan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Perbaiki yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Berapa 20 ditambah 7?
A: 27.

Q: Ceritakan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikali 3?
A: 42.

Q: Tampilkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Saya mau yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 4 dikali 6?
A: 24.

Q: Berapa 20 dikurangi 17?
A: 3.

Q: Berapa 18 dikurangi 17?
A: 1.

Q: Tolong buat seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Kasih yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 ditambah 2?
A: 10.

Q: Berapa 6 ditambah 7?
A: 13.

Q: Pilihkan hal itu.
A: Bisa. Untuk tujuan apa?
