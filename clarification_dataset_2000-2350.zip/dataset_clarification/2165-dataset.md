# Dataset Clarification — 2165

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 ditambah 19?
A: 26.

Q: Tampilkan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 ditambah 2?
A: 4.

Q: Berapa 20 ditambah 18?
A: 38.

Q: Berapa 4 ditambah 12?
A: 16.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Cari yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Tolong buat yang pas.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 3?
A: 14.

Q: Cek yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 10 ditambah 13?
A: 23.

Q: Kasih yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikali 16?
A: 64.

Q: Berapa 5 dikali 9?
A: 45.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Saya mau yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 ditambah 4?
A: 14.

Q: Bikin yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 12 dikurangi 7?
A: 5.

Q: Jelaskan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 ditambah 20?
A: 25.

Q: Berapa 13 ditambah 5?
A: 18.

Q: Berapa 17 dikurangi 9?
A: 8.

Q: Cek yang detail.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 ditambah 3?
A: 5.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Tampilkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 6 dikali 16?
A: 96.

Q: Pilihkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 ditambah 8?
A: 24.

Q: Tolong buat yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?
