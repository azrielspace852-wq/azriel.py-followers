# Dataset Clarification — 2114

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Mohon buatkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Berapa 16 dikurangi 3?
A: 13.

Q: Analisis yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Ubah sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Berikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Ubah yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Cari yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Perbaiki yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Cari yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Buatkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Berikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan energi?
A: Joule.

Q: Ceritakan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Berapa 1 ditambah 9?
A: 10.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Perbaiki hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Ubah hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ubah sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.
