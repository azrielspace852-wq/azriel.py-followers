# Dataset Clarification — 2157

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 14 dikali 11?
A: 154.

Q: Perbaiki yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang sana.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Buatkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Ubah seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 4 dikali 17?
A: 68.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Ubah yang ini.
A: Bisa. Untuk tujuan apa?

Q: Saya mau seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 20 dikali 9?
A: 180.

Q: Hitung yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dikali 17?
A: 102.

Q: Saya butuh yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 18 dikurangi 4?
A: 14.

Q: Berapa 15 ditambah 13?
A: 28.

Q: Berikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikali 6?
A: 120.

Q: Berikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Jelaskan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 7 ditambah 15?
A: 22.

Q: Ubah yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Berapa 1 ditambah 16?
A: 17.

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 12 dikali 5?
A: 60.

Q: Pilihkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 9?
A: 20.

Q: Jelaskan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Cari yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang sesuai.
A: Siap. Maksudnya yang seperti apa?
