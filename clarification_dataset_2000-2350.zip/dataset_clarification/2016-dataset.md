# Dataset Clarification — 2016

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 1 ditambah 12?
A: 13.

Q: Berapa 20 dikali 7?
A: 140.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Pilihkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Bikin seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 16 dikali 2?
A: 32.

Q: Berapa 12 ditambah 7?
A: 19.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Perbaiki yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 4 dikali 20?
A: 80.

Q: Tolong buat yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikali 1?
A: 18.

Q: Sesuaikan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 17 ditambah 6?
A: 23.

Q: Pilihkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dikali 11?
A: 88.

Q: Berapa 14 dikurangi 12?
A: 2.

Q: Berapa 13 dikali 14?
A: 182.

Q: Berapa 3 ditambah 8?
A: 11.

Q: Jelaskan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 18?
A: 33.

Q: Rapikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 ditambah 10?
A: 26.

Q: Berapa 6 dikali 18?
A: 108.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Jelaskan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 ditambah 4?
A: 10.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Rapikan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Jelaskan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dikali 12?
A: 96.
