# Dataset Clarification — 2217

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 9 ditambah 19?
A: 28.

Q: Berapa 11 ditambah 6?
A: 17.

Q: Berapa 13 ditambah 10?
A: 23.

Q: Berapa 9 dikali 18?
A: 162.

Q: Berapa 17 ditambah 8?
A: 25.

Q: Mohon buatkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Hitung yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikurangi 4?
A: 16.

Q: Analisis yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Cek yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 ditambah 17?
A: 18.

Q: Berapa 6 ditambah 7?
A: 13.

Q: Perbaiki yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 ditambah 17?
A: 32.

Q: Berapa 6 dikali 20?
A: 120.

Q: Mohon buatkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikali 8?
A: 112.

Q: Saya butuh hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Analisis yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 2 ditambah 19?
A: 21.

Q: Mohon buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikali 16?
A: 288.

Q: Sesuaikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Analisis hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 ditambah 1?
A: 10.

Q: Saya mau yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 14?
A: 1.

Q: Mohon buatkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 14?
A: 25.

Q: Berapa 9 dikurangi 7?
A: 2.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Tampilkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikurangi 8?
A: 11.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 20 dibagi 10?
A: 2.
