# Dataset Clarification — 2184

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dikali 10?
A: 50.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Kasih yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Kasih yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Hitung hal itu.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang itu.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Rapikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 dikali 17?
A: 153.

Q: Buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berikan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Tampilkan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Analisis yang murah.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Bikin yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Rapikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Tampilkan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Analisis hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 dikali 5?
A: 45.
