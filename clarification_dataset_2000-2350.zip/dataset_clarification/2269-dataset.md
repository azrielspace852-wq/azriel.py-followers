# Dataset Clarification — 2269

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Cek yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 6?
A: 14.

Q: Tampilkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Cek yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 2?
A: 8.

Q: Saya mau yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 9?
A: 171.

Q: Tolong buat yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 15?
A: 28.

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 13 ditambah 9?
A: 22.

Q: Buatkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 20?
A: 240.

Q: Berapa 16 dikali 4?
A: 64.

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Perbaiki yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Hitung hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 ditambah 9?
A: 20.

Q: Jelaskan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Mohon buatkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang itu.
A: Siap. Tentang apa tepatnya?

Q: Cek yang ini.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Analisis seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Rapikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Tampilkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 6 dikali 5?
A: 30.

Q: Berapa 1 dikurangi 1?
A: 0.

Q: Berapa 5 dikali 19?
A: 95.

Q: Berapa 20 ditambah 12?
A: 32.

Q: Berapa 20 dikali 1?
A: 20.
