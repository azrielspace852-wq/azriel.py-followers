# Dataset Clarification — 2117

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dikali 17?
A: 204.

Q: Perbaiki yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikali 9?
A: 81.

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Berapa 1 dikali 10?
A: 10.

Q: Tampilkan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikali 7?
A: 21.

Q: Buatkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikali 14?
A: 238.

Q: Saya butuh hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Saya mau sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Tolong buat yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikurangi 10?
A: 8.

Q: Mohon buatkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Hitung yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 17 dikali 20?
A: 340.

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Rapikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Berapa 3 ditambah 5?
A: 8.

Q: Tampilkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Hitung yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang pas.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 3 dikali 10?
A: 30.

Q: Berapa 18 ditambah 19?
A: 37.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Saya butuh yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 3 dikali 1?
A: 3.

Q: Jelaskan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 ditambah 12?
A: 28.
