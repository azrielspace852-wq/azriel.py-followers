# Dataset Clarification — 2153

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Saya butuh yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Kasih yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Cek yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Saya butuh sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Saya mau yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Hitung yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Jelaskan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Tampilkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Ceritakan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.
