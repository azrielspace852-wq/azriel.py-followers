# Dataset Clarification — 2033

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Sesuaikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Cek yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Cari yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Perbaiki yang pas.
A: Siap. Tentang apa tepatnya?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Hitung yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Berikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Buatkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Cari yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Berikan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Tampilkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Tolong buat yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Bikin yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Rapikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Ceritakan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Ubah yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.
