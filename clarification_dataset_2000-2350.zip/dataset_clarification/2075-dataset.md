# Dataset Clarification — 2075

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 16 dikali 3?
A: 48.

Q: Berapa 10 dikurangi 8?
A: 2.

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Berapa 12 dikali 18?
A: 216.

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Berapa 6 dikali 11?
A: 66.

Q: Berapa 15 dikurangi 7?
A: 8.

Q: Jelaskan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Sesuaikan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikurangi 6?
A: 14.

Q: Cari yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang itu.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dikali 10?
A: 120.

Q: Berapa 4 ditambah 7?
A: 11.

Q: Saya butuh yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Rapikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 dikali 4?
A: 36.

Q: Berikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 ditambah 17?
A: 33.

Q: Kasih yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 ditambah 9?
A: 29.

Q: Berapa 9 ditambah 10?
A: 19.

Q: Berapa 11 dikali 19?
A: 209.

Q: Berapa 8 ditambah 7?
A: 15.

Q: Tampilkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Berapa 18 dikurangi 2?
A: 16.

Q: Bikin seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 4?
A: 14.
