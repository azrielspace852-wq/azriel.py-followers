# Dataset Clarification — 2035

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 18 dikurangi 4?
A: 14.

Q: Berapa 12 ditambah 6?
A: 18.

Q: Berapa 10 ditambah 17?
A: 27.

Q: Tolong buat seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dikurangi 3?
A: 5.

Q: Berapa 7 ditambah 8?
A: 15.

Q: Berapa 16 ditambah 14?
A: 30.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Cari sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 9?
A: 15.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 3 dikali 1?
A: 3.

Q: Jelaskan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dikali 6?
A: 60.

Q: Berapa 20 ditambah 9?
A: 29.

Q: Hitung yang murah.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Berapa 11 dikali 15?
A: 165.

Q: Berikan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikali 2?
A: 22.

Q: Berapa 19 dikurangi 3?
A: 16.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 13 ditambah 5?
A: 18.

Q: Hitung hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikali 13?
A: 221.

Q: Berapa 18 dikali 18?
A: 324.

Q: Berapa 9 dikali 13?
A: 117.

Q: Buatkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Jelaskan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang detail.
A: Siap. Tentang apa tepatnya?

Q: Cek yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Berapa 2 dikali 20?
A: 40.

Q: Berapa 10 ditambah 20?
A: 30.

Q: Sesuaikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan seperti biasa.
A: Siap. Yang mana yang dimaksud?
