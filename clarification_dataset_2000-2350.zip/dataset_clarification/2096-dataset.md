# Dataset Clarification — 2096

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikali 12?
A: 96.

Q: Berapa 9 dikali 14?
A: 126.

Q: Ubah yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 ditambah 3?
A: 13.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 14 dikali 4?
A: 56.

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Analisis yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikali 14?
A: 224.

Q: Berapa 1 ditambah 16?
A: 17.

Q: Berapa 13 dikurangi 9?
A: 4.

Q: Cari yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 dikurangi 9?
A: 0.

Q: Cari hal itu.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikali 5?
A: 70.

Q: Perbaiki sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 6?
A: 19.

Q: Bikin seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikali 15?
A: 210.

Q: Berapa 9 ditambah 13?
A: 22.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Saya butuh yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Cari yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Perbaiki yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang sana.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 10 dikali 1?
A: 10.

Q: Analisis yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 ditambah 15?
A: 30.

Q: Hitung yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Mohon buatkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 16 ditambah 2?
A: 18.

Q: Berikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dikurangi 13?
A: 3.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Saya mau yang cocok.
A: Bisa. Untuk tujuan apa?
