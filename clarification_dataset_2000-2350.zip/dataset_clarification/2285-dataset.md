# Dataset Clarification — 2285

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 15?
A: 270.

Q: Berapa 6 dikali 13?
A: 78.

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Analisis yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Ceritakan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Berapa 13 dikali 20?
A: 260.

Q: Berapa 7 dikali 14?
A: 98.

Q: Berapa 11 dikali 3?
A: 33.

Q: Cari sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 ditambah 11?
A: 15.

Q: Berapa 11 dikali 5?
A: 55.

Q: Kasih yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 20 dikali 20?
A: 400.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Saya butuh yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 6?
A: 9.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 10 ditambah 13?
A: 23.

Q: Sesuaikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Perbaiki yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikali 16?
A: 304.

Q: Buatkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 15 ditambah 20?
A: 35.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Berapa 15 dikurangi 3?
A: 12.
