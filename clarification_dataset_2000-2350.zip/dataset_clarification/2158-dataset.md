# Dataset Clarification — 2158

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 6 dikurangi 4?
A: 2.

Q: Berapa 19 dikurangi 16?
A: 3.

Q: Berapa 6 ditambah 11?
A: 17.

Q: Cari sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Berikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Cari yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Berikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 ditambah 12?
A: 20.

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 16 dikurangi 16?
A: 0.

Q: Cek yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dikali 18?
A: 360.

Q: Cek yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 ditambah 6?
A: 14.

Q: Mohon buatkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Cari sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 14 dikurangi 14?
A: 0.

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 ditambah 13?
A: 14.

Q: Berapa 15 ditambah 10?
A: 25.

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Berapa 7 ditambah 1?
A: 8.

Q: Berapa 8 dikali 8?
A: 64.

Q: Hitung yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Jelaskan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Ubah hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dikali 14?
A: 70.

Q: Berikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikali 7?
A: 105.

Q: Kasih yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Buatkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Perbaiki yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.
