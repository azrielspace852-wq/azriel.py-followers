# Dataset Clarification — 2324

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Kasih sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Tampilkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berapa 3 ditambah 4?
A: 7.

Q: Berapa 4 ditambah 5?
A: 9.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Hitung yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 6?
A: 7.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Sesuaikan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Tampilkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Cek yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama indera perasa?
A: Lidah.

Q: Tolong buat yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 15?
A: 26.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Berapa 18 dikurangi 16?
A: 2.

Q: Perbaiki seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Tolong buat yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Ubah seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Cek yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Kasih yang sana.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.
