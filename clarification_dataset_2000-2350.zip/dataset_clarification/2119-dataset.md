# Dataset Clarification — 2119

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 4 dikali 6?
A: 24.

Q: Berapa 11 dikurangi 3?
A: 8.

Q: Cek yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Perbaiki yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Perbaiki yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 8?
A: 9.

Q: Analisis yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 12?
A: 144.

Q: Berapa 9 dikali 1?
A: 9.

Q: Berapa 16 dikali 18?
A: 288.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Tolong buat yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 13?
A: 30.

Q: Analisis hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 ditambah 11?
A: 25.

Q: Sesuaikan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 1 ditambah 14?
A: 15.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Jelaskan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 5 ditambah 14?
A: 19.

Q: Rapikan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Tampilkan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Cek seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 ditambah 13?
A: 15.

Q: Ceritakan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 11 dikurangi 10?
A: 1.

Q: Mohon buatkan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dikali 7?
A: 35.

Q: Hitung yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikali 9?
A: 99.

Q: Sesuaikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Analisis sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 ditambah 15?
A: 33.

Q: Berapa 12 dikali 18?
A: 216.
