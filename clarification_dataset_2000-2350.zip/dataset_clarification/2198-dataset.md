# Dataset Clarification — 2198

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 12 ditambah 19?
A: 31.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 15 dikurangi 7?
A: 8.

Q: Tampilkan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 ditambah 6?
A: 26.

Q: Saya butuh yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 12?
A: 25.

Q: Jelaskan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 ditambah 10?
A: 24.

Q: Tampilkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Berapa 7 dikali 16?
A: 112.

Q: Berapa 10 ditambah 10?
A: 20.

Q: Saya mau yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 ditambah 16?
A: 25.

Q: Berapa 9 ditambah 3?
A: 12.

Q: Berapa 14 ditambah 16?
A: 30.

Q: Cek yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikali 18?
A: 126.

Q: Berapa 4 dikali 16?
A: 64.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 18 dikali 13?
A: 234.

Q: Berikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Berapa 9 dikali 16?
A: 144.

Q: Kasih yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 ditambah 13?
A: 27.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Tolong buat yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 6?
A: 108.

Q: Saya mau yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikurangi 14?
A: 5.

Q: Jelaskan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Saya mau yang detail.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?
