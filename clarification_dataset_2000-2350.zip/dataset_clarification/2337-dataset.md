# Dataset Clarification — 2337

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 7 ditambah 7?
A: 14.

Q: Berapa 13 ditambah 1?
A: 14.

Q: Berapa 4 ditambah 13?
A: 17.

Q: Sesuaikan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikurangi 14?
A: 1.

Q: Cek yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 5?
A: 10.

Q: Berapa 7 ditambah 10?
A: 17.

Q: Pilihkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 ditambah 18?
A: 37.

Q: Berapa 6 dikali 2?
A: 12.

Q: Jelaskan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 ditambah 12?
A: 31.

Q: Berapa 20 dikali 18?
A: 360.

Q: Berapa 8 dikali 9?
A: 72.

Q: Berapa 3 dikali 8?
A: 24.

Q: Cari yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 dikali 2?
A: 6.

Q: Buatkan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 ditambah 13?
A: 17.

Q: Berapa 16 ditambah 4?
A: 20.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 18 dikali 6?
A: 108.

Q: Berapa 3 dikali 9?
A: 27.

Q: Hitung yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 13 ditambah 15?
A: 28.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Saya mau yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 dikali 13?
A: 169.

Q: Mohon buatkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 ditambah 5?
A: 20.

Q: Ubah yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?
