# Dataset Clarification — 2107

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 ditambah 6?
A: 10.

Q: Perbaiki yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Kasih yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Analisis hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 ditambah 14?
A: 29.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 15 dikali 15?
A: 225.

Q: Pilihkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Berapa 7 dikurangi 3?
A: 4.

Q: Berapa 11 dikali 17?
A: 187.

Q: Pilihkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 10 dikali 3?
A: 30.

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 13 ditambah 11?
A: 24.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Kasih yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 16?
A: 16.

Q: Ceritakan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Berapa 4 dikali 16?
A: 64.

Q: Sesuaikan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Cek seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 ditambah 1?
A: 9.

Q: Ceritakan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikali 4?
A: 28.

Q: Tolong buat yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 14?
A: 210.

Q: Berikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 12?
A: 6.

Q: Buatkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikurangi 8?
A: 9.

Q: Rapikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikali 8?
A: 152.

Q: Ubah yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikurangi 2?
A: 8.
