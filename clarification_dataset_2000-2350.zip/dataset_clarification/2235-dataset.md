# Dataset Clarification — 2235

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 5 dikali 15?
A: 75.

Q: Berapa 19 ditambah 11?
A: 30.

Q: Berapa 18 ditambah 9?
A: 27.

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Kasih yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang itu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 7?
A: 84.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Ubah sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Cari yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Bikin hal itu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dikali 19?
A: 95.

Q: Berapa 15 dikali 8?
A: 120.

Q: Kasih seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikali 9?
A: 171.

Q: Perbaiki hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 ditambah 5?
A: 6.

Q: Bikin yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Berapa 4 ditambah 5?
A: 9.

Q: Buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 ditambah 11?
A: 25.

Q: Buatkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 2 dikali 16?
A: 32.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Sesuaikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Rapikan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Analisis yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Perbaiki yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 ditambah 17?
A: 20.

Q: Analisis sesuatu.
A: Baik. Bisa dijelaskan lebih detail?
