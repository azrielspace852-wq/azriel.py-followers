# Dataset Clarification — 2297

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikali 1?
A: 8.

Q: Buatkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Analisis yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 ditambah 3?
A: 13.

Q: Berapa 10 dikali 8?
A: 80.

Q: Tampilkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Saya mau seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikali 4?
A: 72.

Q: Jelaskan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Saya mau yang detail.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Rapikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 14?
A: 224.

Q: Ubah yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 dikurangi 7?
A: 2.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Bikin yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 17?
A: 3.

Q: Berapa 18 dikurangi 2?
A: 16.

Q: Kasih seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikurangi 17?
A: 1.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 5 ditambah 18?
A: 23.

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Berapa 15 ditambah 17?
A: 32.

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Sesuaikan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikurangi 5?
A: 3.

Q: Berapa 15 ditambah 15?
A: 30.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 19 dikurangi 15?
A: 4.
