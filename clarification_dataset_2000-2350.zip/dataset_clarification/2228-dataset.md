# Dataset Clarification — 2228

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Rapikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 dikali 9?
A: 117.

Q: Pilihkan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 11?
A: 198.

Q: Berapa 19 ditambah 9?
A: 28.

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Bikin yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Berapa 7 ditambah 13?
A: 20.

Q: Kasih yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikali 10?
A: 140.

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 13 dikali 2?
A: 26.

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 2?
A: 18.

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Berapa 20 dikali 11?
A: 220.

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Tampilkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang ini.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Saya butuh yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 ditambah 7?
A: 17.

Q: Berapa 13 dikali 3?
A: 39.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Pilihkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 18 dikurangi 2?
A: 16.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Berapa 3 dikali 7?
A: 21.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Tolong buat yang sana.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Cek hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.
