# Dataset Clarification — 2105

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 19 ditambah 5?
A: 24.

Q: Analisis yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 ditambah 16?
A: 21.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Perbaiki hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 18?
A: 2.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 4?
A: 19.

Q: Berapa 14 dikurangi 7?
A: 7.

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 ditambah 17?
A: 27.

Q: Berapa 20 dikali 18?
A: 360.

Q: Rapikan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikurangi 2?
A: 8.

Q: Berapa 13 ditambah 7?
A: 20.

Q: Cari yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 ditambah 5?
A: 11.

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Cari yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Kasih yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Pilihkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dikali 12?
A: 96.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 13 dikurangi 9?
A: 4.

Q: Hitung yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Jelaskan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dikali 13?
A: 130.

Q: Saya butuh yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 11 dikali 1?
A: 11.

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 dikali 10?
A: 60.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Hitung yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?
