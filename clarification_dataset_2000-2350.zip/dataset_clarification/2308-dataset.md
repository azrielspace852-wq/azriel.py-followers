# Dataset Clarification — 2308

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 14 dikali 8?
A: 112.

Q: Analisis yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Analisis hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 6?
A: 24.

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 4 dikali 14?
A: 56.

Q: Berikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 ditambah 4?
A: 6.

Q: Kasih yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 ditambah 16?
A: 19.

Q: Berapa 18 ditambah 13?
A: 31.

Q: Berapa 20 ditambah 9?
A: 29.

Q: Berapa 18 dikurangi 4?
A: 14.

Q: Berapa 4 dikali 8?
A: 32.

Q: Berapa 16 dikurangi 5?
A: 11.

Q: Berapa 10 dikali 19?
A: 190.

Q: Berapa 12 ditambah 4?
A: 16.

Q: Sesuaikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Pilihkan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 11?
A: 3.

Q: Berapa 18 dikurangi 5?
A: 13.

Q: Ceritakan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Hitung seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 ditambah 4?
A: 9.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Mohon buatkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 dikali 6?
A: 84.

Q: Kasih yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?
