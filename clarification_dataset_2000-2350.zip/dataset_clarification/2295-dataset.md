# Dataset Clarification — 2295

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 1 ditambah 12?
A: 13.

Q: Analisis yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 10 dikali 16?
A: 160.

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Berapa 14 dikali 6?
A: 84.

Q: Pilihkan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 ditambah 20?
A: 28.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Tampilkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikali 18?
A: 288.

Q: Bikin yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikurangi 12?
A: 4.

Q: Hitung yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Buatkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Analisis yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikali 17?
A: 221.

Q: Berapa 9 dikali 2?
A: 18.

Q: Tampilkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikurangi 6?
A: 14.

Q: Berapa 3 dikali 1?
A: 3.

Q: Perbaiki yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Berapa 17 ditambah 18?
A: 35.

Q: Berapa 9 ditambah 2?
A: 11.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Jelaskan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 10 ditambah 14?
A: 24.

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Tampilkan yang detail.
A: Siap. Tentang apa tepatnya?
