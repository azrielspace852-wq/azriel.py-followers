# Dataset Clarification — 2027

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dikali 14?
A: 140.

Q: Saya mau yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek hal itu.
A: Bisa. Untuk keperluan apa?

Q: Buatkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 2?
A: 20.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Hitung yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikurangi 19?
A: 0.

Q: Berikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 12 dikali 16?
A: 192.

Q: Berapa 18 ditambah 13?
A: 31.

Q: Berapa 4 dikali 16?
A: 64.

Q: Buatkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih hal itu.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Kasih seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Kasih hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikali 10?
A: 60.

Q: Berapa 7 dikali 2?
A: 14.

Q: Pilihkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikali 12?
A: 228.

Q: Buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 dikali 12?
A: 180.

Q: Berapa 16 dikali 3?
A: 48.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Ceritakan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 ditambah 2?
A: 7.

Q: Saya butuh yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 ditambah 10?
A: 26.

Q: Berapa 11 ditambah 2?
A: 13.

Q: Berapa 8 ditambah 16?
A: 24.

Q: Berapa 5 ditambah 7?
A: 12.

Q: Cek yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikali 3?
A: 36.

Q: Saya mau yang ini.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Ubah yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 dikali 14?
A: 98.

Q: Berapa 24 dibagi 4?
A: 6.
