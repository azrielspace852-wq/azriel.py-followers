# Dataset Clarification — 2276

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 9?
A: 9.

Q: Berapa 14 ditambah 9?
A: 23.

Q: Sesuaikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang sana.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 ditambah 6?
A: 25.

Q: Tolong buat hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 ditambah 3?
A: 8.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Perbaiki yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikali 8?
A: 88.

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Berapa 13 dikali 8?
A: 104.

Q: Cek yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 dikali 11?
A: 66.

Q: Ceritakan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 9 ditambah 14?
A: 23.

Q: Perbaiki yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 ditambah 3?
A: 22.

Q: Bikin sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 ditambah 11?
A: 13.

Q: Berapa 9 ditambah 4?
A: 13.

Q: Perbaiki sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 ditambah 10?
A: 23.

Q: Berapa 20 dikali 2?
A: 40.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Berikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikurangi 10?
A: 8.

Q: Kasih yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Cari yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 17?
A: 28.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 1 dikali 16?
A: 16.

Q: Tampilkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikali 14?
A: 126.
