# Dataset Clarification — 2028

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 9 dikurangi 3?
A: 6.

Q: Berapa 11 ditambah 1?
A: 12.

Q: Saya butuh hal itu.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikurangi 1?
A: 11.

Q: Pilihkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikali 9?
A: 162.

Q: Kasih yang detail.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 9?
A: 27.

Q: Berapa 4 dikali 16?
A: 64.

Q: Berikan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Sesuaikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikali 10?
A: 190.

Q: Buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Cari yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Jelaskan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Hitung yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Kasih yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikali 10?
A: 100.

Q: Berapa 14 dikali 5?
A: 70.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Saya mau hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 ditambah 19?
A: 27.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Ubah yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Cek yang itu.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 2 dikali 18?
A: 36.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Jelaskan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 9 dikali 16?
A: 144.

Q: Tampilkan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?
