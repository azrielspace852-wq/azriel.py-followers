# Dataset Clarification — 2193

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Ceritakan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Buatkan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Tolong buat yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Ceritakan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Jelaskan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Buatkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Berikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang ini.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Tampilkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Jelaskan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Ubah yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.
