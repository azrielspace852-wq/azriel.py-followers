# Dataset Clarification — 2166

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tolong buat yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 ditambah 18?
A: 36.

Q: Berapa 3 ditambah 4?
A: 7.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Jelaskan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 dikurangi 13?
A: 0.

Q: Berapa 12 ditambah 10?
A: 22.

Q: Tolong buat yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Ceritakan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikali 9?
A: 144.

Q: Berapa 6 dikali 16?
A: 96.

Q: Berikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Cari yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 ditambah 7?
A: 23.

Q: Kasih yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dikali 3?
A: 18.

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Perbaiki seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikali 19?
A: 209.

Q: Tolong buat seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Tampilkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Tampilkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 17?
A: 3.

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Mohon buatkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 dikali 10?
A: 180.

Q: Bikin yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 4?
A: 19.

Q: Jelaskan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikali 12?
A: 228.

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Berapa 17 dikali 5?
A: 85.

Q: Berapa 1 dikali 11?
A: 11.

Q: Sesuaikan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 ditambah 16?
A: 30.

Q: Ceritakan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 6 dikali 17?
A: 102.

Q: Berapa 8 dibagi 2?
A: 4.
