# Dataset Clarification — 2233

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Saya butuh yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Ceritakan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Buatkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Kasih yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Hitung yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Buatkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Cek yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Cek hal itu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Ceritakan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Tolong buat yang sana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Cek yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Jelaskan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Jelaskan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?
