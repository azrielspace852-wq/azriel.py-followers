# Dataset Clarification — 2086

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 ditambah 17?
A: 21.

Q: Buatkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikali 12?
A: 240.

Q: Sesuaikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 3 ditambah 9?
A: 12.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 13 dikali 7?
A: 91.

Q: Ubah yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 ditambah 16?
A: 29.

Q: Pilihkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 15 dikurangi 4?
A: 11.

Q: Berapa 6 ditambah 16?
A: 22.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Buatkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 10 ditambah 20?
A: 30.

Q: Analisis yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 ditambah 17?
A: 27.

Q: Berikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Cari yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Cek yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Bikin yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 ditambah 6?
A: 18.

Q: Saya butuh yang murah.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 ditambah 4?
A: 20.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 dikurangi 13?
A: 0.

Q: Saya mau yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Berikan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 8 ditambah 14?
A: 22.

Q: Ceritakan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Ubah seperti biasa.
A: Tentu. Konteksnya seperti apa?
