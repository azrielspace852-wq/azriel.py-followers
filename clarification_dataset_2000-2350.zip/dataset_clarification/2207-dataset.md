# Dataset Clarification — 2207

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Berapa 6 dikurangi 3?
A: 3.

Q: Analisis yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 ditambah 15?
A: 31.

Q: Jelaskan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 dikali 20?
A: 120.

Q: Analisis yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 ditambah 1?
A: 7.

Q: Kasih yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Perbaiki yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 dikali 16?
A: 272.

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Pilihkan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 5?
A: 16.

Q: Berapa 3 ditambah 9?
A: 12.

Q: Buatkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 dikali 11?
A: 33.

Q: Berapa 8 dikali 13?
A: 104.

Q: Analisis yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 4 dikurangi 1?
A: 3.

Q: Berapa 3 ditambah 4?
A: 7.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Buatkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Cek yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 9 dikali 7?
A: 63.

Q: Cek sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 dikali 16?
A: 80.

Q: Saya butuh yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 3 ditambah 17?
A: 20.
