# Dataset Clarification — 2132

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Siapa penemu telepon?
A: Alexander Graham Bell.

Q: Apa nama gurun terbesar di dunia?
A: Sahara.

Q: Buat ringkasan singkat.
A: Baik. Ringkasan singkat dari apa?

Q: Buat lebih meyakinkan.
A: Siap. Teks yang mana yang ingin dibuat meyakinkan?

Q: Siapa penemu penicilllin?
A: Alexander Fleming.

Q: Apa nama mesin pencari yang paling populer?
A: Google.

Q: Apa sila pertama Pancasila?
A: Ketuhanan Yang Maha Esa.

Q: Siapa penemu gravitasi?
A: Isaac Newton.

Q: Buat lebih lembut.
A: Bisa. Teks yang mana yang ingin dibuat lembut?

Q: Buat versi panjang.
A: Bisa. Versi panjang dari apa?

Q: Apa nama aplikasi pesan instan yang populer di Indonesia?
A: WhatsApp.

Q: Apa nama sistem operasi open source yang populer?
A: Linux.

Q: Apa nama planet yang memiliki cincin?
A: Saturnus.

Q: Apa nama sungai terpanjang di dunia?
A: Nil.

Q: Buat definisi.
A: Baik. Definisi tentang apa?

Q: Apa nama organisasi yang mendirikan negara Indonesia?
A: BPUPKI dan PPKI.

Q: Buat lebih santai.
A: Baik. Teks yang mana yang ingin dibuat santai?

Q: Apa nama galaksi tempat Bumi berada?
A: Galaksi Bima Sakti.

Q: Siapa penulis novel Bumi Manusia?
A: Pramoedya Ananta Toer.

Q: Kapan Indonesia merdeka?
A: 17 Agustus 1945.

Q: Apa sila kelima Pancasila?
A: Keadilan Sosial bagi Seluruh Rakyat Indonesia.

Q: Apa nama ibu kota Argentina?
A: Buenos Aires.

Q: Buat soal.
A: Baik. Soal tentang apa?

Q: Buat versi Indonesia.
A: Siap. Versi Indonesia dari apa?

Q: Apa nama ideologi negara Indonesia?
A: Pancasila.

Q: Buat versi kompleks.
A: Siap. Versi kompleks dari apa?

Q: Apa nama samudra terkecil?
A: Samudra Arktik.

Q: Siapa penulis novel Harry Potter?
A: J.K. Rowling.

Q: Apa sila ketiga Pancasila?
A: Persatuan Indonesia.

Q: Buat versi informal.
A: Baik. Versi informal dari apa?

Q: Apa nama benua yang paling dingin?
A: Antartika.

Q: Buat makna.
A: Bisa. Makna dari apa?

Q: Perbaiki ejaan.
A: Bisa. Ejaan pada teks yang mana?

Q: Apa nama bahasa pemrograman yang populer untuk pemula?
A: Python.

Q: Buat slide.
A: Siap. Slide tentang apa?

Q: Buat jawaban.
A: Siap. Jawaban untuk pertanyaan apa?

Q: Buat lebih sopan.
A: Baik. Teks yang mana yang ingin dibuat sopan?

Q: Perbaiki gaya bahasa.
A: Siap. Gaya bahasa pada teks yang mana?

Q: Buat kuis.
A: Bisa. Kuis tentang apa?

Q: Perbaiki paragraf.
A: Baik. Paragraf yang mana?

Q: Sesuaikan dengan preferensi.
A: Baik. Preferensi yang seperti apa?

Q: Sesuaikan dengan tujuan.
A: Siap. Tujuan yang seperti apa?

Q: Buat laporan.
A: Bisa. Laporan tentang apa?

Q: Sesuaikan dengan platform.
A: Bisa. Platform yang mana?

Q: Buat lebih mudah dipahami.
A: Bisa. Teks yang mana yang ingin disederhanakan?

Q: Siapa presiden kedua Indonesia?
A: Soeharto.

Q: Apa nama bahasa pemrograman untuk database?
A: SQL.

Q: Sesuaikan dengan target.
A: Siap. Target yang seperti apa?

Q: Apa nama ibu kota Meksiko?
A: Kota Meksiko.

Q: Sesuaikan dengan gaya.
A: Baik. Gaya yang seperti apa?
