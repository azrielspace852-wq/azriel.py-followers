# Dataset Clarification — 2093

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Hitung yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Cari yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Cek yang itu.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Perbaiki yang keren.
A: Bisa. Untuk tujuan apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Ubah yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Perbaiki yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang sana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Saya mau yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Berikan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Tampilkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Saya butuh yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Saya butuh yang detail.
A: Bisa. Untuk keperluan apa?

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Cari yang itu.
A: Bisa. Untuk tujuan apa?
