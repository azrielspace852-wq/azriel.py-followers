# Dataset Clarification — 2055

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Pilihkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 12 ditambah 11?
A: 23.

Q: Berapa 10 ditambah 9?
A: 19.

Q: Tampilkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 ditambah 17?
A: 37.

Q: Berapa 6 dikali 5?
A: 30.

Q: Jelaskan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dikurangi 5?
A: 5.

Q: Berikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikali 12?
A: 168.

Q: Berapa 7 dikali 2?
A: 14.

Q: Berikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 12?
A: 7.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Analisis yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Cek yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 13?
A: 15.

Q: Berapa 3 ditambah 6?
A: 9.

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Ceritakan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 ditambah 7?
A: 12.

Q: Tolong buat sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikurangi 11?
A: 2.

Q: Saya butuh yang pas.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Sesuaikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Perbaiki hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikali 14?
A: 224.

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Berapa 16 dikali 11?
A: 176.

Q: Ubah yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikali 8?
A: 112.

Q: Saya mau yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang cepat.
A: Tentu. Konteksnya seperti apa?
