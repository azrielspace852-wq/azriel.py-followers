# Dataset Clarification — 2335

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikali 5?
A: 85.

Q: Berapa 13 ditambah 9?
A: 22.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Sesuaikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Berapa 18 dikali 9?
A: 162.

Q: Berapa 8 ditambah 5?
A: 13.

Q: Berapa 16 dikali 1?
A: 16.

Q: Cari yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 ditambah 6?
A: 15.

Q: Analisis yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 dikali 7?
A: 35.

Q: Berapa 2 ditambah 18?
A: 20.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 3 dikali 14?
A: 42.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Buatkan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikali 3?
A: 18.

Q: Kasih yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 ditambah 2?
A: 16.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 12 ditambah 5?
A: 17.

Q: Pilihkan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 dikali 4?
A: 28.

Q: Mohon buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 ditambah 6?
A: 13.

Q: Berapa 3 dikali 20?
A: 60.

Q: Berikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 dikurangi 3?
A: 3.

Q: Berikan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 12?
A: 120.

Q: Cari yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang murah.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 ditambah 3?
A: 17.

Q: Sesuaikan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 dibagi 2?
A: 7.
