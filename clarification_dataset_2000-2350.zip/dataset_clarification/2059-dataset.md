# Dataset Clarification — 2059

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 1 dikali 7?
A: 7.

Q: Berapa 19 ditambah 15?
A: 34.

Q: Jelaskan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Cari yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Cari sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Ceritakan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikali 16?
A: 208.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 14 dikurangi 5?
A: 9.

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Berapa 20 dikali 19?
A: 380.

Q: Pilihkan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Berapa 5 dikali 2?
A: 10.

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Buatkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikali 10?
A: 120.

Q: Sesuaikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 ditambah 3?
A: 20.

Q: Sesuaikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 18?
A: 54.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 15 ditambah 14?
A: 29.

Q: Berapa 6 dikali 5?
A: 30.

Q: Tampilkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikali 19?
A: 361.

Q: Berapa 9 dikurangi 3?
A: 6.

Q: Perbaiki yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Bikin hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikurangi 4?
A: 5.

Q: Berapa 3 ditambah 1?
A: 4.

Q: Berapa 12 dikurangi 8?
A: 4.

Q: Bikin yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang sana.
A: Bisa. Untuk tujuan apa?
