# Dataset Clarification — 2194

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Ubah yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Cek yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Hitung hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 2 ditambah 14?
A: 16.

Q: Analisis yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Perbaiki yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Perbaiki yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikurangi 9?
A: 9.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Berikan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama indera perasa?
A: Lidah.

Q: Jelaskan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Berapa 14 dikali 1?
A: 14.

Q: Analisis yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Perbaiki yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Tampilkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Kasih yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Tolong buat yang pas.
A: Bisa. Untuk keperluan apa?
