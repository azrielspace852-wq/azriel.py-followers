# Dataset Clarification — 2287

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikurangi 5?
A: 10.

Q: Berapa 11 ditambah 3?
A: 14.

Q: Berapa 9 dikali 15?
A: 135.

Q: Saya butuh yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 11 ditambah 12?
A: 23.

Q: Saya butuh yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Kasih hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikurangi 7?
A: 2.

Q: Berapa 13 dikurangi 12?
A: 1.

Q: Tolong buat yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berikan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikali 2?
A: 14.

Q: Berapa 3 ditambah 11?
A: 14.

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 13 dikali 8?
A: 104.

Q: Ceritakan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 19 dikurangi 11?
A: 8.

Q: Berikan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikurangi 13?
A: 3.

Q: Perbaiki yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 1 dikali 7?
A: 7.

Q: Berapa 15 dikali 5?
A: 75.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Sesuaikan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Analisis yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 ditambah 4?
A: 22.

Q: Ceritakan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikali 16?
A: 240.

Q: Saya mau hal itu.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 10 ditambah 18?
A: 28.

Q: Berikan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Cari yang sesuai.
A: Bisa. Untuk tujuan apa?
