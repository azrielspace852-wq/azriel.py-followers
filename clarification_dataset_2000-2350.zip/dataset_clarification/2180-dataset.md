# Dataset Clarification — 2180

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa jumlah provinsi di Indonesia?
A: 38.

Q: Apa hasil dari akar kuadrat 16?
A: 4.

Q: Kapan bisa?
A: Tentu. Kapan bisa untuk apa?

Q: Berapa jumlah kaki pada kucing?
A: 4.

Q: Lakukan saja.
A: Baik. Lakukan apa yang dimaksud?

Q: Berapa lama?
A: Baik. Lama untuk apa?

Q: Apa nama buah yang berwarna kuning dan panjang?
A: Pisang.

Q: Apa nama sayuran hijau yang sering dibuat lalapan?
A: Selada.

Q: Apa gas yang paling banyak di atmosfer Bumi?
A: Nitrogen.

Q: Saya butuh bantuan.
A: Baik. Bantuan untuk apa tepatnya?

Q: Apa rumus luas persegi?
A: Sisi dikali sisi.

Q: Berapa 5 dikali 3?
A: 15.

Q: Hitung dong.
A: Siap. Hitung apa yang dimaksud?

Q: Cari yang murah.
A: Siap. Yang murah untuk apa?

Q: Apa nama bulan pertama dalam setahun?
A: Januari.

Q: Apa nama jari tengah pada tangan?
A: Jari tengah.

Q: Ikuti saja.
A: Siap. Ikuti apa yang dimaksud?

Q: Saya mau yang itu.
A: Baik. Yang mana yang dimaksud?

Q: Jelaskan dengan singkat.
A: Baik. Jelaskan tentang apa secara singkat?

Q: Apa nama samudra terbesar?
A: Samudra Pasifik.

Q: Selesaikan.
A: Bisa. Selesaikan apa yang dimaksud?

Q: Planet mana yang paling dekat dengan Matahari?
A: Merkurius.

Q: Bandingkan.
A: Tentu. Bandingkan apa dengan apa?

Q: Mana yang lebih baik?
A: Siap. Lebih baik antara apa?

Q: Buat yang sederhana.
A: Tentu. Yang sederhana tentang apa?

Q: Apa hasil dari 7 pangkat 2?
A: 49.

Q: Apa ibu kota Jepang?
A: Tokyo.

Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?

Q: Bagaimana caranya?
A: Baik. Cara untuk melakukan apa?

Q: Siapa yang dimaksud?
A: Siap. Siapa yang Anda tanyakan?

Q: Organ apa yang digunakan untuk bernapas?
A: Paru-paru.

Q: Apa ibu kota Thailand?
A: Bangkok.

Q: Bikin yang keren dong.
A: Siap. Yang keren yang mana? Bisa diperjelas?

Q: Perbaiki.
A: Tentu. Perbaiki apa yang dimaksud?

Q: Apa nama hewan yang menghasilkan susu?
A: Sapi.

Q: Buat yang pas.
A: Bisa. Yang pas untuk apa?

Q: Berapa jumlah hari dalam seminggu?
A: 7.

Q: Berapa jumlah sisi pada persegi?
A: 4.

Q: Berikan saran.
A: Tentu. Saran mengenai apa?

Q: Tolong bantu.
A: Tentu. Membantu dalam hal apa?

Q: Cari yang terbaik.
A: Baik. Yang terbaik untuk keperluan apa?

Q: Apa nama alat untuk memotong kertas?
A: Gunting.

Q: Buat ringkasan.
A: Bisa. Ringkasan dari apa?

Q: Seberapa banyak?
A: Siap. Banyak dalam konteks apa?

Q: Apa nama minuman yang terbuat dari susu dan kopi?
A: Kopi susu.

Q: Apa warna darah manusia?
A: Merah.

Q: Apa rumus keliling lingkaran?
A: 2 dikali pi dikali jari-jari.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Apa nama hari setelah Senin?
A: Selasa.

Q: Tolong jelaskan.
A: Baik. Jelaskan tentang apa?
