# Dataset Clarification — 2319

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 14 dikali 5?
A: 70.

Q: Pilihkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 6 ditambah 6?
A: 12.

Q: Berapa 17 dikurangi 3?
A: 14.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Ceritakan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 16 dikurangi 3?
A: 13.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Berapa 20 dikurangi 11?
A: 9.

Q: Hitung yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang detail.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 1?
A: 10.

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Pilihkan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 ditambah 13?
A: 33.

Q: Rapikan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 6 dikali 5?
A: 30.

Q: Berikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 2?
A: 32.

Q: Berapa 15 dikali 10?
A: 150.

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Berapa 14 dikurangi 12?
A: 2.

Q: Cari yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berikan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikurangi 18?
A: 2.

Q: Berapa 17 dikurangi 17?
A: 0.

Q: Perbaiki hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 ditambah 16?
A: 30.

Q: Saya mau yang sederhana.
A: Tentu. Konteksnya seperti apa?
