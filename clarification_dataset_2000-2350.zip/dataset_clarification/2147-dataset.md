# Dataset Clarification — 2147

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Buatkan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 7?
A: 63.

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Hitung yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikali 10?
A: 120.

Q: Berapa 18 dikurangi 7?
A: 11.

Q: Kasih yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Tampilkan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 9 dikali 11?
A: 99.

Q: Berapa 14 ditambah 10?
A: 24.

Q: Berapa 18 ditambah 16?
A: 34.

Q: Saya mau yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Ubah yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikali 7?
A: 77.

Q: Berapa 8 ditambah 2?
A: 10.

Q: Tampilkan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Jelaskan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 11?
A: 198.

Q: Mohon buatkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 4 ditambah 4?
A: 8.

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 11 dikurangi 10?
A: 1.

Q: Jelaskan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 ditambah 14?
A: 21.

Q: Bikin yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikali 20?
A: 380.

Q: Berapa 20 dikali 1?
A: 20.

Q: Hitung yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikurangi 7?
A: 3.

Q: Saya butuh yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 35 dibagi 5?
A: 7.
