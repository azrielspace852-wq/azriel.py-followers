# Dataset Clarification — 2227

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 ditambah 17?
A: 29.

Q: Kasih yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikurangi 10?
A: 8.

Q: Berapa 19 dikurangi 18?
A: 1.

Q: Berikan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berikan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 dikali 18?
A: 54.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 12 dikali 9?
A: 108.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Rapikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 20 dikali 3?
A: 60.

Q: Ubah hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikurangi 11?
A: 3.

Q: Tampilkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 15?
A: 26.

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 5 ditambah 11?
A: 16.

Q: Berapa 9 ditambah 1?
A: 10.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Ceritakan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 17 ditambah 16?
A: 33.

Q: Buatkan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Tolong buat yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikali 16?
A: 240.

Q: Berapa 20 dikurangi 17?
A: 3.

Q: Berapa 5 dikali 6?
A: 30.

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Cek yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 9?
A: 1.
