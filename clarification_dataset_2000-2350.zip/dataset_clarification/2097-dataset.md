# Dataset Clarification — 2097

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dikali 14?
A: 140.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 2 dikali 6?
A: 12.

Q: Perbaiki yang detail.
A: Siap. Tentang apa tepatnya?

Q: Cari yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Ceritakan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 ditambah 7?
A: 12.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Kasih yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Jelaskan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikali 6?
A: 42.

Q: Tampilkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Tampilkan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Saya mau yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Analisis yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikali 12?
A: 240.

Q: Jelaskan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikali 9?
A: 81.

Q: Saya butuh yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Buatkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 ditambah 15?
A: 22.

Q: Berapa 10 dikurangi 10?
A: 0.

Q: Hitung yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 ditambah 1?
A: 4.

Q: Rapikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 19?
A: 27.

Q: Berapa 7 dikurangi 3?
A: 4.

Q: Berikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Berapa 1 dikali 4?
A: 4.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Sesuaikan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 13 dikurangi 11?
A: 2.

Q: Pilihkan yang ini.
A: Siap. Maksudnya yang seperti apa?
