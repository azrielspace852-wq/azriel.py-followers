# Dataset Clarification — 2106

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Tolong buat yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 4 dikali 4?
A: 16.

Q: Berapa 16 ditambah 18?
A: 34.

Q: Cari yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 ditambah 5?
A: 13.

Q: Berapa 2 ditambah 5?
A: 7.

Q: Perbaiki yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 2 dikali 14?
A: 28.

Q: Ceritakan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 ditambah 18?
A: 34.

Q: Berapa 4 dikali 19?
A: 76.

Q: Analisis yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Jelaskan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Hitung yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cari yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Berapa 15 ditambah 7?
A: 22.

Q: Berapa 18 dikurangi 12?
A: 6.

Q: Saya mau yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 ditambah 17?
A: 30.

Q: Rapikan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Cek yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Kasih yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 ditambah 16?
A: 24.

Q: Berapa 1 ditambah 10?
A: 11.

Q: Berapa 14 ditambah 19?
A: 33.

Q: Jelaskan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Tolong buat yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 ditambah 5?
A: 12.

Q: Rapikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 15?
A: 33.
