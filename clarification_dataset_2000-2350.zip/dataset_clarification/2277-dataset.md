# Dataset Clarification — 2277

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Hitung yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 ditambah 18?
A: 19.

Q: Berapa 18 dikali 14?
A: 252.

Q: Berapa 11 ditambah 10?
A: 21.

Q: Kasih yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dikali 8?
A: 80.

Q: Berapa 13 ditambah 11?
A: 24.

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Berikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dikali 11?
A: 44.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Cek yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 4 dikali 11?
A: 44.

Q: Tolong buat yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 6 dikali 17?
A: 102.

Q: Cari yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Jelaskan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Hitung seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikali 18?
A: 180.

Q: Berapa 19 ditambah 10?
A: 29.

Q: Ubah yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 3 ditambah 12?
A: 15.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 19 ditambah 15?
A: 34.

Q: Tampilkan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikali 12?
A: 72.

Q: Berapa 4 dikali 10?
A: 40.

Q: Mohon buatkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 19 dikurangi 16?
A: 3.

Q: Berapa 9 ditambah 20?
A: 29.

Q: Saya butuh yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 6?
A: 90.

Q: Mohon buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 40 dibagi 10?
A: 4.
