# Dataset Clarification — 2008

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 ditambah 2?
A: 12.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Pilihkan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 ditambah 16?
A: 27.

Q: Berapa 17 dikali 15?
A: 255.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Perbaiki yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 ditambah 16?
A: 29.

Q: Tampilkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 ditambah 20?
A: 36.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Ceritakan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Sesuaikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Jelaskan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dikali 14?
A: 28.

Q: Pilihkan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 dikali 9?
A: 18.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Ubah yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 ditambah 2?
A: 6.

Q: Berapa 17 ditambah 16?
A: 33.

Q: Berapa 13 ditambah 7?
A: 20.

Q: Tampilkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 ditambah 11?
A: 29.

Q: Rapikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Ceritakan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 6 dikali 3?
A: 18.

Q: Saya butuh yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dikali 7?
A: 70.

Q: Saya mau hal itu.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Berapa 2 ditambah 12?
A: 14.

Q: Rapikan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 20?
A: 320.
