# Dataset Clarification — 2294

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 9 dikurangi 4?
A: 5.

Q: Jelaskan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Tampilkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Rapikan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Cek yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikurangi 6?
A: 0.

Q: Analisis yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang itu.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama satuan energi?
A: Joule.

Q: Sesuaikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Buatkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Bikin yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama indera perasa?
A: Lidah.

Q: Berapa 10 ditambah 14?
A: 24.

Q: Bikin yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Ceritakan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.
