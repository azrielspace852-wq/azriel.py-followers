# Dataset Clarification — 2343

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Ceritakan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Kasih sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Mohon buatkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Pilihkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Cari yang murah.
A: Siap. Tentang apa tepatnya?

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh hal itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Berikan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Jelaskan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Mohon buatkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Analisis yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Tolong buat yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Saya mau yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.
