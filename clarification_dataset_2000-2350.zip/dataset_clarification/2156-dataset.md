# Dataset Clarification — 2156

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 20 ditambah 20?
A: 40.

Q: Berapa 10 dikurangi 8?
A: 2.

Q: Hitung yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikurangi 3?
A: 0.

Q: Berapa 7 dikali 2?
A: 14.

Q: Bikin seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 9 ditambah 6?
A: 15.

Q: Berapa 17 ditambah 6?
A: 23.

Q: Berapa 14 dikali 6?
A: 84.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 2 ditambah 6?
A: 8.

Q: Sesuaikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 ditambah 4?
A: 18.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 13 ditambah 9?
A: 22.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Saya butuh yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 ditambah 4?
A: 21.

Q: Jelaskan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Analisis yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 ditambah 8?
A: 13.

Q: Saya butuh seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 dikali 15?
A: 135.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Buatkan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikali 11?
A: 121.

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 ditambah 13?
A: 31.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikali 12?
A: 216.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 10 dibagi 10?
A: 1.
