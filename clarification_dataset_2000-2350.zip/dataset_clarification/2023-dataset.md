# Dataset Clarification — 2023

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Perbaiki yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Sesuaikan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Kasih yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Pilihkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya butuh yang pas.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Buatkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Analisis yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Tampilkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Jelaskan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Bikin yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Analisis hal itu.
A: Tentu. Konteksnya seperti apa?
