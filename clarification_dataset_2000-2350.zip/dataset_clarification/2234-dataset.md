# Dataset Clarification — 2234

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Bikin yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Analisis yang ini.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 10 ditambah 14?
A: 24.

Q: Hitung sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Rapikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Tampilkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Bikin yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Ceritakan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Analisis yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Saya butuh yang sana.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Ubah yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Cek yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Berapa 7 dikali 3?
A: 21.
