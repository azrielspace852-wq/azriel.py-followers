# Dataset Clarification — 2095

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 18 dikurangi 12?
A: 6.

Q: Berapa 11 dikali 3?
A: 33.

Q: Cari sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikurangi 3?
A: 0.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Tolong buat yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Bikin yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 ditambah 18?
A: 33.

Q: Kasih yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 ditambah 2?
A: 10.

Q: Berapa 9 dikali 9?
A: 81.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Tolong buat yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Analisis yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Cari yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikali 18?
A: 270.

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikali 18?
A: 306.

Q: Jelaskan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 20 ditambah 16?
A: 36.

Q: Berapa 4 ditambah 8?
A: 12.

Q: Berapa 17 dikurangi 1?
A: 16.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Sesuaikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikali 9?
A: 126.

Q: Buatkan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikurangi 14?
A: 1.

Q: Perbaiki sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 1 ditambah 9?
A: 10.

Q: Berikan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 dikali 3?
A: 39.

Q: Berapa 15 dikurangi 8?
A: 7.
