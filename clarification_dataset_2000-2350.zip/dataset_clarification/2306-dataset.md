# Dataset Clarification — 2306

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 5 dikurangi 1?
A: 4.

Q: Berapa 7 ditambah 4?
A: 11.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 18 dikali 12?
A: 216.

Q: Berapa 6 dikali 15?
A: 90.

Q: Berapa 14 dikali 4?
A: 56.

Q: Berapa 19 ditambah 10?
A: 29.

Q: Berapa 7 dikali 1?
A: 7.

Q: Buatkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Saya mau yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dikali 1?
A: 4.

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Hitung yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dikali 1?
A: 5.

Q: Hitung yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Sesuaikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 ditambah 17?
A: 25.

Q: Kasih yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 ditambah 13?
A: 27.

Q: Berapa 18 dikurangi 8?
A: 10.

Q: Ubah yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 ditambah 14?
A: 20.

Q: Rapikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 dikali 5?
A: 70.

Q: Jelaskan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Rapikan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Mohon buatkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Saya mau sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikurangi 1?
A: 7.
