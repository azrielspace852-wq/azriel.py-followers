# Dataset Clarification — 2083

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Saya butuh sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Tolong buat yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Pilihkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Hitung yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Cari yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Cek yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Saya butuh yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang detail.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Ubah yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Cari yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Berikan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Tampilkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Cek yang murah.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Saya mau yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.
