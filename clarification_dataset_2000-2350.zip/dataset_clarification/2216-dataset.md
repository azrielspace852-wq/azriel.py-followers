# Dataset Clarification — 2216

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 1 ditambah 11?
A: 12.

Q: Saya butuh yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 3 ditambah 9?
A: 12.

Q: Berapa 19 ditambah 17?
A: 36.

Q: Berikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Cek yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 ditambah 7?
A: 18.

Q: Berapa 20 dikali 7?
A: 140.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Perbaiki yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Berapa 8 ditambah 15?
A: 23.

Q: Kasih hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 ditambah 2?
A: 11.

Q: Tolong buat yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Ceritakan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikali 14?
A: 238.

Q: Bikin yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 dikali 12?
A: 156.

Q: Hitung yang pas.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Berapa 11 ditambah 10?
A: 21.

Q: Saya mau yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 4 dikali 17?
A: 68.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Sesuaikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau hal itu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 20 dikurangi 4?
A: 16.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 16 ditambah 2?
A: 18.

Q: Ceritakan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 1?
A: 1.

Q: Kasih hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 ditambah 6?
A: 19.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 8 dibagi 4?
A: 2.
