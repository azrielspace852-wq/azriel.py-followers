# Dataset Clarification — 2275

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 1 dikali 14?
A: 14.

Q: Bikin yang sana.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 ditambah 2?
A: 18.

Q: Cek yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Cari yang ini.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikurangi 8?
A: 4.

Q: Sesuaikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 ditambah 20?
A: 32.

Q: Bikin hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 ditambah 7?
A: 16.

Q: Tampilkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Cek yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Perbaiki yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 17 dikurangi 1?
A: 16.

Q: Berapa 7 ditambah 7?
A: 14.

Q: Berapa 8 dikali 3?
A: 24.

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Saya mau yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Saya mau yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 7?
A: 126.

Q: Saya butuh yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 7 dikali 2?
A: 14.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Saya mau yang itu.
A: Bisa. Untuk keperluan apa?
