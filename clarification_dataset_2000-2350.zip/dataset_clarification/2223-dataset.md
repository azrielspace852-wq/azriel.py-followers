# Dataset Clarification — 2223

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cek yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Saya butuh yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Berikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Ubah yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Ubah yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Sesuaikan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Cek seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Berikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Ceritakan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Saya mau seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Rapikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Bikin yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Mohon buatkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Sesuaikan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Kasih yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.
