# Dataset Clarification — 2266

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Cari yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 ditambah 13?
A: 30.

Q: Saya mau yang detail.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 9 ditambah 1?
A: 10.

Q: Berapa 10 dikurangi 9?
A: 1.

Q: Cek yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 5 dikali 9?
A: 45.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Berapa 5 ditambah 9?
A: 14.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 4 ditambah 2?
A: 6.

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Jelaskan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Analisis yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikali 3?
A: 57.

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Berapa 10 dikurangi 8?
A: 2.

Q: Pilihkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 ditambah 15?
A: 18.

Q: Hitung yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 6?
A: 72.

Q: Berapa 19 ditambah 8?
A: 27.

Q: Berikan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Berapa 9 ditambah 19?
A: 28.

Q: Berapa 18 dikurangi 12?
A: 6.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Analisis yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 ditambah 5?
A: 14.

Q: Berapa 19 dikurangi 14?
A: 5.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Bikin yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Rapikan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?
