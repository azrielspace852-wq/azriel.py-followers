# Dataset Clarification — 2209

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 19 dikurangi 3?
A: 16.

Q: Saya mau yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikali 20?
A: 400.

Q: Berapa 9 ditambah 6?
A: 15.

Q: Analisis yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 7?
A: 0.

Q: Ceritakan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 7 ditambah 19?
A: 26.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Rapikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Tolong buat yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 12?
A: 180.

Q: Jelaskan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 8 dikali 6?
A: 48.

Q: Berapa 11 ditambah 17?
A: 28.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Hitung yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 12?
A: 18.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Tolong buat yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikali 5?
A: 50.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Cari sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Berapa 2 dikali 5?
A: 10.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Ubah yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikurangi 8?
A: 1.

Q: Sesuaikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 16 ditambah 18?
A: 34.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Saya mau yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Sesuaikan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan sesuatu.
A: Tentu. Yang mana yang Anda maksud?
