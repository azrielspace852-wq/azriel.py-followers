# Dataset Clarification — 2253

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang detail.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Jelaskan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang keren.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Cek yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Jelaskan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Jelaskan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Rapikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Tolong buat seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang ini.
A: Siap. Tentang apa tepatnya?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya mau yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Ubah yang murah.
A: Bisa. Untuk tujuan apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.
