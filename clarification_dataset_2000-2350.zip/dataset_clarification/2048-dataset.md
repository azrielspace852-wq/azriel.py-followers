# Dataset Clarification — 2048

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 1?
A: 7.

Q: Saya mau yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 6?
A: 54.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 15 dikali 20?
A: 300.

Q: Kasih hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 ditambah 2?
A: 14.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Berapa 14 dikali 9?
A: 126.

Q: Rapikan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dikali 7?
A: 70.

Q: Bikin yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang keren.
A: Bisa. Untuk tujuan apa?

Q: Saya mau sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Cari yang sana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 ditambah 4?
A: 6.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 11 dikali 11?
A: 121.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 14 ditambah 11?
A: 25.

Q: Saya mau sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Berapa 18 dikurangi 8?
A: 10.

Q: Berapa 3 ditambah 4?
A: 7.

Q: Tolong buat yang sana.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 ditambah 9?
A: 10.

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Cek yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 dikali 20?
A: 80.

Q: Berapa 9 ditambah 12?
A: 21.

Q: Berapa 11 dikali 2?
A: 22.

Q: Analisis yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 7 dikali 14?
A: 98.

Q: Analisis yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dikali 10?
A: 150.

Q: Mohon buatkan hal itu.
A: Siap. Tentang apa tepatnya?
