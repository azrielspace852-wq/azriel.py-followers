# Dataset Clarification — 2196

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Hitung yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dikali 4?
A: 32.

Q: Berapa 12 dikali 17?
A: 204.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Bikin hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 7 ditambah 18?
A: 25.

Q: Cari yang keren.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang itu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 2 ditambah 4?
A: 6.

Q: Cek yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Berapa 2 dikali 13?
A: 26.

Q: Bikin yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikali 12?
A: 144.

Q: Berikan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 dikali 8?
A: 56.

Q: Kasih seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 18 dikurangi 15?
A: 3.

Q: Berapa 2 ditambah 15?
A: 17.

Q: Bikin yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Ceritakan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 dikali 8?
A: 56.

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 2?
A: 3.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Saya mau yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Saya mau yang detail.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang murah.
A: Siap. Yang mana yang dimaksud?
