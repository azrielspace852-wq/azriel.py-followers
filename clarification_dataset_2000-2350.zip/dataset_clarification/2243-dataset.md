# Dataset Clarification — 2243

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Ceritakan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Tolong buat sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang pas.
A: Bisa. Untuk keperluan apa?

Q: Cari yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Sesuaikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Rapikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Cek sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Pilihkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Analisis sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Cek yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Saya mau seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Berikan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Hitung yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Analisis seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Hitung hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Hitung yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Pilihkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.
