# Dataset Clarification — 2205

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 9 dikurangi 5?
A: 4.

Q: Saya mau hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 ditambah 20?
A: 32.

Q: Saya mau yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Saya mau yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Tampilkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikali 14?
A: 280.

Q: Ceritakan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 10?
A: 27.

Q: Tolong buat yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Saya butuh yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 ditambah 17?
A: 28.

Q: Saya mau yang keren.
A: Bisa. Untuk keperluan apa?

Q: Bikin seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikali 9?
A: 90.

Q: Bikin yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Cari yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 dikali 4?
A: 28.

Q: Kasih yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Cari hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 ditambah 7?
A: 21.

Q: Saya mau yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Perbaiki yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 ditambah 20?
A: 37.

Q: Mohon buatkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 8?
A: 21.

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Rapikan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 19 ditambah 14?
A: 33.

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Pilihkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Berapa 17 dikurangi 10?
A: 7.

Q: Berapa 11 dikali 15?
A: 165.

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Saya butuh yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 9?
A: 90.

Q: Saya mau yang detail.
A: Tentu. Konteksnya seperti apa?
