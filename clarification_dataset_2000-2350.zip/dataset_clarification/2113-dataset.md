# Dataset Clarification — 2113

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Sesuaikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Sesuaikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Saya butuh yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Kasih yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Tampilkan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Ubah yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Tolong buat seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Sesuaikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Perbaiki yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Jelaskan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Analisis yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Tampilkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Sesuaikan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Berikan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Kasih hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama platform streaming film yang populer?
A: Netflix.
