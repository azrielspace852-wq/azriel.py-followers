# Dataset Clarification — 2039

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikali 9?
A: 135.

Q: Saya butuh hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Rapikan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Kasih hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikali 3?
A: 36.

Q: Jelaskan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 4 dikali 14?
A: 56.

Q: Berapa 5 ditambah 14?
A: 19.

Q: Berapa 19 dikurangi 11?
A: 8.

Q: Berapa 2 dikali 1?
A: 2.

Q: Berapa 3 ditambah 8?
A: 11.

Q: Ubah yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikali 3?
A: 54.

Q: Ceritakan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 13?
A: 143.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Berapa 17 dikali 7?
A: 119.

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Ubah yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikurangi 5?
A: 9.

Q: Buatkan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Berapa 5 ditambah 15?
A: 20.

Q: Buatkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 19?
A: 361.

Q: Berapa 6 dikali 10?
A: 60.

Q: Saya mau yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 ditambah 20?
A: 34.

Q: Hitung yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 12 ditambah 13?
A: 25.

Q: Jelaskan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Cari yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 ditambah 9?
A: 28.

Q: Berikan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 ditambah 6?
A: 22.

Q: Bikin yang sederhana.
A: Siap. Tentang apa tepatnya?
