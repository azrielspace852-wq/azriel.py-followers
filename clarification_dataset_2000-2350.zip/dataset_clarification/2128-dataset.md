# Dataset Clarification — 2128

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Hitung yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikali 13?
A: 143.

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Kasih yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Cari seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 ditambah 3?
A: 20.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 11 dikurangi 3?
A: 8.

Q: Berapa 18 dikali 4?
A: 72.

Q: Berapa 8 dikali 18?
A: 144.

Q: Berapa 18 ditambah 12?
A: 30.

Q: Berapa 7 dikali 5?
A: 35.

Q: Berikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 ditambah 8?
A: 16.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Cek yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikali 9?
A: 54.

Q: Tolong buat sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Sesuaikan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Ubah yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikali 1?
A: 16.

Q: Berapa 4 ditambah 19?
A: 23.

Q: Cari yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Ubah seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 dikali 1?
A: 3.

Q: Saya butuh yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Sesuaikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Saya mau yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang keren.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 ditambah 4?
A: 13.
