# Dataset Clarification — 2163

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Mohon buatkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Buatkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Cari yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Ubah yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Cek yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Saya butuh yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Jelaskan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Berikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Ubah yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Tolong buat sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang ini.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Cari yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Pilihkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.
