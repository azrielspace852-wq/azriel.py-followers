# Dataset Clarification — 2315

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Hitung sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 ditambah 12?
A: 32.

Q: Saya mau yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 dikali 6?
A: 42.

Q: Analisis sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 8?
A: 128.

Q: Jelaskan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 18 ditambah 15?
A: 33.

Q: Berapa 12 dikali 12?
A: 144.

Q: Berapa 9 ditambah 13?
A: 22.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Buatkan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 16 dikurangi 16?
A: 0.

Q: Berapa 19 dikali 3?
A: 57.

Q: Pilihkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Pilihkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Berapa 19 dikali 20?
A: 380.

Q: Saya mau hal itu.
A: Bisa. Untuk tujuan apa?

Q: Cari yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 16?
A: 3.

Q: Buatkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Cek yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 ditambah 15?
A: 18.

Q: Rapikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Rapikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 ditambah 11?
A: 26.

Q: Berapa 15 dikali 18?
A: 270.

Q: Sesuaikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?
