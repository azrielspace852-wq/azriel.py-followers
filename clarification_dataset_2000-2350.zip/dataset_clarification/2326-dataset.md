# Dataset Clarification — 2326

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 7 dikali 18?
A: 126.

Q: Bikin yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Cari yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 4?
A: 76.

Q: Tolong buat seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Jelaskan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikali 6?
A: 54.

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Hitung yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 6?
A: 17.

Q: Buatkan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 3 ditambah 12?
A: 15.

Q: Kasih seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Mohon buatkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Berapa 18 dikali 5?
A: 90.

Q: Analisis yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikurangi 9?
A: 10.

Q: Berapa 19 dikali 2?
A: 38.

Q: Berapa 6 ditambah 18?
A: 24.

Q: Berapa 19 dikali 9?
A: 171.

Q: Berapa 12 ditambah 4?
A: 16.

Q: Cek yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 ditambah 19?
A: 26.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Saya mau yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 6 ditambah 17?
A: 23.

Q: Berapa 11 dikurangi 9?
A: 2.
