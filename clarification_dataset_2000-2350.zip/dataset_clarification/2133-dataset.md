# Dataset Clarification — 2133

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Hitung yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Berikan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Mohon buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Ubah seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Analisis yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Pilihkan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Ubah sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Rapikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Cek yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Cari yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang pas.
A: Siap. Tentang apa tepatnya?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Rapikan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Perbaiki yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Hitung yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Rapikan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Berikan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.
