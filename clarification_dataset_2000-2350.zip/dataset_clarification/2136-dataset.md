# Dataset Clarification — 2136

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Saya butuh yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 ditambah 6?
A: 10.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Perbaiki yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang sana.
A: Siap. Tentang apa tepatnya?

Q: Cek sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Cek yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 19 ditambah 8?
A: 27.

Q: Buatkan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 14 ditambah 13?
A: 27.

Q: Ubah yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 ditambah 20?
A: 30.

Q: Hitung seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Kasih hal itu.
A: Bisa. Untuk tujuan apa?

Q: Cari yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dikali 16?
A: 80.

Q: Berikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikali 15?
A: 180.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Berapa 5 dikali 4?
A: 20.

Q: Rapikan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 ditambah 19?
A: 27.

Q: Berapa 20 dikali 2?
A: 40.

Q: Berapa 12 dikurangi 2?
A: 10.

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 6 ditambah 5?
A: 11.

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 8 dibagi 2?
A: 4.
