# Dataset Clarification — 2047

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Tampilkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikurangi 1?
A: 13.

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 ditambah 14?
A: 19.

Q: Berikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 ditambah 19?
A: 32.

Q: Berapa 7 ditambah 15?
A: 22.

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Hitung seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Berapa 16 ditambah 20?
A: 36.

Q: Saya butuh seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 ditambah 20?
A: 23.

Q: Saya mau yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 5 ditambah 11?
A: 16.

Q: Ubah yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki hal itu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 ditambah 9?
A: 27.

Q: Berikan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 2 ditambah 8?
A: 10.

Q: Berikan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Mohon buatkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Cek yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Rapikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 ditambah 11?
A: 19.

Q: Berapa 19 ditambah 3?
A: 22.

Q: Berapa 20 dikurangi 20?
A: 0.

Q: Berapa 17 dikali 18?
A: 306.

Q: Berapa 6 ditambah 5?
A: 11.

Q: Jelaskan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 15 dikali 7?
A: 105.

Q: Perbaiki yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 100 dibagi 10?
A: 10.
