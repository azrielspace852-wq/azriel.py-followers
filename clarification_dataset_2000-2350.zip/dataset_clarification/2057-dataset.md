# Dataset Clarification — 2057

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cek yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Hitung yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikali 17?
A: 340.

Q: Mohon buatkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikali 11?
A: 33.

Q: Berapa 19 dikali 4?
A: 76.

Q: Berapa 18 ditambah 12?
A: 30.

Q: Tolong buat yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikali 11?
A: 33.

Q: Kasih yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 12 dikali 3?
A: 36.

Q: Pilihkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikali 12?
A: 144.

Q: Tolong buat seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 12 dikurangi 2?
A: 10.

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Jelaskan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikali 19?
A: 114.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Berapa 15 dikali 5?
A: 75.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Rapikan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikurangi 3?
A: 8.

Q: Berapa 4 dikali 18?
A: 72.

Q: Tolong buat yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Tampilkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikali 2?
A: 22.

Q: Sesuaikan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 ditambah 10?
A: 17.

Q: Mohon buatkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 4?
A: 19.

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang ini.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 2 ditambah 11?
A: 13.

Q: Ubah yang bagus.
A: Baik. Bisa dijelaskan lebih detail?
