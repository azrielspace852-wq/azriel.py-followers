# Dataset Clarification — 2076

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Pilihkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Kasih yang sana.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 6 ditambah 17?
A: 23.

Q: Kasih yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Bikin yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 6?
A: 12.

Q: Berapa 2 dikali 15?
A: 30.

Q: Rapikan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 8?
A: 16.

Q: Perbaiki yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 17?
A: 204.

Q: Analisis yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikali 16?
A: 304.

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Berapa 15 dikali 15?
A: 225.

Q: Saya butuh yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Bikin yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Pilihkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Saya butuh sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 11 ditambah 13?
A: 24.

Q: Tampilkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 1 dikali 6?
A: 6.

Q: Ubah yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 ditambah 13?
A: 27.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 6 dikali 11?
A: 66.

Q: Tampilkan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikali 7?
A: 84.

Q: Kasih yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Bikin yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 ditambah 10?
A: 14.
