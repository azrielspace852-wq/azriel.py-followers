# Dataset Clarification — 2203

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Perbaiki yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Hitung yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Mohon buatkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Berikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Saya butuh yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Rapikan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Ceritakan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Rapikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Tolong buat hal itu.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Hitung yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Analisis yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.
