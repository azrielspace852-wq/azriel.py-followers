# Dataset Clarification — 2316

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dikali 4?
A: 32.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Ubah yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Mohon buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 dikali 15?
A: 165.

Q: Berapa 17 ditambah 20?
A: 37.

Q: Hitung yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 dikali 3?
A: 12.

Q: Analisis yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikali 14?
A: 210.

Q: Berapa 12 dikurangi 1?
A: 11.

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Berapa 18 ditambah 7?
A: 25.

Q: Pilihkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Saya mau yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Ubah seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 dikurangi 10?
A: 0.

Q: Berapa 16 ditambah 19?
A: 35.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 15 ditambah 2?
A: 17.

Q: Hitung yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Cek sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berikan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Perbaiki yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Ubah yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang itu.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 19 ditambah 9?
A: 28.
