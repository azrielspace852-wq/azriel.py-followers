# Dataset Clarification — 2134

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 4?
A: 7.

Q: Berikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Tolong buat yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Perbaiki yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Ceritakan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Kasih yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Buatkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Cari yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Saya butuh yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Pilihkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Cek yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 3?
A: 48.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Saya butuh yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Ubah yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Rapikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Kasih yang ini.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang sana.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.
