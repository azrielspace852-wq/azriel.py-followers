# Dataset Clarification — 2073

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Cek yang detail.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Cek sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang ini.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Mohon buatkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Bikin yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang keren.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang pas.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Analisis yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Analisis yang sana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Kasih yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Mohon buatkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Saya butuh yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Rapikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.
