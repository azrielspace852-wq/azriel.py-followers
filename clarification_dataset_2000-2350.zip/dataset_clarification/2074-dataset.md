# Dataset Clarification — 2074

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Mohon buatkan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 7 ditambah 2?
A: 9.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Bikin yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Saya butuh yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama satuan energi?
A: Joule.

Q: Jelaskan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Analisis yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Tolong buat yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Buatkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Tolong buat yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berapa 5 ditambah 12?
A: 17.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Tolong buat yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Kasih yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Hitung yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Pilihkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Tampilkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sendi di lutut?
A: Sendi lutut.
