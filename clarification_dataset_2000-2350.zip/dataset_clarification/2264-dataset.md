# Dataset Clarification — 2264

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Pilihkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ceritakan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Cari yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Cek yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama satuan energi?
A: Joule.

Q: Analisis yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Hitung yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Analisis yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Kasih yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Sesuaikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Ubah yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang ini.
A: Bisa. Untuk tujuan apa?

Q: Cari seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 4?
A: 4.
