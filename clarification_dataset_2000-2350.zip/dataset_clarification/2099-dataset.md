# Dataset Clarification — 2099

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Buatkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 ditambah 6?
A: 18.

Q: Hitung yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Tolong buat yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 17 ditambah 19?
A: 36.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Hitung yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikurangi 9?
A: 4.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 9 dikali 16?
A: 144.

Q: Berapa 18 ditambah 13?
A: 31.

Q: Saya butuh seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 11?
A: 8.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Jelaskan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikali 15?
A: 210.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 14 ditambah 10?
A: 24.

Q: Saya mau yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang sana.
A: Siap. Tentang apa tepatnya?

Q: Rapikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 dikali 1?
A: 11.

Q: Bikin yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 12?
A: 3.

Q: Berapa 9 dikali 19?
A: 171.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Tolong buat yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 ditambah 11?
A: 27.

Q: Berapa 7 dikali 18?
A: 126.

Q: Berapa 15 dikali 5?
A: 75.

Q: Berapa 20 ditambah 13?
A: 33.

Q: Berapa 17 dikali 4?
A: 68.

Q: Bikin yang murah.
A: Bisa. Untuk keperluan apa?

Q: Cek yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Jelaskan yang sederhana.
A: Siap. Maksudnya yang seperti apa?
