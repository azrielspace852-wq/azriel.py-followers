# Dataset Clarification — 2064

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang ini.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama indera perasa?
A: Lidah.

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Berikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Bikin sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Saya butuh yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Mohon buatkan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Saya mau yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Rapikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Pilihkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Cari yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berikan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Ceritakan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Sesuaikan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Cek yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan energi?
A: Joule.
