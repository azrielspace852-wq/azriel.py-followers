# Dataset Clarification — 2085

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 ditambah 2?
A: 14.

Q: Buatkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 2?
A: 4.

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Berapa 2 ditambah 3?
A: 5.

Q: Berapa 2 dikali 1?
A: 2.

Q: Jelaskan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dikali 13?
A: 208.

Q: Tolong buat yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 ditambah 5?
A: 12.

Q: Berapa 5 dikali 19?
A: 95.

Q: Pilihkan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikurangi 13?
A: 3.

Q: Saya mau yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang murah.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 ditambah 20?
A: 23.

Q: Berapa 8 ditambah 16?
A: 24.

Q: Sesuaikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 ditambah 4?
A: 17.

Q: Berapa 4 dikurangi 4?
A: 0.

Q: Berapa 16 ditambah 12?
A: 28.

Q: Tampilkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Berapa 18 dikali 3?
A: 54.

Q: Jelaskan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Tolong buat hal itu.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 ditambah 19?
A: 29.

Q: Bikin yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 ditambah 6?
A: 14.

Q: Berapa 1 ditambah 12?
A: 13.

Q: Berapa 18 dikurangi 17?
A: 1.

Q: Mohon buatkan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 dikali 20?
A: 60.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Jelaskan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 ditambah 14?
A: 24.

Q: Berapa 15 ditambah 6?
A: 21.
