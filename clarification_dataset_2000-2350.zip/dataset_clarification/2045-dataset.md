# Dataset Clarification — 2045

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cek seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 9 dikurangi 1?
A: 8.

Q: Bikin yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikurangi 9?
A: 1.

Q: Saya butuh yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Kasih yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 2 dikali 5?
A: 10.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Hitung yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 20 dikali 18?
A: 360.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 17 dikali 18?
A: 306.

Q: Berapa 13 dikali 1?
A: 13.

Q: Bikin yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang sana.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 5 dikali 2?
A: 10.

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikali 6?
A: 42.

Q: Sesuaikan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 ditambah 4?
A: 16.

Q: Jelaskan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 ditambah 13?
A: 27.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 5 dikali 4?
A: 20.

Q: Tampilkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 dikali 7?
A: 21.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Ceritakan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Berapa 19 dikali 2?
A: 38.

Q: Mohon buatkan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang murah.
A: Siap. Tentang apa tepatnya?
