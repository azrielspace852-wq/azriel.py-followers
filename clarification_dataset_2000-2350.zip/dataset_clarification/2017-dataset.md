# Dataset Clarification — 2017

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikali 14?
A: 126.

Q: Hitung yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Pilihkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 ditambah 9?
A: 28.

Q: Berapa 18 ditambah 12?
A: 30.

Q: Pilihkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikurangi 14?
A: 1.

Q: Berapa 1 dikali 1?
A: 1.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 9 dikali 12?
A: 108.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 8 ditambah 5?
A: 13.

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 8 dikali 2?
A: 16.

Q: Saya mau yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Rapikan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Berapa 10 dikali 1?
A: 10.

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Berapa 12 ditambah 4?
A: 16.

Q: Bikin yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 ditambah 4?
A: 21.

Q: Rapikan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikali 13?
A: 117.

Q: Ceritakan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 ditambah 6?
A: 26.

Q: Berapa 8 ditambah 17?
A: 25.

Q: Berapa 12 dikali 4?
A: 48.

Q: Cari seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikali 5?
A: 35.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Bikin yang pas.
A: Siap. Maksudnya yang seperti apa?
