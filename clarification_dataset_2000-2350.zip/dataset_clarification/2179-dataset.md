# Dataset Clarification — 2179

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dikurangi 7?
A: 5.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 20 dikali 18?
A: 360.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 4 dikali 6?
A: 24.

Q: Perbaiki yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 ditambah 13?
A: 15.

Q: Berapa 4 dikali 6?
A: 24.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Kasih yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 ditambah 12?
A: 22.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Cari yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 dikurangi 5?
A: 3.

Q: Cek yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Ubah hal itu.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 20?
A: 80.

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Buatkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 11?
A: 44.

Q: Berapa 16 dikali 11?
A: 176.

Q: Berapa 17 ditambah 5?
A: 22.

Q: Ceritakan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Buatkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Berapa 8 dikali 1?
A: 8.

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Cari yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Bikin yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikali 6?
A: 90.

Q: Berapa 1 dikali 5?
A: 5.

Q: Tolong buat yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikurangi 16?
A: 4.
