# Dataset Clarification — 2236

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang itu.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 dikali 9?
A: 117.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Saya butuh sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 16?
A: 2.

Q: Berapa 16 dikurangi 12?
A: 4.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Jelaskan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Rapikan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikali 13?
A: 208.

Q: Jelaskan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikali 13?
A: 260.

Q: Bikin yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 11?
A: 176.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Buatkan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Bikin yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Buatkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikali 12?
A: 192.

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Berapa 4 ditambah 4?
A: 8.

Q: Tolong buat yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Analisis yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Cari yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dikali 4?
A: 40.

Q: Rapikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 9 dikurangi 1?
A: 8.

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Jelaskan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dikurangi 1?
A: 4.

Q: Berapa 5 ditambah 5?
A: 10.

Q: Jelaskan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikurangi 7?
A: 8.
