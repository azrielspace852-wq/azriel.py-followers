# Dataset Clarification — 2098

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 ditambah 4?
A: 19.

Q: Ceritakan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikali 6?
A: 102.

Q: Hitung yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikurangi 13?
A: 3.

Q: Rapikan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikurangi 13?
A: 0.

Q: Berapa 18 ditambah 14?
A: 32.

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Berapa 9 dikurangi 9?
A: 0.

Q: Saya butuh yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 ditambah 11?
A: 15.

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Berapa 18 dikali 15?
A: 270.

Q: Perbaiki yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang itu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Kasih sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 ditambah 7?
A: 24.

Q: Berapa 13 dikurangi 11?
A: 2.

Q: Analisis yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 ditambah 20?
A: 34.

Q: Berapa 4 ditambah 16?
A: 20.

Q: Tampilkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 16 ditambah 1?
A: 17.

Q: Saya mau yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 ditambah 6?
A: 14.

Q: Berapa 10 dikurangi 1?
A: 9.

Q: Kasih yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 ditambah 18?
A: 22.

Q: Berapa 8 dikali 10?
A: 80.

Q: Mohon buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikurangi 19?
A: 0.

Q: Pilihkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 7?
A: 7.

Q: Berikan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Cari yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 20 ditambah 8?
A: 28.

Q: Pilihkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang cocok.
A: Tentu. Konteksnya seperti apa?
