# Dataset Clarification — 2338

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Berapa 5 dikali 6?
A: 30.

Q: Berapa 11 ditambah 3?
A: 14.

Q: Kasih yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 ditambah 14?
A: 29.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 7 ditambah 1?
A: 8.

Q: Berapa 10 dikali 15?
A: 150.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Kasih yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 ditambah 17?
A: 37.

Q: Pilihkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Cek seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Mohon buatkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikali 7?
A: 49.

Q: Berapa 16 ditambah 1?
A: 17.

Q: Berapa 16 ditambah 1?
A: 17.

Q: Cari yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Ubah hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikali 14?
A: 224.

Q: Hitung hal itu.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 1 dikali 6?
A: 6.

Q: Berapa 18 dikurangi 11?
A: 7.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Jelaskan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berikan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Rapikan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Saya mau yang sana.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang keren.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dikali 14?
A: 28.

Q: Tolong buat yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 ditambah 15?
A: 18.

Q: Berapa 3 dikali 6?
A: 18.

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Saya mau sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Berapa 13 dikurangi 2?
A: 11.

Q: Berapa 5 dikali 19?
A: 95.
