# Dataset Clarification — 2049

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tolong buat yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 9 dikali 11?
A: 99.

Q: Cek yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Cari yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Pilihkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Cek yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 17 ditambah 13?
A: 30.

Q: Berapa 20 dikurangi 2?
A: 18.

Q: Berapa 15 ditambah 11?
A: 26.

Q: Cari seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikurangi 4?
A: 7.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Analisis yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Cari yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 1 dikali 15?
A: 15.

Q: Berapa 1 ditambah 19?
A: 20.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Rapikan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 9?
A: 10.

Q: Tampilkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 9?
A: 10.

Q: Berapa 2 ditambah 11?
A: 13.

Q: Mohon buatkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Mohon buatkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikali 12?
A: 156.

Q: Ubah yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 3 dikali 1?
A: 3.

Q: Analisis yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikali 13?
A: 247.

Q: Hitung yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 1 ditambah 17?
A: 18.

Q: Cek hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Tampilkan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?
