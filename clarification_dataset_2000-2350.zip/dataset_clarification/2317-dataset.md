# Dataset Clarification — 2317

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Berapa 3 dikali 1?
A: 3.

Q: Saya butuh yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Berapa 15 dikali 19?
A: 285.

Q: Berapa 9 dikurangi 3?
A: 6.

Q: Mohon buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 dikurangi 1?
A: 1.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 10 dikali 1?
A: 10.

Q: Berikan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang ini.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Berapa 16 dikali 6?
A: 96.

Q: Berapa 13 dikurangi 5?
A: 8.

Q: Berapa 17 ditambah 9?
A: 26.

Q: Buatkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Saya butuh yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 ditambah 5?
A: 20.

Q: Kasih yang itu.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Sesuaikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Ceritakan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 9 ditambah 5?
A: 14.

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Analisis yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang detail.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 10?
A: 180.

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Bikin seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 2?
A: 36.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berikan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang itu.
A: Bisa. Untuk tujuan apa?
