# Dataset Clarification — 2318

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 ditambah 17?
A: 24.

Q: Berapa 11 dikurangi 4?
A: 7.

Q: Analisis yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 18 dikurangi 10?
A: 8.

Q: Berapa 8 dikali 14?
A: 112.

Q: Rapikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Buatkan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 ditambah 17?
A: 24.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 2 ditambah 8?
A: 10.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Cari yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Rapikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 dikali 16?
A: 176.

Q: Berapa 20 ditambah 20?
A: 40.

Q: Cek yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Analisis yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 ditambah 19?
A: 30.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 11 ditambah 4?
A: 15.

Q: Mohon buatkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 1 ditambah 20?
A: 21.

Q: Saya butuh yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikali 1?
A: 17.

Q: Cari yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berikan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 11?
A: 198.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 8 dikurangi 5?
A: 3.

Q: Sesuaikan yang bagus.
A: Tentu. Konteksnya seperti apa?
