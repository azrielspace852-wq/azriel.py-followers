# Dataset Clarification — 2149

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Tolong buat yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 6 ditambah 13?
A: 19.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Saya butuh yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dikali 14?
A: 56.

Q: Analisis yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikurangi 8?
A: 6.

Q: Analisis yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Sesuaikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 dikali 6?
A: 12.

Q: Berapa 14 dikurangi 7?
A: 7.

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 ditambah 19?
A: 23.

Q: Berapa 10 dikali 4?
A: 40.

Q: Berapa 15 dikali 15?
A: 225.

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Berapa 7 ditambah 1?
A: 8.

Q: Ubah yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Kasih seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Hitung yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Cek yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 3?
A: 54.

Q: Pilihkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 5?
A: 13.

Q: Berapa 9 dikurangi 4?
A: 5.

Q: Tampilkan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dikali 3?
A: 36.

Q: Tampilkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Cek yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikali 10?
A: 180.

Q: Saya butuh yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Cek yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 ditambah 19?
A: 38.
