# Dataset Clarification — 2124

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ubah yang pas.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 5 ditambah 6?
A: 11.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Rapikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Ubah hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 19?
A: 0.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Cek yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Perbaiki yang ini.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Rapikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Saya butuh yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama indera perasa?
A: Lidah.

Q: Analisis hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Analisis seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 dikurangi 1?
A: 8.

Q: Cari yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang keren.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.
