# Dataset Clarification — 2214

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Analisis yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang pas.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 6 dikali 14?
A: 84.

Q: Perbaiki seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama satuan energi?
A: Joule.

Q: Berikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Ubah yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Apa nama indera perasa?
A: Lidah.

Q: Pilihkan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Cek yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Berapa 15 ditambah 11?
A: 26.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Tolong buat yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Perbaiki yang detail.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Sesuaikan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Mohon buatkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Tolong buat yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dikurangi 1?
A: 1.

Q: Pilihkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang ini.
A: Baik. Bisa dijelaskan lebih detail?
