# Dataset Clarification — 2066

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 ditambah 20?
A: 30.

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Berapa 1 dikali 4?
A: 4.

Q: Tolong buat yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Berapa 20 dikali 13?
A: 260.

Q: Tolong buat yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Berapa 2 ditambah 6?
A: 8.

Q: Jelaskan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikali 16?
A: 256.

Q: Berapa 16 dikali 13?
A: 208.

Q: Ceritakan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Ubah sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Cari yang murah.
A: Bisa. Untuk tujuan apa?

Q: Cek yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Ubah seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikurangi 5?
A: 8.

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Rapikan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 ditambah 11?
A: 22.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 4 dikali 12?
A: 48.

Q: Berapa 4 dikali 5?
A: 20.

Q: Tolong buat yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikurangi 8?
A: 10.

Q: Berapa 15 dikali 11?
A: 165.

Q: Berapa 16 dikali 12?
A: 192.

Q: Berapa 8 ditambah 7?
A: 15.

Q: Tolong buat yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikali 20?
A: 340.

Q: Kasih sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 12 ditambah 19?
A: 31.

Q: Kasih yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 dikurangi 17?
A: 0.

Q: Ceritakan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang bagus.
A: Tentu. Yang mana yang Anda maksud?
