# Dataset Clarification — 2239

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 18 ditambah 15?
A: 33.

Q: Sesuaikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikali 4?
A: 68.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Sesuaikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikurangi 2?
A: 8.

Q: Berapa 2 dikurangi 1?
A: 1.

Q: Berapa 18 ditambah 8?
A: 26.

Q: Bikin yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Berapa 8 ditambah 15?
A: 23.

Q: Tolong buat hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 5?
A: 24.

Q: Berapa 18 dikurangi 15?
A: 3.

Q: Berapa 5 ditambah 2?
A: 7.

Q: Jelaskan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikali 12?
A: 108.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 12 dikali 14?
A: 168.

Q: Berapa 19 dikurangi 12?
A: 7.

Q: Berapa 11 ditambah 2?
A: 13.

Q: Berapa 12 ditambah 16?
A: 28.

Q: Hitung yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Cari yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Jelaskan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Saya butuh yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 2?
A: 21.

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Kasih yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 ditambah 10?
A: 13.

Q: Berapa 1 dikali 16?
A: 16.

Q: Bikin yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 dikali 6?
A: 6.

Q: Hitung yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang cocok.
A: Bisa. Untuk tujuan apa?
