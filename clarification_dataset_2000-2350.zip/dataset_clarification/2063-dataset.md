# Dataset Clarification — 2063

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya mau seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Hitung yang detail.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Cek yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Mohon buatkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Analisis yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Kasih yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Analisis yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Hitung yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Bikin sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Tolong buat yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Ubah hal itu.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Saya mau yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Jelaskan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.
