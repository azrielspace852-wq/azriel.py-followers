# Dataset Clarification — 2092

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Buat versi panjang.
A: Bisa. Versi panjang dari apa?

Q: Apa nama ibu kota Argentina?
A: Buenos Aires.

Q: Buat slide.
A: Siap. Slide tentang apa?

Q: Apa sila pertama Pancasila?
A: Ketuhanan Yang Maha Esa.

Q: Apa nama galaksi tempat Bumi berada?
A: Galaksi Bima Sakti.

Q: Sesuaikan dengan preferensi.
A: Baik. Preferensi yang seperti apa?

Q: Apa nama sistem operasi open source yang populer?
A: Linux.

Q: Apa sila kelima Pancasila?
A: Keadilan Sosial bagi Seluruh Rakyat Indonesia.

Q: Buat makna.
A: Bisa. Makna dari apa?

Q: Siapa presiden kedua Indonesia?
A: Soeharto.

Q: Buat lebih lembut.
A: Bisa. Teks yang mana yang ingin dibuat lembut?

Q: Perbaiki gaya bahasa.
A: Siap. Gaya bahasa pada teks yang mana?

Q: Sesuaikan dengan gaya.
A: Baik. Gaya yang seperti apa?

Q: Buat soal.
A: Baik. Soal tentang apa?

Q: Buat lebih meyakinkan.
A: Siap. Teks yang mana yang ingin dibuat meyakinkan?

Q: Siapa penemu telepon?
A: Alexander Graham Bell.

Q: Buat kuis.
A: Bisa. Kuis tentang apa?

Q: Apa nama benua yang paling dingin?
A: Antartika.

Q: Apa nama gurun terbesar di dunia?
A: Sahara.

Q: Siapa penemu penicilllin?
A: Alexander Fleming.

Q: Buat definisi.
A: Baik. Definisi tentang apa?

Q: Apa nama ibu kota Meksiko?
A: Kota Meksiko.

Q: Apa nama organisasi yang mendirikan negara Indonesia?
A: BPUPKI dan PPKI.

Q: Apa sila ketiga Pancasila?
A: Persatuan Indonesia.

Q: Apa nama bahasa pemrograman untuk database?
A: SQL.

Q: Perbaiki paragraf.
A: Baik. Paragraf yang mana?

Q: Apa nama aplikasi pesan instan yang populer di Indonesia?
A: WhatsApp.

Q: Buat versi informal.
A: Baik. Versi informal dari apa?

Q: Buat lebih sopan.
A: Baik. Teks yang mana yang ingin dibuat sopan?

Q: Sesuaikan dengan tujuan.
A: Siap. Tujuan yang seperti apa?

Q: Sesuaikan dengan target.
A: Siap. Target yang seperti apa?

Q: Perbaiki ejaan.
A: Bisa. Ejaan pada teks yang mana?

Q: Apa nama ideologi negara Indonesia?
A: Pancasila.

Q: Buat lebih santai.
A: Baik. Teks yang mana yang ingin dibuat santai?

Q: Buat versi Indonesia.
A: Siap. Versi Indonesia dari apa?

Q: Apa nama mesin pencari yang paling populer?
A: Google.

Q: Apa nama bahasa pemrograman yang populer untuk pemula?
A: Python.

Q: Kapan Indonesia merdeka?
A: 17 Agustus 1945.

Q: Buat versi kompleks.
A: Siap. Versi kompleks dari apa?

Q: Siapa penulis novel Bumi Manusia?
A: Pramoedya Ananta Toer.

Q: Apa nama sungai terpanjang di dunia?
A: Nil.

Q: Buat lebih mudah dipahami.
A: Bisa. Teks yang mana yang ingin disederhanakan?

Q: Buat ringkasan singkat.
A: Baik. Ringkasan singkat dari apa?

Q: Apa nama samudra terkecil?
A: Samudra Arktik.

Q: Sesuaikan dengan platform.
A: Bisa. Platform yang mana?

Q: Buat laporan.
A: Bisa. Laporan tentang apa?

Q: Buat jawaban.
A: Siap. Jawaban untuk pertanyaan apa?

Q: Siapa penulis novel Harry Potter?
A: J.K. Rowling.

Q: Siapa penemu gravitasi?
A: Isaac Newton.

Q: Apa nama planet yang memiliki cincin?
A: Saturnus.
