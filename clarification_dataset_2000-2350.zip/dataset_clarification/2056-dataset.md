# Dataset Clarification — 2056

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 12 dikali 8?
A: 96.

Q: Berapa 12 ditambah 8?
A: 20.

Q: Hitung yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 17 ditambah 1?
A: 18.

Q: Berapa 17 ditambah 6?
A: 23.

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Berapa 1 ditambah 9?
A: 10.

Q: Berapa 19 dikurangi 8?
A: 11.

Q: Berapa 12 dikurangi 1?
A: 11.

Q: Bikin yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dikali 13?
A: 130.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 6 dikali 11?
A: 66.

Q: Bikin yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikali 8?
A: 152.

Q: Jelaskan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dikali 5?
A: 50.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 1 ditambah 12?
A: 13.

Q: Cari yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 ditambah 13?
A: 25.

Q: Cek yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikali 19?
A: 209.

Q: Hitung yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Perbaiki yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikali 1?
A: 12.

Q: Tolong buat yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 ditambah 1?
A: 5.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berikan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Saya butuh yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dikali 1?
A: 8.
