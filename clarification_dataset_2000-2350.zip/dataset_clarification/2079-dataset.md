# Dataset Clarification — 2079

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dikali 5?
A: 50.

Q: Berapa 19 dikurangi 19?
A: 0.

Q: Berapa 18 dikurangi 17?
A: 1.

Q: Ceritakan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 ditambah 10?
A: 16.

Q: Ubah yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 5 dikali 7?
A: 35.

Q: Berapa 10 ditambah 14?
A: 24.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Berapa 8 dikali 6?
A: 48.

Q: Sesuaikan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 2?
A: 17.

Q: Cek yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Berapa 11 dikali 16?
A: 176.

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Rapikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Saya mau yang murah.
A: Bisa. Untuk keperluan apa?

Q: Cek hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 9 dikali 14?
A: 126.

Q: Pilihkan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 ditambah 5?
A: 22.

Q: Saya mau yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dikurangi 2?
A: 8.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Saya mau yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Kasih seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 ditambah 1?
A: 11.

Q: Jelaskan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 ditambah 3?
A: 11.

Q: Analisis yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 20?
A: 240.

Q: Berapa 11 ditambah 2?
A: 13.
