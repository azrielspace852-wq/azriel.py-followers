# Dataset Clarification — 2268

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikali 9?
A: 81.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Tampilkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Kasih yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 ditambah 1?
A: 15.

Q: Berapa 8 ditambah 15?
A: 23.

Q: Hitung yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Cari yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 6 ditambah 19?
A: 25.

Q: Berapa 17 dikurangi 17?
A: 0.

Q: Saya butuh yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Jelaskan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 3 dikali 1?
A: 3.

Q: Ubah hal itu.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Bikin yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Buatkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 ditambah 11?
A: 28.

Q: Ubah hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 ditambah 7?
A: 26.

Q: Rapikan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikali 16?
A: 176.

Q: Berapa 14 ditambah 2?
A: 16.

Q: Mohon buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Cek yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 ditambah 7?
A: 12.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Bikin sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin sesuatu.
A: Siap. Tentang apa tepatnya?
