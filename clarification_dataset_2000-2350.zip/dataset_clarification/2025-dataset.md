# Dataset Clarification — 2025

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dikali 11?
A: 110.

Q: Berapa 12 dikurangi 9?
A: 3.

Q: Kasih sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Mohon buatkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 ditambah 14?
A: 33.

Q: Berikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikali 7?
A: 28.

Q: Bikin yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Tampilkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 7 ditambah 15?
A: 22.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Buatkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikali 16?
A: 112.

Q: Berapa 4 ditambah 1?
A: 5.

Q: Mohon buatkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikali 20?
A: 260.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Ceritakan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 16 dikurangi 5?
A: 11.

Q: Saya butuh yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 dikali 19?
A: 190.

Q: Berapa 5 ditambah 12?
A: 17.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Bikin yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Pilihkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Buatkan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Berikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 dikali 8?
A: 40.

Q: Berapa 100 dibagi 10?
A: 10.
