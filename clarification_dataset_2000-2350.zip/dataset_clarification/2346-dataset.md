# Dataset Clarification — 2346

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 19 dikali 16?
A: 304.

Q: Berapa 9 dikurangi 5?
A: 4.

Q: Berapa 2 ditambah 19?
A: 21.

Q: Tampilkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Cari yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikurangi 4?
A: 4.

Q: Berapa 11 dikurangi 1?
A: 10.

Q: Berapa 2 ditambah 15?
A: 17.

Q: Berikan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikali 17?
A: 204.

Q: Cari yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 17 ditambah 3?
A: 20.

Q: Analisis yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dikali 17?
A: 68.

Q: Berapa 20 dikali 6?
A: 120.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 1 dikurangi 1?
A: 0.

Q: Berapa 5 dikali 7?
A: 35.

Q: Ubah sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Bikin yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikali 2?
A: 14.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Analisis yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 ditambah 5?
A: 23.

Q: Sesuaikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 ditambah 9?
A: 26.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Ubah yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Perbaiki sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang pas.
A: Bisa. Untuk keperluan apa?
