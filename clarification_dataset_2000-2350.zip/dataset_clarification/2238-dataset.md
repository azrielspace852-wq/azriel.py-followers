# Dataset Clarification — 2238

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Ceritakan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 1 dikali 18?
A: 18.

Q: Cari sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikali 15?
A: 225.

Q: Mohon buatkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 ditambah 19?
A: 20.

Q: Rapikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 dikali 13?
A: 78.

Q: Berapa 12 ditambah 11?
A: 23.

Q: Berapa 10 ditambah 12?
A: 22.

Q: Berapa 8 dikali 1?
A: 8.

Q: Rapikan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 6?
A: 12.

Q: Berapa 8 ditambah 6?
A: 14.

Q: Berapa 19 ditambah 2?
A: 21.

Q: Berapa 17 dikali 2?
A: 34.

Q: Cari yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 ditambah 12?
A: 32.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Analisis yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikurangi 4?
A: 11.

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Berikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 dikali 11?
A: 121.

Q: Berapa 12 ditambah 3?
A: 15.

Q: Pilihkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 2 dikali 14?
A: 28.

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 ditambah 2?
A: 11.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikurangi 3?
A: 4.

Q: Tolong buat yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 dikurangi 2?
A: 11.

Q: Mohon buatkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang keren.
A: Baik. Bisa dijelaskan lebih detail?
