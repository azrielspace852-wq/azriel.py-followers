# Dataset Clarification — 2009

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Mohon buatkan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Kasih yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berikan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Sesuaikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikali 3?
A: 45.

Q: Ceritakan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikali 10?
A: 170.

Q: Analisis yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 17 dikurangi 11?
A: 6.

Q: Ubah yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 6?
A: 108.

Q: Berapa 5 dikali 7?
A: 35.

Q: Berapa 1 dikali 7?
A: 7.

Q: Buatkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Pilihkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Berapa 15 dikurangi 7?
A: 8.

Q: Bikin yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berikan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 5 ditambah 7?
A: 12.

Q: Berapa 8 dikali 5?
A: 40.

Q: Rapikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikurangi 13?
A: 1.

Q: Saya butuh yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Kasih yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 10?
A: 29.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berikan yang ini.
A: Siap. Maksudnya yang seperti apa?
