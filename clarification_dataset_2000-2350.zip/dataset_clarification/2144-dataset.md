# Dataset Clarification — 2144

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Saya butuh yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Berikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Rapikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berapa 7 ditambah 8?
A: 15.

Q: Berikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama satuan energi?
A: Joule.

Q: Bikin yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Cari yang keren.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Saya mau yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Cari yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Kasih hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Cek hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Perbaiki yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 2?
A: 22.

Q: Berapa 10 ditambah 16?
A: 26.

Q: Berapa 19 dikali 8?
A: 152.

Q: Sesuaikan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Bikin yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?
