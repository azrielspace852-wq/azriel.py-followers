# Dataset Clarification — 2278

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Kasih hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 16 dikurangi 15?
A: 1.

Q: Berapa 7 ditambah 10?
A: 17.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Pilihkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Tolong buat yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Berapa 19 dikurangi 12?
A: 7.

Q: Berapa 20 dikurangi 2?
A: 18.

Q: Sesuaikan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dikurangi 15?
A: 1.

Q: Cari yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Berapa 17 dikurangi 1?
A: 16.

Q: Berikan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 ditambah 10?
A: 27.

Q: Analisis yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 19?
A: 21.

Q: Cari yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 11?
A: 7.

Q: Cari yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 8?
A: 6.

Q: Kasih yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 ditambah 9?
A: 18.

Q: Berapa 8 dikurangi 7?
A: 1.

Q: Perbaiki sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Buatkan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 20 ditambah 11?
A: 31.

Q: Tolong buat yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 dikali 4?
A: 12.

Q: Tolong buat yang pas.
A: Baik. Bisa dijelaskan lebih detail?
