# Dataset Clarification — 2044

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Saya butuh seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Ubah yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Saya butuh yang sana.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 2?
A: 16.

Q: Jelaskan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Saya butuh yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Apa nama satuan energi?
A: Joule.

Q: Saya butuh yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Jelaskan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Berikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Cari yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Kasih hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Ceritakan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera perasa?
A: Lidah.

Q: Berikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Berikan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Cari yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Bikin yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Mohon buatkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Berapa 20 dikali 1?
A: 20.
