# Dataset Clarification — 2013

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Buatkan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Cari yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Berikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Mohon buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Mohon buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Saya butuh yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Kasih sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Analisis yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Analisis yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Kasih hal itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Cek yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.
