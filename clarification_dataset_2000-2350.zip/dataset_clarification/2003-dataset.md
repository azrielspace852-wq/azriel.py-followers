# Dataset Clarification — 2003

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Rapikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Analisis yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Ceritakan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Tampilkan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Rapikan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Cari yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Saya butuh yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Perbaiki yang sana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Cari yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Saya mau yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang murah.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Ceritakan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Cek yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Mohon buatkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Pilihkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.
