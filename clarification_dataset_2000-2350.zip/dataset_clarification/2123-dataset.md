# Dataset Clarification — 2123

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Tolong buat yang pas.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Analisis yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Rapikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Analisis yang sana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Jelaskan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Analisis yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Pilihkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Cek yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Perbaiki yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Pilihkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Saya butuh yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?
