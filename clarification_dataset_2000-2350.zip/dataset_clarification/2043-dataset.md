# Dataset Clarification — 2043

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Analisis yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Tampilkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Berikan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Berikan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Jelaskan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Sesuaikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Tampilkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Cari seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Sesuaikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Ceritakan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Mohon buatkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Mohon buatkan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.
