# Dataset Clarification — 2146

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang ini.
A: Siap. Tentang apa tepatnya?

Q: Cari yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 1?
A: 1.

Q: Ceritakan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Sesuaikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 ditambah 10?
A: 27.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Sesuaikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 dikali 20?
A: 220.

Q: Berapa 4 ditambah 15?
A: 19.

Q: Saya mau yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Hitung yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 ditambah 9?
A: 25.

Q: Berapa 4 dikurangi 3?
A: 1.

Q: Berapa 12 ditambah 12?
A: 24.

Q: Berapa 4 dikali 13?
A: 52.

Q: Ubah hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 13?
A: 5.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 18 dikali 13?
A: 234.

Q: Berapa 8 ditambah 5?
A: 13.

Q: Berapa 3 ditambah 1?
A: 4.

Q: Rapikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 14?
A: 32.

Q: Analisis yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Saya butuh yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 dikali 10?
A: 40.

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Berapa 14 dikali 10?
A: 140.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Ceritakan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 6 dikali 11?
A: 66.

Q: Berapa 16 dikali 5?
A: 80.

Q: Kasih yang sederhana.
A: Siap. Yang mana yang dimaksud?
