# Dataset Clarification — 2263

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Kasih yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Ubah yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang detail.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Kasih yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin yang pas.
A: Siap. Tentang apa tepatnya?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Mohon buatkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Cari yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Hitung yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Hitung yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Analisis yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Ubah yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Tolong buat sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Saya mau yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Jelaskan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.
