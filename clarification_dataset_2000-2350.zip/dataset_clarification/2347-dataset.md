# Dataset Clarification — 2347

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 7 dikali 9?
A: 63.

Q: Berapa 4 dikali 6?
A: 24.

Q: Berapa 10 dikali 15?
A: 150.

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 9 ditambah 19?
A: 28.

Q: Saya butuh yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 ditambah 1?
A: 14.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 12 ditambah 8?
A: 20.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berikan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikali 9?
A: 126.

Q: Berikan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 6?
A: 21.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Ubah yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikurangi 8?
A: 4.

Q: Berapa 10 dikali 1?
A: 10.

Q: Berapa 18 dikali 8?
A: 144.

Q: Hitung yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang pas.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dikurangi 13?
A: 3.

Q: Pilihkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Kasih seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 ditambah 17?
A: 27.

Q: Saya mau yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikurangi 4?
A: 15.

Q: Berapa 3 dikali 5?
A: 15.

Q: Berapa 7 dikurangi 7?
A: 0.

Q: Hitung yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 2?
A: 17.

Q: Tampilkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 dikurangi 3?
A: 6.

Q: Ubah yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dikurangi 15?
A: 1.
