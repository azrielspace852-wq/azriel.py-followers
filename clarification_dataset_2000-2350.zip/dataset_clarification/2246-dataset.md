# Dataset Clarification — 2246

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikali 18?
A: 108.

Q: Analisis yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 ditambah 20?
A: 33.

Q: Berapa 2 ditambah 16?
A: 18.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Ubah sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikali 12?
A: 156.

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Tampilkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 dikali 17?
A: 85.

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 13 dikali 10?
A: 130.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 10 dikali 8?
A: 80.

Q: Berapa 5 ditambah 17?
A: 22.

Q: Berapa 19 dikurangi 11?
A: 8.

Q: Analisis hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 17 dikali 11?
A: 187.

Q: Cek yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 ditambah 12?
A: 29.

Q: Berapa 7 dikali 13?
A: 91.

Q: Mohon buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 1 dikali 13?
A: 13.

Q: Berapa 20 dikali 3?
A: 60.

Q: Berapa 20 ditambah 20?
A: 40.

Q: Pilihkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Mohon buatkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikurangi 5?
A: 3.

Q: Sesuaikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 10?
A: 160.

Q: Tolong buat yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Saya butuh yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dikali 2?
A: 10.
