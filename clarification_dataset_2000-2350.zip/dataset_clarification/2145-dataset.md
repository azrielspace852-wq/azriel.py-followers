# Dataset Clarification — 2145

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Saya butuh yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 ditambah 1?
A: 16.

Q: Cari yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 6 dikali 5?
A: 30.

Q: Pilihkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 ditambah 15?
A: 22.

Q: Berapa 10 dikurangi 3?
A: 7.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Pilihkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Berapa 1 dikali 8?
A: 8.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Jelaskan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 ditambah 9?
A: 26.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Ceritakan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 ditambah 4?
A: 16.

Q: Analisis sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 ditambah 20?
A: 36.

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Buatkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 9?
A: 10.

Q: Berapa 8 ditambah 20?
A: 28.

Q: Bikin sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 ditambah 12?
A: 28.

Q: Berapa 20 dikurangi 4?
A: 16.

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dikurangi 4?
A: 0.

Q: Berapa 2 dikali 4?
A: 8.

Q: Hitung yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 11?
A: 165.
