# Dataset Clarification — 2054

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Perbaiki yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 dikali 9?
A: 45.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Tolong buat yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Cek yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang murah.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Saya mau yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Saya mau yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Bikin yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Perbaiki yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Perbaiki yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 12?
A: 2.

Q: Mohon buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berapa 18 dikali 7?
A: 126.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Saya butuh yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Buatkan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?
