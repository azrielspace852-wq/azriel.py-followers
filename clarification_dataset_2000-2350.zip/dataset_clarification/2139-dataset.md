# Dataset Clarification — 2139

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Kasih yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikali 11?
A: 33.

Q: Pilihkan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Cek yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 19?
A: 57.

Q: Cek hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 ditambah 17?
A: 20.

Q: Ceritakan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang murah.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dikali 11?
A: 165.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 9 dikurangi 1?
A: 8.

Q: Hitung hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang ini.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikali 8?
A: 64.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Ubah sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 18 ditambah 12?
A: 30.

Q: Berapa 17 dikurangi 9?
A: 8.

Q: Berapa 1 ditambah 3?
A: 4.

Q: Berapa 19 ditambah 5?
A: 24.

Q: Ceritakan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dikali 18?
A: 252.

Q: Berapa 11 ditambah 14?
A: 25.

Q: Buatkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Kasih yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Berapa 3 dikali 13?
A: 39.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berikan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 ditambah 8?
A: 23.

Q: Ceritakan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 20 ditambah 12?
A: 32.

Q: Mohon buatkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 18?
A: 2.

Q: Jelaskan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dikali 3?
A: 15.

Q: Tampilkan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang ini.
A: Bisa. Untuk keperluan apa?
