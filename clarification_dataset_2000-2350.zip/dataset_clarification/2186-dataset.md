# Dataset Clarification — 2186

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Saya mau yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Kasih hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikali 17?
A: 221.

Q: Berapa 13 ditambah 7?
A: 20.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Bikin yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Berapa 1 ditambah 16?
A: 17.

Q: Pilihkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 13 ditambah 15?
A: 28.

Q: Kasih yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 11 ditambah 19?
A: 30.

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Bikin yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 ditambah 4?
A: 9.

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Berapa 13 dikurangi 9?
A: 4.

Q: Perbaiki yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang murah.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Jelaskan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 ditambah 9?
A: 19.

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Berikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 ditambah 4?
A: 16.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Saya butuh yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 ditambah 2?
A: 5.

Q: Buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 3 ditambah 14?
A: 17.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Analisis yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 ditambah 16?
A: 17.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Buatkan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikali 6?
A: 48.

Q: Kasih yang sana.
A: Baik. Bisa sebutkan lebih spesifik?
