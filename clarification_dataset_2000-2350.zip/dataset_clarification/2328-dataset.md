# Dataset Clarification — 2328

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 ditambah 20?
A: 22.

Q: Berapa 4 ditambah 10?
A: 14.

Q: Berapa 6 ditambah 18?
A: 24.

Q: Ubah yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Berapa 16 dikali 3?
A: 48.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Hitung yang itu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikurangi 11?
A: 9.

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang sana.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 18 ditambah 14?
A: 32.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Cek yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Buatkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikali 12?
A: 240.

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 20 ditambah 7?
A: 27.

Q: Berapa 10 dikali 3?
A: 30.

Q: Jelaskan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 ditambah 4?
A: 8.

Q: Saya mau yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikali 14?
A: 196.

Q: Tampilkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Berapa 8 ditambah 13?
A: 21.

Q: Berapa 11 dikali 8?
A: 88.

Q: Sesuaikan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Ubah yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang pas.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 19?
A: 190.
