# Dataset Clarification — 2005

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dikali 9?
A: 108.

Q: Berapa 18 dikali 1?
A: 18.

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cek yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang itu.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 ditambah 17?
A: 27.

Q: Cek yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 ditambah 18?
A: 20.

Q: Berapa 8 ditambah 1?
A: 9.

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 2 dikali 8?
A: 16.

Q: Berapa 15 ditambah 13?
A: 28.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Cari yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 2?
A: 4.

Q: Rapikan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 ditambah 17?
A: 22.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Ubah yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Hitung seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Berapa 8 ditambah 9?
A: 17.

Q: Bikin yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Buatkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Ubah yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Ceritakan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikali 6?
A: 90.

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Berapa 20 ditambah 5?
A: 25.

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Saya butuh yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 9?
A: 27.

Q: Berapa 14 ditambah 4?
A: 18.
