# Dataset Clarification — 2068

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cari yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dikali 19?
A: 76.

Q: Perbaiki yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 ditambah 16?
A: 24.

Q: Jelaskan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 ditambah 18?
A: 38.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Berapa 13 ditambah 1?
A: 14.

Q: Kasih yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Kasih yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 ditambah 18?
A: 22.

Q: Cari yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Rapikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Cari yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 ditambah 12?
A: 22.

Q: Berapa 6 ditambah 15?
A: 21.

Q: Berapa 17 ditambah 5?
A: 22.

Q: Ceritakan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikali 6?
A: 114.

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Saya mau yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 11?
A: 12.

Q: Berapa 4 ditambah 15?
A: 19.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Mohon buatkan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Jelaskan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 2?
A: 30.

Q: Berikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 ditambah 11?
A: 28.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Ceritakan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?
