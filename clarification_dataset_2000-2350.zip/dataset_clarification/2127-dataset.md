# Dataset Clarification — 2127

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Pilihkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 dikali 16?
A: 16.

Q: Berapa 6 ditambah 16?
A: 22.

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dikali 15?
A: 30.

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 14 ditambah 6?
A: 20.

Q: Bikin yang detail.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Rapikan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Cari yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 ditambah 3?
A: 11.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Jelaskan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 dikali 5?
A: 40.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Rapikan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 dikali 20?
A: 160.

Q: Pilihkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 ditambah 12?
A: 26.

Q: Saya mau hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 14 dikali 9?
A: 126.

Q: Buatkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikali 3?
A: 30.

Q: Berapa 7 ditambah 4?
A: 11.

Q: Kasih yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dikali 5?
A: 10.

Q: Berapa 5 dikali 9?
A: 45.

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Berapa 13 ditambah 1?
A: 14.

Q: Sesuaikan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 ditambah 13?
A: 33.

Q: Saya mau yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Bikin yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dibagi 2?
A: 8.
