# Dataset Clarification — 2204

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Mohon buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Ceritakan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 10 ditambah 2?
A: 12.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Cari yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Pilihkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Cek yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Analisis hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Saya butuh hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Berapa 15 dikurangi 5?
A: 10.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Rapikan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Pilihkan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Buatkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.
