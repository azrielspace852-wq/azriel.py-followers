# Dataset Clarification — 2148

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang ini.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Cari hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikurangi 5?
A: 11.

Q: Berapa 7 ditambah 6?
A: 13.

Q: Cek yang sana.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikali 7?
A: 84.

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Saya mau yang sana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dikali 12?
A: 60.

Q: Berikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Perbaiki yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Berapa 12 dikali 13?
A: 156.

Q: Ceritakan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dikali 1?
A: 10.

Q: Jelaskan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 8 ditambah 10?
A: 18.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Saya butuh sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikali 17?
A: 340.

Q: Tampilkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Saya butuh yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Jelaskan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 dikali 20?
A: 80.

Q: Hitung yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 ditambah 5?
A: 24.

Q: Berapa 36 dibagi 4?
A: 9.
