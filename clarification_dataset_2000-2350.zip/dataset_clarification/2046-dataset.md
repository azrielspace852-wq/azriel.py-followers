# Dataset Clarification — 2046

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 6 ditambah 2?
A: 8.

Q: Berikan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 ditambah 15?
A: 23.

Q: Berapa 12 ditambah 16?
A: 28.

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 5 dikali 12?
A: 60.

Q: Berikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 ditambah 13?
A: 29.

Q: Berapa 17 dikurangi 2?
A: 15.

Q: Buatkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikurangi 6?
A: 12.

Q: Analisis yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 10?
A: 21.

Q: Berapa 14 ditambah 13?
A: 27.

Q: Kasih yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 ditambah 19?
A: 29.

Q: Berapa 16 ditambah 17?
A: 33.

Q: Berapa 16 dikurangi 12?
A: 4.

Q: Rapikan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikali 13?
A: 260.

Q: Ceritakan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Ceritakan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikali 9?
A: 126.

Q: Berapa 9 dikali 8?
A: 72.

Q: Berapa 19 ditambah 4?
A: 23.

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Ubah yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikali 4?
A: 28.

Q: Mohon buatkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 ditambah 4?
A: 23.

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Saya butuh seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 ditambah 18?
A: 27.

Q: Bikin yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Jelaskan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Cari yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Bikin sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan seperti biasa.
A: Bisa. Untuk keperluan apa?
