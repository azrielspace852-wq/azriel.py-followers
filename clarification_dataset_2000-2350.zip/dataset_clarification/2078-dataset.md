# Dataset Clarification — 2078

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Berapa 15 ditambah 11?
A: 26.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Sesuaikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 ditambah 18?
A: 20.

Q: Saya mau yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dikurangi 15?
A: 5.

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 13 dikurangi 5?
A: 8.

Q: Jelaskan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 ditambah 5?
A: 20.

Q: Berapa 3 dikali 8?
A: 24.

Q: Berapa 9 dikali 3?
A: 27.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 15 dikali 6?
A: 90.

Q: Cari yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 ditambah 11?
A: 27.

Q: Berapa 14 ditambah 7?
A: 21.

Q: Tolong buat yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 ditambah 5?
A: 24.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Berapa 9 ditambah 16?
A: 25.

Q: Kasih yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 6?
A: 108.

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Saya mau yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Bikin sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang murah.
A: Siap. Tentang apa tepatnya?

Q: Rapikan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 ditambah 2?
A: 10.

Q: Kasih yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 3 ditambah 19?
A: 22.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 16 ditambah 5?
A: 21.

Q: Berapa 17 ditambah 18?
A: 35.

Q: Sesuaikan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Cari yang ini.
A: Baik. Bisa dijelaskan lebih detail?
