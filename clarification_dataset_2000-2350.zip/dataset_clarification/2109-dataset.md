# Dataset Clarification — 2109

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Berapa 19 dikali 10?
A: 190.

Q: Ubah yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 2 dikali 4?
A: 8.

Q: Berapa 14 ditambah 18?
A: 32.

Q: Bikin yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikali 19?
A: 171.

Q: Ceritakan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 10?
A: 5.

Q: Saya butuh seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Perbaiki yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Mohon buatkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikurangi 7?
A: 5.

Q: Kasih yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 11?
A: 7.

Q: Berapa 17 dikurangi 8?
A: 9.

Q: Berapa 4 dikurangi 1?
A: 3.

Q: Berikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Pilihkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 16 dikali 2?
A: 32.

Q: Berapa 17 ditambah 1?
A: 18.

Q: Buatkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 5 dikali 3?
A: 15.

Q: Analisis yang pas.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikurangi 11?
A: 6.

Q: Berapa 15 ditambah 18?
A: 33.

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Jelaskan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 14?
A: 4.

Q: Berapa 13 ditambah 13?
A: 26.

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikali 15?
A: 300.
