# Dataset Clarification — 2019

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 16 dikali 9?
A: 144.

Q: Sesuaikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 ditambah 9?
A: 16.

Q: Berapa 7 dikali 19?
A: 133.

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Berapa 15 dikali 4?
A: 60.

Q: Berikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 3 ditambah 18?
A: 21.

Q: Mohon buatkan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 7 ditambah 19?
A: 26.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Ceritakan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 ditambah 3?
A: 23.

Q: Hitung yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Bikin yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Tampilkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 14 dikurangi 11?
A: 3.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 18 dikali 16?
A: 288.

Q: Analisis yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikali 17?
A: 136.

Q: Sesuaikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 2?
A: 18.

Q: Sesuaikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 ditambah 7?
A: 23.

Q: Berapa 19 dikali 2?
A: 38.
