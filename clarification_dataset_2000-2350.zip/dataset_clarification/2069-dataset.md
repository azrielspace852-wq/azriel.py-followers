# Dataset Clarification — 2069

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dikali 20?
A: 40.

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Ceritakan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 dikali 14?
A: 210.

Q: Hitung yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 1 dikali 19?
A: 19.

Q: Rapikan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 18?
A: 216.

Q: Berapa 4 ditambah 5?
A: 9.

Q: Berapa 20 ditambah 20?
A: 40.

Q: Ceritakan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 14?
A: 154.

Q: Berapa 6 ditambah 6?
A: 12.

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Bikin yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Rapikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 2 ditambah 5?
A: 7.

Q: Berapa 8 dikali 2?
A: 16.

Q: Jelaskan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 1 dikali 8?
A: 8.

Q: Cek yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Ubah sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Jelaskan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 dikali 17?
A: 204.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Rapikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Analisis sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Cari hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dikali 14?
A: 84.

Q: Buatkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Jelaskan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 ditambah 3?
A: 10.

Q: Perbaiki seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Berapa 18 dikurangi 11?
A: 7.

Q: Analisis yang sana.
A: Tentu. Yang mana yang Anda maksud?
