# Dataset Clarification — 2006

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Mohon buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikali 5?
A: 80.

Q: Berapa 17 dikali 8?
A: 136.

Q: Berapa 6 ditambah 8?
A: 14.

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Pilihkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 1?
A: 18.

Q: Berapa 18 dikali 11?
A: 198.

Q: Sesuaikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Rapikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 2 ditambah 19?
A: 21.

Q: Analisis seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Sesuaikan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 5 dikali 9?
A: 45.

Q: Kasih yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Saya mau yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 14 dikali 11?
A: 154.

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 ditambah 9?
A: 28.

Q: Berapa 5 ditambah 16?
A: 21.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Saya butuh yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Mohon buatkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 16?
A: 27.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Berikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Pilihkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Bikin yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 ditambah 3?
A: 18.

Q: Saya butuh sesuatu.
A: Siap. Maksudnya yang seperti apa?
