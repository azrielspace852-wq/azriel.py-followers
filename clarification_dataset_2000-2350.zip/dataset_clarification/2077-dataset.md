# Dataset Clarification — 2077

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 9 ditambah 19?
A: 28.

Q: Tampilkan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 2 ditambah 5?
A: 7.

Q: Analisis yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 2 ditambah 20?
A: 22.

Q: Berapa 15 ditambah 6?
A: 21.

Q: Berapa 12 ditambah 9?
A: 21.

Q: Kasih yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 6 ditambah 12?
A: 18.

Q: Mohon buatkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 10 dikali 8?
A: 80.

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Tolong buat yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Berapa 6 ditambah 16?
A: 22.

Q: Jelaskan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 ditambah 11?
A: 28.

Q: Mohon buatkan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Ceritakan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 9?
A: 3.

Q: Ceritakan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 ditambah 16?
A: 24.

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Cek yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Hitung yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Berapa 7 ditambah 13?
A: 20.

Q: Mohon buatkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dikali 4?
A: 16.

Q: Sesuaikan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 dikali 14?
A: 70.

Q: Cari yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?
