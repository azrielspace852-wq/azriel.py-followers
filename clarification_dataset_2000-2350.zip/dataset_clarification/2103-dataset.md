# Dataset Clarification — 2103

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Mohon buatkan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Mohon buatkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Tampilkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Analisis yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Tampilkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Pilihkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Cek yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Sesuaikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Cek yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Mohon buatkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Pilihkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Perbaiki yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Ubah yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Perbaiki yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Ceritakan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Berikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?
