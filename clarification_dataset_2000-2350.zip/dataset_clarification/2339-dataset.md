# Dataset Clarification — 2339

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang murah.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 7 dikali 20?
A: 140.

Q: Mohon buatkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikurangi 9?
A: 4.

Q: Berapa 11 dikali 8?
A: 88.

Q: Rapikan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Berapa 16 dikurangi 15?
A: 1.

Q: Tampilkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 ditambah 20?
A: 25.

Q: Saya mau seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 ditambah 4?
A: 17.

Q: Berapa 10 dikurangi 8?
A: 2.

Q: Tolong buat yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Sesuaikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 ditambah 9?
A: 27.

Q: Tampilkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikali 18?
A: 306.

Q: Berapa 16 ditambah 10?
A: 26.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 15 ditambah 18?
A: 33.

Q: Jelaskan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 ditambah 11?
A: 13.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Kasih yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikali 18?
A: 234.

Q: Cari yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 12?
A: 18.

Q: Jelaskan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 4 ditambah 19?
A: 23.

Q: Perbaiki yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 ditambah 3?
A: 15.

Q: Buatkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 ditambah 4?
A: 24.

Q: Kasih yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikurangi 4?
A: 15.

Q: Berikan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 dikali 19?
A: 266.
