# Dataset Clarification — 2143

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang detail.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Ubah yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Bikin yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Ceritakan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Ubah yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Ceritakan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang sana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Pilihkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Tampilkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Tampilkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Buatkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Cek yang itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Mohon buatkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Rapikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang ini.
A: Bisa. Untuk tujuan apa?
