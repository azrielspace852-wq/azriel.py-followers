# Dataset Clarification — 2265

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 18?
A: 1.

Q: Berapa 1 ditambah 17?
A: 18.

Q: Cari yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 13?
A: 4.

Q: Kasih yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 1?
A: 10.

Q: Berapa 8 dikurangi 5?
A: 3.

Q: Berapa 18 ditambah 2?
A: 20.

Q: Ubah yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Tolong buat yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikali 5?
A: 15.

Q: Kasih yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Mohon buatkan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dikali 6?
A: 60.

Q: Ubah yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Ubah yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 ditambah 20?
A: 34.

Q: Berapa 2 ditambah 16?
A: 18.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Tolong buat hal itu.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 11?
A: 30.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 14 dikali 18?
A: 252.

Q: Tolong buat yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 ditambah 11?
A: 21.

Q: Saya butuh yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Tolong buat yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 dikurangi 9?
A: 10.

Q: Buatkan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 4 dibagi 2?
A: 2.
