# Dataset Clarification — 2255

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 14 dikali 16?
A: 224.

Q: Berapa 17 dikali 3?
A: 51.

Q: Hitung hal itu.
A: Siap. Tentang apa tepatnya?

Q: Hitung sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 20 dikurangi 15?
A: 5.

Q: Berapa 1 dikali 19?
A: 19.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Pilihkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dikali 14?
A: 140.

Q: Jelaskan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 ditambah 13?
A: 20.

Q: Hitung yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 11?
A: 30.

Q: Mohon buatkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 12?
A: 132.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Cari yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Berikan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Tampilkan yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 14?
A: 4.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 4 ditambah 15?
A: 19.

Q: Hitung yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikali 13?
A: 39.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 4 dikali 11?
A: 44.

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Saya mau yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 3 ditambah 13?
A: 16.

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang itu.
A: Bisa. Untuk keperluan apa?
