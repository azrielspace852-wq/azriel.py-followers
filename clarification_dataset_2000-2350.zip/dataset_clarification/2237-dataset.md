# Dataset Clarification — 2237

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Mohon buatkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 10?
A: 12.

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 5 dikali 17?
A: 85.

Q: Tolong buat seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Cari yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikali 13?
A: 221.

Q: Hitung yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 18 ditambah 5?
A: 23.

Q: Bikin seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 3?
A: 45.

Q: Sesuaikan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikali 4?
A: 52.

Q: Saya butuh yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 2?
A: 8.

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Berapa 12 ditambah 10?
A: 22.

Q: Buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Cek yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 16 dikali 9?
A: 144.

Q: Berapa 13 ditambah 16?
A: 29.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 3 ditambah 10?
A: 13.

Q: Berapa 18 dikali 7?
A: 126.

Q: Berapa 12 dikali 16?
A: 192.

Q: Saya mau yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang murah.
A: Baik. Bisa dijelaskan lebih detail?
