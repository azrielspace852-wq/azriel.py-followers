# Dataset Clarification — 2188

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tampilkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Saya butuh yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 ditambah 4?
A: 24.

Q: Berikan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 dikali 5?
A: 10.

Q: Ubah yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 6?
A: 14.

Q: Berapa 16 ditambah 11?
A: 27.

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Hitung yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 ditambah 13?
A: 17.

Q: Jelaskan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Analisis yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 8?
A: 11.

Q: Berapa 3 ditambah 2?
A: 5.

Q: Ceritakan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 ditambah 20?
A: 34.

Q: Sesuaikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Cari seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Berapa 10 dikali 6?
A: 60.

Q: Analisis yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dikali 3?
A: 15.

Q: Berapa 9 dikali 17?
A: 153.

Q: Berapa 13 dikali 20?
A: 260.

Q: Sesuaikan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 dikali 9?
A: 63.

Q: Berikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 dikali 10?
A: 70.

Q: Berapa 19 dikali 11?
A: 209.

Q: Rapikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 ditambah 19?
A: 22.

Q: Berapa 15 dikali 5?
A: 75.

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Analisis yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin yang pas.
A: Siap. Yang mana yang dimaksud?
