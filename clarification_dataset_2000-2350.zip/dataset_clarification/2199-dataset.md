# Dataset Clarification — 2199

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Analisis yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 dikali 2?
A: 16.

Q: Berapa 15 ditambah 2?
A: 17.

Q: Berapa 16 dikali 20?
A: 320.

Q: Saya mau yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 ditambah 13?
A: 20.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 8 ditambah 13?
A: 21.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Ceritakan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Kasih yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 2?
A: 10.

Q: Berapa 19 dikurangi 10?
A: 9.

Q: Berikan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 17?
A: 2.

Q: Analisis yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Jelaskan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 ditambah 6?
A: 24.

Q: Hitung yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Berapa 7 dikali 9?
A: 63.

Q: Rapikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dikali 5?
A: 20.

Q: Tampilkan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 ditambah 5?
A: 12.

Q: Rapikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Berapa 13 dikali 15?
A: 195.

Q: Berapa 20 ditambah 13?
A: 33.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 16 dibagi 4?
A: 4.
