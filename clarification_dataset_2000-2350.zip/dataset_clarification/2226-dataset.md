# Dataset Clarification — 2226

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Pilihkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikali 12?
A: 144.

Q: Sesuaikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 15?
A: 0.

Q: Berapa 14 ditambah 11?
A: 25.

Q: Berapa 3 dikali 2?
A: 6.

Q: Mohon buatkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 3 ditambah 19?
A: 22.

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Analisis hal itu.
A: Bisa. Untuk tujuan apa?

Q: Cek yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Saya mau yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikali 11?
A: 198.

Q: Mohon buatkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 ditambah 7?
A: 15.

Q: Berapa 19 dikurangi 16?
A: 3.

Q: Tampilkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Cek yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 11 ditambah 20?
A: 31.

Q: Saya butuh yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Ubah hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang pas.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 ditambah 8?
A: 15.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 6 dikali 13?
A: 78.

Q: Tampilkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikali 18?
A: 306.

Q: Berikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Hitung yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 11 dikali 8?
A: 88.

Q: Berapa 4 ditambah 9?
A: 13.

Q: Berapa 16 dikali 6?
A: 96.

Q: Pilihkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Jelaskan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang keren.
A: Tentu. Konteksnya seperti apa?
