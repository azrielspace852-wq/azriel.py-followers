# Dataset Clarification — 2256

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin yang itu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 1 ditambah 9?
A: 10.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 15 dikali 19?
A: 285.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Ubah yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dikali 5?
A: 20.

Q: Berapa 4 dikali 19?
A: 76.

Q: Berapa 2 dikali 18?
A: 36.

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Sesuaikan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Berapa 11 dikali 18?
A: 198.

Q: Kasih yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 ditambah 13?
A: 15.

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Berapa 13 ditambah 7?
A: 20.

Q: Cari yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Cek yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Berapa 17 dikurangi 16?
A: 1.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Ceritakan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 ditambah 7?
A: 13.

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Berikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Hitung yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 dikurangi 7?
A: 8.

Q: Saya butuh yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang sesuai.
A: Siap. Maksudnya yang seperti apa?
