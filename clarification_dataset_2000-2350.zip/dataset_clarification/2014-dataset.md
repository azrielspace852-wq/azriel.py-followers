# Dataset Clarification — 2014

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Berapa 20 dikali 20?
A: 400.

Q: Apa nama indera perasa?
A: Lidah.

Q: Tolong buat yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Jelaskan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Buatkan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 dikali 5?
A: 40.

Q: Buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Pilihkan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 12 dikali 18?
A: 216.

Q: Buatkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Saya mau yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Cek sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Cek sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Cari sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 17 dikurangi 8?
A: 9.

Q: Cek yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama satuan energi?
A: Joule.

Q: Sesuaikan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.
