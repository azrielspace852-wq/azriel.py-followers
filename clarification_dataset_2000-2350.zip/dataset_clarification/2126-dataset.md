# Dataset Clarification — 2126

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dikurangi 6?
A: 4.

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 ditambah 3?
A: 19.

Q: Berapa 10 dikali 20?
A: 200.

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Saya mau yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dikurangi 20?
A: 0.

Q: Berikan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 12 dikurangi 9?
A: 3.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 11 dikali 13?
A: 143.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Saya butuh hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 dikali 18?
A: 90.

Q: Analisis yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 dikali 15?
A: 105.

Q: Saya butuh yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 ditambah 20?
A: 23.

Q: Berapa 19 ditambah 16?
A: 35.

Q: Berapa 20 dikali 9?
A: 180.

Q: Tolong buat yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Bikin seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikali 17?
A: 306.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Mohon buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 15?
A: 225.

Q: Saya butuh yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 6 ditambah 14?
A: 20.

Q: Berapa 12 dikali 2?
A: 24.
