# Dataset Clarification — 2116

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 4 dikali 20?
A: 80.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Tampilkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 ditambah 12?
A: 13.

Q: Bikin yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dikali 16?
A: 160.

Q: Berapa 5 ditambah 14?
A: 19.

Q: Sesuaikan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 17 dikurangi 10?
A: 7.

Q: Buatkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 18?
A: 33.

Q: Mohon buatkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 4 ditambah 4?
A: 8.

Q: Berapa 6 dikali 11?
A: 66.

Q: Berapa 19 ditambah 6?
A: 25.

Q: Ceritakan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Berapa 17 ditambah 15?
A: 32.

Q: Saya mau yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 dikali 10?
A: 70.

Q: Berapa 9 ditambah 7?
A: 16.

Q: Mohon buatkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Cari yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 ditambah 20?
A: 36.

Q: Berapa 19 ditambah 13?
A: 32.

Q: Perbaiki yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat hal itu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Saya mau yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Ceritakan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikurangi 2?
A: 7.
