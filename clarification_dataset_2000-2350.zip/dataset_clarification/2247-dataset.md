# Dataset Clarification — 2247

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Analisis yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikali 1?
A: 9.

Q: Saya butuh yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 ditambah 1?
A: 15.

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Tampilkan sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 ditambah 6?
A: 26.

Q: Hitung yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Sesuaikan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikali 11?
A: 209.

Q: Tolong buat yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Jelaskan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 ditambah 14?
A: 26.

Q: Berapa 6 dikali 4?
A: 24.

Q: Berapa 10 dikali 17?
A: 170.

Q: Berikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikali 3?
A: 9.

Q: Berapa 2 ditambah 7?
A: 9.

Q: Jelaskan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 ditambah 20?
A: 25.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Perbaiki sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikali 20?
A: 300.

Q: Berapa 6 dikali 4?
A: 24.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Cek yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dikali 14?
A: 56.

Q: Berapa 19 ditambah 20?
A: 39.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 13 dikali 2?
A: 26.

Q: Cari yang murah.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 ditambah 15?
A: 26.

Q: Buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 ditambah 11?
A: 29.

Q: Ceritakan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?
