# Dataset Clarification — 2167

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya butuh yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Saya mau yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Saya butuh yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikurangi 3?
A: 6.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Hitung yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Buatkan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Kasih yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikurangi 13?
A: 1.

Q: Berapa 7 ditambah 19?
A: 26.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Rapikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 20 ditambah 15?
A: 35.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Saya butuh yang keren.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 ditambah 12?
A: 30.

Q: Sesuaikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikali 12?
A: 168.

Q: Berapa 19 ditambah 4?
A: 23.

Q: Cek hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 ditambah 20?
A: 32.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 20 dikali 8?
A: 160.

Q: Berapa 7 ditambah 20?
A: 27.

Q: Mohon buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Berapa 11 ditambah 8?
A: 19.

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Rapikan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 6 dikali 6?
A: 36.
