# Dataset Clarification — 2007

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 9 dikali 2?
A: 18.

Q: Kasih seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Cek hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikali 17?
A: 323.

Q: Tolong buat yang keren.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Kasih yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikurangi 1?
A: 10.

Q: Berapa 8 ditambah 13?
A: 21.

Q: Berapa 8 dikali 14?
A: 112.

Q: Tolong buat sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Berapa 16 dikali 1?
A: 16.

Q: Berikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 ditambah 8?
A: 18.

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Sesuaikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Berapa 3 dikali 16?
A: 48.

Q: Berapa 19 dikurangi 4?
A: 15.

Q: Perbaiki seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 15 dikali 15?
A: 225.

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Berapa 15 ditambah 20?
A: 35.

Q: Ceritakan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 ditambah 20?
A: 34.

Q: Tolong buat yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 ditambah 9?
A: 14.

Q: Cek yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikurangi 12?
A: 4.

Q: Berapa 18 ditambah 19?
A: 37.

Q: Pilihkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 11?
A: 12.

Q: Perbaiki yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 20 dibagi 5?
A: 4.
