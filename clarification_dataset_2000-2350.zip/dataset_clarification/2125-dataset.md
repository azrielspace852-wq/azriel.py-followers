# Dataset Clarification — 2125

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Sesuaikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 3?
A: 8.

Q: Buatkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 12?
A: 192.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Tampilkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Kasih yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Saya butuh hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 9?
A: 24.

Q: Cari yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 ditambah 19?
A: 33.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Rapikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 4 dikurangi 4?
A: 0.

Q: Jelaskan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Cari seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 8 ditambah 19?
A: 27.

Q: Berikan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikali 3?
A: 27.

Q: Cek yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 16 ditambah 7?
A: 23.

Q: Berapa 13 dikali 6?
A: 78.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 14 dikurangi 5?
A: 9.

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikali 9?
A: 90.

Q: Berapa 6 dikali 3?
A: 18.

Q: Hitung yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 18?
A: 31.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Cari yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Mohon buatkan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 6?
A: 9.

Q: Berapa 7 ditambah 4?
A: 11.
