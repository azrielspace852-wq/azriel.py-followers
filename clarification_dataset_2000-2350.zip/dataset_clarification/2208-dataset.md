# Dataset Clarification — 2208

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 dikurangi 2?
A: 0.

Q: Cari yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang keren.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Saya butuh yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikali 12?
A: 156.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Cari yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikurangi 8?
A: 6.

Q: Buatkan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikali 19?
A: 304.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Pilihkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 9 ditambah 19?
A: 28.

Q: Berapa 15 dikali 7?
A: 105.

Q: Cari yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dikurangi 4?
A: 4.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 14?
A: 31.

Q: Berapa 16 dikali 19?
A: 304.

Q: Ubah yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 17?
A: 51.

Q: Berapa 20 ditambah 5?
A: 25.

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Kasih yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Pilihkan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 ditambah 12?
A: 32.

Q: Saya butuh yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Kasih yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 ditambah 17?
A: 34.

Q: Analisis sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?
