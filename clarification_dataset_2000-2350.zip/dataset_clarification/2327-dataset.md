# Dataset Clarification — 2327

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Buatkan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 ditambah 7?
A: 21.

Q: Berikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 8 ditambah 6?
A: 14.

Q: Pilihkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikali 1?
A: 17.

Q: Berapa 1 ditambah 2?
A: 3.

Q: Tampilkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 10?
A: 7.

Q: Berapa 15 ditambah 7?
A: 22.

Q: Berapa 6 dikali 7?
A: 42.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Rapikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikali 19?
A: 209.

Q: Saya mau sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Mohon buatkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang sana.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 9 ditambah 15?
A: 24.

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Kasih yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Pilihkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Perbaiki yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 13?
A: 247.

Q: Ubah yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Cari yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 ditambah 5?
A: 24.

Q: Pilihkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Berapa 6 dikali 4?
A: 24.

Q: Berapa 8 dikurangi 8?
A: 0.

Q: Berapa 2 dikali 19?
A: 38.
