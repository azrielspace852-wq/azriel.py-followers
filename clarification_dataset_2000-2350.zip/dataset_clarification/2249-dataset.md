# Dataset Clarification — 2249

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Berapa 13 ditambah 19?
A: 32.

Q: Saya mau yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikurangi 2?
A: 6.

Q: Tampilkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 19?
A: 228.

Q: Berapa 15 dikali 5?
A: 75.

Q: Berapa 16 ditambah 9?
A: 25.

Q: Berapa 10 dikali 2?
A: 20.

Q: Berapa 6 dikurangi 3?
A: 3.

Q: Sesuaikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Rapikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Jelaskan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 13 dikali 5?
A: 65.

Q: Saya butuh yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Perbaiki yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 ditambah 12?
A: 22.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Mohon buatkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Bikin yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikali 1?
A: 20.

Q: Bikin yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 ditambah 4?
A: 7.

Q: Perbaiki yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Cari sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikurangi 4?
A: 2.

Q: Berapa 15 dikali 17?
A: 255.

Q: Ceritakan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Pilihkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Analisis seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikali 15?
A: 165.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Ubah yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dibagi 2?
A: 6.
