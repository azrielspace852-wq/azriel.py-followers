# Dataset Clarification — 2325

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 13 dikali 1?
A: 13.

Q: Berapa 7 ditambah 14?
A: 21.

Q: Berapa 17 dikali 8?
A: 136.

Q: Berapa 8 dikali 14?
A: 112.

Q: Ubah yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang ini.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikali 7?
A: 98.

Q: Ceritakan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 dikali 2?
A: 10.

Q: Cari hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Berapa 10 dikali 20?
A: 200.

Q: Berapa 7 dikali 3?
A: 21.

Q: Berapa 2 dikali 4?
A: 8.

Q: Sesuaikan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikali 8?
A: 152.

Q: Berapa 20 ditambah 11?
A: 31.

Q: Kasih yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Analisis yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dikali 20?
A: 40.

Q: Berapa 6 dikali 18?
A: 108.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Saya mau yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Kasih yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Analisis yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 14 dikali 8?
A: 112.

Q: Tampilkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Buatkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?
