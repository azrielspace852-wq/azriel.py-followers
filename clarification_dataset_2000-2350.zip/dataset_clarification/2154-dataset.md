# Dataset Clarification — 2154

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Tolong buat yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Rapikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Cari sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera perasa?
A: Lidah.

Q: Jelaskan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Tampilkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Hitung yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Mohon buatkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Tolong buat yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikali 11?
A: 187.

Q: Rapikan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dikali 19?
A: 190.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Cari yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Kasih yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikurangi 9?
A: 1.

Q: Kasih yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Sesuaikan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Cek yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Tampilkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Cek yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Kasih yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama indera pendengaran?
A: Telinga.
