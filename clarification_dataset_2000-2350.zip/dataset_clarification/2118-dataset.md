# Dataset Clarification — 2118

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 5 ditambah 10?
A: 15.

Q: Berapa 14 ditambah 17?
A: 31.

Q: Tolong buat yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Saya butuh yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Analisis yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Analisis yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang sana.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 ditambah 1?
A: 6.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Perbaiki yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Kasih sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Rapikan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 ditambah 7?
A: 20.

Q: Sesuaikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Berapa 4 dikali 17?
A: 68.

Q: Berikan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Cek yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 6 ditambah 9?
A: 15.

Q: Sesuaikan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Perbaiki yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 ditambah 15?
A: 28.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Buatkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 dikurangi 7?
A: 10.

Q: Berapa 20 dikurangi 2?
A: 18.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Berapa 18 dikali 3?
A: 54.

Q: Berapa 18 ditambah 17?
A: 35.

Q: Perbaiki yang pas.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang menarik.
A: Siap. Tentang apa tepatnya?
