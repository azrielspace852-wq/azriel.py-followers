# Dataset Clarification — 2288

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 8 dikali 3?
A: 24.

Q: Berapa 13 dikurangi 6?
A: 7.

Q: Ceritakan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Cek sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang keren.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikali 4?
A: 76.

Q: Analisis hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikurangi 10?
A: 9.

Q: Berapa 20 dikurangi 10?
A: 10.

Q: Berapa 5 ditambah 11?
A: 16.

Q: Berapa 5 dikali 4?
A: 20.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Sesuaikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 3 ditambah 5?
A: 8.

Q: Sesuaikan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 3 dikurangi 3?
A: 0.

Q: Tolong buat yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Ubah sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang sana.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikurangi 14?
A: 4.

Q: Buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 dikali 9?
A: 36.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Cari seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 5?
A: 5.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 6 dikali 3?
A: 18.

Q: Berapa 12 ditambah 5?
A: 17.

Q: Berapa 7 dikali 16?
A: 112.

Q: Berapa 12 ditambah 5?
A: 17.

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Saya butuh yang itu.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang murah.
A: Bisa. Untuk keperluan apa?

Q: Sesuaikan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 ditambah 19?
A: 39.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Bikin yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 ditambah 16?
A: 35.

Q: Berapa 18 dikali 12?
A: 216.
