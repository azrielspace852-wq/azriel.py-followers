# Dataset Clarification — 2257

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Jelaskan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Ceritakan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikurangi 4?
A: 4.

Q: Ceritakan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikali 15?
A: 105.

Q: Kasih yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikali 5?
A: 65.

Q: Ceritakan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 5?
A: 80.

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Hitung seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 4?
A: 16.

Q: Rapikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 19 dikurangi 12?
A: 7.

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 3 dikali 11?
A: 33.

Q: Berapa 20 ditambah 19?
A: 39.

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 19 ditambah 2?
A: 21.

Q: Kasih yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Cek sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 ditambah 2?
A: 17.

Q: Saya butuh yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Hitung yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikali 10?
A: 140.

Q: Berapa 6 ditambah 8?
A: 14.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 7 dikurangi 7?
A: 0.

Q: Berapa 19 dikali 19?
A: 361.

Q: Berapa 1 dikali 16?
A: 16.

Q: Rapikan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikali 20?
A: 180.

Q: Berapa 12 ditambah 7?
A: 19.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Tampilkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Perbaiki yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dikali 5?
A: 50.
