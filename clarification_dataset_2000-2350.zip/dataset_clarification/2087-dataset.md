# Dataset Clarification — 2087

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tampilkan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 ditambah 11?
A: 23.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Pilihkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Saya butuh yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 15 dikali 16?
A: 240.

Q: Berapa 2 ditambah 10?
A: 12.

Q: Berapa 20 dikurangi 18?
A: 2.

Q: Analisis seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang keren.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Saya butuh yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikurangi 2?
A: 11.

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Perbaiki yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Cari yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 17?
A: 34.

Q: Rapikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Perbaiki seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Mohon buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 14 ditambah 4?
A: 18.

Q: Berapa 14 dikali 12?
A: 168.

Q: Saya butuh yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikali 9?
A: 126.

Q: Berapa 14 dikali 19?
A: 266.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Berapa 11 dikali 14?
A: 154.

Q: Berapa 3 dikali 12?
A: 36.

Q: Mohon buatkan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 8 ditambah 12?
A: 20.

Q: Analisis yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang sana.
A: Siap. Yang mana yang dimaksud?
