# Dataset Clarification — 2169

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Bikin yang sana.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 7 ditambah 3?
A: 10.

Q: Tampilkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Cek yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 1 ditambah 3?
A: 4.

Q: Rapikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Cek yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikurangi 11?
A: 6.

Q: Berapa 6 dikali 12?
A: 72.

Q: Berapa 14 ditambah 17?
A: 31.

Q: Bikin hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Kasih yang keren.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 ditambah 18?
A: 31.

Q: Berapa 2 dikali 7?
A: 14.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Saya mau sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 dikali 5?
A: 85.

Q: Mohon buatkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 ditambah 1?
A: 14.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Berikan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Cek yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Mohon buatkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 14?
A: 1.

Q: Mohon buatkan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 9 ditambah 2?
A: 11.

Q: Buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 4?
A: 40.

Q: Berapa 14 ditambah 9?
A: 23.

Q: Berapa 10 dikali 16?
A: 160.

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Rapikan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 dikali 18?
A: 270.

Q: Perbaiki yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?
