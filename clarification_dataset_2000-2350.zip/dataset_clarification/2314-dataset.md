# Dataset Clarification — 2314

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Sesuaikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berikan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Rapikan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ceritakan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Ubah yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Mohon buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Cek yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Analisis yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera perasa?
A: Lidah.

Q: Bikin yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Berapa 17 dikali 8?
A: 136.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Cek yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Analisis yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan energi?
A: Joule.

Q: Pilihkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 3 ditambah 10?
A: 13.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Mohon buatkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Analisis yang sederhana.
A: Tentu. Konteksnya seperti apa?
