# Dataset Clarification — 2135

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Tolong buat yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Pilihkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Cari yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Cari seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Ubah hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikurangi 8?
A: 6.

Q: Buatkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 ditambah 6?
A: 17.

Q: Berapa 8 dikali 12?
A: 96.

Q: Perbaiki yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikurangi 18?
A: 0.

Q: Berapa 17 dikurangi 11?
A: 6.

Q: Perbaiki yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 19 dikali 14?
A: 266.

Q: Ubah yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 ditambah 7?
A: 12.

Q: Sesuaikan yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Jelaskan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 ditambah 10?
A: 20.

Q: Berapa 11 dikurangi 10?
A: 1.

Q: Kasih yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 2 dikali 19?
A: 38.

Q: Berapa 3 dikurangi 1?
A: 2.

Q: Mohon buatkan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berikan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 6 dikali 16?
A: 96.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Mohon buatkan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 18 dikali 19?
A: 342.

Q: Berapa 19 dikurangi 7?
A: 12.

Q: Berapa 2 dikali 9?
A: 18.

Q: Berapa 18 dikali 13?
A: 234.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Analisis hal itu.
A: Bisa. Untuk tujuan apa?
