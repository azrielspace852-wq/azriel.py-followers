# Dataset Clarification — 2267

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Tampilkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Rapikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Hitung yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikurangi 11?
A: 9.

Q: Saya butuh yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 14?
A: 25.

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 ditambah 10?
A: 19.

Q: Berapa 11 ditambah 6?
A: 17.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Buatkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Tampilkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Jelaskan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikurangi 4?
A: 0.

Q: Berapa 18 ditambah 10?
A: 28.

Q: Sesuaikan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikali 20?
A: 400.

Q: Perbaiki sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 ditambah 2?
A: 21.

Q: Berapa 17 ditambah 19?
A: 36.

Q: Ceritakan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Cek seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikali 1?
A: 18.

Q: Tampilkan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Analisis hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Saya mau yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 1 dikali 19?
A: 19.

Q: Rapikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 dikali 10?
A: 170.

Q: Berapa 16 dikurangi 6?
A: 10.
