# Dataset Clarification — 2303

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Saya mau yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Hitung yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Tampilkan yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Mohon buatkan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang itu.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Ubah sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Bikin yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya mau yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Perbaiki yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Buatkan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Hitung yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Tampilkan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Berikan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Ubah yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.
