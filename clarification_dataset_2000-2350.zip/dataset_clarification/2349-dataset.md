# Dataset Clarification — 2349

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Berapa 10 dikurangi 1?
A: 9.

Q: Berikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 5?
A: 15.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 20 ditambah 18?
A: 38.

Q: Ubah yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 dikali 6?
A: 72.

Q: Berapa 4 ditambah 14?
A: 18.

Q: Berapa 7 dikali 14?
A: 98.

Q: Perbaiki yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikali 16?
A: 288.

Q: Cek yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 ditambah 3?
A: 18.

Q: Berapa 17 ditambah 19?
A: 36.

Q: Berapa 20 dikurangi 3?
A: 17.

Q: Berapa 16 ditambah 2?
A: 18.

Q: Sesuaikan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikurangi 3?
A: 4.

Q: Berapa 1 ditambah 15?
A: 16.

Q: Saya mau yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Berapa 10 dikurangi 9?
A: 1.

Q: Perbaiki yang sana.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dikali 20?
A: 120.

Q: Berapa 17 dikali 1?
A: 17.

Q: Berapa 20 dikali 16?
A: 320.

Q: Analisis yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Pilihkan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 5 dikali 7?
A: 35.

Q: Perbaiki yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikali 7?
A: 77.

Q: Berapa 7 ditambah 2?
A: 9.

Q: Buatkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikali 5?
A: 65.

Q: Rapikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang menarik.
A: Bisa. Untuk tujuan apa?
