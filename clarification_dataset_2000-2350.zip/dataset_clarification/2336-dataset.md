# Dataset Clarification — 2336

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 5 ditambah 11?
A: 16.

Q: Berapa 13 dikali 12?
A: 156.

Q: Berapa 15 dikurangi 12?
A: 3.

Q: Berapa 5 dikali 16?
A: 80.

Q: Berapa 10 dikurangi 4?
A: 6.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Tolong buat yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 15 dikali 17?
A: 255.

Q: Berapa 12 dikali 20?
A: 240.

Q: Hitung hal itu.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Cek seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 6?
A: 24.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Tampilkan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Kasih yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 dikali 18?
A: 108.

Q: Berapa 9 dikali 13?
A: 117.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Bikin yang keren.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 ditambah 6?
A: 10.

Q: Jelaskan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 14 ditambah 12?
A: 26.

Q: Berapa 10 dikurangi 5?
A: 5.

Q: Perbaiki yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Cari yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 14 ditambah 15?
A: 29.

Q: Tolong buat sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 13 ditambah 2?
A: 15.

Q: Jelaskan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Saya mau hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang menarik.
A: Siap. Yang mana yang dimaksud?
