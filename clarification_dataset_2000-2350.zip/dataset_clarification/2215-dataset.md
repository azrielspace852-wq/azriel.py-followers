# Dataset Clarification — 2215

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Sesuaikan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Tampilkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 ditambah 9?
A: 24.

Q: Bikin yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikurangi 4?
A: 12.

Q: Tolong buat yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Jelaskan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Perbaiki sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikurangi 6?
A: 12.

Q: Perbaiki yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 12 ditambah 5?
A: 17.

Q: Berapa 17 dikurangi 14?
A: 3.

Q: Jelaskan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikali 3?
A: 24.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Cek yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 18 dikurangi 7?
A: 11.

Q: Berapa 1 ditambah 14?
A: 15.

Q: Analisis yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dikurangi 3?
A: 5.

Q: Berapa 7 dikali 16?
A: 112.

Q: Berikan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 2 dikali 14?
A: 28.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 18 ditambah 3?
A: 21.

Q: Analisis yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Ubah yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Berikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Berapa 20 ditambah 15?
A: 35.

Q: Berapa 2 dikali 20?
A: 40.

Q: Pilihkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang ini.
A: Tentu. Yang mana yang Anda maksud?
