# Dataset Clarification — 2313

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Saya mau seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Analisis yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Hitung yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Perbaiki yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Pilihkan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Perbaiki yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Saya mau yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Hitung sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Tampilkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?
