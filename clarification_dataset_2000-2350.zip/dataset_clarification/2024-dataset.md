# Dataset Clarification — 2024

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Cari yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Apa nama indera perasa?
A: Lidah.

Q: Ubah yang itu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 8?
A: 9.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Cari yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Jelaskan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Cek yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Bikin yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Buatkan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Bikin yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Berikan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Sesuaikan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Jelaskan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Cek yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang keren.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berikan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ceritakan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?
