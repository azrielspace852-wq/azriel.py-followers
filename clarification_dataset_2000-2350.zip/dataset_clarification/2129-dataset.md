# Dataset Clarification — 2129

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Bikin yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 ditambah 17?
A: 33.

Q: Berapa 12 dikali 20?
A: 240.

Q: Hitung hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Bikin yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 10 dibagi 2?
A: 5.

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Saya butuh yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Cek yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Mohon buatkan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 dikali 1?
A: 7.

Q: Berapa 8 dibagi 4?
A: 2.

Q: Bikin yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 ditambah 13?
A: 20.

Q: Berapa 14 ditambah 6?
A: 20.

Q: Berapa 15 dikurangi 13?
A: 2.

Q: Jelaskan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Berapa 13 dikali 9?
A: 117.

Q: Berapa 13 ditambah 20?
A: 33.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Analisis yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Bikin yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Saya butuh seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 20 dikali 1?
A: 20.

Q: Ubah hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 5 dikali 7?
A: 35.

Q: Buatkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikurangi 5?
A: 4.

Q: Cari hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikali 18?
A: 144.

Q: Jelaskan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang itu.
A: Bisa. Untuk keperluan apa?

Q: Cari yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cocok.
A: Bisa. Untuk tujuan apa?
