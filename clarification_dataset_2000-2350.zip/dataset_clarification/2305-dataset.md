# Dataset Clarification — 2305

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berikan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 13?
A: 24.

Q: Saya mau yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Ubah sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Saya mau yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 90 dibagi 10?
A: 9.

Q: Buatkan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Berapa 6 ditambah 13?
A: 19.

Q: Cari yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 15 dikurangi 9?
A: 6.

Q: Tolong buat yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dikali 8?
A: 120.

Q: Tampilkan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Perbaiki yang pas.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 15 ditambah 1?
A: 16.

Q: Berapa 15 ditambah 9?
A: 24.

Q: Cek yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Saya mau yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Ubah yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 4 dikali 4?
A: 16.

Q: Cek yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 ditambah 17?
A: 19.

Q: Saya mau yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 ditambah 12?
A: 17.

Q: Berapa 14 dikali 19?
A: 266.

Q: Berapa 16 dikali 15?
A: 240.

Q: Berapa 20 dikali 6?
A: 120.

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 2 ditambah 19?
A: 21.

Q: Jelaskan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dikali 20?
A: 320.
