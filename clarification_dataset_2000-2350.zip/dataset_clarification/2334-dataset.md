# Dataset Clarification — 2334

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 20 dikali 20?
A: 400.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Hitung yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 ditambah 15?
A: 29.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Saya mau yang pas.
A: Bisa. Untuk keperluan apa?

Q: Tampilkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Ceritakan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Saya butuh yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Hitung yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Analisis sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Saya butuh yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Cek seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Sesuaikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Buatkan seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berapa 20 dikurangi 11?
A: 9.

Q: Berapa 13 ditambah 15?
A: 28.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Berikan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Mohon buatkan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Bikin yang murah.
A: Bisa. Untuk tujuan apa?

Q: Ubah yang ini.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.
