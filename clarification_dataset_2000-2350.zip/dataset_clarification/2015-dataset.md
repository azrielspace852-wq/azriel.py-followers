# Dataset Clarification — 2015

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 18 ditambah 3?
A: 21.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Cek yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikurangi 7?
A: 11.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Kasih seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 ditambah 9?
A: 16.

Q: Berapa 13 ditambah 2?
A: 15.

Q: Bikin yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 17?
A: 204.

Q: Cari yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 20?
A: 28.

Q: Cek yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 7 ditambah 4?
A: 11.

Q: Ceritakan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Cari hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 dikali 1?
A: 2.

Q: Kasih yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 ditambah 12?
A: 24.

Q: Berapa 11 ditambah 19?
A: 30.

Q: Ceritakan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dikali 8?
A: 96.

Q: Kasih yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 ditambah 5?
A: 11.

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Berapa 20 dikali 19?
A: 380.

Q: Berapa 12 ditambah 12?
A: 24.

Q: Jelaskan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Mohon buatkan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 10 dikali 3?
A: 30.

Q: Buatkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tampilkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 8 dikali 19?
A: 152.

Q: Berapa 1 ditambah 13?
A: 14.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Tolong buat yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 ditambah 3?
A: 13.

Q: Berikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Cek seperti biasa.
A: Bisa. Untuk keperluan apa?
