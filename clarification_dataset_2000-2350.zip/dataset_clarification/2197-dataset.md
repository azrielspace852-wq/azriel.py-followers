# Dataset Clarification — 2197

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikurangi 8?
A: 7.

Q: Berapa 7 ditambah 2?
A: 9.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Rapikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Berapa 3 dikali 7?
A: 21.

Q: Berapa 4 ditambah 1?
A: 5.

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 7 dikurangi 2?
A: 5.

Q: Jelaskan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 ditambah 13?
A: 16.

Q: Berapa 10 ditambah 5?
A: 15.

Q: Cek yang murah.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Bikin yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dikurangi 14?
A: 0.

Q: Cek yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikali 7?
A: 112.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Pilihkan yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikurangi 16?
A: 2.

Q: Tolong buat yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 4 ditambah 12?
A: 16.

Q: Cari yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 19 dikali 3?
A: 57.

Q: Bikin yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikurangi 7?
A: 3.

Q: Saya mau sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 ditambah 12?
A: 23.

Q: Tampilkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Tolong buat yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 ditambah 5?
A: 25.

Q: Tampilkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikali 1?
A: 14.

Q: Hitung yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 ditambah 18?
A: 27.

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Bikin yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?
