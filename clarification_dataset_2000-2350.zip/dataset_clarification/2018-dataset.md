# Dataset Clarification — 2018

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 7 ditambah 11?
A: 18.

Q: Perbaiki yang sana.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Berapa 12 dikurangi 7?
A: 5.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Cek yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 ditambah 8?
A: 19.

Q: Berapa 5 dikurangi 2?
A: 3.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Mohon buatkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 5?
A: 12.

Q: Berikan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 19 dikali 8?
A: 152.

Q: Berikan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 ditambah 9?
A: 28.

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Berapa 8 ditambah 10?
A: 18.

Q: Sesuaikan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikali 9?
A: 153.

Q: Berapa 19 dikali 18?
A: 342.

Q: Berapa 13 dikurangi 2?
A: 11.

Q: Ubah yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 ditambah 13?
A: 16.

Q: Perbaiki yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 ditambah 13?
A: 15.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Saya butuh yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Buatkan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 9 dikali 10?
A: 90.

Q: Bikin yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dikali 6?
A: 96.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 14 dikurangi 14?
A: 0.

Q: Jelaskan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Cek yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 14 dikurangi 8?
A: 6.

Q: Berapa 9 dikali 10?
A: 90.

Q: Saya butuh yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Berikan sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang pas.
A: Baik. Bisa dijelaskan lebih detail?
