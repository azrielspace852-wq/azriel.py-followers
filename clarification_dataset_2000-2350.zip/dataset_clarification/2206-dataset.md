# Dataset Clarification — 2206

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 dikurangi 3?
A: 2.

Q: Berapa 14 ditambah 7?
A: 21.

Q: Berapa 13 dikali 20?
A: 260.

Q: Pilihkan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikurangi 11?
A: 1.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Berapa 18 dikali 3?
A: 54.

Q: Saya mau yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikurangi 12?
A: 1.

Q: Analisis yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 dikurangi 2?
A: 1.

Q: Berapa 18 dikali 17?
A: 306.

Q: Ceritakan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 ditambah 4?
A: 21.

Q: Buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dikali 13?
A: 104.

Q: Berapa 7 dikurangi 7?
A: 0.

Q: Berapa 11 dikali 16?
A: 176.

Q: Berapa 17 ditambah 2?
A: 19.

Q: Berapa 13 dikali 8?
A: 104.

Q: Kasih yang murah.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 5 ditambah 4?
A: 9.

Q: Ubah yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikali 3?
A: 27.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 10 ditambah 2?
A: 12.

Q: Berapa 12 ditambah 13?
A: 25.

Q: Berapa 14 dikurangi 4?
A: 10.

Q: Perbaiki yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 8 dikurangi 7?
A: 1.

Q: Pilihkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 14 dikurangi 1?
A: 13.

Q: Berapa 4 ditambah 20?
A: 24.

Q: Ubah yang keren.
A: Tentu. Yang mana yang Anda maksud?
