# Dataset Clarification — 2248

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikali 16?
A: 304.

Q: Rapikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 10 dikurangi 2?
A: 8.

Q: Pilihkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dikurangi 15?
A: 3.

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Mohon buatkan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Berapa 8 dikurangi 8?
A: 0.

Q: Berapa 10 dikali 17?
A: 170.

Q: Berapa 16 ditambah 1?
A: 17.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Cari yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Bikin yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 ditambah 19?
A: 30.

Q: Berapa 10 ditambah 7?
A: 17.

Q: Sesuaikan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 12?
A: 20.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 20 ditambah 5?
A: 25.

Q: Hitung yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 ditambah 5?
A: 18.

Q: Tolong buat yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Berapa 14 dikurangi 10?
A: 4.

Q: Berikan yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 8 ditambah 9?
A: 17.

Q: Berapa 10 dikurangi 5?
A: 5.

Q: Bikin yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Tampilkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Berapa 14 dikali 16?
A: 224.
