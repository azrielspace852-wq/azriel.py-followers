# Dataset Clarification — 2067

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 13 dikali 19?
A: 247.

Q: Kasih seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 dikali 13?
A: 182.

Q: Sesuaikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 ditambah 16?
A: 19.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Jelaskan yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 2 ditambah 2?
A: 4.

Q: Kasih yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 ditambah 5?
A: 20.

Q: Berikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 3 dikali 14?
A: 42.

Q: Berapa 16 ditambah 7?
A: 23.

Q: Hitung yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikurangi 2?
A: 17.

Q: Cari yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 ditambah 14?
A: 31.

Q: Berapa 20 ditambah 4?
A: 24.

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berikan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang ini.
A: Bisa. Untuk tujuan apa?

Q: Berapa 3 dikali 10?
A: 30.

Q: Berikan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Cari seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 1 dikali 14?
A: 14.

Q: Berapa 16 dikali 8?
A: 128.

Q: Cari seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 ditambah 13?
A: 16.

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Berapa 12 ditambah 17?
A: 29.

Q: Berikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikurangi 1?
A: 11.

Q: Berapa 17 ditambah 1?
A: 18.

Q: Ubah yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 dikali 7?
A: 14.

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Cek yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Tampilkan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?
