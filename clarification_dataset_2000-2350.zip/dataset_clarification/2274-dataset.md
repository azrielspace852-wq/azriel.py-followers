# Dataset Clarification — 2274

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Buatkan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Cek yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Buatkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama indera perasa?
A: Lidah.

Q: Mohon buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Buatkan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Mohon buatkan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Tolong buat yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Analisis yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Rapikan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berapa 20 dikurangi 12?
A: 8.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berapa 20 ditambah 1?
A: 21.

Q: Sesuaikan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Saya butuh yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Cari sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berapa 13 ditambah 2?
A: 15.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.
