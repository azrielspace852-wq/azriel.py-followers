# Dataset Clarification — 2108

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tampilkan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 ditambah 19?
A: 34.

Q: Cek yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Sesuaikan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikurangi 7?
A: 2.

Q: Berapa 3 ditambah 6?
A: 9.

Q: Analisis yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 ditambah 16?
A: 18.

Q: Sesuaikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 6 dikurangi 3?
A: 3.

Q: Berapa 8 dikurangi 4?
A: 4.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 11 dikurangi 9?
A: 2.

Q: Mohon buatkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 ditambah 15?
A: 31.

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 dikali 6?
A: 78.

Q: Perbaiki yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Perbaiki yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 ditambah 3?
A: 5.

Q: Berapa 15 ditambah 12?
A: 27.

Q: Perbaiki yang sana.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 ditambah 13?
A: 21.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 19 ditambah 20?
A: 39.

Q: Mohon buatkan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 17 dikali 18?
A: 306.

Q: Pilihkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Berapa 4 dikali 16?
A: 64.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikali 7?
A: 133.

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Saya mau yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah hal itu.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang sana.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 ditambah 20?
A: 28.

Q: Tampilkan yang itu.
A: Siap. Maksudnya yang seperti apa?
