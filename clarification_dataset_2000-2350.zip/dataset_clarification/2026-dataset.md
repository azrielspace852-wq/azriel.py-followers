# Dataset Clarification — 2026

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 10 ditambah 20?
A: 30.

Q: Bikin sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 ditambah 17?
A: 33.

Q: Berapa 2 ditambah 9?
A: 11.

Q: Berikan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Mohon buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Berapa 18 dikali 2?
A: 36.

Q: Tampilkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cek seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 10?
A: 2.

Q: Jelaskan yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 ditambah 6?
A: 7.

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 16 ditambah 20?
A: 36.

Q: Perbaiki yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 20?
A: 180.

Q: Ceritakan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikali 12?
A: 216.

Q: Berapa 20 dikali 12?
A: 240.

Q: Berapa 19 ditambah 14?
A: 33.

Q: Hitung yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikurangi 11?
A: 0.

Q: Berapa 1 ditambah 7?
A: 8.

Q: Berapa 30 dibagi 5?
A: 6.

Q: Rapikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Ubah yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Kasih hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Berapa 19 dikali 2?
A: 38.

Q: Berapa 5 ditambah 6?
A: 11.

Q: Berapa 20 dikurangi 4?
A: 16.

Q: Saya mau yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 14 ditambah 5?
A: 19.
