# Dataset Clarification — 2175

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Cek yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 8?
A: 24.

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Saya butuh yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 12?
A: 7.

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 dikali 5?
A: 75.

Q: Ubah yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 ditambah 15?
A: 24.

Q: Rapikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Ceritakan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Ubah yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang murah.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Berapa 18 dikurangi 12?
A: 6.

Q: Berapa 4 ditambah 20?
A: 24.

Q: Berapa 17 ditambah 9?
A: 26.

Q: Ceritakan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 dikurangi 6?
A: 12.

Q: Saya mau yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 ditambah 15?
A: 32.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Mohon buatkan yang itu.
A: Siap. Tentang apa tepatnya?

Q: Buatkan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 3 dikurangi 3?
A: 0.

Q: Berapa 16 dikali 12?
A: 192.

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Berapa 11 dikali 1?
A: 11.

Q: Berikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 11 ditambah 8?
A: 19.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Sesuaikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 9 dikali 10?
A: 90.

Q: Berapa 11 dikali 16?
A: 176.

Q: Berapa 20 dibagi 4?
A: 5.
