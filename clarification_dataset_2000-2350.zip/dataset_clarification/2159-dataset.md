# Dataset Clarification — 2159

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Cek yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 2 dikurangi 2?
A: 0.

Q: Berapa 5 ditambah 4?
A: 9.

Q: Ceritakan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ubah yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 8?
A: 2.

Q: Cek seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Analisis hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 ditambah 10?
A: 24.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Tampilkan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 8 ditambah 9?
A: 17.

Q: Ubah yang cepat.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Saya mau yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 19 ditambah 7?
A: 26.

Q: Hitung yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 ditambah 17?
A: 26.

Q: Berapa 19 dikurangi 15?
A: 4.

Q: Berapa 2 dikali 14?
A: 28.

Q: Berapa 9 dikali 18?
A: 162.

Q: Jelaskan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 14?
A: 56.

Q: Bikin seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan yang sana.
A: Bisa. Untuk keperluan apa?

Q: Cari seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Pilihkan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Bikin yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 40 dibagi 4?
A: 10.

Q: Mohon buatkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 14?
A: 29.

Q: Kasih yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dikali 19?
A: 342.

Q: Berapa 12 dikali 4?
A: 48.

Q: Berapa 18 dikali 20?
A: 360.

Q: Analisis yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 ditambah 7?
A: 25.

Q: Ubah sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikali 5?
A: 85.
