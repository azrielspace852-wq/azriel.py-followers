# Dataset Clarification — 2254

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Hitung yang itu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ceritakan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Saya butuh yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Tolong buat seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Cek yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berikan yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Pilihkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Jelaskan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 dikali 1?
A: 18.

Q: Sesuaikan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Berikan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dikali 1?
A: 10.

Q: Apa nama indera perasa?
A: Lidah.

Q: Ceritakan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Pilihkan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 17 dikali 20?
A: 340.

Q: Rapikan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Perbaiki yang sana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Tolong buat yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Tolong buat yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Cek yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikali 17?
A: 51.

Q: Bikin yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 90 dibagi 10?
A: 9.

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan hal itu.
A: Bisa. Untuk tujuan apa?
