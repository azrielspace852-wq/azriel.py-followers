# Dataset Clarification — 2115

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 11 dikurangi 10?
A: 1.

Q: Kasih yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 16 dikali 9?
A: 144.

Q: Ceritakan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikurangi 15?
A: 5.

Q: Berapa 11 dikurangi 8?
A: 3.

Q: Ubah yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Berapa 10 dikali 3?
A: 30.

Q: Berapa 8 dikurangi 3?
A: 5.

Q: Mohon buatkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 9?
A: 10.

Q: Berapa 5 ditambah 15?
A: 20.

Q: Berapa 14 dikali 9?
A: 126.

Q: Berapa 8 dikali 1?
A: 8.

Q: Saya butuh yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 20?
A: 37.

Q: Perbaiki yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Kasih hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikali 4?
A: 48.

Q: Cek yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 20 ditambah 20?
A: 40.

Q: Berapa 17 ditambah 1?
A: 18.

Q: Berapa 3 ditambah 5?
A: 8.

Q: Berikan yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Cek yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Rapikan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 ditambah 15?
A: 33.

Q: Berapa 15 dikali 17?
A: 255.

Q: Sesuaikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dikali 13?
A: 208.

Q: Mohon buatkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 11 dikurangi 1?
A: 10.

Q: Berapa 3 dikali 6?
A: 18.

Q: Sesuaikan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang detail.
A: Siap. Yang mana yang dimaksud?
