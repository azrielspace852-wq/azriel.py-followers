# Dataset Clarification — 2244

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Cari yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera perasa?
A: Lidah.

Q: Ubah seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Berapa 11 dikali 19?
A: 209.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Saya butuh yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Analisis yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Rapikan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 8 dibagi 2?
A: 4.

Q: Perbaiki seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 20 dikali 1?
A: 20.

Q: Tolong buat yang keren.
A: Siap. Tentang apa tepatnya?

Q: Cek yang pas.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 14?
A: 14.

Q: Sesuaikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Berikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Sesuaikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Jelaskan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.
