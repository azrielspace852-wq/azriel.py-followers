# Dataset Clarification — 2307

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 7 ditambah 1?
A: 8.

Q: Saya butuh yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 dikali 18?
A: 234.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Kasih yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 dikali 11?
A: 121.

Q: Berapa 10 ditambah 12?
A: 22.

Q: Bikin yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Ubah yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikali 5?
A: 95.

Q: Berapa 1 dikali 3?
A: 3.

Q: Berapa 18 ditambah 12?
A: 30.

Q: Berapa 19 dikali 5?
A: 95.

Q: Tolong buat yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 9?
A: 8.

Q: Sesuaikan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Rapikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 18 dikali 3?
A: 54.

Q: Kasih yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 5 dikurangi 5?
A: 0.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Saya mau yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Berapa 4 ditambah 13?
A: 17.

Q: Saya mau yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 8 ditambah 14?
A: 22.

Q: Berapa 15 dikurangi 4?
A: 11.

Q: Cek yang ini.
A: Baik. Bisa dijelaskan lebih detail?
