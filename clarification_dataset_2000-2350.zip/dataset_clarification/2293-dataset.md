# Dataset Clarification — 2293

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Cari yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Tolong buat yang murah.
A: Bisa. Untuk keperluan apa?

Q: Ubah seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Saya mau yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Saya butuh yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Kasih sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Saya mau yang detail.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ceritakan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Analisis yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Analisis seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Cek sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Ubah hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Bikin hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang pas.
A: Tentu. Yang mana yang Anda maksud?
