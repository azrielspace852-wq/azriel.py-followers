# Dataset Clarification — 2178

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ubah yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikali 7?
A: 91.

Q: Berapa 9 dikali 12?
A: 108.

Q: Analisis yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 4 dikali 16?
A: 64.

Q: Berapa 18 dikali 5?
A: 90.

Q: Berapa 8 ditambah 18?
A: 26.

Q: Saya mau yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 9 dikali 7?
A: 63.

Q: Tolong buat yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 dikali 4?
A: 64.

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cari yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Ceritakan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 14 dikurangi 12?
A: 2.

Q: Pilihkan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berikan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Analisis seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Perbaiki yang itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dikali 9?
A: 144.

Q: Saya butuh yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 3 dikali 11?
A: 33.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Tolong buat yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikurangi 13?
A: 7.

Q: Saya butuh hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 ditambah 19?
A: 25.

Q: Rapikan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikali 5?
A: 60.

Q: Berikan yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 17 dikali 17?
A: 289.

Q: Saya mau yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 3?
A: 57.

Q: Berapa 7 ditambah 12?
A: 19.

Q: Bikin sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikali 2?
A: 14.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Ceritakan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berikan yang cocok.
A: Tentu. Konteksnya seperti apa?
