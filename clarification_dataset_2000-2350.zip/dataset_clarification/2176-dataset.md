# Dataset Clarification — 2176

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 2 dikali 8?
A: 16.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Tampilkan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 7 ditambah 7?
A: 14.

Q: Berapa 13 ditambah 6?
A: 19.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berikan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 18 ditambah 3?
A: 21.

Q: Ubah yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Berapa 3 dikali 2?
A: 6.

Q: Ubah yang itu.
A: Bisa. Untuk keperluan apa?

Q: Bikin hal itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Berikan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 dikali 14?
A: 252.

Q: Mohon buatkan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Hitung hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh hal itu.
A: Bisa. Untuk tujuan apa?

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikali 20?
A: 400.

Q: Berapa 12 dikali 12?
A: 144.

Q: Berapa 5 dikurangi 4?
A: 1.

Q: Kasih yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Berikan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Rapikan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 ditambah 16?
A: 27.

Q: Berapa 4 dibagi 4?
A: 1.

Q: Cek yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 ditambah 12?
A: 15.

Q: Berapa 16 dikurangi 16?
A: 0.

Q: Berapa 20 dikali 16?
A: 320.

Q: Perbaiki yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Pilihkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 15 ditambah 9?
A: 24.
