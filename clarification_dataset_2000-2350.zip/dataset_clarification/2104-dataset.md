# Dataset Clarification — 2104

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Jelaskan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Rapikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Rapikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Hitung yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Kasih yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 11 dikurangi 7?
A: 4.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Pilihkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berikan sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Pilihkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Cek yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Perbaiki yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang ini.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Tolong buat yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 17 dikali 4?
A: 68.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Saya mau hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berikan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 5?
A: 11.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Rapikan yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Pilihkan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Perbaiki yang bagus.
A: Siap. Yang mana yang dimaksud?
