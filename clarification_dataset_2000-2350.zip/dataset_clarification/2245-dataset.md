# Dataset Clarification — 2245

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Mohon buatkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 ditambah 18?
A: 28.

Q: Berikan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Hitung yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berikan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Mohon buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 20?
A: 220.

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 16 dikali 5?
A: 80.

Q: Berapa 17 ditambah 11?
A: 28.

Q: Rapikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 13 dikali 3?
A: 39.

Q: Bikin sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 ditambah 11?
A: 27.

Q: Sesuaikan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 1 dikali 18?
A: 18.

Q: Berapa 7 dikurangi 5?
A: 2.

Q: Tolong buat yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Cek sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 7 dikali 20?
A: 140.

Q: Berapa 2 dikali 2?
A: 4.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Berapa 9 dikali 18?
A: 162.

Q: Berapa 19 dikurangi 10?
A: 9.

Q: Ceritakan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 ditambah 12?
A: 27.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 10 ditambah 5?
A: 15.

Q: Tampilkan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Cari yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Jelaskan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Rapikan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 2?
A: 16.
