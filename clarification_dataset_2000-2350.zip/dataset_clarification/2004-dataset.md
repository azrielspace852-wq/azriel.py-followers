# Dataset Clarification — 2004

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Perbaiki yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Cari yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama indera perasa?
A: Lidah.

Q: Rapikan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Mohon buatkan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Perbaiki yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikurangi 3?
A: 10.

Q: Jelaskan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Saya butuh yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Pilihkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Perbaiki yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikali 15?
A: 195.

Q: Berapa 10 dibagi 2?
A: 5.

Q: Ceritakan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Ceritakan yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Berapa 20 ditambah 16?
A: 36.

Q: Bikin yang murah.
A: Siap. Tentang apa tepatnya?

Q: Saya butuh hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Saya mau sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Tolong buat yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama satuan energi?
A: Joule.

Q: Analisis yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 ditambah 7?
A: 12.

Q: Cari yang detail.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Ubah yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Kasih seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Berikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Hitung yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Mohon buatkan yang detail.
A: Tentu. Konteksnya seperti apa?
