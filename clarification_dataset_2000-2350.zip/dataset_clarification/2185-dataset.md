# Dataset Clarification — 2185

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Analisis yang keren.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 10?
A: 25.

Q: Cek hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 dikali 1?
A: 2.

Q: Berapa 5 ditambah 16?
A: 21.

Q: Berapa 19 dikali 17?
A: 323.

Q: Tampilkan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Cek yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 4 dikali 4?
A: 16.

Q: Berapa 2 dikali 12?
A: 24.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Tolong buat yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Cari yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Ceritakan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya mau yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 7 ditambah 8?
A: 15.

Q: Berapa 18 dikurangi 14?
A: 4.

Q: Berapa 10 dikali 2?
A: 20.

Q: Berapa 1 dikali 7?
A: 7.

Q: Berapa 1 ditambah 6?
A: 7.

Q: Cari yang sana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 dikurangi 1?
A: 2.

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Tolong buat seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Tampilkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 14 dikurangi 6?
A: 8.

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Kasih yang keren.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Tolong buat sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 ditambah 3?
A: 23.

Q: Berapa 12 dikurangi 5?
A: 7.

Q: Berikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 20 dikurangi 16?
A: 4.

Q: Berapa 14 dikurangi 14?
A: 0.

Q: Pilihkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 17 dikurangi 9?
A: 8.
