# Dataset Clarification — 2213

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cari hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Saya mau yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang sederhana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Ubah yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Perbaiki yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Saya mau yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang murah.
A: Bisa. Untuk tujuan apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Saya butuh hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Mohon buatkan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Analisis yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Saya mau yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Saya mau yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Ceritakan yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya mau yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Ubah yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Pilihkan yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Sesuaikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Sesuaikan yang ini.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.
