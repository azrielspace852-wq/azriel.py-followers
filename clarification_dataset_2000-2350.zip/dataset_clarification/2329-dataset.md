# Dataset Clarification — 2329

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Saya butuh sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikali 18?
A: 324.

Q: Ceritakan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 ditambah 10?
A: 26.

Q: Berapa 12 dikurangi 7?
A: 5.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 16 dikurangi 12?
A: 4.

Q: Kasih yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Analisis seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 15 ditambah 17?
A: 32.

Q: Berapa 9 ditambah 7?
A: 16.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Ceritakan sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 7 dikurangi 3?
A: 4.

Q: Berapa 2 dikali 11?
A: 22.

Q: Berapa 4 ditambah 15?
A: 19.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Tolong buat yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Jelaskan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 4 dikurangi 1?
A: 3.

Q: Perbaiki yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 17 dikurangi 12?
A: 5.

Q: Saya butuh yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikurangi 1?
A: 18.

Q: Berapa 13 ditambah 8?
A: 21.

Q: Berapa 7 dikurangi 4?
A: 3.

Q: Berapa 12 ditambah 4?
A: 16.

Q: Kasih yang sana.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 13 dikurangi 5?
A: 8.

Q: Buatkan yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 4 ditambah 4?
A: 8.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Ceritakan yang bagus.
A: Tentu. Konteksnya seperti apa?
