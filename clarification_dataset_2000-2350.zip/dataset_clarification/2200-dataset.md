# Dataset Clarification — 2200

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Apa gas yang paling banyak di atmosfer Bumi?
A: Nitrogen.

Q: Planet mana yang paling dekat dengan Matahari?
A: Merkurius.

Q: Berikan saran.
A: Tentu. Saran mengenai apa?

Q: Apa hasil dari 7 pangkat 2?
A: 49.

Q: Berapa jumlah sisi pada persegi?
A: 4.

Q: Berapa jumlah hari dalam seminggu?
A: 7.

Q: Apa nama bulan pertama dalam setahun?
A: Januari.

Q: Berapa lama?
A: Baik. Lama untuk apa?

Q: Cari yang terbaik.
A: Baik. Yang terbaik untuk keperluan apa?

Q: Apa nama hewan yang menghasilkan susu?
A: Sapi.

Q: Buat ringkasan.
A: Bisa. Ringkasan dari apa?

Q: Berapa jumlah kaki pada kucing?
A: 4.

Q: Ikuti saja.
A: Siap. Ikuti apa yang dimaksud?

Q: Apa ibu kota Thailand?
A: Bangkok.

Q: Apa nama minuman yang terbuat dari susu dan kopi?
A: Kopi susu.

Q: Apa nama sayuran hijau yang sering dibuat lalapan?
A: Selada.

Q: Kapan bisa?
A: Tentu. Kapan bisa untuk apa?

Q: Seberapa banyak?
A: Siap. Banyak dalam konteks apa?

Q: Berapa jumlah provinsi di Indonesia?
A: 38.

Q: Hitung dong.
A: Siap. Hitung apa yang dimaksud?

Q: Apa nama samudra terbesar?
A: Samudra Pasifik.

Q: Apa rumus luas persegi?
A: Sisi dikali sisi.

Q: Mana yang lebih baik?
A: Siap. Lebih baik antara apa?

Q: Jelaskan dengan singkat.
A: Baik. Jelaskan tentang apa secara singkat?

Q: Apa rumus keliling lingkaran?
A: 2 dikali pi dikali jari-jari.

Q: Tolong bantu.
A: Tentu. Membantu dalam hal apa?

Q: Buat yang pas.
A: Bisa. Yang pas untuk apa?

Q: Apa warna darah manusia?
A: Merah.

Q: Tolong jelaskan.
A: Baik. Jelaskan tentang apa?

Q: Apa hasil dari akar kuadrat 16?
A: 4.

Q: Berapa 5 dikali 3?
A: 15.

Q: Siapa yang dimaksud?
A: Siap. Siapa yang Anda tanyakan?

Q: Apa nama buah yang berwarna kuning dan panjang?
A: Pisang.

Q: Perbaiki.
A: Tentu. Perbaiki apa yang dimaksud?

Q: Bagaimana caranya?
A: Baik. Cara untuk melakukan apa?

Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?

Q: Cari yang murah.
A: Siap. Yang murah untuk apa?

Q: Organ apa yang digunakan untuk bernapas?
A: Paru-paru.

Q: Bikin yang keren dong.
A: Siap. Yang keren yang mana? Bisa diperjelas?

Q: Saya butuh bantuan.
A: Baik. Bantuan untuk apa tepatnya?

Q: Lakukan saja.
A: Baik. Lakukan apa yang dimaksud?

Q: Apa nama hari setelah Senin?
A: Selasa.

Q: Buat yang sederhana.
A: Tentu. Yang sederhana tentang apa?

Q: Bandingkan.
A: Tentu. Bandingkan apa dengan apa?

Q: Selesaikan.
A: Bisa. Selesaikan apa yang dimaksud?

Q: Apa nama alat untuk memotong kertas?
A: Gunting.

Q: Apa ibu kota Jepang?
A: Tokyo.

Q: Apa nama jari tengah pada tangan?
A: Jari tengah.

Q: Saya mau yang itu.
A: Baik. Yang mana yang dimaksud?
