# Dataset Clarification — 2065

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Berapa 1 dikali 9?
A: 9.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 16 ditambah 19?
A: 35.

Q: Saya mau seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dikali 3?
A: 24.

Q: Berapa 12 dikali 19?
A: 228.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 16 ditambah 12?
A: 28.

Q: Cari yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Rapikan sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Ubah seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 5 dikali 18?
A: 90.

Q: Berapa 1 dikali 18?
A: 18.

Q: Ubah yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 15 ditambah 4?
A: 19.

Q: Cari yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 14 dikurangi 13?
A: 1.

Q: Berapa 16 dikurangi 1?
A: 15.

Q: Saya butuh yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 ditambah 13?
A: 30.

Q: Saya mau yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Perbaiki yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 5 ditambah 19?
A: 24.

Q: Cek yang detail.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berikan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 9 ditambah 7?
A: 16.

Q: Ubah yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 20 dikali 19?
A: 380.

Q: Berapa 5 dikali 20?
A: 100.

Q: Hitung yang itu.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Sesuaikan yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Bikin seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Ceritakan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 dikali 19?
A: 342.
