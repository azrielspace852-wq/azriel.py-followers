# Dataset Clarification — 2210

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Mana yang lebih baik?
A: Siap. Lebih baik antara apa?

Q: Selesaikan.
A: Bisa. Selesaikan apa yang dimaksud?

Q: Apa hasil dari 7 pangkat 2?
A: 49.

Q: Apa rumus keliling lingkaran?
A: 2 dikali pi dikali jari-jari.

Q: Apa nama bulan pertama dalam setahun?
A: Januari.

Q: Saya butuh bantuan.
A: Baik. Bantuan untuk apa tepatnya?

Q: Seberapa banyak?
A: Siap. Banyak dalam konteks apa?

Q: Apa nama alat untuk memotong kertas?
A: Gunting.

Q: Apa gas yang paling banyak di atmosfer Bumi?
A: Nitrogen.

Q: Buat yang sederhana.
A: Tentu. Yang sederhana tentang apa?

Q: Apa nama sayuran hijau yang sering dibuat lalapan?
A: Selada.

Q: Perbaiki.
A: Tentu. Perbaiki apa yang dimaksud?

Q: Berapa jumlah provinsi di Indonesia?
A: 38.

Q: Cari yang murah.
A: Siap. Yang murah untuk apa?

Q: Apa warna darah manusia?
A: Merah.

Q: Apa ibu kota Thailand?
A: Bangkok.

Q: Berapa jumlah kaki pada kucing?
A: 4.

Q: Apa rumus luas persegi?
A: Sisi dikali sisi.

Q: Buat ringkasan.
A: Bisa. Ringkasan dari apa?

Q: Apa nama buah yang berwarna kuning dan panjang?
A: Pisang.

Q: Ikuti saja.
A: Siap. Ikuti apa yang dimaksud?

Q: Apa hasil dari akar kuadrat 16?
A: 4.

Q: Berapa lama?
A: Baik. Lama untuk apa?

Q: Bagaimana caranya?
A: Baik. Cara untuk melakukan apa?

Q: Hitung dong.
A: Siap. Hitung apa yang dimaksud?

Q: Bandingkan.
A: Tentu. Bandingkan apa dengan apa?

Q: Berapa jumlah sisi pada persegi?
A: 4.

Q: Tolong bantu.
A: Tentu. Membantu dalam hal apa?

Q: Apa nama minuman yang terbuat dari susu dan kopi?
A: Kopi susu.

Q: Buatkan yang bagus.
A: Bisa. Yang ingin dibuat apa?

Q: Apa nama jari tengah pada tangan?
A: Jari tengah.

Q: Berapa 20 dibagi 5?
A: 4.

Q: Saya mau yang itu.
A: Baik. Yang mana yang dimaksud?

Q: Tolong jelaskan.
A: Baik. Jelaskan tentang apa?

Q: Apa ibu kota Jepang?
A: Tokyo.

Q: Planet mana yang paling dekat dengan Matahari?
A: Merkurius.

Q: Jelaskan dengan singkat.
A: Baik. Jelaskan tentang apa secara singkat?

Q: Bikin yang keren dong.
A: Siap. Yang keren yang mana? Bisa diperjelas?

Q: Buat yang pas.
A: Bisa. Yang pas untuk apa?

Q: Organ apa yang digunakan untuk bernapas?
A: Paru-paru.

Q: Apa nama samudra terbesar?
A: Samudra Pasifik.

Q: Berapa jumlah hari dalam seminggu?
A: 7.

Q: Berapa 5 dikali 3?
A: 15.

Q: Berikan saran.
A: Tentu. Saran mengenai apa?

Q: Apa nama hewan yang menghasilkan susu?
A: Sapi.

Q: Cari yang terbaik.
A: Baik. Yang terbaik untuk keperluan apa?

Q: Lakukan saja.
A: Baik. Lakukan apa yang dimaksud?

Q: Apa nama hari setelah Senin?
A: Selasa.

Q: Siapa yang dimaksud?
A: Siap. Siapa yang Anda tanyakan?

Q: Kapan bisa?
A: Tentu. Kapan bisa untuk apa?
