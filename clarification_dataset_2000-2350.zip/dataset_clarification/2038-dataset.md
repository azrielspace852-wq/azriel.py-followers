# Dataset Clarification — 2038

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Berapa 9 ditambah 9?
A: 18.

Q: Mohon buatkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Berapa 19 dikurangi 8?
A: 11.

Q: Berapa 11 ditambah 6?
A: 17.

Q: Hitung yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Ceritakan yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Sesuaikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 10 dibagi 10?
A: 1.

Q: Kasih yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikurangi 2?
A: 13.

Q: Berapa 14 dikurangi 9?
A: 5.

Q: Berapa 16 dikali 19?
A: 304.

Q: Sesuaikan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 15 dikurangi 5?
A: 10.

Q: Bikin yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 ditambah 13?
A: 17.

Q: Berapa 8 dikali 16?
A: 128.

Q: Saya butuh yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 30 dibagi 10?
A: 3.

Q: Hitung yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 ditambah 18?
A: 28.

Q: Berapa 10 dikurangi 1?
A: 9.

Q: Tolong buat yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya mau yang itu.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 9?
A: 81.

Q: Tampilkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 11 ditambah 14?
A: 25.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Buatkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Cari yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikali 11?
A: 121.

Q: Berapa 17 dikali 17?
A: 289.

Q: Cari yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Berapa 4 ditambah 7?
A: 11.

Q: Sesuaikan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dikali 15?
A: 180.
