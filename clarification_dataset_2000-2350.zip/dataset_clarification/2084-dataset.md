# Dataset Clarification — 2084

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Bikin yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Perbaiki yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Hitung yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Analisis yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Berapa 4 ditambah 2?
A: 6.

Q: Pilihkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Bikin yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Cek yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Ubah yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 dikurangi 11?
A: 6.

Q: Sesuaikan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Hitung yang terbaik.
A: Tentu. Konteksnya seperti apa?

Q: Analisis yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama satuan energi?
A: Joule.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Jelaskan yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Tolong buat hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 5 dikali 16?
A: 80.

Q: Tampilkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berapa 20 dikurangi 10?
A: 10.

Q: Analisis yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Rapikan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Buatkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tampilkan yang menarik.
A: Tentu. Konteksnya seperti apa?

Q: Saya butuh sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?
