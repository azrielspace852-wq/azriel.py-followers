# Dataset Clarification — 2053

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Ceritakan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Bikin seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Cari yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Pilihkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Tampilkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Rapikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Perbaiki seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Buatkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Rapikan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Sesuaikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Analisis yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Saya mau yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Cek sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Ubah hal itu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Tolong buat yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Bikin yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Bikin sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Rapikan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Cari yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.
