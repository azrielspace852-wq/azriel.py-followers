# Dataset Clarification — 2218

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 1 dikali 4?
A: 4.

Q: Tampilkan sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Saya butuh sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 1?
A: 9.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Analisis yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikali 18?
A: 306.

Q: Cek yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 3 ditambah 1?
A: 4.

Q: Berapa 20 ditambah 10?
A: 30.

Q: Berapa 9 dikali 11?
A: 99.

Q: Berapa 18 ditambah 8?
A: 26.

Q: Mohon buatkan yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Tolong buat yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dibagi 2?
A: 3.

Q: Hitung yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikali 14?
A: 154.

Q: Ubah yang cocok.
A: Bisa. Untuk keperluan apa?

Q: Bikin yang ini.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Tolong buat sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Saya butuh yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 ditambah 17?
A: 30.

Q: Tolong buat seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 17 ditambah 6?
A: 23.

Q: Berapa 13 dikali 3?
A: 39.

Q: Rapikan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 dikurangi 3?
A: 9.

Q: Berapa 13 dikurangi 7?
A: 6.

Q: Analisis hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dikali 13?
A: 195.

Q: Perbaiki yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 dikurangi 6?
A: 5.

Q: Berapa 4 dikali 1?
A: 4.

Q: Berapa 16 ditambah 17?
A: 33.

Q: Saya butuh yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 ditambah 13?
A: 28.

Q: Analisis yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cari yang itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikali 18?
A: 126.

Q: Berapa 7 dikali 14?
A: 98.

Q: Berapa 9 dikurangi 6?
A: 3.
