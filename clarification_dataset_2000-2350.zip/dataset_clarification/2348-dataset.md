# Dataset Clarification — 2348

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tampilkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikali 3?
A: 60.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Perbaiki yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 2 dikurangi 1?
A: 1.

Q: Berapa 13 ditambah 9?
A: 22.

Q: Berapa 1 ditambah 5?
A: 6.

Q: Mohon buatkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Hitung yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 2 ditambah 19?
A: 21.

Q: Ceritakan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 dikali 18?
A: 36.

Q: Ubah yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan hal itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 dikurangi 11?
A: 3.

Q: Berapa 4 dikali 16?
A: 64.

Q: Berapa 12 dikurangi 4?
A: 8.

Q: Pilihkan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Berapa 13 dikali 19?
A: 247.

Q: Berikan yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Jelaskan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 ditambah 17?
A: 33.

Q: Tolong buat yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikali 3?
A: 30.

Q: Pilihkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Mohon buatkan yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Ubah yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Buatkan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 14 dikali 7?
A: 98.

Q: Berapa 20 dikurangi 18?
A: 2.

Q: Mohon buatkan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Pilihkan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 20 dibagi 2?
A: 10.

Q: Berapa 11 dikali 9?
A: 99.

Q: Ubah yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang murah.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 19 dikali 9?
A: 171.

Q: Tampilkan yang murah.
A: Siap. Tentang apa tepatnya?

Q: Pilihkan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Ubah yang menarik.
A: Bisa. Untuk tujuan apa?
