# Dataset Clarification — 2229

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Sesuaikan seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang cocok.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 7?
A: 3.

Q: Rapikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 2 dikali 20?
A: 40.

Q: Ubah yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Hitung yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 11?
A: 4.

Q: Berapa 9 ditambah 14?
A: 23.

Q: Rapikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berikan yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 7 dikali 7?
A: 49.

Q: Saya mau seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Ceritakan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Berapa 15 dikurangi 3?
A: 12.

Q: Pilihkan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 3 ditambah 13?
A: 16.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Sesuaikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 ditambah 14?
A: 18.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Buatkan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Cek yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Kasih yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Saya butuh yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 2?
A: 17.

Q: Berapa 3 dikali 7?
A: 21.

Q: Berapa 19 dikurangi 4?
A: 15.

Q: Berapa 30 dibagi 10?
A: 3.

Q: Rapikan yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 14 ditambah 8?
A: 22.

Q: Perbaiki yang cepat.
A: Bisa. Untuk keperluan apa?

Q: Hitung yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 dibagi 2?
A: 8.

Q: Buatkan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 ditambah 17?
A: 37.

Q: Saya butuh yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 19 dikurangi 5?
A: 14.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Berikan yang terbaik.
A: Siap. Yang mana yang dimaksud?
