# Dataset Clarification — 2299

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 19 dikali 18?
A: 342.

Q: Berapa 40 dibagi 5?
A: 8.

Q: Hitung yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 1 dikali 6?
A: 6.

Q: Rapikan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berapa 12 dikali 8?
A: 96.

Q: Ubah yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Berapa 9 dikali 3?
A: 27.

Q: Berapa 12 ditambah 1?
A: 13.

Q: Jelaskan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikali 11?
A: 165.

Q: Saya butuh yang sesuai.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikali 8?
A: 72.

Q: Berapa 20 dikurangi 8?
A: 12.

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Berapa 60 dibagi 10?
A: 6.

Q: Berapa 8 dibagi 2?
A: 4.

Q: Jelaskan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Buatkan seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Berapa 11 ditambah 19?
A: 30.

Q: Berapa 9 dikali 3?
A: 27.

Q: Kasih yang itu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dikali 20?
A: 400.

Q: Berikan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Sesuaikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Jelaskan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Jelaskan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Mohon buatkan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Tolong buat seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 ditambah 10?
A: 23.

Q: Berapa 12 dikurangi 10?
A: 2.

Q: Mohon buatkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau hal itu.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikurangi 2?
A: 4.

Q: Berapa 16 ditambah 2?
A: 18.

Q: Berapa 8 dikurangi 3?
A: 5.

Q: Tampilkan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikali 14?
A: 224.

Q: Analisis yang cepat.
A: Tentu. Konteksnya seperti apa?
