# Dataset Clarification — 2177

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 9 dikali 17?
A: 153.

Q: Ceritakan sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 1 dikurangi 1?
A: 0.

Q: Berapa 12 dikali 13?
A: 156.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Cari yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 ditambah 6?
A: 10.

Q: Hitung yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 4 dibagi 4?
A: 1.

Q: Pilihkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 19 dikurangi 13?
A: 6.

Q: Ubah yang murah.
A: Bisa. Untuk keperluan apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Rapikan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang sesuai.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Sesuaikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 19 dikali 14?
A: 266.

Q: Saya mau yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berikan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 10 dikali 5?
A: 50.

Q: Berapa 3 ditambah 3?
A: 6.

Q: Berapa 17 dikali 17?
A: 289.

Q: Berapa 9 ditambah 7?
A: 16.

Q: Analisis yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 dikali 19?
A: 38.

Q: Cek yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Berapa 4 ditambah 13?
A: 17.

Q: Bikin yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 2 dikali 19?
A: 38.

Q: Tolong buat yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 13 dikurangi 10?
A: 3.

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 16 dikurangi 7?
A: 9.

Q: Rapikan yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 11 dikurangi 5?
A: 6.

Q: Saya butuh yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Tampilkan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 ditambah 10?
A: 16.
