# Dataset Clarification — 2138

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikurangi 1?
A: 14.

Q: Tampilkan yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Berapa 5 dikali 11?
A: 55.

Q: Berapa 9 ditambah 18?
A: 27.

Q: Berapa 32 dibagi 4?
A: 8.

Q: Buatkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 15 ditambah 19?
A: 34.

Q: Mohon buatkan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 6 dikurangi 5?
A: 1.

Q: Berapa 3 ditambah 5?
A: 8.

Q: Berapa 15 dikali 3?
A: 45.

Q: Cek yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang cocok.
A: Siap. Yang mana yang dimaksud?

Q: Rapikan yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Kasih seperti biasa.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan hal itu.
A: Bisa. Untuk tujuan apa?

Q: Saya butuh yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 dikali 9?
A: 18.

Q: Ceritakan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Berapa 13 ditambah 9?
A: 22.

Q: Berapa 10 ditambah 17?
A: 27.

Q: Berapa 80 dibagi 10?
A: 8.

Q: Tolong buat yang terbaik.
A: Bisa. Untuk keperluan apa?

Q: Ubah yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 1 dikali 5?
A: 5.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Tolong buat yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 4 dikali 10?
A: 40.

Q: Perbaiki sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Saya mau yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Cari hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 18 ditambah 17?
A: 35.

Q: Berapa 45 dibagi 5?
A: 9.

Q: Hitung yang sana.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Bikin yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikali 20?
A: 280.

Q: Berapa 2 dikali 5?
A: 10.

Q: Berapa 20 ditambah 13?
A: 33.

Q: Rapikan seperti biasa.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Tolong buat yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?
