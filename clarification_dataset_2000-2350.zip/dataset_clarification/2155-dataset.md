# Dataset Clarification — 2155

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 20?
A: 26.

Q: Perbaiki yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 6 ditambah 7?
A: 13.

Q: Berapa 15 ditambah 12?
A: 27.

Q: Tampilkan yang bagus.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 ditambah 15?
A: 16.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 7 dikurangi 1?
A: 6.

Q: Ubah yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Tampilkan yang menarik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 dibagi 2?
A: 2.

Q: Berapa 20 dikurangi 9?
A: 11.

Q: Sesuaikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Berapa 6 ditambah 15?
A: 21.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Bikin yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Berapa 20 dikali 15?
A: 300.

Q: Berapa 12 dikurangi 8?
A: 4.

Q: Analisis yang murah.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang keren.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Saya butuh seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 20 dibagi 5?
A: 4.

Q: Sesuaikan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 40 dibagi 5?
A: 8.

Q: Sesuaikan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 9 dikali 1?
A: 9.

Q: Berapa 18 dikali 9?
A: 162.

Q: Berapa 28 dibagi 4?
A: 7.

Q: Rapikan yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 50 dibagi 5?
A: 10.

Q: Kasih yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang ini.
A: Bisa. Untuk keperluan apa?

Q: Berapa 18 dikurangi 3?
A: 15.

Q: Hitung yang pas.
A: Bisa. Untuk keperluan apa?

Q: Berapa 6 dikurangi 4?
A: 2.

Q: Berapa 40 dibagi 10?
A: 4.

Q: Berapa 1 ditambah 7?
A: 8.

Q: Berapa 3 dikali 15?
A: 45.

Q: Ubah yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 12 ditambah 19?
A: 31.

Q: Tolong buat yang murah.
A: Siap. Tentang apa tepatnya?
