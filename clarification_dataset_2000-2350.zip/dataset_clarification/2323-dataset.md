# Dataset Clarification — 2323

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Rapikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Sesuaikan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Kasih yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Ceritakan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang sesuai.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Ceritakan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Berikan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Saya mau yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan yang murah.
A: Bisa. Untuk tujuan apa?

Q: Jelaskan yang ini.
A: Bisa. Untuk tujuan apa?

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Analisis yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Tolong buat sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Cari yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Saya butuh yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Cari yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Cari yang menarik.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang ini.
A: Siap. Tentang apa tepatnya?

Q: Saya mau yang pas.
A: Siap. Tentang apa tepatnya?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Pilihkan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Perbaiki yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Hitung yang murah.
A: Siap. Tentang apa tepatnya?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Rapikan yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang terbaik.
A: Bisa. Untuk tujuan apa?
