# Dataset Clarification — 2201

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama pulau yang menjadi ibu kota sementara?
A: Kalimantan.

Q: Gabungkan.
A: Baik. Gabungkan apa dengan apa?

Q: Apa nama danau di Sumatera Utara yang terkenal?
A: Danau Toba.

Q: Apa nama bahasa resmi Indonesia?
A: Bahasa Indonesia.

Q: Buat outline singkat.
A: Siap. Outline singkat tentang apa?

Q: Apa nama ibu kota Spanyol?
A: Madrid.

Q: Buat timeline.
A: Bisa. Timeline untuk apa?

Q: Apa nama lagu kebangsaan Indonesia?
A: Indonesia Raya.

Q: Apa nama ibu kota Mesir?
A: Kairo.

Q: Berikan contoh.
A: Bisa. Contoh tentang apa?

Q: Buat tabel.
A: Siap. Tabel tentang apa?

Q: Jelaskan contoh.
A: Siap. Contoh yang mana?

Q: Apa nama gunung tertinggi di Indonesia?
A: Puncak Jaya.

Q: Tampilkan hasil.
A: Baik. Hasil dari apa?

Q: Apa nama pohon yang menjadi lambang negara?
A: Beringin.

Q: Apa nama pantai terkenal di Bali?
A: Kuta.

Q: Apa nama hewan endemik yang hanya ada di Sulawesi?
A: Anoa.

Q: Buat format.
A: Baik. Format untuk apa?

Q: Tampilkan daftar.
A: Bisa. Daftar tentang apa?

Q: Susun ulang.
A: Bisa. Susun ulang apa?

Q: Coba yang lain.
A: Siap. Yang lain yang seperti apa?

Q: Apa nama alat untuk melihat waktu?
A: Jam.

Q: Apa nama selat yang memisahkan Jawa dan Bali?
A: Selat Bali.

Q: Perkecil.
A: Baik. Perkecil apa?

Q: Apa nama ibu kota Tiongkok?
A: Beijing.

Q: Ada alternatif?
A: Bisa. Alternatif untuk apa?

Q: Sesuaikan warna.
A: Bisa. Warna untuk apa?

Q: Apa nama ibu kota Jerman?
A: Berlin.

Q: Buat diagram.
A: Baik. Diagram tentang apa?

Q: Buat rencana.
A: Baik. Rencana untuk apa?

Q: Apa nama candi Hindu terkenal di Jawa Tengah?
A: Prambanan.

Q: Sudah siap?
A: Siap. Siap untuk apa?

Q: Buat kerangka.
A: Bisa. Kerangka untuk apa?

Q: Apa nama pelabuhan utama di Jakarta?
A: Tanjung Priok.

Q: Apakah mungkin?
A: Baik. Mungkin untuk apa?

Q: Turunkan.
A: Siap. Turunkan apa?

Q: Apa nama ibu kota India?
A: New Delhi.

Q: Apa nama ibu kota Inggris?
A: London.

Q: Apa nama sungai terpanjang di Indonesia?
A: Sungai Kapuas.

Q: Apa nama hewan yang menjadi lambang negara?
A: Garuda.

Q: Kelompokkan.
A: Siap. Kelompokkan berdasarkan apa?

Q: Hapus yang itu.
A: Baik. Hapus yang mana?

Q: Apa nama bandara internasional di Jakarta?
A: Soekarno-Hatta.

Q: Kurangi sedikit.
A: Bisa. Kurangi apa yang dimaksud?

Q: Buat versi baru.
A: Siap. Versi baru dari apa?

Q: Apa nama alat untuk menghitung?
A: Kalkulator.

Q: Apa nama laut di selatan Jawa?
A: Samudra Hindia.

Q: Apa nama monumen di Jakarta yang terkenal?
A: Monas.

Q: Apa nama ibu kota Australia?
A: Canberra.

Q: Buat daftar tugas.
A: Siap. Daftar tugas untuk apa?
