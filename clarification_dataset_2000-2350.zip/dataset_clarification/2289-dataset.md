# Dataset Clarification — 2289

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 15 dikali 10?
A: 150.

Q: Rapikan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Mohon buatkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Tampilkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Ubah yang terbaik.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Ubah yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 14 ditambah 14?
A: 28.

Q: Berapa 17 dikali 3?
A: 51.

Q: Berapa 9 dikurangi 6?
A: 3.

Q: Berapa 5 ditambah 19?
A: 24.

Q: Cari yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Buatkan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 ditambah 17?
A: 20.

Q: Saya butuh yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 10 dikurangi 7?
A: 3.

Q: Analisis yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 8 dibagi 4?
A: 2.

Q: Berapa 10 dikali 7?
A: 70.

Q: Mohon buatkan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berikan yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Ceritakan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikali 1?
A: 20.

Q: Berapa 19 ditambah 9?
A: 28.

Q: Saya mau yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Berapa 11 dikali 6?
A: 66.

Q: Berapa 1 ditambah 5?
A: 6.

Q: Berapa 9 ditambah 14?
A: 23.

Q: Berapa 15 dikali 6?
A: 90.

Q: Berapa 10 dikurangi 1?
A: 9.

Q: Berapa 19 dikali 7?
A: 133.

Q: Bikin yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikali 15?
A: 135.

Q: Berapa 13 ditambah 18?
A: 31.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Ceritakan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berikan yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 11?
A: 5.

Q: Jelaskan hal itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Hitung yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Ubah seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 ditambah 8?
A: 22.

Q: Analisis yang menarik.
A: Tentu. Konteksnya seperti apa?
