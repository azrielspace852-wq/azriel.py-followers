# Dataset Clarification — 2258

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tolong buat yang sana.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang bagus.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikali 9?
A: 108.

Q: Tampilkan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 2 dikali 7?
A: 14.

Q: Hitung yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Kasih yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 32 dibagi 4?
A: 8.

Q: Berapa 15 dikali 11?
A: 165.

Q: Berapa 10 dikali 16?
A: 160.

Q: Berapa 1 ditambah 20?
A: 21.

Q: Buatkan hal itu.
A: Bisa. Untuk keperluan apa?

Q: Kasih seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang bagus.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 4 ditambah 1?
A: 5.

Q: Berapa 19 dikali 14?
A: 266.

Q: Kasih yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Ubah sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Berikan yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 100 dibagi 10?
A: 10.

Q: Berapa 12 ditambah 2?
A: 14.

Q: Berapa 40 dibagi 4?
A: 10.

Q: Pilihkan seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 16 dikurangi 3?
A: 13.

Q: Berapa 11 dikurangi 4?
A: 7.

Q: Saya mau yang terbaik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dikurangi 12?
A: 0.

Q: Ubah yang sana.
A: Bisa. Untuk keperluan apa?

Q: Analisis hal itu.
A: Bisa. Untuk keperluan apa?

Q: Rapikan yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berapa 17 dikurangi 3?
A: 14.

Q: Berapa 18 dikurangi 1?
A: 17.

Q: Berapa 11 ditambah 4?
A: 15.

Q: Berapa 1 ditambah 11?
A: 12.

Q: Ceritakan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikurangi 4?
A: 9.

Q: Berapa 1 dikali 16?
A: 16.

Q: Tolong buat yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 7 dikurangi 6?
A: 1.

Q: Berapa 9 dikurangi 5?
A: 4.

Q: Berapa 6 dikali 8?
A: 48.

Q: Perbaiki yang menarik.
A: Bisa. Untuk tujuan apa?
