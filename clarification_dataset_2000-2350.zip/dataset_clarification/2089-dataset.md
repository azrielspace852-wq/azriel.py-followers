# Dataset Clarification — 2089

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Perbaiki sesuatu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 6 dikali 6?
A: 36.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Rapikan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Saya mau yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 13?
A: 4.

Q: Berapa 1 dikali 2?
A: 2.

Q: Kasih yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Analisis yang detail.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikurangi 6?
A: 13.

Q: Berapa 16 dikurangi 5?
A: 11.

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berikan yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang pas.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Rapikan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Perbaiki sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 3 dikali 10?
A: 30.

Q: Berapa 19 ditambah 7?
A: 26.

Q: Hitung sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 15 dibagi 5?
A: 3.

Q: Cek yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berikan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 3 ditambah 3?
A: 6.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Mohon buatkan yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 12 dikurangi 2?
A: 10.

Q: Mohon buatkan yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 15 ditambah 4?
A: 19.

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berapa 5 ditambah 16?
A: 21.

Q: Jelaskan yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Hitung yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Berapa 5 dibagi 5?
A: 1.

Q: Berapa 12 ditambah 16?
A: 28.

Q: Perbaiki sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 17 ditambah 8?
A: 25.

Q: Saya butuh seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Jelaskan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 ditambah 13?
A: 21.

Q: Berapa 15 dikurangi 12?
A: 3.

Q: Berapa 13 dikali 8?
A: 104.

Q: Berapa 16 ditambah 2?
A: 18.
