# Dataset Clarification — 2034

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Cek yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Hitung yang cocok.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah yang itu.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang bagus.
A: Bisa. Untuk keperluan apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Berapa 6 dibagi 2?
A: 3.

Q: Saya butuh yang pas.
A: Bisa. Untuk keperluan apa?

Q: Cek yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Saya butuh yang detail.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 3 dikali 8?
A: 24.

Q: Cari yang itu.
A: Tentu. Yang mana yang Anda maksud?

Q: Bikin hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikali 15?
A: 255.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Tolong buat yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Bikin yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Sesuaikan seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Kasih yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Berapa 3 ditambah 8?
A: 11.

Q: Mohon buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Analisis sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Analisis yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Berapa 16 dikurangi 10?
A: 6.

Q: Hitung yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang cepat.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Mohon buatkan yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Bikin sesuatu.
A: Tentu. Yang mana yang Anda maksud?

Q: Ceritakan sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang cepat.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.
