# Dataset Clarification — 2345

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Buatkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 19 ditambah 10?
A: 29.

Q: Tolong buat yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Bikin yang itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 17 dikurangi 15?
A: 2.

Q: Cari yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Mohon buatkan yang itu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Hitung yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 1 dikali 16?
A: 16.

Q: Tolong buat yang detail.
A: Bisa. Untuk keperluan apa?

Q: Kasih yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 3 dikali 3?
A: 9.

Q: Berapa 20 dikurangi 14?
A: 6.

Q: Berapa 3 dikali 20?
A: 60.

Q: Berapa 6 dikali 11?
A: 66.

Q: Jelaskan yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang menarik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 20 dikurangi 17?
A: 3.

Q: Jelaskan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 2 dibagi 2?
A: 1.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Rapikan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 dikali 10?
A: 90.

Q: Bikin yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Kasih yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 9 dikurangi 2?
A: 7.

Q: Berapa 17 ditambah 11?
A: 28.

Q: Berikan hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 ditambah 19?
A: 20.

Q: Berikan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 5 dikali 7?
A: 35.

Q: Ubah yang pas.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Bikin yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dikurangi 5?
A: 5.

Q: Berapa 18 dikali 10?
A: 180.

Q: Jelaskan yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Bikin yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 30 dibagi 5?
A: 6.

Q: Berapa 15 dikurangi 12?
A: 3.

Q: Berapa 19 dikali 11?
A: 209.

Q: Berapa 2 dikurangi 2?
A: 0.

Q: Perbaiki seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 13 dikurangi 13?
A: 0.

Q: Berapa 9 dikurangi 4?
A: 5.

Q: Saya butuh yang menarik.
A: Baik. Bisa diperjelas apa yang dimaksud?
