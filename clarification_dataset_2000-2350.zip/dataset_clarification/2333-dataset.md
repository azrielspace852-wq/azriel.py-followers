# Dataset Clarification — 2333

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama sup khas Indonesia dari daging?
A: Soto.

Q: Saya mau yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Analisis yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Pilihkan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama minuman khas Indonesia dari santan?
A: Es cendol.

Q: Ubah seperti biasa.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Rapikan yang terbaik.
A: Siap. Maksudnya yang seperti apa?

Q: Ceritakan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Rapikan yang keren.
A: Siap. Tentang apa tepatnya?

Q: Apa nama makanan dari tahu yang digoreng?
A: Tahu goreng.

Q: Cari yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan sepeda?
A: Bersepeda.

Q: Analisis seperti biasa.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Cek seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama olahraga bela diri dari Jepang?
A: Karate atau Judo.

Q: Apa nama piala dunia sepak bola?
A: Piala Dunia FIFA.

Q: Apa nama bumbu dapur yang harum?
A: Bawang putih atau jahe.

Q: Jelaskan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama aplikasi ojek online yang populer?
A: Gojek atau Grab.

Q: Kasih yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama camilan dari singkong?
A: Keripik singkong.

Q: Apa nama organisasi pendidikan dan budaya dunia?
A: UNESCO.

Q: Apa nama makanan khas Jawa yang manis?
A: Gudeg.

Q: Apa nama bumbu dapur yang berwarna kuning?
A: Kunyit.

Q: Apa nama makanan khas Sulawesi?
A: Coto Makassar.

Q: Berikan yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Cek yang sederhana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama platform streaming film yang populer?
A: Netflix.

Q: Apa nama alat untuk memotong sayur?
A: Pisau.

Q: Apa nama buah yang berbiji banyak dan manis?
A: Manggis.

Q: Saya mau yang detail.
A: Siap. Maksudnya yang seperti apa?

Q: Hitung yang keren.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama olahraga yang menggunakan raket dan shuttlecock?
A: Bulu tangkis.

Q: Apa nama organisasi perserikatan bangsa-bangsa?
A: PBB.

Q: Apa nama olahraga yang dimainkan di lapangan rumput dengan 11 pemain?
A: Sepak bola.

Q: Apa nama olahraga bela diri dari Indonesia?
A: Pencak silat.

Q: Pilihkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama sayuran yang berwarna ungu?
A: Terong.

Q: Apa nama mata uang digital yang paling dikenal?
A: Bitcoin.

Q: Apa nama alat untuk memanggang?
A: Oven atau panggangan.

Q: Cek yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama alat masak untuk merebus?
A: Panci.

Q: Bikin yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Cek yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan massa dalam sistem metrik?
A: Kilogram.
