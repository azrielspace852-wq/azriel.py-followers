# Dataset Clarification — 2296

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Saya mau seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 13 ditambah 2?
A: 15.

Q: Tampilkan yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 1 dikali 10?
A: 10.

Q: Berapa 11 dikali 14?
A: 154.

Q: Mohon buatkan yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Sesuaikan yang sesuai.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Rapikan yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 12?
A: 132.

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 6 dikali 5?
A: 30.

Q: Jelaskan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 28 dibagi 4?
A: 7.

Q: Berapa 18 dikurangi 8?
A: 10.

Q: Tampilkan yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 17 dikurangi 6?
A: 11.

Q: Berapa 20 dikurangi 19?
A: 1.

Q: Berapa 16 dibagi 2?
A: 8.

Q: Perbaiki yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 15 dikurangi 12?
A: 3.

Q: Berapa 20 dibagi 10?
A: 2.

Q: Sesuaikan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Perbaiki yang detail.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Sesuaikan yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 12 ditambah 8?
A: 20.

Q: Analisis yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tolong buat yang cocok.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 2 ditambah 8?
A: 10.

Q: Kasih yang bagus.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 18 ditambah 6?
A: 24.

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Saya butuh yang sederhana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Tampilkan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis yang pas.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 6 ditambah 12?
A: 18.

Q: Saya butuh yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Ceritakan yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Berapa 11 ditambah 6?
A: 17.

Q: Rapikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 15 dikali 7?
A: 105.

Q: Berapa 16 dikurangi 8?
A: 8.

Q: Berapa 19 ditambah 3?
A: 22.

Q: Ceritakan yang itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Jelaskan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?
