# Dataset Clarification — 2224

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Saya mau yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Perbaiki yang murah.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama satuan energi?
A: Joule.

Q: Berapa 4 dikali 1?
A: 4.

Q: Mohon buatkan yang itu.
A: Bisa. Untuk keperluan apa?

Q: Cari yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Hitung yang ini.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 11 dikurangi 2?
A: 9.

Q: Perbaiki yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Tampilkan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Perbaiki yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Mohon buatkan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Analisis seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Jelaskan yang sesuai.
A: Siap. Maksudnya yang seperti apa?

Q: Berikan yang bagus.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 10 dibagi 5?
A: 2.

Q: Mohon buatkan yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Buatkan yang terbaik.
A: Bisa. Untuk tujuan apa?

Q: Sesuaikan yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Tampilkan yang sesuai.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Pilihkan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berikan hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Analisis seperti biasa.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 11 dikali 1?
A: 11.

Q: Kasih yang keren.
A: Bisa. Untuk tujuan apa?

Q: Tolong buat yang sesuai.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang terbaik.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Hitung yang bagus.
A: Tentu. Yang mana yang Anda maksud?
