# Dataset Clarification — 2187

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 11 dikali 7?
A: 77.

Q: Hitung yang sana.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 9 dikali 9?
A: 81.

Q: Berapa 17 dikurangi 17?
A: 0.

Q: Cek yang itu.
A: Siap. Yang mana yang dimaksud?

Q: Cek hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang itu.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang cepat.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang detail.
A: Bisa. Untuk tujuan apa?

Q: Cari yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Cek sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Analisis hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Buatkan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang cocok.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Saya butuh yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Tampilkan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 15 ditambah 3?
A: 18.

Q: Berikan seperti biasa.
A: Siap. Tentang apa tepatnya?

Q: Berapa 45 dibagi 5?
A: 9.

Q: Berapa 9 dikali 17?
A: 153.

Q: Berapa 20 dikurangi 7?
A: 13.

Q: Hitung yang ini.
A: Bisa. Untuk tujuan apa?

Q: Kasih yang detail.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 18 ditambah 9?
A: 27.

Q: Bikin yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 10 dikali 7?
A: 70.

Q: Berapa 8 dikurangi 4?
A: 4.

Q: Berapa 2 dibagi 2?
A: 1.

Q: Hitung yang bagus.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang menarik.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 12 dibagi 2?
A: 6.

Q: Pilihkan yang ini.
A: Siap. Tentang apa tepatnya?

Q: Mohon buatkan yang murah.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 16 ditambah 12?
A: 28.

Q: Berapa 8 dikurangi 1?
A: 7.

Q: Berapa 9 ditambah 8?
A: 17.

Q: Berapa 9 ditambah 13?
A: 22.

Q: Sesuaikan yang detail.
A: Bisa. Untuk keperluan apa?

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Berapa 7 ditambah 1?
A: 8.

Q: Buatkan yang sesuai.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Rapikan yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang itu.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Berapa 15 ditambah 4?
A: 19.

Q: Berapa 10 dibagi 5?
A: 2.

Q: Berapa 28 dibagi 4?
A: 7.
