# Dataset Clarification — 2174

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tolong buat yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya butuh sesuatu.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Bikin yang keren.
A: Bisa. Untuk keperluan apa?

Q: Berapa 4 dikurangi 2?
A: 2.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Cari hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama indera perasa?
A: Lidah.

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Tolong buat yang pas.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Cari yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 9 ditambah 15?
A: 24.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Saya mau yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Buatkan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Berapa 15 ditambah 15?
A: 30.

Q: Ceritakan yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Apa nama satuan energi?
A: Joule.

Q: Jelaskan yang sana.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Rapikan yang sesuai.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang ini.
A: Siap. Yang mana yang dimaksud?

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Bikin yang detail.
A: Bisa. Untuk keperluan apa?

Q: Saya mau yang ini.
A: Tentu. Yang mana yang Anda maksud?

Q: Berikan yang bagus.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Tolong buat yang pas.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Perbaiki yang cocok.
A: Siap. Tentang apa tepatnya?

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Ceritakan sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Kasih yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Saya mau yang bagus.
A: Siap. Tentang apa tepatnya?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Berapa 16 ditambah 13?
A: 29.

Q: Saya butuh hal itu.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Cek yang sana.
A: Tentu. Konteksnya seperti apa?

Q: Kasih yang sana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 16 dikurangi 10?
A: 6.
