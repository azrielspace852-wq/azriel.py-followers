# Dataset Clarification — 2037

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Berapa 8 dikurangi 6?
A: 2.

Q: Berapa 20 ditambah 2?
A: 22.

Q: Berapa 8 ditambah 2?
A: 10.

Q: Saya mau yang sana.
A: Siap. Maksudnya yang seperti apa?

Q: Buatkan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 12 dikali 10?
A: 120.

Q: Berapa 18 dikali 3?
A: 54.

Q: Sesuaikan yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Berapa 6 dikurangi 1?
A: 5.

Q: Berapa 20 dikurangi 15?
A: 5.

Q: Saya mau yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Berapa 14 dikurangi 11?
A: 3.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Analisis yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Analisis yang pas.
A: Siap. Maksudnya yang seperti apa?

Q: Saya mau yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek yang terbaik.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 80 dibagi 10?
A: 8.

Q: Ceritakan yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 16 ditambah 17?
A: 33.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Cek hal itu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Ubah seperti biasa.
A: Siap. Maksudnya yang seperti apa?

Q: Berapa 18 dibagi 2?
A: 9.

Q: Berapa 3 dikali 14?
A: 42.

Q: Berapa 20 dibagi 4?
A: 5.

Q: Ceritakan yang sana.
A: Siap. Tentang apa tepatnya?

Q: Hitung yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 14 dikurangi 2?
A: 12.

Q: Pilihkan yang detail.
A: Siap. Tentang apa tepatnya?

Q: Sesuaikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari yang cepat.
A: Siap. Yang mana yang dimaksud?

Q: Ceritakan yang terbaik.
A: Siap. Tentang apa tepatnya?

Q: Berapa 3 dikali 6?
A: 18.

Q: Berapa 2 dikali 12?
A: 24.

Q: Berapa 20 dikurangi 6?
A: 14.

Q: Berapa 6 dikali 6?
A: 36.

Q: Berapa 15 dikali 14?
A: 210.

Q: Kasih yang pas.
A: Bisa. Untuk tujuan apa?

Q: Berapa 16 dikurangi 14?
A: 2.

Q: Saya mau yang keren.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 6 dikali 19?
A: 114.

Q: Bikin sesuatu.
A: Siap. Maksudnya yang seperti apa?

Q: Sesuaikan hal itu.
A: Siap. Tentang apa tepatnya?

Q: Buatkan yang cocok.
A: Baik. Bisa diperjelas apa yang dimaksud?
