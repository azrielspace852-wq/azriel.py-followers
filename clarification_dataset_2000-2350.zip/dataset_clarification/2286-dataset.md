# Dataset Clarification — 2286

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Tampilkan yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Ubah seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 24 dibagi 4?
A: 6.

Q: Berapa 50 dibagi 10?
A: 5.

Q: Jelaskan yang sederhana.
A: Siap. Maksudnya yang seperti apa?

Q: Pilihkan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Hitung sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Jelaskan yang sederhana.
A: Tentu. Yang mana yang Anda maksud?

Q: Ubah sesuatu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 50 dibagi 10?
A: 5.

Q: Buatkan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Saya mau hal itu.
A: Baik. Bisa dijelaskan lebih detail?

Q: Analisis yang pas.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 19 dikali 2?
A: 38.

Q: Berapa 16 ditambah 10?
A: 26.

Q: Berapa 18 dikurangi 15?
A: 3.

Q: Ubah sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Berapa 16 dikurangi 9?
A: 7.

Q: Hitung yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Tolong buat yang menarik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 8 dikali 14?
A: 112.

Q: Ubah yang ini.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 4 ditambah 9?
A: 13.

Q: Berapa 8 ditambah 11?
A: 19.

Q: Buatkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 36 dibagi 4?
A: 9.

Q: Tampilkan yang ini.
A: Bisa. Untuk keperluan apa?

Q: Perbaiki yang menarik.
A: Siap. Tentang apa tepatnya?

Q: Ubah yang sederhana.
A: Siap. Tentang apa tepatnya?

Q: Berapa 2 ditambah 9?
A: 11.

Q: Berapa 8 ditambah 10?
A: 18.

Q: Berapa 3 dikali 1?
A: 3.

Q: Perbaiki yang cepat.
A: Bisa. Untuk tujuan apa?

Q: Analisis sesuatu.
A: Tentu. Konteksnya seperti apa?

Q: Mohon buatkan yang detail.
A: Bisa. Untuk tujuan apa?

Q: Berapa 18 dikurangi 5?
A: 13.

Q: Berapa 13 dikali 15?
A: 195.

Q: Berapa 12 ditambah 8?
A: 20.

Q: Saya mau yang detail.
A: Siap. Tentang apa tepatnya?

Q: Berapa 20 dibagi 4?
A: 5.

Q: Berapa 25 dibagi 5?
A: 5.

Q: Berapa 4 dikurangi 1?
A: 3.

Q: Buatkan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang murah.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Jelaskan yang cepat.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 13 dikurangi 1?
A: 12.

Q: Berapa 10 dikurangi 7?
A: 3.

Q: Berapa 10 ditambah 13?
A: 23.

Q: Berapa 10 dibagi 10?
A: 1.

Q: Berapa 10 ditambah 20?
A: 30.
