# Dataset Clarification — 2344

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Apa nama satuan waktu?
A: Detik, menit, jam.

Q: Apa nama tulang yang melindungi otak?
A: Tengkorak.

Q: Berapa 12 dibagi 4?
A: 3.

Q: Apa nama satuan arus listrik?
A: Ampere.

Q: Apa nama saraf yang menghubungkan otak dan tubuh?
A: Saraf tulang belakang.

Q: Apa nama satuan energi?
A: Joule.

Q: Buatkan yang keren.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama indera pendengaran?
A: Telinga.

Q: Cek yang cepat.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Kasih yang keren.
A: Tentu. Yang mana yang Anda maksud?

Q: Apa nama unsur kimia dengan simbol Ca?
A: Kalsium.

Q: Apa nama gas yang kita hembuskan saat bernapas?
A: Karbon dioksida.

Q: Ceritakan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Jelaskan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Apa nama unsur kimia dengan simbol Au?
A: Emas.

Q: Hitung seperti biasa.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol N?
A: Nitrogen.

Q: Cek yang sana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 19 dikali 13?
A: 247.

Q: Apa nama organ yang menyaring darah?
A: Ginjal.

Q: Apa nama satuan resistansi listrik?
A: Ohm.

Q: Saya butuh yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama sendi di lutut?
A: Sendi lutut.

Q: Apa nama unsur kimia dengan simbol Na?
A: Natrium.

Q: Apa nama proses pembakaran dalam tubuh?
A: Respirasi.

Q: Sesuaikan yang keren.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 17 ditambah 5?
A: 22.

Q: Perbaiki yang keren.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan hal itu.
A: Siap. Maksudnya yang seperti apa?

Q: Jelaskan yang murah.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Apa nama indera perasa?
A: Lidah.

Q: Berikan yang keren.
A: Bisa. Untuk tujuan apa?

Q: Berapa 1 ditambah 16?
A: 17.

Q: Ceritakan sesuatu.
A: Bisa. Untuk keperluan apa?

Q: Saya butuh yang sederhana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Bikin yang sesuai.
A: Bisa. Untuk tujuan apa?

Q: Apa nama unsur kimia dengan simbol O?
A: Oksigen.

Q: Cek yang sederhana.
A: Tentu. Konteksnya seperti apa?

Q: Rapikan yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Kasih sesuatu.
A: Siap. Tentang apa tepatnya?

Q: Berapa 13 dikurangi 8?
A: 5.

Q: Apa nama senyawa kimia garam dapur?
A: Natrium klorida.

Q: Saya mau yang sana.
A: Bisa. Untuk keperluan apa?

Q: Apa nama organ yang menghasilkan insulin?
A: Pankreas.

Q: Apa nama sel darah yang melawan infeksi?
A: Sel darah putih.

Q: Kasih yang cocok.
A: Tentu. Konteksnya seperti apa?

Q: Hitung hal itu.
A: Bisa. Untuk tujuan apa?

Q: Pilihkan yang menarik.
A: Bisa. Untuk keperluan apa?

Q: Buatkan yang murah.
A: Tentu. Yang mana yang Anda maksud?

Q: Perbaiki sesuatu.
A: Siap. Yang mana yang dimaksud?
