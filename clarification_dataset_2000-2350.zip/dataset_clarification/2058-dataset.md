# Dataset Clarification — 2058

# Kategori: Clarification
# Tujuan: Melatih model mengetahui kapan harus bertanya (klarifikasi) dan kapan tidak.
# Prinsip: Jika pertanyaan ambigu dan jawaban bergantung pada konteks, tanya. Jika jelas, jawab langsung.

Q: Kasih yang keren.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Analisis yang sederhana.
A: Siap. Yang mana yang dimaksud?

Q: Berapa 2 dikali 3?
A: 6.

Q: Perbaiki yang bagus.
A: Siap. Maksudnya yang seperti apa?

Q: Analisis yang ini.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 7 ditambah 19?
A: 26.

Q: Berapa 35 dibagi 5?
A: 7.

Q: Berapa 12 dikurangi 6?
A: 6.

Q: Cek sesuatu.
A: Siap. Yang mana yang dimaksud?

Q: Pilihkan yang pas.
A: Siap. Tentang apa tepatnya?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 14 dibagi 2?
A: 7.

Q: Berapa 4 ditambah 17?
A: 21.

Q: Cek yang ini.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 20 dikurangi 11?
A: 9.

Q: Mohon buatkan yang cocok.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cek seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Buatkan yang murah.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 35 dibagi 5?
A: 7.

Q: Kasih yang sederhana.
A: Bisa. Untuk tujuan apa?

Q: Berapa 14 dikali 2?
A: 28.

Q: Berapa 16 dikurangi 2?
A: 14.

Q: Ceritakan yang pas.
A: Bisa. Untuk keperluan apa?

Q: Ceritakan seperti biasa.
A: Bisa. Untuk keperluan apa?

Q: Berapa 20 ditambah 7?
A: 27.

Q: Berapa 5 ditambah 8?
A: 13.

Q: Berapa 20 dikurangi 1?
A: 19.

Q: Sesuaikan hal itu.
A: Siap. Yang mana yang dimaksud?

Q: Perbaiki yang cepat.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 11 ditambah 19?
A: 30.

Q: Analisis yang terbaik.
A: Baik. Bisa dijelaskan lebih detail?

Q: Berapa 13 dikurangi 5?
A: 8.

Q: Tampilkan yang menarik.
A: Bisa. Untuk tujuan apa?

Q: Berapa 17 dikurangi 4?
A: 13.

Q: Ceritakan seperti biasa.
A: Tentu. Konteksnya seperti apa?

Q: Berapa 11 dikali 12?
A: 132.

Q: Analisis yang murah.
A: Bisa. Untuk keperluan apa?

Q: Hitung hal itu.
A: Baik. Bisa diperjelas apa yang dimaksud?

Q: Berapa 16 dibagi 4?
A: 4.

Q: Perbaiki yang detail.
A: Siap. Yang mana yang dimaksud?

Q: Saya mau hal itu.
A: Bisa. Untuk tujuan apa?

Q: Berapa 70 dibagi 10?
A: 7.

Q: Berapa 4 dikali 3?
A: 12.

Q: Analisis yang detail.
A: Baik. Bisa sebutkan lebih spesifik?

Q: Berapa 1 ditambah 14?
A: 15.

Q: Berapa 14 dikurangi 3?
A: 11.

Q: Berapa 18 ditambah 1?
A: 19.

Q: Berapa 8 ditambah 1?
A: 9.

Q: Kasih yang sana.
A: Baik. Bisa dijelaskan lebih detail?

Q: Cari sesuatu.
A: Baik. Bisa sebutkan lebih spesifik?
