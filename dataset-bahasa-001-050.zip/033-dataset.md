Q: Bisa bedain 'ke' sama 'dari'?
A: 'Ke' menunjukkan arah tujuan, 'dari' menunjukkan asal.
Q: Contohnya?
A: Saya pergi ke sekolah. Saya datang dari rumah.
Q: Apa arti 'sedang'?
A: Sedang menunjukkan kegiatan yang sedang berlangsung.
Q: Bedanya dengan 'sudah'?
A: Sudah berarti kegiatan telah selesai.
Q: Kalau 'akan'?
A: Akan menunjukkan kegiatan yang belum terjadi.
Q: Bisa buat kalimat pakai ketiga itu?
A: Saya sedang makan. Saya sudah makan. Saya akan makan.
Q: Apa arti 'karena'?
A: Karena menunjukkan alasan.
Q: Contoh?
A: Saya diam di rumah karena hujan.
Q: Kalau 'meskipun'?
A: Meskipun menunjukkan kontras. Contoh: Meskipun hujan, saya tetap berangkat.
Q: Apa bedanya 'dan' sama 'atau'?
A: 'Dan' menggabungkan, 'atau' memilih salah satu.
Q: Contoh 'dan'?
A: Saya beli buku dan pensil.
Q: Contoh 'atau'?
A: Mau teh atau kopi?
Q: Apa arti 'jika'?
A: Jika menunjukkan syarat.
Q: Contoh?
A: Jika hujan, saya bawa payung.
Q: Kalau 'supaya'?
A: Supaya menunjukkan tujuan. Contoh: Saya belajar supaya pintar.
Q: Apa arti 'yang'?
A: Yang digunakan untuk menjelaskan atau merujuk.
Q: Contoh?
A: Buku yang di meja itu milik saya.
Q: Bedanya 'ini' sama 'itu'?
A: Ini dekat dengan pembicara, itu lebih jauh.
Q: Apa arti 'saya'?
A: Saya adalah kata ganti orang pertama.
Q: Kalau 'kamu'?
A: Kamu adalah kata ganti orang kedua.
Q: Bedanya 'dia' sama 'mereka'?
A: Dia satu orang, mereka lebih dari satu.
Q: Apa arti 'punya'?
A: Punya berarti memiliki.
Q: Contoh?
A: Saya punya buku.
Q: Kalau 'tidak punya'?
A: Saya tidak punya buku.
Q: Apa arti 'bisa'?
A: Bisa berarti mampu atau boleh.
Q: Bedanya dengan 'harus'?
A: Harus berarti wajib dilakukan.
Q: Contoh 'bisa'?
A: Saya bisa berenang.
Q: Contoh 'harus'?
A: Saya harus belajar.
Q: Apa arti 'ingin'?
A: Ingin berarti mempunyai keinginan.
Q: Bedanya dengan 'mau'?
A: Hampir sama, mau lebih sering dipakai sehari-hari.
Q: Apa arti 'suka'?
A: Suka berarti merasa senang terhadap sesuatu.
Q: Contoh?
A: Saya suka membaca.
Q: Kalau tidak suka?
A: Saya tidak suka menunggu.
Q: Apa arti 'baik'?
A: Baik berarti positif atau menyenangkan.
Q: Bedanya dengan 'bagus'?
A: Hampir sama, bagus lebih sering untuk benda atau hasil.
Q: Apa arti 'buruk'?
A: Buruk berarti tidak baik atau jelek.
Q: Contoh kalimat?
A: Cuaca hari ini buruk.
Q: Apa arti 'cepat'?
A: Cepat berarti dalam waktu singkat.
Q: Bedanya dengan 'lambat'?
A: Lambat berarti membutuhkan waktu lama.
Q: Apa arti 'tinggi'?
A: Tinggi berarti ukuran ke atas yang besar.
Q: Gue mau belajar bahasa.
A: Mau mulai dari dasar atau sudah punya pengalaman?
Q: Dasar.
A: Baik. Kita bisa mulai dari huruf, kata, lalu kalimat sederhana.
Q: Yang pertama apa?
A: Mulai dari mengenal huruf dan cara membacanya.
Q: Setelah itu?
A: Lanjut ke kata-kata dasar dan cara membentuk kalimat.
Q: Bisa kasih contoh kalimat sederhana?
A: Contoh: Saya pergi ke pasar.
