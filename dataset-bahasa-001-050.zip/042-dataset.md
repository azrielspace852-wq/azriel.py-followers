Q: Kalau lagi marah boleh kasar?
A: Lebih baik tetap menjaga nada, karena kata kasar bisa memperburuk situasi.
Q: Bagaimana kalau tidak mengerti pertanyaan?
A: Boleh meminta penjelasan ulang dengan sopan, misalnya 'Maaf, bisa diulang?'.
Q: Apa arti 'maaf' yang tepat?
A: Maaf digunakan untuk meminta maaf atau meminta perhatian dengan lembut.
Q: Bedanya 'permisi' sama 'maaf'?
A: Permisi untuk meminta jalan atau perhatian, maaf untuk mengakui kesalahan.
Q: Kapan harus bilang terima kasih?
A: Setiap kali menerima bantuan, informasi, atau kebaikan dari orang lain.
Q: Apa arti 'sama-sama'?
A: Jawaban sopan setelah orang mengucapkan terima kasih.
Q: Bagaimana cara menolak dengan sopan?
A: Bisa bilang 'Maaf, saya tidak bisa' atau 'Mungkin lain kali'.
Q: Apa arti 'tolong'?
A: Tolong digunakan untuk meminta bantuan.
Q: Bedanya dengan 'bantu'?
A: Tolong lebih sopan sebagai permintaan, bantu lebih langsung.
Q: Bagaimana cara bertanya tanpa menyinggung?
A: Gunakan kata-kata netral dan hindari tuduhan langsung.
Q: Contoh pertanyaan yang baik?
A: Bisa dijelaskan lebih detail tentang hal ini?
Q: Apa arti 'mohon'?
A: Mohon lebih formal daripada tolong, sering dipakai dalam surat atau situasi resmi.
Q: Kapan pakai 'silakan'?
A: Ketika menawarkan sesuatu atau mempersilakan orang melakukan sesuatu.
Q: Apa arti 'dengan senang hati'?
A: Menunjukkan kesediaan membantu dengan sukarela.
Q: Bagaimana cara memperbaiki salah ucap?
A: Bisa bilang 'Maaf, maksud saya ...' lalu perbaiki.
Q: Apa arti 'sebenarnya'?
A: Digunakan untuk menekankan fakta atau memperbaiki kesalahpahaman.
Q: Bedanya 'sebenarnya' sama 'sebetulnya'?
A: Hampir sama, keduanya untuk menekankan kebenaran.
Q: Bagaimana cara menyela percakapan dengan sopan?
A: Bisa bilang 'Maaf mengganggu' atau 'Boleh saya menambahkan?'.
Q: Apa arti 'ngomong-ngomong'?
A: Digunakan untuk menyisipkan topik baru secara alami.
Q: Kapan boleh ganti topik?
A: Setelah topik sebelumnya selesai atau jika lawan bicara setuju.
Q: Bagaimana cara kembali ke topik lama?
A: Bisa bilang 'Kembali ke yang tadi ...' atau 'Mengenai hal sebelumnya ...'.
Q: Apa arti 'omong kosong'?
A: Pembicaraan yang tidak berguna atau tidak benar.
Q: Bagaimana cara menanggapinya?
A: Lebih baik tidak membalas dengan nada yang sama, tetap tenang.
Q: Apa arti 'basi' dalam percakapan?
A: Cerita atau lelucon yang sudah sering didengar sehingga tidak menarik.
Q: Bagaimana cara bilang 'tidak tahu' dengan baik?
A: Bisa bilang 'Saya belum tahu' atau 'Saya tidak yakin'.
Q: Kenapa penting bilang tidak tahu?
A: Agar tidak memberikan informasi yang salah.
Q: Apa arti 'kira-kira'?
A: Menunjukkan perkiraan, bukan kepastian.
Q: Bedanya dengan 'pasti'?
A: Pasti menunjukkan keyakinan penuh.
Q: Bagaimana cara mengungkapkan keraguan?
A: Bisa bilang 'Sepertinya' atau 'Mungkin'.
Q: Apa arti 'sepertinya'?
A: Menunjukkan kesan atau dugaan berdasarkan informasi terbatas.
Q: Kapan harus minta klarifikasi?
A: Ketika pertanyaan atau pernyataan ambigu dan bisa disalahpahami.
Q: Contoh minta klarifikasi?
A: Maksudnya yang mana, A atau B?
Q: Apa arti 'ambigu'?
A: Bisa ditafsirkan lebih dari satu cara.
Q: Bagaimana cara menghindari ambiguitas?
A: Pilih kata yang tepat dan berikan konteks yang cukup.
Q: Apa arti 'implisit' lagi?
A: Tersirat, tidak dinyatakan langsung.
Q: Bedanya dengan 'tersurat'?
A: Tersurat berarti tertulis atau dinyatakan jelas.
Q: Bagaimana cara memahami yang tersirat?
A: Perhatikan konteks, nada, dan situasi pembicaraan.
Q: Apa arti 'nada' dalam percakapan?
A: Cara penyampaian yang menunjukkan perasaan atau sikap.
Q: Kenapa nada penting?
A: Karena nada yang sama dengan kata berbeda bisa mengubah makna.
Q: Bagaimana cara menjaga nada positif?
A: Pilih kata yang ramah dan hindari nada menyalahkan.
Q: Apa arti 'empati' dalam bicara?
A: Kemampuan memahami perasaan lawan bicara.
Q: Bagaimana cara menunjukkan empati?
A: Bisa bilang 'Saya mengerti perasaanmu' atau 'Pasti sulit ya'.
Q: Apa arti 'mendengarkan aktif'?
A: Mendengarkan dengan penuh perhatian dan memberi tanggapan yang sesuai.
Q: Kenapa penting mendengarkan dulu?
A: Agar jawaban yang diberikan benar-benar relevan.
Q: Bagaimana cara menutup percakapan dengan baik?
A: Bisa bilang 'Terima kasih sudah berbagi' atau 'Sampai jumpa'.
